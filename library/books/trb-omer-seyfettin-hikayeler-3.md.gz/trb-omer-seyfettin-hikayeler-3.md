# Primo Türk Çocuğu

Serin ve karanlık eylül gecesinin yıldızsız seması altında Selanik, sanki gündüzkü heyecanlardan, gürültülerden yorulmuş gibi, baygın ve sakin uyumaktadır. Rıhtım tenhadır. Olimpos Palas’ın, Kristal’in, Splandit Palas’ın, diğer küçük gazinoların lambaları çoktan sönmüştür. Tramvay yolunu tamir için yığılmış parke taşlarının ilersinde, denize inen küçük merdivenin başında, hareketsiz bir gölge dimdik durmaktadır. Gölgenin sahibi tahsilini Paris’te bitirip daha sonra dolgun bir maaşla İzmir’e giden ve orada aşık olduğu güzel bir İtalyan kızı olan Grazia ile evlenen genç mühendis Kenan Bey’dir. Kenan Bey Türklüğe, yani medeniyetsizliğe karşı olan garazi Avrupalılara, onların adetlerine, ananelerine, terbiyelerine, cemiyetlerine hayran olan ve bunları uygulayan kişiliği ile tanınmaktadır. Nazik ve şendir. Savaşa tamamen karşıdır. İşte bu gece Kemal Bey kırk sekiz saat boyunca işittikleri, gördükleri gazetelerde okuduklarının etkisindedir. Son derece rahatsızdır. Çünkü savaş çıkmıştır. İtalya Trablus’a saldırmıştır. Hayran olduğu, insaniyet hizmet ettiğine inandığı Avrupalıların önceden önem vermediği hatta bazen çok doğal bulduğu hareketleri aklına gelmektedir. İlk Fransa’yı hatırlar. Daima fazilete, insaniyete hizmet ettiğini haykıran bu millet, yüz senedir Afrika’yı kana boyamakta, masum, silahsız insanları öldürmekte onları esir edip hayatlarını, ruhlarını zapt etmektedir. Daha sonra İngilizleri düşünür ve İspanyolları, Almanları hatta Belçika ve Portekizlileri en sonunda da İtalyanları düşünür. Hepsi aynıdır. Kenan Bey yıllarca ruhunu zapteden bu toplumun, Avrupalıların naçiz bir kulu, hizmetçisi olduğunu düşündükçe kahrolmaktadır. Düne gelinceye kadar kendisine bile Türküm demeye sıkıldığını ve bu memlekette kendisi gibi tarihinin büyüklüğünü, mazisinin şerefini, dedelerinin şanını bilmeyen, inkar eden, milliyetinden uzak ve hatta utanan ne kadar Avrupalılaşmış renksiz olduğunu düşünerek yürür. Evine gitme düşüncesinden uzaktır. Şuursuz bir şekilde Splandi Palas’ın önüne gelir. Bir odaya çıkar ve yatağa uzanır. Yaşadığı olaylar onu şaşırtmış, mevcudiyetini perişan etmiştir. Hakaretin, tecavüzün, itisafın şiddetinden ansızın uyanan millet, İtalyan mektebinin, acentesinin, hastanesinin, hatta konsolosluğunun armalarını parçalamış, bayrak direklerini kırmış, sancaklarını yırtmıştır. Ne kadar İtalyan varsa şüphesiz kovulacaktır. İtalyan dostu görünecek bir Türk şüphesiz lanetler, nefretler, içinde tahkir olunacak, memleketten dışarı çıkarılacaktır. Başı ağrımakta başını arısından gözleri yaşarmaktadır. Yüzükoyun döner, gözünün önüne zevcesi, çocuğu, evi gelir. O hiç böyle bir günü düşünmemiş bu ana kadar mesut yaşamıştır. Avrupa'dan geldiği seneyi, gençlik ve bekarlık günlerini hatırlar. Bir İtalyan’la izdivaç etmek, hayatını birleştirmek ona doğal görünmüş, hatta iftihar edebilecek bir mümtazlık gibi gelmiştir. Gerçi Grazia ile evlenmek istediğinde Grazia’nın babası Kenen Bey’in Türk oluşundan dolayı bir barbar, bir medeniyet düşmanına kızını vermeyi şiddetle reddetmiştir. Daha sonra ise gerek kişisel menfaatlerini gerekse kızıyla yaptığı bir konuşma sonrasında Kenen Bey’i Rumeli ve Anadolu’da Türk namı altında yaşayan on yedi milyon Rum'dan biri olarak değerlendirir. Zira ona göre Türkiye’de sultanın ailesinden başka Türk bir familya yoktur. Bu düşünceler doğrultusunda Kenan Bey’i kızıyla birlikte hayallerinde Rum olarak kabul eder ve bu evliliğe izin verir. Kenan Bey’le Grazi’nin evliliklerinin ilk iki yılında iki erkek çocukları olmuştur. İtalyan adetlerini takip ederek çocuklarını numara ile çağırırlar. ‘Primo! Sekundo!’ Sekundo hastalanır ve ölür. Grazia’nın babası Mösyö Vitalis Meşrutiyetin ilanından sonra Türkiye’de işlerin iyi gitmeyeceğini düşünerek İtalya’ya gider ve çiftlik alarak oraya yerleşir.

Kenen Bey babasının Grazia’yı ve kendisini İtalya’ya çağıracağını düşünür, ne yapacaktır? Gitmeyeceği kesindir. Grazia’nın kendi tabiiyetini bırakmaya razı olup olmayacağı aklına gelir. Çocukları ve mutlu bir evlilikleri vardır. Birbirlerini çok sevmektedirler. Şakaklarından soğuk terler akmaya başlar. Mendiliyle yüzünü siler. Sabah olmaktadır, ayağa kalkar uyuyamamaktadır. Otelin kapısından çıkar, tramvaya biner ve yalısına gelir. Kapıyı hizmetçi kız acar. Grazia ve Premo evde yoklardır. İki yol sandığı dikkatini çeker. Grazia’nın yolculuğu düşündüğünü anlar. İlk defa görüyormuşçasına duvarlara , perdelere, eşyalara bakar. Türk hayatına Türk ruhuna ait bir gölge bir çizgi yoktur, birden Bursa’daki çocukluğunun geçtiği baba evini hatırlar. Merdiven başındaki, ceviz ağcından eski ve guguklu saati, yaldızlı kafesin içindeki sürekli öten kanarya kuşunu ve babasının odasını düşünür. Alçak sedirler ve kalın halılarla döşeli, vişne renginde perdeleri, duvarlarında asılı olan eğri ve altın kakmalı kılıçları, kamaları düşünür ve en önemlisi bu odadaki baş sedirin üstündeki etrafı ipekten ve sırmalı çevrelerle süslenmiş, mert bir Türk ruhundan saçılan iffet, namus, metanet, istiğna tavsiye eden mısraların yazılı olduğu levhayı hatırlar. Mısralardan bazıları aklına gelir.

‘Geçme namert köprüsünden, koparmasın seni!’

‘Korkma düşmandan, ki ateş olsa yandırmaz seni!’

‘Müstakim ol, Hazreti Allah utandırmaz seni!’

Babası ne kadar genç dururdu. Gelen misafirlerde, ağalarda ona benzerdi. Bu levha güya kalplerin, ahlaklarının tercümesiydi. Başı yeşil örtülü annesiyle daima yere bakan, omzunda hale gibi pembe bir atkı taşıyan mukaddes hemşiresini düşünür. Tahsilde iken annesi ve babası ölmüş, amcasının yanına giden hemşiresi de oranın yerlilerinden bir beyle evlenmiştir. Kendisi on senedir ne Bursa’ya gitmiş, ne akrabalarını görmüş, hatta mallarını bile İstanbul’dan gönderdiği bir vekil vasıtasıyla satmıştır. Kenan Bey düşünür, düşündükçe iki gündür farkına vardığı mevcudiyetinin aşağılığını, sefaletini, adiliğini anlar, unuttuğu milliyetinin kıymetini takdir edemediği esasları için acı bir matem duyar. Vicdan azapları içinde geçen yarım saat ona bir gün gibi görünmüştür. Kapı zili çalar. Grazia gelmiştir. Ona sabah aldığı kararı nasıl söyleyeceğinin sıkıntısı içindedir. Grazia Kenan Bey’e dün gece niye gelmediğini ve onu çok merak ettiğini söyler. Kenan Bey işi olduğunu ve bir otelde kaldığını söyler. Grazia ilan olunan harpten bahseder. Grazia sabah tercüman ile konuştuğunu hiç kimsenin bilmediğini, gazetelerin yazmadığı havadisleri öğrendiğini söyler. Avrupalılar aralarında Fransa’ya Fas’ı, Almanya’ya Anadolu’yu, İtalya’ya Trablus’u, İngiltere ve Rusya’ya da Acemistan’ı taksim etmişlerdir. Birkaç ay sonra Rumeli’nin her tarafında bombalar patlayacak, Girit Yunanistan’a bağışlanacak, Arnavutluk’a, Makedonya’ya, Suriye’ye, Arabistan’a muhtariyet verilecektir. Sultanlık Avrupalıların himayesine alınarak Türkiye’de de ‘Beynelmilel bir idare’ tesis olunacaktır. Avrupa’nın programı budur. Grazia bunları çabuk anlatır, tercümanın korkularını tekrar eder. Şimdi hükümet genç Türklerin elindedir. İki üç ay içinde Selanik’i terk edip İstanbul, İtalya ve yahut başka bir Avrupa memleketine gidilmelidir, pasaportları bile hazırlatmıştır. Grazia Kenan Bey’e ne zaman hareket edebileceklerini sorar. Kenan Bey buradan bir yere gitmeyeceğini söyler. Grazia inanamaz. Peki ben diye sorar. Sen de... bu sırada Primo içeri girer, yavaş yavaş yürümektedir. Annesi ona hiddetli ve sert bir tavırla önemli bir konu konuştuklarını söyleyerek dışarı çıkarır. Oysa primo olayların farkındadır. Çünkü sabah mektebe gitmemiş Rum çocuklarıyla rıhtımda balık tutmaya çalışırken mektep arkadaşlarından Orhan’ı görmüş ve yanındaki biraz büyükçe olan bir Türk çocuğuyla tanışmıştır. Bu bir Türk paşasının oğludur. Orhan Primo’ya sorar,

‘Senin baban Türk değil mi?’

Primo biraz kızararak ‘Niçin soruyorsun?’ der.

Soruyorum, neye inkar ediyorsun? Senin baban Türk mühendisi değil mi?

‘Evet...’

‘O halde sen de Türksün!...’

Primo Türkçe bilmemektedir. Orhan Fransızca olarak elindeki Genç Türklerin beyannamesini tercüme eder. İtalyanlarla Türklerin muharebe ettiğini anlatır. Anlatırken en cesur, en asil, en kavi bir millet olduğunu asırlarca bütün Asya’ya hakim olduklarını, Atilla’nın Avrupa’yı ezip, köpek gibi inlettiğini, dünyanın en büyük hükümetini Cengiz’in kurduğunu anlatır. Bir kaç asır evvel Avrupa’yı terbiye eden bu nesle, Osmanlı Türkleri’ne bütün Avrupalıların saldırdıklarını, mahvetmek için uğraştıklarını ama başarılı olamayacaklarını söyler. Türklerin eski deniz muharebelerinden vaktiyle Akdeniz’i bir Türk gölü yaptıklarını, büyük paşa babasından, mülazım ağabeyinden duyduğu şeyleri oldukça büyüterek, mübalağalaştırarak, uzun uzadıya hikâye etmektedir. Primo dinler ve o an kendisinin, babasının Türk oluşundan derin bir iftihar duyar. Rıhtımdaki Rum çocukları onun bir Türk çocuğu ile saatlerce konuşmasını kıskanırlar. Onu çağırırlar Primo aldırmaz. Orhan bu sineklerin bir şey yapamayacaklarını ancak taciz etmesini bildiklerini ve kendilerini rahat bırakmayacaklarını söyleyerek dışarı çıkmalarını tavsiye eder. Bahçeden çıkarlar, ileride İttihat ve Terakki kulübü önünde dehşetli bir kalabalık görürler. Kapının yanındaki parmaklık setine siyah esvaplı, sarı bıyıklı, küçük fesli bir adam çıkmış, namussuz, alçak, korsan İtalyanların haberleri yokken, araları iyiyken dostları iken birdenbire vatanlarına hücum ettiklerini anlatmaktadır. Onların büyük ve kavi zırhlılarına karşılık, kendilerinin de mukaddes bir hakları olduğunu bunun onların zırhlılarının karşısındaki kuvvetinden bahsetmektedir. Sonra bir telgraf okunur. Orhan onu tercüme eder. İtalyanların Trablus’ta iki harp gemisi kayalıklara çarparak batmıştır. Daha sonra nümayişçiler yukarılara doğru çekilmişlerdir. Primo kapının dibinde bunları düşünür. Dünün hatırasını noktası noktasına hayalinden geçirir ve göğsünün kabardığını hisseder.

Kapıya döner içeride şiddetli ve heyecanlı konuşma devam etmektedir. Anahtar deliğinden içeriyi dinler. Annesi burada kalmayacağını söyler Kenan Bey ise kalırsa artık İtalyan olarak değil Türk olarak kalacağını, gider ve İtalyan olarak kalırsa aralarındaki münasebetin biteceğini, kendisini boşayacağını ve görüşmemek üzere ayrılacaklarını söyler. Annesi yüz sene uzunluğunda geçen bir dakika sonunda cevabını verir. On seneyi, sadakatimi sen düşünmezsen ben hiç düşünmem babamın yanına gider orada rahibe olur kalırım der. Tek isteği Primo’yu da yanında götürmektedir. Kenan Bey bu kararı Primo’nun vermesi gerektiğini söyler. Annesi Primo’yu çağırır. Annesi içeri giren Primo’yu kucaklamak ister. Primo bunu dehşetli bir ciddiyetle reddeder. Grazia birdenbire değişen yavrusunun bu hareketi karşısında donar. Primo büyük bir adam tavrıyla babasının yanındaki koltuğa oturur. Başını eline dayar ve gayet garip bir şive ile Fransızca olarak beni niye çağırdınız der. İtalyanca söylemiyordur. Her ikisi de şaşırırlar. Kısa bir sessizlikten sonra Kenan Bey savaş çıktığını annesi ile tamamen ayrılacaklarını ya kendisi ile kalıp Türk olacağını ya da annesi ile gidip İtalyan olacağını söyler ve bu konudaki kararını sorar. Primo oturduğu yerden şiddetle fırlar Grazia ve Kenan Bey ne yapıyor diye birbirlerine bakarlar. Primo ellerini kalçalarına dayar, heyecanlı tavrıyla annesini ve babasını süzer ve gayet bozuk bir Türkçe ile ‘Ben... Turko çocuk... Ben yok İtalyano... Ben burda... Ben çocuk Türk...’ diye haykırır. Grazia hayret ve teessüründen masanın yanındaki sandalyeye yığılır. Kenan Bey gözlerine ve kulaklarına inanamamaktadır. Primo sonra seri bir hareketle kenardaki hasır sandalyeyi kaparak kanepeye fırlar ve şiddetle Victor Emmanuel’in resmine vurarak onu parçalar. Kenan Bey sevinçli ve şuursuz bir şekilde ayağa kalkar, kanepenin üzerinde, yükseklerden kendisine bakan bu Türk çocuğunu kucaklar onu göğsüne bastırır alnından öper.

# Rüşvet

Çarşı meydanının büyük çınar ağaçları, yere düşen gölgelerini alacalandırarak, fısıldıyorlardı. Kuvvetli bir rüzgâr esiyordu. Avukat Hacı Namık Efendi, kağıtlarım uçmasın diye, zümrüt bir kameriyeye benzeyen küçük dükkanının camlarını indirdi. Sonra gitti, açık kapıyı iterken heybesi omuzunda, semerli atının yuları elinde, sarıklı, kısa boylu yuvarlak bir köylünün yaklaştığını gördü:  
— Merhaba Ali Hoca, dedi, böyle vakistiz ne arıyorsun burada? Daha pazara iki gün var...  
Köylü, siyah sivri iki noktaya benzeyen mini mini gözlerini daha fazla küçülterek:  
— Aleyküm selam, Namık Efendi! Belaya düştüm. Bir dava için geliyorum...  
Diye başını salladı.  
— Ey, gel, biraz konuşalım bakalım.  
— Konuşalım.  
— Derdini anlat bana bakayım.  
— Senden başka zaten kime anlatacağım?  
Atının yularını peykenin destek direğine bağladı. Küçük dükkana girdi. Ceviz yazıhanenin sağındaki hasırlı alçak sedire oturdu. Heybesini yanına koydu. Namık Efendi'nin uzattığı tabakadan sigara sararken davasını anlattı. Hasmı, köyün muhtarı Huysuzoğlu'ydu. Ona ait bir arsanın üzerine Ali Hoca vaktiyle bir bina yaptırmıştı. Şimdi o, neden sonra bu binayı kabullenmeye kalkıyordu. Halbuki bina kimin ise, yerde onun demekti...  
Namık Efendi kır sakalını kaşıdı. Gözlüğünün üstünden bakarak:  
— Sen haksızsın Ali Hoca! dedi.  
— Haksız myım?  
— Evet.  
— Hayır, ben haklıyım. Neye binayı yaparken sesini çıkarmamış?  
— Çıkarmasın.  
— Ben haklı olduğumu biliyorum, Namık Efendi. Davadan vazgeçmem.  
— Kaybedeceksin!..  
— Edeyim, zararı yok. Ama davadan vazgeçmem.  
Namık Efendi haksız davaları alamazdı. Ali Hoca'nın vekâlet teklifini reddetmek istiyordu. Fakat, "Bozoyük" köyünün halkı otuz senelik müşterileriydi. Eşek, ahırını beller gibi onun dükkanını bellemişler, hükümetteki her işleri için ona müracaatı âdet edinmişlerdi. Kışlık zahîresi de hemen hemen tamamıyla oradan gelirdi. Nihayet:  
— Pekala, senin bu işine bakayım. Kaybedince bana darılmayacaksın! dedi.  
— Darılmam, ama neye kaybedeceksin?  
— Çünkü haksızsın.  
— Hâkime güzel bir koç göndersem?..  
— Ne?..  
— O vakit davayı kazanamaz mıyım?  
— O vakit hiç şüphesiz kayberdersin işte!..  
— Niçin?  
— Yeni hâkim senin bildiğin adamlardan değil...  
— ....  
Ali Hoca avukatının heyecanını anlayamıyordu. Ondan yeni hâkimin medhini uzun uzadıya dinledi. Bu zat rüşvetin, hediyenin korkunç bir düşmanıymış! En haklı bir davacı kendisine rüşvet vermeye teşebbüs etse, o saatte onu haksız çıkarırmış!  
Ali Hoca:  
— Allah böyle doğruları dünya yüzünden eksik etmesin!  
Diye dua etti. Namık Efendi:  
— Amin, amin!  
Dedi. Davaya, doğruluğa dair bir saat kadar konuştular. Vekâlet için anlaştılar. Avukat ümitsizdi. Bu işi hatır için alıyordu. Haksızlık o kadar meydanda idi ki...

İki hafta sonra, aynı saatte Ali Hoca, yeşil boyalı dükkanın kapısında göründü. Namık Efendi bir arzuhal yazıyordu. Gözlüğünün üstünden müşterisini görünce güldü:  
— Hoşgeldin be! Ne dersin, davayı kazandık!  
Dedi. Bu kadar haksız bir hükmü hâkimin nasıl verdiğine bir haftadır şaşıyordu. Ali Hoca soğukkanlı:  
— Benim gönderdiğim koç sayesinde kazandık! cevabını verdi.  
— Ne!.. Sen hâkime bir koç mu gönderdin?  
— Evet.  
— Buna cesaret ettin ha...  
— Evet, ama sen bana "Rüşvet düşmanıdır, kim hediye verirse haksız çıkar" dememiş miydin?  
— Evet.  
— Ben de koçu gönderirken kendi ismimi vermedim.  
— Ya ne yaptın?  
— Hasmım, muhtar Huysuzoğlu'nun ismini verdim.  
— !!!...  
İhtiyar avukatın kalem elinden düştü. Arkasına dayandı. Karşısında parlayan mini mini siyah gözlere bakakaldı. Meydandaki büyük çınar ağaçlarının derin fısıltıları, kapıda ayakta duran Ali Hoca'mn yanlarından, tepesinden, bacaklarının arasından giriyor, duvarlarına eski vilayet gazeteleri yapıştırılmış dükkancığın içini dolduruyordu...

# Tarih Ezeli Bir Tekerrürdür

Müverrih S... Bey'e mektup

Son makale-i tarihiyenizi büyük bir dikkatle okudum. Sizi bütün kuvvetimle, bütün maddiyetimle tasdik ederim. Gözlerini müstakbel-i na-mahduda dikip maziye asla ehemmiyet vermeyen bugünkü gençliğe güzel bir ders veriyorsunuz. Diyorsunuz ki:«Yeni bir şey yoktur. Her şey eskidir. Eskiden cereyan etmiş bir vak'anın hep esbap ve şerait1 dahilinde tekerrürüdür. Ulûm ve fünun bile eskidir. Meselâ fiziğin, tıbbın ilk kaideleri mazide vaz'olunmuş, yalnız bazı teferruatında keşfi-yat ve teceddüdat2 vukubulmuştur. Asırlarca evvel gelen Buda, bütün edyanın3 bütün felsefelerin, o yekahenk efsane-i hikmet ve faziletim teganni etmiş; sonrakiler, hattâ şimdikiler hep onun efkârını tekrar etmişlerdir» Ve okurken insanın samiasında beyaz, mütevarid4 dişlere çarparak feveran5 eden bir nutk-ı huruşanın galat hayalini uyandıran rasîn6 ve murassa7 ifadenizle hislerimizin; iyi ve fena; ve kavî memduh8 ve na-makbul fikirlerimizin yeni bir kis-bî9 olmayıp eskiden kalma olduğunu, hattâ sosyalizm ve anti-militarizm gibi gafletle yeni addolunan harekât-ı içtimaiyeti-nin bile pek eski olduğunu filozof Senegue'in ve ondan evvel gelenlerin esbabı ile ispat ediyorsunuz. Bu kıymetli, bu en doğru hakikatleri ihtiva eden altın satırları ihtimal bazı genç- 1- Şartlar 2- Yeni olma 3- Dinler 4- Birbirine yaklaşan 5- Kaynayıp fışkıran 6-  Güçlü 7- Süslü 8- Övülmeye değer 9- Yaradıllıştan olmayan ler, masum müstehzi bir gülüşle okudular. Onların fikirlerin-ce mazi mezardır, ölümdür, yokluktur. Tarih en can sıkıcı, en faydasız, mürteciane bir meşgaledir, köhneliktir. Ben de dört sene evvel tamamıyle böyle düşünüyordum. Hiç tarih okumamış, mektepte iken tarih derslerinde ya uyumuş, yahut meçhul istikbali tahayyül ederek muallimin saatlerce söylediklerini asla işitmemiştim. Tahsilimi ikmal ile hayata girdiğim vakit Kurunuvusta'nm nereden başladığım, HannibaPm kim olduğunu, hattâ Roma'mn kimler tarafından tesis edildiğini, İstanbul'u zapteden Fatih'in babasının hangi padişah olduğunu bilmiyordum. Fakat bugün?.. Sizin kadar malûmatım olduğunu iddia edemezsem de, bizim bütün tarih muallimlerimizden, hattâ bazı ihtiyar müverrihlerimizden pek çok tarihî mütalâalara malik bulunduğumu iftiharsız söyleyebilirim. Beş senedir hayatım yalnız tarih okumakla geçti. Büyük bir kütüphanem var ki, içinde tarihten başka kitap bulamazsınız. Eskiden san'at, edebiyat sevdasıyle tetebbu ettiğim meşhurları unuttum. Şimdi Michelet'den, Saint-Guillaume'dan, Lavaisse'den tutunuz de en mutavassıt10 müverrihlere11 kadar hepsini büyük bir zevk ile okuyorum. En ehemmiyetsiz an'aneler, hatıralar beni teshir ediyor. Artık P. Clement, F. Masson, J. Turquand, Loliee, P. de Nolhac, Dr. Cabanis en sevdiğim, en perestiş ettiğim muharrirler... Dünü okudukça, bugünün, yarının safhaları önümde perde perde açılıyor. Kendimde gayri ihtiyarî bir falcı ruhu hissediyorum. Şimdi gülüm-süyorsunuz değil mi? Karşımzda olsam soracaksınız ki: «Neye tarihe bu kadar merak ettin? Büyük bir müverrih, bir muallim mi olmak istiyorsun. Maksadın ne?» Evvela sizi temin edeyim ki, müverrih olmak niyetinde değilim, muharrir, muallim hiç... Bu merak bende marizî, ad verilmez ruhî bir halettir. Ben tesellisi mümkünsüz bir felâketin, intikamı alınamaz bir mağlubiyetin şaşırttığı bir ada 10-  Orta halde olan 11- Tarihçi mim. Ye'simi uyutmak için dimağımı tarih okumakla yoruyorum. Beş senedir sizinle tamamıyle hemfikirim: «Tarih ezeli bir tekerrürdür!» Ben bunu herkesten ziyade hissettim, yaşadım. İtmi'na-nım amelidir. Benim kadar tarihin feci, itisafkârane tükerrü-rünü gören yoktur sanırım. Tetebbu ile kısalan kıymettar zamanınızı suiistimal etmediğime emin olarak hikâyemi, kendi tarihimi, Milâttan evvel, sekizinci asırda cereyan etmiş bir vak'amn, haberim olmadan benim zavallı başımda nasıl tekerrür ettiğini size anlatacağım. Bu biraz mufassal olacak. Fakat rica ederim, tahammül edeniz. Binlerce kitapların tozlanmış sahifelerini süzen gözlerinizde harikulade bir kuvvet vardır. Bunu biliyorum. İlmî itikadınızı da tamamıyle, samimiyetle kabul etmekte ne kadar haklı olduğumu anlayacaksınız. Yedi sene evvel kavî, gürbüz kadınlara âşık, düşüncesiz bir genç idim. Edebiyatı, san'atı seviyordum. Her şey nazarımda bir fantezi, bir serap, bir rüya idi. Garp kitaplarının zaten şairlikle sarsılan müfekkiremde bıraktığı teşevvüşler, tezatlar eski nazariyelerimi tamamen tahrip ettiğine mukabil yeni bir şey öğretmemişti. Bütün o kitapları okuyanlar gibi ben de artık her şeyi inkâr eden, hiçbir şeye inanmaz, paradoksal, münasebetsiz bir herif olmuştum. Dünü tamamıyle unutuyor, yarını asla düşünmüyor; bugünü memnun, müsterih12 hayranlıkla geçiriyordum. İnkâr ettiğim şeylerin içinde aşk da vardı. Ona da bütün ahlâk kanunları, bütün içtimaî itikatlar gibi mevzu, mevhum bir yalan diyordum. Fakat Ef-ser'i -bu, boşadığım karımın adıdır- görünce fikrim değişmişti. O andan itibaren aşk, nazarımda yegâne hakikat oldu. Âlî, ruhanî, lâhutî13 bir hakikat... Ufak bir muaşaka14 devresi geçirdik. Vakıa ben de çirkin değildim. Fakat o... Size nasıl anlatayım? Bir harika idi. Uzunca bir boy, hayalin üstünde güzel bir çehre, mutlaka bir 12- Gönlü rahat olan 13- İlâhi 14- Karşılıklı aşk dahinin elinden çıkmış zannolunacak bir vücut tahayyül ediniz. O kadar muntazam, o kadar bediî, o kadar âlî ki, Venüs'ün en eski, cazip statüsü onun yamnda hasta, aciz kalır. Mübalâğa ediyorum sanıyorsunuz. Zararı yok, inanmayınız. Fakat ben eminim ki, Efser'deki esatiri güzelliğin böyle iki satırla yüzde birini ifade etmiş olmuyorum. Fakat size, yine biraz izahat vereyim; kayınpederimin babası güzel endamıy-le meşhur bir paşa, vaktiyle ihtida etmiş bir Macar'dı. Kayın-valdem eski gözdelerin en mümtazı olan bir Çerkez saraylı... Bunların kızı Efser, Macar - Çerkez güzelliğini, sıhhatini vücudunda toplamış, muhteşem, inanılmaz bir afet, nurdan, şeffafiyetten, esîrden masnu15 samlacak zihayat bir harika... İngiliz mektebinde tahsilini ikmal etmişti. Bütün orada tahsilini ikmal eden kızlar gibi biraz fazla ukalâ, nazariyeci, kendini beğenmişti. Benim İngilizce bilmememi sarih bir kusur olmak üzere kabul ederdi. Muallimleri hatırasında o kadar derin bir eser, o kadar garip bir intibaa bırakmıştı ki, tâ Amerika'ya gidenleriyle mektuplaşır, her hafta müdiresini ziyaret ederdi. «İzdivaç aşkın mezarıdır» Derler. İşte vahşiyane bir yalan! İzdivacımdan sonra onu o kadar çok sevmeğe başladım ki... Kadınlığa yakışmayacak ilmî, fennî meşguliyetlerini bile hoş görüyor, rasat dürbünlerini bizzat getiriyor, onun hoşuna gitmek için cahil, karanlık muhitimizde âlim şöhretini taşır adi, mutavassıt bir fizik muallimi olmadığıma teessüfler ediyordum. Arzusu üzerine Bağlarbaşı'nda bir köşk tutmuştuk. Yaz-kış orada oturuyorduk. Bir aşçımız, iki hizmetçimiz, on dört yaşında küçük bir uşağımız vardı. Ah, evimiz bir sevda yuvasıydı. Yatağımız ezelî bir aşk, huzuz lânesiydi. Efser orada asla İngiliz mektebinin ukalâ, münasebetsiz mezunu değildi. Yorganımızın altında lâtif, tatlı bir kadın, haris, mün-kat bir Çerkez kızıydı. Fecrin pembe nazarları odamızın mavi tül perdeleri arasından süzülürken bu sıcak yatağın haricinde geçecek bütün bir günü düşünerek mahzun olur, çılgın de-raguşlarla16 onu uyandırır, gözlerini buselerimle açar, şeffaf, dolgun göğsünün teravetli kokusunu sükûn bulmaz deliliklerimle massederdim17. Bir sene geçti. Aşkımız gittikçe teza-yüt ediyordu. Dünyada kitaplarıyle benden başka bir şey onu meşgul etmiyordu. Gündüzleri ben yokken okuyor, yazıyor; ben gelince hemen kucağıma atılıyor, geceleri pek erken girdiğimiz yatak odamızda ezelî aşk, perestiş saatleri yaratıyordu. Bu esnada İtalya'daki halazadem Ahmet Bidar İstanbul'a gelmişti. Bu, benden küçük, zayıf, narin bir çocuktu... Heykeltıraşlığa çalışıyordu. Uzun saçlarıyle, mütefekkir çehresiyle, nahif endamıyle lâtif, cazip, tam bir sanatkârdı. Eve getireceğimi, kendisine takdim edeceğimi Efser'e söyledim. Biraz hoşnutsuzlukla muvafakat etti. Fakat görünce, konuşunca memnun oldu. Bidar da sanatı icabı olarak eski Yunan, Roma tarihini tetebbu etmişti. Efser için bu pek büyük meziyetti. Tatil müddetini bizde geçirmesini teklif ettik. Israr ettik. Kabul etti. Artık yalnızlığımızdan bıkmağa başlıyorduk. Vaktimiz böyle daha hoş geçiyordu. Değişen bir baharın mü-teheyyiç geceleri muharrik rüzgânyle küçük salonumuzu doldururken üçümüz saatlerce sanata, tarihe dair musahabelere dalar, ben hep yatacak zamammızı düşünerek elleriyle cesim abidelerin hayalî şekillerini tersim ederek anlatan zevcemin bediî vücudunu derin derin temaşa ederdim. Yavaş yavaş yaz geçiyordu. Bidar'la Efser'in arasında fikrî bir uygunluğun hâsıl ettiği ihtiram. Meftunluk dikkatimi celbediyordu. Bidar pek saftı. Dimağında, henüz klasik malûmattan başka bir şey yer bulamamıştı. Namus hakkındaki iptidaî itikatlarından emin idim. Efser'e gelince, gördüğü İngiliz terbiyesi onu bir ahlâk statüsü haline ifrağ18 etmişti. Zev- 15- Sanat mahsulü 16- Kucaklama 17- Emmek 18- Bir şekle sokma ciyetin haricinde ihtiyar, çirkin bir Katolik mürebbiye kadar mutaassıp, afifti 19. Beraber geçirdiğimiz bir senelik hayatta nispeten beni bile kendine benzetmişti. Bekârlığımızdaki serbest fikirleri takip edemiyor, mecburen nazariyeci, mutekit, ahlâkî an'anelere riayetkar oluyor; en üzücü mutad vazifelere gayri ihtiyarî hürmet ediyordum. Yemek yerken, salonda otururken zevceme bakarak içimde yavaşça: «Ne mesudum; ne bahtiyarım!» Diyordum. Şüphesiz Efser dünyanın en güzel kadını idi. Bunu yalnız ben biliyordum. Muhitimiz umumî bir güzellik müsabakasına müsait değildi ki, herkes de takdir etsin: «Hakkın var, dünyanın en güzel kadım sana aittir.» Densin, ben de iftihar edeyim, saadetim tezauf etsin. Bana böyle bir güzellik harikası ithaf eden büyük, mukaddes tesadüfe teşekkürler edeyim. Evet, arkadaşlarımla konuşurken gayri ihtiyarî: «Benim zevcemi görseniz, dünyanın en güzel kadım olduğunu tastik edeceksiniz.» Diye haykırmak ister, zorla kendimi tutardım. Bir gün Bidar'ın yamnda idim. Kitaplarımı karıştırırken büyük bir albüm gördüm. Aldım, bakmağa başladım. Bu, vücut güzelliklerim mukayese eden binlerce çıplak kadın heykeli resimlerinden müteşekkil bediî bir mecmua idi. Kalın sa-hifelerini çevirdikçe Bidar yammda: «Filân heykeltıraşın, filân sanatkârın.» Diye tafsilât veriyor, yapılış tarihini, hangi müzelerde bulunduğunu, kimlerin malı olduğunu, her resim altındaki İtalyanca yazılan okuyarak, söylüyordu. Kadın güzelliğinin en gizli, en mahrem taraflarım ifşa eden bu çıplak statü resimlerine bakarken hep zevcemi düşünüyordum. Hiçbirisi onun kadar güzel değildi. En mütekâmil olmak üzere yapı-lanlannda bile sanki görünmez bir kusuru vardı. Azıcık daha 19- Namuslu Bidar'a: «Bunlann içinde Efser kadar güzeli var mı?» Diye soracaktım. Bana tamamıyle ondan geçtiğine kani olduğum bir hicap ile kendimi tuttum. Sanki bunu sorsaydım pek mukaddes, pek muhterem bir şeye küfretmiş olacaktım. Fakat fikrimi saklayarak, aklımda hiç Efser yokmuş gibi: -  Artık böyle vücutlar, böyle sırtlar, böyle kalçalar böyle kollar, böyle çehreler yalmz sanatkârların hayalhanelerinde mevcut Maatteessüf hakikatte yok! dedim. Bidar gözlerim bana kaldırdı. Tuhaf tuhaf baktı. Galiba biraz sarardı. Gülümsedi. Gayri ihtiyarî sordum: -  Neye baktın? -  Hiç! Dedi. Kızararak ilâve etti -  Çok nankörsün. Birden kalbim çarpmağa başladı. Mutlaka Efser'i telmih etmek istiyordu. Fakat ben alenen söyletmek istedim. İntikal etmemiş gibi sordum: -  Niçin? Cevap vermedi. Sahifeleri çeviriyor, başka resimlere bakıyordu. Mustarip olduğunu görüyordum. Yine ısrar ettim: -  Niçin, söyle, niçin nankörüm? Tekrar nafiz gözlerim bana çevirerek manasız bir gülüşle, bilinmez bir heyecanla, bozulmuş gayri muntazam bir taşkınlıkla cevap verdi: -  Evet, nankörsün. Niçin mi? İşte bunu bilmemekliğin de ikinci nankörlük. Talihin sana sebepsiz verdiği haksız bir mükâfatın kıymetini takdir edemiyorsun. Efser senin zevcen... Fakat güzelliği, harikulade güzelliği dikkatini celbet-memiş. Tetkik etmemişsin. Ona karşı lâkayıtsın. Hayret veren cinsî tekâmülünü görmüyorsun. Sonra şurada gördüğün ruhtan mahrum heykel resimlere bakarak: «Artık böyle vücutlar, böyle çehreler yalmz sanatkârlann hayallerinde mevcut, maatteessüf hakikatte yok...» diyor, karşıda parlayan bediî, vazıh güneşi inkâr ediyorsun. Devam ediyordu. Ben dinliyor, mahzuz oluyordum: Demek zevcemin harikulade güzelliği yalmz nisbî hodgâm bir duygum, bir vehmim değildi. Sanatın en yeni inceliklerine seri bir zekâ ile vakıf olan, güzellik hakkında fikrini söylemeğe en ziyade salâhiyettar, müsait bir mesleğin mensubu, onun emsalsiz güzelliğini, bana, zevcine gayri ihtiyarî itiraf ediyordu. Ben de açıldım. Bilmem kaç saat konuştuk. Bu uzun bir hasbihal oldu. Saçlarım, omuzlarım, belini, ayaklarını, ellerini, çehresini, gülüşlerini, bakışlarını, hâsılı her şeyini samimiyetle, heyecanla münakaşa ediyor, ben, birikmiş meftuniyetimi, peres-tişlerimi anlatırken o, kendi hayretinin, takdirinin benim duygularımdan on kat fazla, kuvvetli olduğunu iddia ediyordu... O esnada ikimiz birden, aralık kapıdan yüksek, muhteşem, Efser'i gördük. Koyu renkli esvabı pembe çehresine ifrat derecede bir parlaklık, hayalî bir ışık vermişti. -  İki saattir buraya kapandınız, diyordu. Neler konuşuyorsunuz? Nasıl Bidar Bey, hücumlara mı uğruyorsunuz?.. Ben, sanki ilk defa müşahede ettiğim bir peri imiş gibi onu derin, tarif edilmez hayvani istiğrak ile süzürken Bidar: -  Bugün fikirlerimiz muvafık çıktı, diye cevap veriyordu. Bugünkü mevzuda benim hakkımı o kadar teslim etti ki... -  Bilakis o benim hakkımı o kadar teslim etti ki... Efser ne konuştuğumuzu soruyordu. «Güzelliğe, sanata dair» dedik. Tafsilât istemedi. Önümüzdeki açık albüme baktı. Bir iki sayfa çevirdi. Birden kapayarak: -  Oh deşhet Yarabbi! dedi. Çıplaklar! Bunlardan şiddetle nefret ederim. Bilmem ki vahşetin, iptidaîliğin böyle iğrenç hatıralarını bazı insanlar nasıl sever? Bence ahlâkla, ilimle fena meyillerimizi, sevkitabiilerimizi nasıl örtüyorsak, kalın esvaplarla da vücudumuzu öyle örtmek icap eder. İnsan etinin tadına, lezzetine dair nasıl bugün bir şiir yazamı-yorsak, vahşî kavimlerin muhitini, hayatım yadettirecek böyle çıplak resimleri, hayâsız heykelleri sanatkârların nezih elleri için muvafık, meşru bir meşgale tanımamalıyız.. Artık Bidar benim mahremim olmuştu. O da Efser'in müstesna güzelliğini, dünyanın en güzel kadım olduğunu tasdik ediyordu. Ben yine tekrar ediyordum, asla kıskanmıyordum. Bilâkis iftihar ediyor, mahzuz oluyordum. Bir gece Efser, biraz başı ağrıdığından, erkence yatak odasına çekilmişti. Sıcak, yıldızlı, rüzgârsız bir gece idi. Uzaklardan tek bir bülbül öksüz öksüz haykırıyor, susuyor, yine başlıyor, tatlı, müheyyiç, devam ediyordu. Bidar'la balkonda idik. Efser'in rahatsızlığını konuşuyorduk. Yine güzelliğine intikal ettik. Bidar, her vakitkinden ziyade bir hararetle, meftuniyetle onu methediyor, ben hemen kalkıp yatak odasına geçmek, şedit, çılgın kucaklamalarla zevcemi göğsümde sıkmak ihtiyaçlarını duyuyordum. Bidar: -  Saadetin nisbî olduğunu herkes itikat eder, diyordu, ben bu nazariyeyi kabul etmem. Temin ederim ki sen dünyanın en mes'udusun. Çünkü servetle, güzellikle, asaletle, kuvvetle elde edilemeyecek bir şeyi talih sana takdim etmiş. Dinledikçe mahzuz oluyordum. Bilmem nasıl oldu, birdenbire bana bir fikir geldi. Düşünmedim, muhakeme etmedim, hemen söyledim: -  Haklısın Bidar. Fakat sen onun güzelliğinden yüzde birini görmedim. Yalnız benden işittin. Amma ben sana göstereceğim. Kulaklarına belki itimat etmiyor, söylediklerime inanmıyorsun. Gözlerinle görünce, mübalâğalarımın birer hakikat olduğuna hiç şüphen kalmayacak. Şaşkın, mütehayyir sordu: -  Fakat, nasıl? -  Nasıl mı? Sana Efser'i çırılçıplak göstereceğim. Evvelâ inanmadı. Yüzüme tuhaf tuhaf baktı. Sahi, ciddî söylediğimi anlayınca, şiddetle reddetti. Efser'e karşı beslediği ihtiram katiyen buna mani imiş... Ben meyus olmadım. Onu iknaa çalışıyordum. Gece yansı çoktan geçmiş, tek, öksüz bülbül susmuş, hafif çiçek kokuları getiren tatlı bir rüzgâr çıkmıştı. Onun heykeltıraşlığından, sanatından bahsediyor, bu kadar eflâtunî bir temaşayı ondan saklayacak kadar budala, mutaassıp olmadığını söylüyordum. O, reddetmekte devam ediyor: «Bu pek kelbî bir eflâtunîlik olacak!» Diye beni muaheze ediyor, o reddettikçe benim bu münasebetsiz garip arzum teşeddüt ediyordu. -  Cahilliği bırak, diyordum, senin gördüğünü o Hissetmeyecek, haberi olmayacak. Fakat sen bütün ruhunh4 onun müstesna güzelliğini tasdik edeceksin. Ben bunu istiyorum. Reddedersen, danlacağım. Sana âli bir sanatkâr değil, nefsine mağlûp, korkak bir şehvetperest diyeceğim... Uğraştım, uğraştım, Lâfımı uzattım. Adeta onu ahmak-laştırdım, nihayet kandırdım. Heyecandan sararmış: -  Fakat nasıl göstereceksin, onun haberi olmadan?.. Diye soruyordu. -  Pek basit, dedim. Bizim yatak odasımn kapısı arkasında yarım açılmış bir paravan vardır. Sana gündüzden gösteririm. Yann gece bahçeye çıkarız, geç vakte kadar kalırız. Sen rahatsızlığım bahane ederek, sözde yatmaya gidersin. Doğru git bu paravamn arkasına saklan. Tabiî biraz sonra yatmak için biz de geleceğiz. Evvelâ ben soyunurum. O pencerenin önündeki kanepede soyunur, yatağa gelir. Ben gömleğini de çıkarttırırım. Tamamıyle görürsün. Yatağa girerken sen yavaşça kapıdan çıkıverirsin. Katiyen hissetmez. Cesaret edemiyor: «Mümkün değil, mümkün değil.» diyordu. İzahata başladım. İzahatımı tafsil ettim. Söylediğim gibi hareket ederse, Efser'in kendini görmeyeceğine mutmain oldu. Yatmak için kalktık. Sapsarıydı. Ben odamıza gittim. Efser, yarı çıplak yüzükoyun yatmış, uyuyordu. Gidip Bi-dar'ı getirmek istedim. Ah, uyurken ne güzel olacaktı. Katiyen hissetmek ihtimali yoktu. Fakat vazgeçtim. «Yarın gece yatakta uyanık görsün.» dedim. Yamna yattım. Uyuyamadım. Ertesi gün geç kalkmıştım. Bahçede onları geziyor buldum. Bidar'ın çehresi pek yorgundu. Belliydi ki, gece hiç uyumamış. Yemekten sonra Efser yukarı çıktı. Mektuplarını yazacakmış. Ben Bidar'a gece nasıl hareket edeceğini tarife başladım. Yatak odamıza götürdüm. Paravanı gösterdim. Nasıl arkasına saklanacağını, Efser yatağa girmek için arkasını kapıya döndüğü zaman nasıl çıkacağım mahir bir rejisör gibi ona talim ettim. O, cidden bir cinayet ika edecek bir masum gibi, idraksiz hareket ediyordu. Göreceği manzara onu şimdiden teshir, tenvim etmişti. Sözleri gayet kısalmış, birden mütefekkir olmuştu. Sıcağa rağmen gezmeğe çıktık. Akşama kadar nasıl hareket edeceğini tekrar ettim. İyice karar vermişti. Akşam geç vakit geldik. Doğru yemeğe oturduk. Zavallı hiç yiyemedi. Kahvelerimizi içtikten sonra bahçeye çıktık. Gece sakin, biraz rutubetli idi. Ben çok neşeliydim. Kolumun altında Efser'in hararetini, kuvvetini hissettiğim elini sıkıştırıyor, koşmak, raksetmek, perende atmak, tehlikeli jimnastik hünerleri icra etmek arzuları duyuyordum. Bidar bana bakmayarak Efser'-den müsaade istedi. Yatmaya gitti. Biz bir saatten ziyade bahçede kaldık. Bu rutubetli gecelerin aşk için yapıldığım söylüyor, o, gülerek: «Uyku için hangileri?» diyordu. Sağ kolumla belinin üst tarafım ihata etmiştim. Böyle hazdan bitkin geziniyorduk. O bütün bütün kendini bırakıyordu. Yıldızların sanki bu serin rüzgârla daha ziyade parlayan, ketum, teşvik edici gözleri karşısında 'dudaklarını öpüyordum. O da öyle asabî bir tehalük, şuh bir acele ile mukabele ediyordu. Daha aşağılara indirdiğim elimin altında yumuşak adaleli kalçasının sıcaklığım duyuyor, şimdicik meçhul bir şahidin gözü göreceği için bu bediî vücudu daha kıymetli, daha müstesna, daha leziz, daha nefis hissediyordum. - Yatalım!... dedim. Muvafakat etti. Yine kucak kucağa, yekvücut, -içdik, yukarı çıktık. Yatak odasına geçtik. Ben soyunken her vakitki gibi yardım etti. Bidar'ın paravanın arkasında olduğunu bildiğimden şimdi öpmüyordum. Bu, onun dikkatini cel-betti: -  Çok gezdik, yoruldun galiba? -  Hayır, hayır. Bilâkis yorulmak istiyorum, ruhum... Güldü, eliyle ağzıma vurdu. Ben yatağa girmiştim. O, pencerenin yanındaki kanepede soyunuyordu, ben seyrediyordum. Ceketini, etekliğini, çoraplarım, külotunu yavaş yavaş çıkarıyor, pencereden giren çapkın rüzgâr, dağıttığı saçlarını, dekolte gömleğinden pek cazip görünen, beyaz, dolgun omuzlan üzerinde uçuruyordu. Oh, Bidar da tabiî benim gibi şimdi onu görüyordu. Bazı sabahlar benim müfrit okşayışla-nmdan yorularak yataktan kaçmaya çalıştığı vakitler, buselerimle saçlannın arasında teganni ettiğim bir şarkıyı mırıldanıyordum: «Sert oldu hava, çıkma koyundan kuzucağım.» Elleriyle saçlarını arkaya attı. Üstünde yalnız pembe ve dekolte gömleği kalmıştı. Yatağa şuh ve handan, koştu; elimle omuzundan tuttum! -  Daha girmedim ki... Dedi. -  Tamamıyle soyun, dedim. Gömleğini de çıkar! İtiraz etmedi. Bir artist sür'atiyle, çabucak, bir saniye içinde çıkardı. Çırılçıplak kalmıştı. Yine elimle yatağa girmesine mani oldum. Azıcık dargın durdu: -  Daha ne istiyorsun? -  Gerin... Dedim. Yine itiraz etmedi. Ona da itaat etti: -  Çılgınlığı bırak! Diye tatlı tatlı gülerek gerindi. Gerinirken galiba merak etti, endamım kendisi de görmek istedi. Sol köşedeki dolabın büyük aynasına başım çevirerek baktı. Tam bu esnada Bidar kapıdan çıkıyordu. Birden haykırdı. Sapsan oldum. Kalbim şiddetle atmaya başladı. Gördü zannettim: -  Ne var? -  Bir şey yok, ayağım acıdı. Hemen koynuma girmişti; tekrar neye haykırdığım sordum. Gerinirken ayağı acıdığını, bir parça burkulduğunu söyledi. Israr ettim. Beni ikna etti. Hakikaten görmediğine kani oldum. Kucaklayışlanma o kadar şedit, samimî mukabele ediyordu ki, şüphe etmek kabil değildi. Ertesi sabah Bidar'ı yine bahçede buldum yanına gittim. O da çıkarken haykırmasından korkmuş. Görmediğini temin ettim. Müsterih oldu. Çınlçıplak gördüğü vücudu için bir şey söylemiyor; yalmz: «Hayret! Hayret!» Diyor, derin derin dalıyordu. İki üç hafta geçti. Hiçbir şey değişmemiş görünüyordu. Fakat Bidar natıkasını kaybetmişti. Hasta, ıslak bir tavuk gibi mütemadiyen düşünüyor, sorduğumuz suallere en kısa cevaplarla mukabele ediyordu. Efser daha ziyade şenlenmiş! Bilmem niçin her vakit ifratla üzerine düştüğü mütalâasını terketmiş, çok konuşuyor, çok gülüyor, şimdiye kadar kendisinde asla müşahede etmediğim suni bir hoppalık, tuhaf bir fazlalık gösteriyordu. Bir akşam birkaç arkadaşa işlerimiz hakkında konuşmak için, Bağlarbaşı gazinosuna geleceğimi vaadetmiştim. Yemekten sonra gitmeğe kalktım. Bidar'ı da çağırdım. Rahatsız olduğunu söyledi. Halbuki evvelden, ne vakit gazinoya gidecek olsam, refakat etmek isterdi. Bu sefer gelmemesini biraz garip bulmaktan kendimi menedemedim. Rahatsız olmadığı belliydi. Pardösümü istedim. Efser gitti, getirdi. Elinde hiç kullanmadığım revolverim de vardı. Onu niçin getirdiğini sordum. İhtimal arkadaşlarımla geç vakte kadar kalacağımı, yolda gelirken yanımda bulanması fena olmadığını gülerek söyledi. -  Fakat, azizem, ben Kafdağı'na gitsem silâh almam, bilmiyor musun? Dedim. Giydiğim pardösünün cebine kendi eliyle koydu, manasım hissedemediğim garip gülüşle devam ederek: - Kafdağı'na gitmeyeceksin amma, gece yansından sonra karanlık, tenha sokaklardan geçeceksin. İhtimal bu gece mutlak lâzım olacak... İçimde meçhul bir rahatsızlık duydum. Meçhul, kablelvuku bir his: «Yakın bir felâket var!» Diyordu. Yangınlar, ihtilâller, suikastler, cinayetler tasavvur ediyordum. Bu hayaları zihnimden defetmek istedim: «Ciddî olalım!» Dedim. Gazinoya doğru gidiyor, bir marş mırıldanarak ayaklarımı ona uyduruyor, zorla cebimdeki revolveri, Efser'in bana garip, manalı bir tavırla verişini unutmuyordum. Gazinoda arkadaşlarımı buldum. Bunların hepsi bekârdı. İşimizi konuşamadık. İçmeğe başladık. Unutmak istediğim meçhul can sıkıntısını mağlûp etmek için tamam yirmi dört şişe bira içtim. Senede hiç olmazsa bir gün kendimi kaybedecek kadar sarhoş olmak on altı yaşımdanberi âdetimdi... Gece yarısı geçmiş, bizden başka kimse kalmamıştı. Hepimiz, sarhoş, kalktık. Bozuk, tozlu yollardan tam bizim köşkün önüne geldik. Dehşetli bir karanlık vardı. Uzak fenerler, mühtazır ateşböcekleri gibi, titrek, donuk bir ışık çıkarıyor, havlayan köpeklerin tehditkâr sadaları, soğuk, korkunç, aksediyordu. Kapımn önünde arkadaşlarla veda ettik. Aşağı doğru gittiler. Hemen kayboldular. Müphem bir korku duyuyordum. Zili olanca kuvvetimle çektim. İhtimal komşular uyandı. Tekrar çektim. Küçük uşak, elinde lamba, başı, göğsü yarı açık geldi. Kapıyı açtı. Biraz ferahladım. Bu ferahla, genç uşağın tüysüz yanağım okşadım. -  Uyuyordun, seni rahatsız ettim! Dedim. Tatlı tatlı güldü. Son derece sarhoş olduğumu görüyor, tuhaf bir çekinişle: -  Estağfurullah efendim... Diyordu. Tuttuğu lambamn gölgeli aydınlığı içinden bahçenin yolunu yaklaşılmış bir uçurum kıyısı gibi görüyordum. Yürüdüm, içeri girdim. Merdivenleri çıktım. Düşecektim. Son derece sarhoştum. Duvara dayandım. Biraz dinledim. Son bir gayretle sendeleyerek yatak odasına yaklaştım, kapımn önünde durdum. Efser'in sesini işitiyordum, gülüyor, birisiyle konuşuyordu. Acaba hizmetçi kız yanında mıydı? Uyamk olsaydı, o kadar şiddetle çektiğim zili işitecek, mutlaka sofaya çıkacaktı. Daha ziyade muhakeme edemedim. Kapıyı ittim. Efser, çıplak denecek derecede dekolte, yatağın kenarına oturmuştu. Beni görünce ayağa kalktı. Yatağa baktım. Yan çıplak Bidar yatıyordu. Bu sanki bir rüya idi. Katiyen kendime malik değildim. O anda ayılır gibi oldum, birden cebimdeki revolveri, medenî kanunun verdiği vahşet müsaadesini, o meşhur öldürmek hakkım hatırladım. Çabuk mi-hanikî bir hareketle revolveri çıkararak bana büyük bir itidalle bakan Bidar'm üzerine sıktım. Ateş almadı. Bir daha, bir daha... Hiç! Bidar taş gibi bakıyordu. Yatağın yanında, kaldığı gibi duran, gülümseyen Efser'e baküm. Asla korkmamıştı. Haykırması, hatta bayılması lâzım gelmiyor muydu? Bu pat-layaman revolveri yere attım. Şiddetli bir hiddetle: -  Alçak, seni elimle boğacağım... Diye yatağa, Bidar'a doğru yürüdüm. Efser önüme dikildi: -  Dur, dedi. Alçak sensin! Sanki manyetize oldum. Hiddetten, hayretten, sarhoşluktan, asabiyetten çenem titriyor, dişlerim birbirlerine vuruyordu. Efser gözlerini gözlerime dikerek devam etti: -  Onun hiç kabahati yok. Onu buraya ben getirdim. Niçin getirdiğimi, niçin onu arzu ettiğimi sana söyleyeceğim. Vicdansızlığına, alçaklığına, namussuzluğuna bir de adilik, rezalet, gürültü katma! -  Namussuz, alçak, vicdansız sensin! Diye mukabele edebildim. O büyük, kati bir itidalle asla ehemmiyet vermeyerek: -  Konuşuruz, hangimiz olduğunu anlarsın! Dedi. Sonra yatağın içinde doğrulan Bidar'a döndü: -  Haydi, Bidar Bey, siz gidiniz... Bidar bana hiç bakmayarak yatağın ayakucunda duran ropdöşambrını aldı. Çıktı. Efser karşıma geçti. Ben kuvvetsiz, sarhoş, gazup, mağlûp, intikamı alamayanlara mahsus olan o acı yeise, ümitsizliğe kapılmış kanepenin üzerine yığıldım. Oda, tavan, duvarlar etrafımda dönüyordu. Kalkmalı, onun üzerine hücum etmek istiyordum. Fakat muktedir değildim. Hatta parmaklarımı bile oynatamıyordum. Bazı kâbuslarda olduğu gibi tamamıyle hissediyor, fakat asla hareket edemiyordum. Bir müddet bana baktı. Korkunç, uzak memleketlere mensup bir manyatizör katiyetiyle şu emri verdi: -   Şimdi kımıldamayacak, söylenen şeyi anlamayacak kadar sarhoşsun. Yarın merak ettiğin şeyi öğrenirsin. Sakın bir rezalet çıkarma. Sabaha ancak iki saat var. Sabret.  Sonra ne oldu bilmiyorum. Gözlerim kapandı, sızdım.. Uyandığım vakit kendimi kanepenin dibinde, arka üstü uzanmış buldum. Başım çatlayacak gibi ağrıyordu. Dudaklarım yapışmıştı. Her tarafım acıyordu. Sanki ezilmiştim. Kalkmak istedim. Güçlükle doğruldum. Kanepenin üzerine oturdum. Acaba gece gördüğüm şey bir rüya, bir kâbus mu idi? Hizmetçi kıza seslendim; geldi. Hanımının nerede olduğunu sordum. Bidar Bey'le beraber sabahleyin erkenden çıktıklarını söyledi. Şaşırdım. Ne yapmak lâzım geldiğini tayin edemiyordum. Bir müddet donmuş gibi durdum. Sonra hırsımdan ağlamaya başladım. Hiddet, aciz, yeis, ümitsizlik içinde ağlarken aklıma intihar etmek geliyordu. «Bu ne muvafık!» Diyordum. Ağladım, ağladım, nihayet gözümdeki yaşlar bitti; kanepeye uzandım. Düşünmeye başladım. Aczimden iğreniyordum. Birden ayağa kalktım: «İntikamımı almalıyım! Dedim.

Fakat nasıl?.. İşte bunu düşünemiyor, bunu muhakeme edemiyordum. Kapı açıldı. Hizmetçi kız göründü. Elinde küçük bir zarf vardı: «Hanımefendi giderken bunu bıraktı. Size vermemi tembih etti. Deminden unuttum.» Diye vererek savuştu. Hemen açtım, Okudum. Efser annesinin evine gittiğini, bugün Bidar'ın da İtalya'ya hareket edeceği, eğer namuslu bir adam olursam, hareketinin esba-bam bana izah edebileceği, nazarında, namusumu kurtar-maklığım ancak kendisini boşamama bağlı olduğunu, yoksa bana cevap, izahat vermeye tenezzül etmeyeceğini yazıyordu. Aylarca düşündüm. Uykusuz geceler geçirdim. Neler düşünüyordum. Hepsini öldürmek, sonra intihar etmek... Facialar yapmak! Evet, facialar... Hakikî beyaz bir Othello olmak! Her elemi, her matemi, her yeisi teskin, tedavi ettiği iddia olunan zaman geçtikçe, muhakememi iade etti. Sakin-leştim. Hissetmeden düşünmeye çalıştım. Efser'in niçin bana karşı bunu yaptığım merak etmeye başladım. Merakım gazabıma galip geliyordu... Sekiz aylık bir ezalı hicrandan sonra onu boşamaya karar verdim. Artık her şeyi anlayacaktım. İhtimal onun boşanma arzusunu yerine getirdikten sonra tekrar birleşmek, barışmak mümkün olacaktı? Heyhat! Dargın kimdi, kimin barışması lâzım geliyordu? Bir sabah boş kâğıdım gönderdim. Üç gün sonra ondan uzun bir mektup aldım. Hıyanetinin esbabım anlatıyordu. İşte, azizim Müverrih Bey, bu mektubu aynen size yazıyorum. Rica ederim, dikkatle okuyunuz.  Beyefendi,

Bugün artık tamamıyle birbirimize yabancı bulunuyoruz. Boşanma ile beraber bütün müşterek mukadderatımız, karşılıklı vazifelerimiz iflas etti. Birlikte geçen hayatımıza ait hatıraları tekrar etmek tüylerimi ürpertecek derecede nefret verici ise de, yine vazife duygusu bu ıstıraba katlanmaya beni mecbur ediyor. Son vaadimi icra edeceğim. Edilen vait bence bir vazife olmuş demektir. Size hareketimin, Bidar'la muaşakamızın sebeplerini izah edeceğim. Biliyorsunuz ki, Bidar bize geldiği zaman bir kız kadar mahcup, bir melek kadar âli, bir köylü kadar saf, mertti. Benim taay-yül ettiğim ahlâklı, namuslu gencin canlı bir resmi, bir timsaliydi. Onu küçük bir kardeş, onu muhterem bir mabut yavrusu gibi sevmeye başladım. Masumiyeti, doğruluğu, saf ahlâkı bende o kadar derin bir his uyandırıyordu. Halbuki siz, ahlâk iflâsına uğramış, bozulmuş, hayvanlıktan başka her şeyi kaybetmiş, berbat, tahammül edilemez bir adamsınız. Akın yanında kara nasıl vuzuh ile göze çarparsa, Bidar'ın yanında da sizin kokmuş maneviyetiniz mü-teaffin bir levs harabesi gibi tezahür ediyordu. Ben sanki birden uyanmıştım. Sizin ruhunuzu görmek, tanımak istedim. Bu ruh, katiyen bir insan ruhu değildi. Sizde din, duygu, ahlâk, fazilet, teessür kabiliyeti yoktu. Bu bir domuz ruhu idi. Yalnız şehveti, hayvanlığı takdir ediyordu. İnsanlık şekliniz bu karanlık ruha ikinci bir karanlık daha ilâve etmişti: Bu da hodbinlik, hodgâmhktı. Bana olan müfrit meylinize dikkat ettim. Tarassut ettim, tahlil ettim, tetkik ettim. Bunun da katiyen aşk olmadığını anladım. Meyliniz sırf şehvetten, bana münhasıran malik olmak gururundan hâsıl olmuş bir zevkten ibaretti. Hareketleriniz, konuşmalarınız, düşünceleriniz, hâsılı her şeyiniz gayri ahlâkî idi. Ben bunların hepsine tahammül edecek, sizi tashihe çalışacak: «Talihim! Talihim!» Diye müteselli olacaktım. Fakat o geceki şenaatler üstünde ahlâksızlığınız... «Hangi gece?» Diye düşünmeye lüzum görmezsiniz sanırım. İyice hatırladınız. Ah, işte hâlâ yüreğim çarpıyor. Ellerim saranyor, yüzümün kızardığını duyuyorum. Evet, bana karşı en umumî, en hayâsız bir kadına lâyık görülemeyecek bir harekette bulundunuz. Çılgınca bir itisaf ettiniz. Bidar'ın bu cinayette isteyerek bir dahli olmadığına kani idim... Ah, kalbimden, ruhumdan vurulmuştum... Lâkin elemimi, tahammül edilmez kalp ağrımı büyük bir metanetle sakladım. Sizden intikam almaya karar verdim. Sizin bütün maneviyeti-nizin muhassalası hodgâmlık, şehvetti. Size başkasıyle muaşaka ettiğimi gösterince, birincisini yaralayacak, sizden ayrılınca, ikincisini yıkacaktım. Ben de böyle hareket ettim. Bidar şüphesiz odamıza kendi kendine giremezdi. Mutlaka onu siz getirmiş, bu korkunç ahlâksızlığa teşvik etmiştiniz. Buna kani idim. Aklında, hatıramda vaktiyle derin bir iz, bir nefret duygusu bırakan bir vak'a bana plân hizmetini ifa etti. Bu Can-dole'ün hikâyesi'ydi. Kütüphanemden Herodot'un tarihini aldım. Bu vak'ayı belki yüz defa daha okudum. Candole'ün ahlâksız hodbinisi de tıpkı sizinki gibiydi. Hatta dekorlar bile benziyordu. Sanki bu müstehcen piyesi binlerce sene sonra siz tekrar oynamak istediniz. Mahvedilen bendim. İlk sahnesini, ilk perdesini oynadığımız bu piyesin, ikinci perdesini itmam etmek hakkı bana isabet ediyordu. Bana bir aktör, bir intikam şeriki lâzımdı. Bu da ancak Bidar olabilirdi. Ben onu nasıl kandıracağımı düşünür, size emelimi ihsas etmemeye çalışırken, siz her şeyden habersiz, yine o mahut, adî sıfatınızla, hani o ancak bir dondurma, bir yemek, bir tatlı için kullanılan kelimelerinizle beni metheder: «Ah Efserciğim; ne nefis, ne lezizsin!» Diye hayvanlığınızın tufanı içinde bağırırdınız. Bir gün siz, yoktunuz. Bidar'ı yalnız yakaladım. Odamıza götürdüm. Girmeğe tereddüt ediyor: «Salonda otursak...» Diyordu. Gündüz yatak odasıyle salonun pek farklı olmadığını, lâkin geceleri büyük bir fark olması lâzım geldiğini manalı bir tebessümle söyledim. Cevap veremedi. Ona meseleyi doğrudan doğruya açsam, inkâr edecek, belki bu müşterek intikama rıza göstermeyecekti. Pencerenin içinde duran Herodot'un tarihini aldım. -  Size bir şey okuyacağım, fakat dikkatle, gayet büyük bir dikkatle dinleyeceğinizi vaat eder misiniz? Diye sordum. Biraz mütereddit: -  Vaat ederim! Dedi. Kanepeye oturduk. Son derecede dikkat etmesini tekrar rica ettim. Yirminci sahifeyi açtım. Kelimeleri müfrit bir vuzuhla telaffuz ederek, cümlelerin nihayetinde manalı tevakkuflarla durarak okumaya başladım. Okuduğum yer ancak bir buçuk sahife idi. Bu bir buçuk sahifeyi işte aynen, harfi harfine, size tercüme ediyorum: «8 - Bu hükümdar zevcesine o kadar meftun idi ki, onu dünyanın en güzel kadını sanıyordu. En ehemmiyetli sırlarını tevdi ettiği, çok sevdiği zabitlerinden birisine Vasilüs'ün oğlu Giges'e şiddetli sevdasına zebun, zevcesinin güzelliğini mübalâğa ederek anlatırdı. Az vakit sonra Candole (felâketten içtinap edemiyordu.) Giges'e şu nutku irat etti: «Bana öyle geliyor ki, zevcemin güzelliği hakkında benim söylediklerime inanmıyorsun. Gözler kulaklardan daha çabuk inanır. Ne yapıp yapıp onu çıplak görmeğe çalış.» Giges: - Ne akıl almaz söz haşmetmeab! Diye haykırdı. Bunu düşünmediniz mi? Bir esire melikesini çırılçıplak görmesini emretmek! Bir kadının, üstünden, hayasını es-vaplanyle beraber çıkardığını unuttunuz mu? Takibe mecbur olduğumuz ahlâk, edep kaideleri içinde en mühimi bir adamın kendisine ait olmayan kadına bakma-masıdır. Bütün kadınların en güzeline malik olduğunuza samimiyetle mutmainim. Fakat yalvarırım, benden böyle ayıp bir şey istemeyiniz.» «9 - Kralın teklifini, başına bir felâket geleceğinden korkan Giges, böyle reddediyordu. Kral: «Emin ol Giges, dedi, ne Kralından kork, (bu teklif senin için bir tuzak değildir) ne Kraliçenden. O sana hiçbir fenalık yapmayacak. Öyle bir tertip yapacağım ki, hatta senin kendisim gördüğünü bilmeyecek. Seni yattığımız odaya, açık kalan kapımn arkasına saklayacağım. Kraliçe, çok geçmeyecek beni takip edecek. Methalde bir yer vardır ki, soyundukça esvaplajım oraya koyacak. Böylece onu tamamıyle görebileceksin. Soyunduğu yerden yatağa doğru ilerleyeceği vakit, arkası senden tarafa dönmüş olacağından, bu esnada görünmeden dışarı çıkıyer.» «10 - Giges, bu tekliften yakasım kurtaramadı. İtaate mecbur kaldı. Candole, onu yatılacak saatte odasına götürdü. Kraliçe gecikmedi, geldi. Giges soyunurken onu seyretti. Yatağa gitmek için arkasım dönerken yavaşça dışarı çıktı. Fakat Kraliçe, Giges'i çıkarken gördü. Kocasının yaptığım anladı. Bu hareketi sükût ile hazmetti. Candole'den intikam almaya karar vererek bir şey bilmiyormuş gibi göründü! Zira bütün eski kavimlerde olduğu gibi Lidyalılarca da çıplak görünmek, hatta bir erkek için bile en büyük fezahattir.»20. «11 - Kraliçe fikrini belli etmeyerek müsterih kaldı. Fakat sabah olunca en sadık zabitlerinin muavenetini temin etti. Giges'i çağırdı. Giges Kraliçesinin işten haberdar olmasına ihtimal vermeyerek, her vakitki gibi emrine tebean21 geldi. Huzuruna çıkınca bu melike ona dedi ki: «Giges, işte iki yol ki, birisim takip etmeye müsaade ediyorum. Hemen şimdi karar ver. Ya Candole'ü 20- Rezalet 21- Uyarak katledip benimle evlen, Lidya tahtını eline geçir. Yahut çabuk bir ölüm, Candole'ün hukukuna küçük bir riayet için, bundan sonra seni yasak olan bir şeye bakmaktan menedecek. İkinizden birisinin mahvolması lâzımdır: Ya, ahlâkı tahkiren sana bu tavsiyesi veren, yahut beni çıplak gören sen!» Giges, biraz dilsiz gibi durdu. Sonra böyle bir intihaptan affı için yalvardı. Kraliçeyi tatmin edemediğini, mutlaka kendisini öldürmek, yahut Kralı katletmek lâzım geldiğini görünce kendi hayatını tercih etti. Kraliçeye: «Mademki, dedi, arzuma muhalif olarak efendimin katli için beni icbar ediyorsun, öğret bana, nasıl onun üzerin elimi kaldıracağım.» - «Beni sana gösterdiği aynı yerde üzerine atılacaksın, uyurken hücum edeceksin.» «12 - Kraliçe böylece Giges'i tuttu. Onun hiç kurtulmak çaresi yoktu. Ya kendisini, ya Candole'ü mahvetmek lâzım geliyordu. Kraliçe gece olunca onu elinde bir hançerle oraya, kapının arkasına soktu. Candole henüz uyumuştu. Giges onu hançerledi. Karısını, tahtını zaptetti...» Kitabı kapayarak yanıma koydum. Bidar'ın yüzüne baktım. Sapsarı idi. Titriyordu. Teselli verdim: -  Sizde kabahat yok, dedim; nafile sıkılıyorsunuz. Kabahat tamamiyle Candole'dedir. Bidar hiçbir şey söylemedi. Biraz dalgın durdu. Sonra birden diz çökerek ayaklarıma kapandı, af istemeye başladı. Ellerinden tuttum, kaldırdım. Yanıma oturttum. -  Siz susunuz, bana müsaade ediniz. Diye ağlamaya başladım. Mebzuliyetle akan göz yaşları, birbirini takip eden hıçkırıklar arasında sordum: -  Giges benim intikamımı alacak mı? Zavallı saf! Bütün bütün sarardı. Ölecek zannettim. Dudakları titriyor: «Oh, mümkün mü? Kan, kan bir cinayet!» Diyordu. Ben elimin tersiyle göz yaşlarını silerek ahlâkî ruhumun nasıl yaralandığını anlatmaya başladım. Söylüyor, söylüyor, elemle, teheyyüçle hıçkırıyordum. Eğer Can-dole'den intikam almazsa, vakıa kendisine bir şey yapamayacağımı, fakat behemehal kendimi öldüreceğimi söyledim, onu inandırdım. Sizi intikam için öldürmeye lüzum yoktu. Bir darbe ile ahlâksızlığınızın cezasını vermek kâfi idi. Bu da evvelâ hodbinliğinize indirilecek bir darbe ile başlayacaktı. Sonra boşanma, sonra Bidar'la izdivaç... Sizin üstünde oturulacak bir tahtınız yoktu... Hâsılı Bidar'ı kandırdım. Aramızda gayet muazzam bir sevişme başladı. Bu hakikî bir aşk idi. Asla sizin hayvanlığınıza benzemiyordu. Sanki tatlı, kıymetli bir şiir mecmuası içinde yaşıyorduk. Benim için pek lezzetli olacak intikam saatini tayin etmeye çalışıyorduk. Yukarıda yazdığım gibi planımı Herodot'un kitabından çıkardım. Yalnız, Bidar, Giges gibi, sizi öldürme-yecekti. Benimle gayri meşru bir temasta bulunuyor, beni -Fransızca manasıyle- öpüyor gibi görünecekti. Bu hali size bir m, şhut cürüm gibi gösterecek, hodbinizi insafsızca yaralayacaktık. Bütün itminan içinde sizi bir müddet mustarip ederek boşanmayı temin edecektim. İşte bu da oldu. Evlenmemizi bekleyebilirsiniz. Şunu da biliniz ki, bu güne kadar Bidar bana elini sürmedi. Yatakta onu benimle yatıyor görmüştünüz. Fakat bu hazırlanmış bir tablo idi. Hatta o kadar hazırlanmış ki, fazla vak'alı, entrikalı olsun diye, o gece dışarı çıkarken, zorla size revolverinizi vermiştim. Halbuki fişeklerini gündüzden çıkarmıştım. Bidar'a attığınız kurşunlardan hiç biri ateş almadı. Hatırlıyorsunuz ya? Hâsılı benim maksadım sizin adiliğinizden, ahlâksızlığınızdan doğan içten, yıkıcı hiddetimi teskin etmek, sizden intikam almaktı. Yoksa namussuzluk, nefsine uymak,aşk falan değil... Namussuzluğu katiyen kabul etmem! Eğer namussuz yaşamaya biraz istidadım olsaydı, sizinle yaşardım. Ben gayet namuslu bir kadındım, daima namuslu kalacağım. Bana yaptığınız itisafa mukabil, hayvanlığınızı yaralamak, boşanmayı teinin etmek için size gösterdiğim yatak tablosu hakikatte eflâtunî idi. Siz anlayamadınız. Bununla beraber, o gece benim yatağımda gördüğünüz adam yarın meşru kocam olacaktır. Artık en mülevves, hodbinane bir inanış, ahlâka uymaz boş bir iftira derecesini asla tecavüz etmeyecektir. Efser Bidar  Bu mektubu okuduktan sonra, hayretten, şiddetten büsbütün sersemleşmiştim, İçimdeki acı büyüyor, daha zehirli bir tesir hâsıl ediyordu. Tamamıyle mağlup idim: Kımıldana-mayacak derecede yaralanmıştım. Hemen o meşum Here-dot'un tarihi aldım. Ömrümde ilk defa bu kitabı görüyordum. Yirminci sahifeyi açtım. Okudum. Ne benzeyiş! Oh, bu tıpkı, tıpkı benimki, benim hareketimdi. Ben de biçare Can-dole gibi onun emsalsiz güzelliğini ikinci bir şahide göstermek, harikulade meftunluğumu tatmin etmek istiyordum. Fakat o... O... Barbar mahlûk bunu bir cinayet telâkki etti. İntikam aldı. Vakıa beni öldürtmedi. Keşke öldürtsey-di... Bu kadar mustarip olmaz, azabın Candole'ünkü gibi bir iki dakikalık geçici bir hançer darbesinden, acısından ibaret kalırdı. Halbuki bana vuralan intikam hançeri Candole'ün nasibinden daha müthişti. Ben sağ, aciz kalıyordum İfratla perestij etmekten başka bir kusurum olmadığı halde o vücudun Giges'e ait olduğunu görüyorum. Evet, bu mektuptan bir ay sonra Bidar'la evlendiler. *** Aradan seneler geçti. Ben ise hâlâ her sabah uyanırken, her gece yatarken elimden kaçırdığım Efser'i tahayyül ederek ruhumun derinliğine namütenahi, zehirli hançerlerin saplandığını duyuyorum. Mukaddes kitaplar tarafından tasvir olunan cehhennemlerin o öldürmeyen, fakat asırlarca yakıp kavuran ateşi gibi bu hançerler beni her gün öldürmeden kıv-randınyor, çırpındınyor. Unutmak, maziye lâkayıt kalmak, ehemmiyet vermemek istiyorum, Fakat mümkün mü? Duygularımıza, düşüncelerimize gelebeyi arzu etmek kadar masumane bir hülya olamaz. Unutmak istedikçe daha ziyade Efser'le, Bidar'ı düşünüyorum. Ye'simi en ziyade şiddetlendiren şey hiç kabahatim olmamasına inamşımdır. Ben ne yaptım? Binlerce sene evvel bir başkası tarafından izhar olunmuş bir aşk hadisesini haberim olmadan, gayri ihtiyarî tekrar ettim. Maziyi dolduran namütenahi vak'alardan birisi benim başımda tekerrür etti. Ah, söyleyiniz, hiç kabahatim, kusur sayılacak bir cürmüm var mı? Bu ezelî tekerrüre ben nasıl mani olabilirdim? Mazide barbar, vahşî kavimlerin, bizimkiler gibi hiçbir hakka, ta-biate istinat etmeyen münasebetsiz itikatları olduğu gibi, Hint, Yunan medeniyetleri gibi insanın sevkitabiîlerini tahkir etmeyenler de vardı. Onlar çıplaklığı bir fezahat değil, hatta cinsin muhafazası için en âli, en esaslı bir safhası olan tenasül fiilini saklanılacak bir cinayet telâkki etmeyerek alenen takdis, tahsin ediyorlardı. Halbuki bugün bu tabiî, bu medenî günlerden ne kadar uzağız. Elde olmayan bir tekerrür affedilmez bir cinayet sayılıyor. Medeniyetimiz suni bir vahşete, cehalete, zulmete doğru gidiyor. İşte ben de bu cehaletin yaşayan bir şahidiyim. Şimdi sevgili müverrihim «Tarih ezelî bir tekürrürdür» fikrinize ne kadar samimiyetle iştirak ettiğimi, iştirak etmekte ne kadar haklı olduğumu anladınız ya?.. Artık müsaade ediniz de susayım. Hür düşüncelerin, vicdan cesaretinden mustarip olan biçarelerin, bilhassa zavallı kendimin tesellisi kabil olmayan matemlerini tutayım...

# Teke Tek

"...Türkler az söyler, çok yapar." Maktûl İbrahim Paşa

Bosna Beyi ile Semendire Beyi'nin askerleri işte kaç haftadır "Yayçe"'yi sarmışlar, kumandanlarının gelmesini bekliyorlardı. Dinmez yağmurların, çılgın fırtınaların döve döve yosunlattığı tekir duvarlı büyük kale, kuvvetine emindi. Ne kapısında, ne bedenlerinde kimse görünmüyordu. Burçlarında sallanan bayraklar olmasa, bomboş bir kaya yığını sanılacaktı.

İki ot atımı ötede kurulu beyaz çadırların önünde, yere serili siyah kebelere oturmuş genç voyvodalar ihtiyar bir zâbitin anlattıklarını dinliyorlardı. Hava, tıpkı bir yaz sabahı kadar güzeldi. Etrafta devriye takımları uzun mızraklarıyla cirit oynar gibi koşuşuyorlar, aydınlıktan huylanan atlar şaha kalkarak, deli gibi dörtnala ileri atılıyorlardı. Sanki bütün ordugâhta, dört gündür güneşi göstermeyen ıslak sisin hapsettiği birikmiş bir neşe canlanmıştı. Kırçıl pos bıyıklarını, burnunun ucuna bakarak iki eliyle büken ihtiyar zâbit:  
— Benim büyük babam burada şehit oldu, dedi.  
— Geçen sefer sarıldığı zaman mı?  
— Ne geçen seferi?  
— !..  
— ... Çocuk musunuz? Ben altmışı tutttum. Büyük babamın kaç yaşında olması lazım gelir?  
Dinleyenler gülüştüler:  
— Herhalde senden büyük, dediler.  
— Hem çok büyük. Malum ya, asker geç evlenir. İhtimal benim gibi kırkından sonra evlendi. Ben yüzünü görmedim. Yalnız hikâyesini işittim. Bu kalenin kumandanı imiş...  
— "Yayçe"nin mi?  
Diye şaştılar.  
— Evet?  
— !...  
..........

Sağında oturan iri, esmer genç sordu:  
— Öyleyse niçin "şehit oldu" diyorsun?  
— Ya ne diyeyim?  
— "Vuruldu, öldü" de.  
— Niçin?  
— ....  
Esmer delikanlı, dilinin ucuna gelen lafı söylemedi. Yutkundu. Silah arkadaşlarının karşısında soğuk bir şey söylemek istemiyordu. Hıristiyanken vurulup ölene "şehit" denir miydi? İhtiyar zâbitin etrafında bağdaş kurmuş yoldaşlar, öbür voyvodalar, "niçin, niçin?" gibi yüzüne bakıyorlardı. Sussa, bu sükûn daha ağırlaşacak, kendi daha müşkül bir mevkide kalacaktı. Kızardı. Düşünmeden ağzından kaçırdığı itiraza pişman oldu. Ama artık hiçbir kaçamak yolu yoktu. Sıkılarak:  
— Dedenin adı neydi?  
Dedi.  
— Sungur...  
— Ay, Türk müydü?  
— Hem cetbecet..  
— Hıristiyanların ordusunda mı askerdi?  
— Hayır bizim ordumuzda.  
— O halde nasıl "Yayçe"ye kumandan olmuş?  
— "Yayçe" bizim kalemizdi, be..  
— ...  
Genç, cesur, kahraman voyvodalar şaştılar. Bunlar tam harp adamlarıydı. Yalnız aldıkları emirle yapacakları şeyi bilirlerdi. Sanatları içinde o kadar kaybolmuşlardı ki... Vakaya hiç ehemmiyet vermezlerdi. Uzak, yakın tarihini değil, hatta vaktiyle kendilerinin yaptığı şeyleri bile bilmezler, vurdukları kasabaların, yağma ettikleri şehirlerin isimlerini unuturlardı. Unutmadıkları şey istikbâle aitti: "Kızılelma"ya gidilecekti. Bu hücumlar, bu akınlar, bu muhasaralar, hep oraya yol açmak içindi. Orası, dünya üzerinde bir cennetti! Bütün dünyanın zaferi, şanı, saadeti, ganimeti orada idi. İhtiyar zâbit, pos bıyıklarına baktı. Biraz düşündü. Başını salladı. Kalın damarları görünen kıllı, esmer elini kaleye doğru uzattı:  
— Burası iki sene bizde kaldı.  
— Ne vakit?  
Dediler.  
— Fatih Gazi zamanında...  
Genç muhariplere bu iki senelik hâkimiyeti anlatmaya başladı. Dedesiyle gelen Türkmenler, kalenin içindekilere aman vermişlerdi. Ne canlarına, ne mallarına dokunulmuştu. Hatta esir bile alınmamıştı. Yerlinin hâkimden hiç farkı yoktu. O kadar ki... Bir yortu günü pazar meydanında gürültü eden bir sarhoş Hıristiyanı dövdükleri için, iki başıbozuğun boynu vurulmuştu. Tarlalarında, ticaretlerinde rahat rahat çalışan Yayçelileri sanki "adalet" azdırdı. Reâya larından emin olan Osmanlıların hepsi bir cuma günü camiye toplanmıştı. Namaz kılıyorlardı. Gördükleri iyiliklerin intikamını almak isteyen yerliler, toplanıp camiyi bastılar. Sungur Alp ile adamlarının hepsini bir anda öldürdüler. Kıyıda bucakta kalanları da esir ettiler. İşte... İşte aşağı yukarı yetmiş sene var ki "Yayçe" yine onlarda...  
Diye hikâyesini bitiren ihtiyar doğruldu. Ellerini dizlerine dayadı. Kükredi:  
— Ama bu sefer mutlaka alacağız.  
— Mutlaka...  
— Hele, beyler gelsinler bir.  
— Fırsat düşerse beyleri de beklemeyiz.  
— ......  
— Bir hücum...  
— Ama daha asker gelecek...  
— ....  
.......

İhtiyar, bundan evvelki muhasarada bulunmuştu. O bozgun ne korkunç bir felaketti. Ferhat Bey'i gafil avlayıp kırk sancakla başını alan muharip papazı bulmak için Vuryüzen, Manastır, Semendire Beyleri meydana atılmışlardı. Hüsrev Bey, Sinan Bey, Bali Bey —Fran Triyban kontu meşhur muharip Kristof, on altı bin kişiyle imdada gelinceye kadar— Yayçe'yi sıkıştırmışlardı. İhtiyar birden sustu. Yüzünü ekşitti:  
— Ah zavallı Cem...  
Dedi. Gözleri yaşardı.  
— ......  
— Dünyada bu Cem'in hali kadar yüreğimi parçalayan bir acı yoktur. Ne cesur, ne kuvvetli, ne bahadır bir tosundu!  
Zâbit ağlıyordu. Sordular.  
— Şimdi nerede?  
— ....  
— Öldü mü?  
— Keşke ölseydi...  
— Ya ne oldu?  
— Yarım ölü kaldı.  
— ?..  
— Evet, yarım ölü. Bir asker için ömrü oldukça dövüşmemek, "yarım ölü" demektir. Cem, muharebe için yaratılmıştı. Geçen muhasarada, bir gün, yine işte buracıkta oturmuş, yoldaşlarla sohbet ediyorduk. Cem dedi ki: "Benim canım sıkılıyor. Vuruşmak istiyorum." Sonra: "Haydi gelin, düşmanın başmuharibini teke tek kavgaya çağırayım. Kabul ederse eğleniriz." dedi. Ben, maksat, kendi gücümüzü, kuvvetimizi, göstermek olmadığını söyledim. Meramımız hep birden kaleyi almaktı. Vazgeçirmeye çalıştım. Lafımı dinletemedim. Kalktık. Arkasından gittik. Kaleye yaklaşınca, Cem atını oynatarak: "İçinizden kendine güvenen varsa işte meydan... Teke tek dövüşelim." diye haykırdı. Kaleden "Var, var" diye bağırdılar. Biraz sonra kalenin kapısı açıldı. Bir atlı çıktı. Bu muhafızların kumandanı "Blas Şeri" idi. Tepeden tırnağa kadar zırhlar giymişti. Atı da zırhlıydı. Cem kılıcını çekmedi. Mızrağı sallıyordu. Birbirlerine hücuma başladılar.  
— Blas Şeri ne kullanıyordu?  
— Kılıç...  
— Mızrağa karşı kılıç olur mu?  
— O vakit biz de buna şaştık. Bu adam gayet iri, gayet kuvvvetli bir muharipti. Ama Cem ondan daha iri, daha genç, daha çevikti.  
— Cem'in zırhı yok muydu?  
— Vardı. Ama yalnız göğsünde... İki saat kadar birbirlerini yaralayamadılar. Atları yoruldu. Kalenin siperleri hep seyircilerle dolmuştu. Bizim asker de saf olmuş, uzaktan bu heyecanlı musaraayı seyrediyordu. Berabere kalacaklardı. Bu esnada nasıl oldu göremedik. Çat etti, Cem'in mızrağı kırıldı. Kılıcına davranmaya meydan kalmadı. Blas Şeri, dizine öyle bir kılıç indirdi ki...  
— ....  
— .. Oh, nasıl söyleyeyim. O anda sol bacağı, mahmuzu ile, çizmesi ile beraber yere düştü. Biz koştuk. Atın başını tuttuk. Kendisini aşağı aldık. Blas Şeri "hurrâ, hurrâ" diye kendisini alkışlayan kaleye girdi. Zavallının yüzü sapsarıydı. Yerde duran kopuk bacağına bakıyor: "Allah'ını seven beni öldürsün!" diyordu. Kucağımızda çadıra getirdik. Cerrah, harıl harıl akan kanı durdurdu.

İhtiyar, ağlayarak Cem'in eski kahramanlıklarını anlattı. Böyle yaman bir zâbiti ordu görmemişti. Şimdi zavallı kimbilir Anadolu'nun hangi şehrinde, koltuk değnekleriyle gezerek, serhaddin hülyalarıyla ah çekiyordu. Bir muharip için harpten uzak yaşamak kadar acıklı bir şey yoktu. Ölmek, genç yaşında sakat kalmaktan çok iyiydi. Ölen muharip, şan, şeref içinde ebedî istirahate çekilir; kolsuz, bacaksız kalan kahraman harp hasreti içinde ömrü oldukça bir cehennem azabıyla kıvranırdı. İhtiyar zâbit, cesur Cem'in topal kaldıktan sonraki ümitsizliğini, hırsını, alamadığı intikamının ruhunda açtığı yarayı acı acı anlattı. Dinleyenlerin içinden biri hızla ayağa kalktı. Çadırın arkasında duran neferlere:  
— Benim atımla mızrağımı getirin....  
Diye haykırdı.  
— .....  
Bu, Kasım Voyvoda idi!.

Oturanlar:  
— Ne yapacaksın?  
Dediler.  
— .....  
"Hiç!" gibi omzunu silkti. Elleri kalçalarında, önüne bakarak gezinmeye başladı. Her akında, her hücumda ordunun başında giden bu kısa boylu, nahif genç, hemen hiç lakırdı söylemez, yalnız dinlerdi. Kıyafetinden kuvveti pek belli değildi. Çelimsizdi. Zırhı vücuduna bol gelir, yüksek tolgasından ince bıyıklı nazik yüzü küçücük görünürdü. Atı gelince üstüne fırladı. Mızrağını eline aldı. Sırmalı siyah kebelerde oturanlar da kalktılar. İhtiyar yoldaşlarına:  
— Teke tek vuruşmaya gidiyor, dedi. Bari zırhını giyse...  
..................

Arkadaşları, "Kasım, zırhını giy!" dediler. O hiç cevap vermedi. Yine omzunu silkti. Meydana atını sürdü. Kale kapısının önüne gidince teke tek vuruşmak için muharip istedi.

Kaleden cevap veren olmadı.

Voyvodalar, zâbitler, yayan olarak, seyir için arkasından koşmuşlardı. Kasım, belinden kılıcını çıkardı. Uzağa fırlattı. Atından indi, kıçına mızrağı ile vurdu. At ordugâha doğru dörtnala kaçtı. — Bre korkaklar! diye haykırdı. İşte atımdan indim. Kılıcımı attım. Arkamda zırhım, elimde kalkanım yok. İçinizde benimle teke tek dövüşecek bir er yok mu? ..................

Siperlerden bakışıyorlardı:  
— Kimi istersin?  
Dediler.  
— Blas Şeri'yi...  
— O, burada yok..  
— Ondan üstün birisini istiyorum!..  
— Öyle ise bekle!  
— ....  
Kalenin önünde, Kasım Voyvoda, ağır demir mızrağını yere sapladı. Yuvarlak gölgesini çiğneyerek bekledi. Sabırsızlanıyordu. Yoldaşları uzaktan ona bakıyorlardı. Yaptığı, işte bir delilikti. Kılıçsız, kalkansız, atsız, zırhsız hiç dövüş olur muydu? Ama ona laf anlatmaya imkan yoktu. Gayet inatçıydı. Karar verdiği şeyden ölüm karşısında bile dönmezdi. Kale kapısının gıcırdadığını duydu. Siyah zırhlı bir at üzerinde siyah zırhlı bir dev göründü. Yanında ağır bir kılıç asılıydı. Elinde kalın bir mızrak tutuyordu. Bu dev, Jan Hobordanski idi. Düşman ordusunda onun kadar kuvvetli, onun kadar mehîb, onun kadar iri bir muharip yoktu. Teke tek dövüşlerde kimse karşısına çıkamazdı. Atını mahmuzladı. Kasım Voyvoda'nın üzerine sürdü. Bu atsız, kalkansız, kılıçsız, zırhsız, Türk'ü atına ezdirmek istiyordu. Kasım birden mızrağını çekti. Geri fırladı. Tam Hobordanski'nin atı üzerine gelirken eğildi. At üzerinden aştı. Hobordanski, tekrar atını döndürürken yerden fırlayan Kasım, demir mızrağı ile göğsüne öyle bir çarptı ki... Bir anda... Bu harp devi, zırhları şangırdayarak yere yuvarlandı. Kalkanı bir tarafa, mızrağı bir tarafa gitti. Bu düşüşün dehşetinden ürken at şahlanarak kaçtı. Kasım Voyvoda, yere yatmış bir mandaya hücum eden çevik bir kaplan yavrusu gibi, hasımın üstüne atıldı. Tolgasının tepesinden tuttu. Uzaktan: "Yaşa, yaşa!" diye bağıran yoldaşları:  
— Kafasını kes, kafasını kes!  
Dediler.

Cevap vermedi. Omzunu silkti. Hobordanski'nin tel zırhlı geniş sırtına sağ diziyle bastı. Kalın kollarını arkaya kanırttı... Ciğerlerinin hizasına birkaç yumruk yapıştırdı. Her yumrukta, mızrak darbesiyle göğüs kemikleri çöken baygın Hobordanski, "oh, oh" diye inliyordu. Ağzından oluk gibi pıhtılı kanlar fışkırıyordu. İniltisi kesilince, Kasım Voyvoda, hiçbir şey yapmamış gibi soğukkanlılıkla doğruldu. Yerden kılıcını, mızrağını aldı. Arkadaşlarına doğru yürüdü. Kaleden çıkanlar Hobordanski'nin cesedine koşuşuyorlardı. İhtiyar zâbit:  
— Bre Kasım! Neye bu herifin kellesini almadın?  
Diye omzunu okşadı.

Öbür voyvodalar da etrafını çevirdiler:  
— Neye kesmedin be? Neye kesmedin?  
Diyorlardı.

Kasım gülümsedi. İhtiyara baktı. Tembel dudaklarını zorla oynattı:  
— Er meydanında ölmek şerefine o layık mı ki...  
Dedi.

Sonra arkadaşlarına dönerek ilave etti: — Artık ömrü oldukça eli silah tutamaz. Onu yatağa gömdüm. Dünyada yataktan daha azaplı bir mezar var mı?

Hakikaten Jan Hobordanski bir daha harp edemedi. Yıllarca yatakta kıvrandı... Kalktığı zaman artık o eski müthiş, kuvvetli muharip değil, hasta, mağrur bir siyasetçiydi. İstanbul'a düşmandan ilk defa o sefir geldi. Vezirlerin epeyce canını sıktı. Nihayet... Er meydanında da ölemedi, Sultan Süleyman'ın Macaristan'a kral nasbettiği Yanoş'u vurmak için bir gün gizlice "Buda"ya girerken yakalandı. Bir torbaya konulup Tuna'ya atıldı....

# Terakki

Yaz... Ramazan! Hava öyle sıcak ki... İndirilmiş perdelerin arkasında gizli gizli tutuşan, fakat hiç gürültüsü duyulmayan bir cehennem var sanılacak. Niyazi ile Neşet, duvarları yeşil kâğıt kaplı odanın kapı tarafındaki geniş bir koltuğa iki canlı keyif heykeli gibi uzanmış, cigaralarının dumanları içinde konuşuyorlar:  
— Evet.  
— Olur iş değil.  
— Bu kadar az zaman içinde.  
— Bu kadar terakki!..  
— Şu kadar değişiklik!  
— Âdeta insan gözlerine inanamayacak.  
— Sekiz, on sene evvelki yolları, evleri, arabaları, tramvayları, kıyafetleri, hele o vapurları bir hatırla...  
— Telefon yoktu be...  
— Elektrik var mıydı?  
— Ya sinema?..  
— Ya otomobil?  
— Ya gramofon?  
— Yalnız o vardı işte...  
— Nasıl?..  
— On beş sene evvel ben kırk paraya lastik boruları kulağıma takar, öyle bir garibe, bir hâdise karşısında imiş gibi, hayretle dinlerdim.  
— Tayyareye ne diyeceksin?  
— Olur iş değil.  
— Kim böyle kuş gibi havada uçulacağına, Türklerin de uçacaklarına inanırdı?  
— Zeplin?  
— Vay anasını! Koca bir zırhlı. Fakat havada uçuyor. Farkı bu...  
— Bu muhakkak.  
— Pekâlâ, ama pahalılığa ne diyeceksin?  
— Tabiî her şey gibi paranın da kıymeti değişti. Para çoğaldı. Malların fiyatları yükseldi.  
— Para çoğaldı mı, azaldı mı?  
— Vallahi bilmiyorum.  
— Ben de bilmiyorum.  
— Bilmediğimiz şeye karışmamak...  
— ...Bu doğrudur amma...  
— Amma?  
— Bizim elimizden gelmez.  
— Fakat şunu itiraf etmeli ki, her gülün bir dikeni olur.  
— Tabiî...  
— "Terakki"nin de bazı pot gelen cihet leri olacak.  
— Ne gibi?..  
— Mesela...  
Niyazi misalini söyleyemez. Sokaktan şiddetli, keskin, gür, canlı, latif, parlak, ahenkli bir ses gelir.

"Dünya değişti. Eski günler geçti. Merhamet, mürüvvet, insaniyet kalmadı. Herkes keyfinde, eğlencesinde, kimse kimseyi düşünmez oldu. Bu ne haldir?"

Birbirlerinin yüzlerine bakışırlar. Gayri ihtiyarî, sârî bir hareketle, tellenmiş cigaralarını önlerindeki tablada söndürürler: — Bu ne? — Bilmem. Sokaktan gelen ahenkli ses aynı şiddet, aynı letafet, aynı azamet, aynı belâgat le devam eder:

"...Dünya bir cife dir. Hayf onu isteyen köpeklere! Uyanın, kâinata ibretle bakın. Fâni olan şeylere aldanmayın."

Neşet bir eliyle başını, diğer eliyle sarı pijamasının üstünden kalçasını kaşır. Yüzünü ekşitir. Niyazi alt dudağını ısırarak yavaş yavaş doğrulur:  
— Bu ne be?  
— Saçma...  
— Ama ne güzel, ne yanık söylüyor...  
— Gayet muktedir bir hatip olacak.  
— Şüphesiz.  
Sokaktan gelen ses:

"...Bugün varız, yarın yok! Gündüzün sonu gece. Aydınlığın sonu karanlık. Ateşin sonu kül. Hayatın sonu ölüm... Ölümden kim şüphe eder? Altınlara gark olsak, demirden, çelikten kaleler içine saklansak, mutlaka ölüm oku gelip bizi bulacak. Er geç bize yetişecek. Bu kadar muhakkak bir akibet karşısında gaflete düşen, nefsine uyan, yarını unutan insan mıdır? Hayır... Hayvandır. Nefsine uyanların, zevkten başka bir şey tanımayanların, hayvanlardan ne farkı var?"

Neşet ayağa kalkar, der ki:  
— Bu bir feylesof!  
— Hem de derin...  
— Hem pek derin bir feylesof!  
— Bak, bak, ne diyor?  
Sokaktan gelen ses daha yanık bir hararet, daha azametli bir şiddetle:

"...Merhamet, şefkat, elâlem, kimsenin umurunda değil. Sadakanın ismi unutulmuş. Yiyiniz, içiniz, keyif ediniz... Çalınız. Oynayınız. Güzel evlerin içinde, temiz karyolalarda, rahat rahat gündüz uykularına yatınız. Ah, nerede fazilet?"

Niyazi oturduğu yerden:  
— Hem sosyalist, be! der.  
— Ne demek?..  
— Güpegündüz, bir başına, sokak ortasında bu kadar serbest laf söylemek...  
— Bakalım bir başına mı?  
Niyazi kalkar, pencerenin yanına gider, kapalı perdeyi aralık eder. Bakar, bir kahkaha atar:  
— Olur iş değil be!  
— Ne?  
— Gel de bak.  
Neşet merakla pencereye koşar. Perdenin arasından dışarıya bakar. Sokakta, tek başına yavaş yavaş yürüyen, üstü başı perişan, omuzu torbalı, eli asalı bir adam gözlerini pencereye kaldırır, boynunu bükerek:  
— Allah rızası için bir dilim ekmek! der.  
Niyazi ile Neşet, bir an öyle kalırlar. Sonra hayretle birbirlerine bakışırlar.  
— Ne dersin?  
— Olur iş değil...  
— Dilenci be!  
— Feylesoftan dilenci!  
— Yok, dilenciden feylesof!  
— Hem hatip...  
— Yalnız hatip mi?  
Niyazi kaldırdığı perdeyi tekrar kapatır:  
— Bizim  Dârülbedâyi'de böyle gür sesli bir hatip yok.  
— Yok vallahi...  
Gülüşürler.  
— Hem ne şiddet!  
— Evet, öyle...  
Dışarıda, daima değişen, asla eskiye benzemeyen hayatın hiç şimdiye kadar görülenlerini andırmayan yeni dilenci susmaz:

"Gülün, gülün... Gülmenin sonu ağlamadır. Vuslatın sonu hicran... Yazın sonu hazân... İkbalin sonu zeval... Hayatın sonu ölüm!.. Acaba ibret gözüyle şu dünyaya bir baksanız... vs... vs..!"

Uzaklaştıkça işitilmemeye başlayan müteharrik, geçici bir hutbe gibi devam eder. Eski yerlerine oturan Neşet'le Niyazi yine cigaralarını tellendirirler.  
— Sekiz, on sene evvel İstanbul'da bu kadar muntazam söz söyleyecek, bu kadar hikmeti bir ağızda etrafa saçacak bir müderris var mıydı?  
— Halbuki şimdi...  
— Bir dilencideki bu belâgat!  
. . . .  
— Daha doğrusu bu küstahlık!  
— Olur iş değil...  
— Olur iş değil vallahi...

# Teselli

Batıdan gelen büyük düz yolun tâ ağzındaki taş konak, zairsiz bir türbe gibi sakindi. Yeşil boyalı demir kapısının aralığına yaslanmış ak sakallı, garip, meyus bir kethüdâ; yere, karmakarışık serseri izlere bakarak düşünüyordu. Kapakları örtülü ıssız pencerelerin arkasında sanki derin, duyulmaz bir matem feryadı gizliydi. Beş hafta evvelki bozgunun şehri dolduran yaralıları, kuskunsuz atlar, aç katırlar, kırık arabalar, topallayan askerler, kalkansız süvariler, tolgasız yeniçeriler, mızraksız sipâhîler; yüksek, beyaz duvarlara, geçici bir gölge kabusu halinde, mahzun akislerini bir an sürüyorlar, sonra titreyerek, siliniveriyorlardı.

Bu türbede yatan ölü, Erzurum kumandanı İskender Paşa idi. Haftalardan beri, tozlu bir sanduka içi gibi karanlık odasında, dizlerini acıtan seccadeye kapanmış, yapayalnız oturuyordu. Mihânikî bir huzur ile "Salâtü selam" çekerek beklediği, geç kalan Azrail'di. İşte tam otuz gün... Daima kulağında bir ayak sesi işitir gibi olur, genç kahyasını çağırırdı:  
— Fâzıl!  
— Efendim.  
— Bir gelen mi var?  
— Hayır efendim.  
— ....  
Sadık genç, araladığı kapıyı çekince, yine birden kararan sanduka sükunu içinde, İskender Paşa, galeyansız ibadetine başlardı. Artık dünyaya dair hiçbir ümidi kalmamıştı. İstediği yalnız bir iman selametiydi. Vâkıa korkak bir adam değildi. Ama, muhakkak bir ölümü her gün, her saat, her dakika, hatta her saniye beklemek... Onun cesaretini kırmış, sinirlerini zayıflatmıştı. Evet, ya kafası kesilecek, ya boğulacaktı! Düşündükçe, ensesinde soğuk bir satırın sarih temasını duyar gibi oluyordu. Bu sarih temas silinirken karşısına kendi boğuk hayali gelirdi; gözleri patlamış, kavuğu bir tarafa yuvarlanmış, boynu yağlı bir kement ile sıkılmış, ayağından pabuçları çıkmış, ipek kuşağı çözülmüş, karanlık, köpüklü ağzından siyah dili sarkmış bir naaş... İskender Paşa'nın yerde sürünen ölüsü!

Titrer, gözlerini oğuşturur, yine salât-ü selamlarını çekmeye başlardı. Yakın akıbetinin bu uzvî hatırası o kadar bariz, o kadar kuvvetliydi ki... Çocukluğunun saf muhayyilesini süsleyen cennet bahçelerini, hûri, gılman alaylarını, Tûba ağacını, Sırat köprüsünü şimdi düşünemiyordu bile... Zihni durmuştu. Sinirleri, beyni pek yorgundu. Yemek yiyemiyordu. Boğazına kurşundan bir yumruk tıkanmıştı. Yalnız ara sıra su içerdi. Abdestini tazelemeye kalktığı zamanlar dizleri çözülüyor, gözlerinde karanlık, kırmızı benekler uçuşuyordu. Bazen sedirin üstüne uzanıp dalınca, korkunç, muzip rüyalarla uyanırdı. Ölümden sonrası havsalasına sığamıyor, adem, tasavvuru gibi birdenbire kararıyordu. En büyük hakikat işte, gözünün önünden ayrılmayan, şu kendi boğuk hayaliydi! Evet, hiçbir ümit, hiçbir kurtuluş ümidi yoktu. Kabahati pek büyüktü. Zamanın Süleyman'ı, Türk bayrağını, Viyana surlarına doğru dalgalandırırken... Er meydanlarında beraber şan aldığı birçok arkadaşları, bahtiyar beylerbeyleri, en asil düşmanları önlerinde dize getirirken, o kıymetsiz bir türedinin pususuna düşmüş, perişan olmuştu; Şah'ın oğlu İsmail Mirza, hile ile Erciş'e girmiş, kaleyi yıkmış, kale muhafızı, padişahın o kadar sevdiği cihan pehlivanı İbrahim'in başını kestirmiş, sonra Ahlat ahalisini bin düzenle kandırmış, "Vire" ile şehri terke davet etmişti. Sözde zavallılar serbestçe çekilip gideceklerdi. Halbuki İsmail Mirzâ haini, daha kalenin kapılarından çıkar çıkmaz hepsini, çoluk çocuk, kadın, ihtiyar... Hepsini doğramış, bir tek cana olsun aman vermemişti. Bu canavar katili cezalandıracakken, o, acemi bir asker dalgınlığı ile, aleyhine kurulan pusuya yuvarlanmıştı. Yanında en namdâr kahramanlar; Trabzon, Malatya, Bozok, Karahisar Beyleri şehit düşmüştü. Biga Sancak Beyi Mahmud Bey gibi zarif, kıymettar, şair bir adamla sağ ve sol cenah ağaları esir olmuşlar, ihtimal ki kesilmişlerdi de... Kendi, nasılsa kurtulmuştu! Bu bir mucize idi. Ama keşke kurtulmasaydı. Beklenilmeyen bir ölüm kadar ehemmiyetsiz ne olabilirdi? Fakat bu ölüm beklenildiği zaman ne müthişti!

İskender Paşa, yine ayak sesleri işitti:  
— Fâzıl!  
— Efendim.  
— Bir gelen mi var?  
Kahya, kapının aralığından cevap verdi:  
— Birkaç zâbit gelmiş efendim.  
— Defterdara gönder, onunla konuşsunlar.  
— Başüstüne efendim.  
. . . . . . .

Bir aydır her şeyi defterdarına bırakmış, "Bizim artık dünya gâilesi ile uğraşacak vaktimiz kalmadı. Tövbe zamanımızdır." demişti. Halbuki bozuk ordunun erzakını, intizâmını, zapt ü raptını temin edemeyen defterdar, yine ara sıra zâbitleri kumandana yollamaya mecbur oluyordu. Efendilerinin akıbetini, tıpkı kendisi gibi sarih bir ümitsizlikle bekleyen, kapı halkı, artık onu taciz etmiyorlardı. Herkes kendi başının çaresine düşmüştü. İçinde Azrail beklenilen bu boş konağın mezar havasını hiçbir ses bozmuyordu. Vakit vakit esen serin, hiddetli bir rüzgar, duvarlara çarparak çatılardan süzülüyor, tenha sofalarda cinler top oynuyordu.

Fakat İskender Paşa, bir gün seccadesinin üstünde, iki büklüm, sülûke varmış bir derviş tevekkülüyle, muhakkak ölümünü unutmak istedi. O an mazisini hatırladı. Pek gençken Hüsrev Paşa'nın yanındaki silahşörlüğü, sonra kapıcıbaşılığı, daha sonra çavuşluğu hayalinden geçti. "Orta defterdarı" iken evlenmişti. Karısı, çocukları... Çocukları daha pek küçüktü. Şimdi acaba neredeydiler? Ne olacaklardı! Bir vakitler Van kalesinin fethinde gösterdiği yararlıklarla nasıl padişahın gözüne girmişti! Bu tehlikeli kalede ümerâdan kimse kalmaya cesaret edemiyordu. Kendi isteyerek kalmış, kaç defalar düşmanı bozmuştu. Sonra kumandan olduğu Erzurum havâlisinde de nâmı düşmanları titretmiyor muydu? Lâkin işte nasılsa bir tedbirsizlik etmişti. Padişahın bu serhadde gönderdiği yeniçerilerle ümerâ maiyetine "Kışın Erzurum kalesinde çok adam barınamaz" diye izin vermişti. Mirza İsmail'in zuhûrunu hiç düşünmemişti. Elinin altındaki asker pek azdı. Hemen yalnız ümerâ ile kapı halkından asker pek azdı. Sonra, Mirza ile karşılazmazdan bir gece evvel gördüğü o rüya... İşte hatırlıyordu; kendi siyah at üstünde, dar, çalılık bir yoldan giderken, önüne bir yılan çıkmıştı. Bu yılan, iki çatal dilini ona çıkarıyor, çalıların arasına kaçıyordu. Atından atlıyor, koşuyor, onu tutuyordu. Ama tutar tutmaz elleri kan içinde kalmıştı. Artık yılan filan yoktu. Sabahleyin yanına gelen ümerâ ile ulemâya bunu anlatmış, biri: — Yılan tutmak zehir tutmaktır. Gam ile gussa suretidir. Demiş, ihtiyar bir hoca da: — Şahoğlu galiba üzerinize geliyor. İnşallah onu tutacaksınız... Diye tabir etmişti.

İşte o, bu hayırlı tabire inanmış, Mirza'nın kendini aldatmak için ileri sürdüğü iki alayını görünce, sabrını, kararını, aklını, muhakemesini kaybederek üzerlerine atılmıştı. Vâkıa sonra arkasını kaleye verdi. Saatlerce dövüştü. Altında oniki at öldü. Cenk meydanında gece oluncaya kadar, tek başına kalıncaya kadar vuruştu. Fakat harp, yalnız cesaret miydi? Asıl tedbir lazımdı. Tedbirli, büyük padişah, serhadde o kadar asker tayin etmişken, o, bu hareketin hikmetini anlamamış, birçoğuna icazet vererek evlerine göndermişti. Kabahatı büyüktü!.. Affolunamayacak derecede büyüktü! Bu kabahati ancak ölüm temizleyebilirdi...

Yine ölümünü düşünmeye başladı. Evet, artık İstanbul'dan çıkan cellatla hasekiler ihtimal çok yaklaşmış olmalılardı. Kazaya rızâdan başka ne çare vardı? Yavaş yavaş doğruldu. Odasının hiç aydınlatmadığı karanlığına gözleri alışıktı. Geniş sedir, köşede duran abdest leğen ibriğini görüyordu. Pencerenin kapakları etrafında ziyâdan ince çizgiler parlıyordu. Kalktı. Ve titreyerek, dolabın rafındaki küçük testiden birkaç yudum su içti... Sonra sedire uzandı. Kahyasını çağırdı:  
— Fâzıl!  
— Efendim.  
— Gel içeri.  
Uzun, dar cübbeli, bodur üsküflü delikanlı girdi:  
— Buyurunuz efendim?  
— Fermanımızı getirenlerin buraya pek yaklaştıkları bana malum oldu. Sen hep yola bak. Bekle. Yolda atlıları görünce hemen gel, haber ver. Eğer uyuyorsam uyandır, abdest alayım. Namaza durayım. Ben tahiyyatta otururken, cellat, aldığı emri yapsın. Hasekilere söyle. Vasiyetim budur. Ben hiçbirini görmeyeyim. Anladın mı oğlum?  
— Anladım efendim.  
Delikanlı hıçkırıyordu. İskender Paşa gözlerini kapadı. Kahya dışarı çıkınca odanın eski sanduka sükutu, sabahsız bir bela gecesi gibi, yine karardı.

Bir gün, akşama doğru, bu abûs karanlıkta, İskender Paşa, tövbe, istiğfar ederken kahya kapıdan içeri girdi. Ağzını açamadı:  
— ......  
— Ne var, oğlum?  
— ......  
— Söylesene...  
— ... Geliyorlar!  
Kimlerin geldiğini sormaya hacet yoktu. Biliyordu.  
— Pekala, dedi, vasiyetimi aynıyla icra et... Sakın namazımı fazla bozmasınlar. Ne emir aldılarsa yapsınlar. Ben Allah'la beraberim.  
Delikanlı velinimetinin ellerini tuttu. Ağlayarak öpmeye başladı:  
— Bana hakkınızı helal ediniz efendim.  
— Helal olsun oğlum, inşallah muradına erersin. Sakın bana laf söyletme... Haydi, şimdi şu pencerelerin kapaklarını aç.  
Ağlayan kahya, haftalarca örtülü kapakları açtı. İçeriye çiy aydınlık boşandı. Uzaktan, kaldırdıkları toz duman önünde birtakım süvariler koşuşuyordu. Paşa'nın zaten abdesti vardı. Kıbleye doğru serilmiş seccadesinde ayağa kalktı. Başını sağa çevirdi. Açılan pencerelere baktı. Bu mavi göğü, bu beyaz bulutları artık son defa görüyordu. zayıf ellerini kulaklarına götürdü; dünyaya, mâsivâya dair aklında ne varsa unutmak için bir daha kendini zorladı. İçinden "Allah'la beraber olayım!" dedi. Sureleri okuyor, rükûa, secdeye varıyordu. İki rekat kıldıktan sonra tekrar namaza durdu. Hem okuyor, hem istemeyerek nal sesleri, kılıç şakırtıları duyuyordu.  
— ... Yukarı çıkıyorlardı!  
En hafif bir pıtırtı, dimağında gürültülü akislerle büyüyordu. Kahyasının fısıldayan sesini bir nâra gibi işitti. Vasiyetini onlara söylüyordu:  
— Sakın namazını bozmayın.  
— Olur, olur.  
— Ne emir almış iseniz hemen yapın.  
— Peki, peki!  
— İşte burada! Gelin...  
Arkasındaki kapı açıldı. Vücudunu yakarak damarlarından hızla çekilen bütün kanlarının tıkanmış göğsüne biriktiğini hissetti. Boğulacaktı. Nefes alamıyordu. Tahiyyatta oturuyordu. "Eşhedü enlâ..." derken dizinin üstünde taş kesilen sağ elinin şahadet parmağını kaldırmak istedi. Şuurunun son gayretini sarfetti. Kaldıramadı. Kuvveti yoktu. Ettehiyyâtın aşağısını okuyamadı. Çeneleri kilitlendi. Gözleri kararıyordu. Kalbi durdu. Hatta titreyemedi. Fakat... Hani? Tekrar çarpmaya başlayan kalbiyle zehirli bir ateş bütün vücuduna yayıldı. Her tarafı yanıyordu. Düşecekti. Düşmeden en son bir gayretle selam verdi:  
— Esselâmü aleyküm ve rahmetullah...  
Soluna da döndü. Sonra, hiçbir tarafa bakmadan gözlerini kapadı:  
— Ne duruyorsunuz, haydi!  
Diye son nefesini çıkardı.  
— . . . . . . . . .  
— Size hatt-ı şerifle padişahımızın ihsanları var, paşam!  
— . . . . . . . .  
Tanımadığı bir ses!... Başını arkaya çevirip, yalın kılıç, yahut elinde kemendiyle yağız bir ifrit görecek yerde, kırmızı esvaplı, şal kuşaklı, sırma üsküflü dört çavuş gördü. Birisi kucağında kundak gibi büyük, sırmalı bir bohça tutuyordu. İkincisinin elinde altın bir kılıç... Üçüncüsüne göz attı, murassâ bir topuz... Dördüncü çavuş yürüdü. Yanına yaklaştı. Diz çöktü. Elinde tuttuğu kırmızı torbayı öptü. Başına koydu. Sonra ona uzattı. Kılıçla kement görmeyen paşa şaşırmıştı. Kendisine uzatılan torbayı dalgın bir isti'calle kaptı. Hızla öptü. Başına koydu, mumu kopardı, açtı. Padişahının yazısını tanıdı:

"... İki cihanda yüzün ak olsun. Şahoğlu askeriyle senin küfvün değildi. Ancak ispat-ı vücud ettin. Ve bahadırlıkta taksir etmedin. Nusrat ü hezimet hod meşiyyet-i Hüdâya mütealliktir. Hatırın hoş tutasın..."

Gözlerine inanamadı. Sevincinden ölecekti. Padişah, eski kahramanlıklarını anlatıyor, uğradığı hezimet felaketi için teselli veriyor, üzülmesin diye kendisine bir hil'at, bir altın kılıç, bir murassâ topuz ihsan ettiğini yazıyordu. Bu ulvi tesliyetnâmeyi, bu adil, bu büyük, bu mukaddes hatt-ı şerifi bitirince, İskender Paşa, o kadar hafifledi ki... Tüy gibi ayağa kalktı. Uzun boyu çelik bir sütun kadar dimdikti. Sararmış yanakları hemen kızardı. İri mavi gözlerinde bir hayat alevi tutuştu. Çavuşta öteki vezirlerin de mektupları vardı. Onları da aldı. Birer birer açtı. Göz gezdirdi. Hepsi padişahın emriyle onu teselli ediyorlardı. Sırma bohçayı, altın kılıcı, murassâ topuzu sedirin üstüne bıraktırdı.

Kahyasına: — Fâzıl, ağaları bir odaya yerleştir. Rahat etsinler, yarın kendileriyle konuşuruz, dedi. Yerlere eğilerek kendini selamlayan süslü çavuşların arkasından kahyası da dışarı çıktı. İki dakika evvelki, cansız İskender Paşa, ansızın dirilmişti. Yalnız kalınca gülümsedi. Gerindi. Esnedi. Yavaş yavaş sedire doğru yürüdü. Bohçayı açtı. Düğmeleri elmastan, ağır, sırmalı, erguvanî bir hil'at... Uzandı, kılıcı eline aldı. Sapıyla kını som altındandı. Çekti, sol elinin baş parmağı ile namlu demirini yokladı. Sonra başını aydınlık pencereye çevirdi. Ufukta, yolun tâ nihayetinde yarım batmış güneş, tıpkı yaklaşılmış bir cennet kapısı gibi duruyordu. Baktı, baktı: bu ulvi kapının içinde, hatt-ı şerifin hareketinden bahsettiği büyük orduyu ince mızraklarıyla, bayraklarıyla görüyor gibi oldu. Bu ordu, mert Turan'ın ortasındaki şımarık İran'a adalet nurları saçacaktı. Bütün tüyleri ürperdi. Sevinçten, heyecandan gözleri yaşardı. İşte, yarın, şüphesiz kendisi de... Onlarla beraber kendisi de, şimdi elinde tuttuğu şu altın saplı keskin kılıcı hak uğrunda, hakikat uğrunda sallayacaktı!

# Topuz

Karamanın koyunu,  
Sonra çıkar oyunu...  
Atasözü

Küçük pâyitahtın karışık sokakları bugün çok kalabalıktı. Tıpkı ilkbaharda bir bayram gibi... Bütün kadınlar, bol beyaz yenli, sırma yelekli pazar esvaplarını giymişler, beyaz poturlu dinç erkeklerin dolu testilerle sundukları şarapları içerek coşuyorlardı. Genç, ihtiyar, kadın, çocuk... Nihayetsiz bir "Hurrâ" zinciri, bağırarak, sallanarak kalabalığın içinden geçiyor, canlı bir girdap dalgası halinde, döne döne, sarayın meydanında birikiyordu. Kiliselerin çanları uğulduyordu. Saray kapısının önünde cesur Boyar atlıları saf saf olmuş, bekliyorlardı. Sabahtan beri çektiği şaraplarla epeyce başı dönen meşhur kumandan tolgasının siperini geri itti. Atının ağır üzengileri üstünde biraz kalktı. İleriye baktı. Yanındaki birinci zâbitine:  
— Daha görünmüyorlar, dedi.  
— Geç kaldılar.  
— Evet.  
— Niçin acaba?  
— Mankafa Türkler işte... Teşrifattan, merasimden ne anlarlar?  
— Hem de "Bizans'a lâyıkız" derler.  
— Nerede o incelik?  
— Nerede?..  
—  .....  
Önlerinde birdenbire genişleyen sık bir "hurrâ" halkası ikisini de susturdu. Gemlerini kastılar. Atlarını biraz çektiler. Kumandan, istiklâlini kazanan halkın bu deli, bu sarhoş sevincine bakıyor, keyifleniyordu. Yarı baygın kızlar, şen delikanlıların kucaklarında, gaydaların âhengine ayak uyduruyorlar, "Yaşasın prens! Yaşasın prens!" nakaratını haykırışarak yeni hükümdarlarının şerefine testileri deviriyorlar, oynuyorlar, sıçrıyorlardı... Son Eflâk tacını giyen papazı, Tergoviç'te bozan Mehmed Bey, bir sene vardı ki, kendisini sancak beyi ilan etmişti. Ama, Eflâklılar, bu hâkime boyun eğmemiş, Zips Kontu Zapolya'dan imdat istemişlerdi. İşte bu tehlikeli ittifaktan ürken Mehmed Bey çarçabuk onların haklarını, imtiyazlarını, istiklâllerini vermişti. Açık mavi, bulutsuz ufukta yükselen güneşin aydınlığı kahraman Boyar atlılarının uzun mızraklarını yaldızlıyordu. Kumandan, zırhlı göğsünü kabartan tatlı bir teessürle bir halka, bir askerine bakıyor; mahmuzlarıyla dokunarak atını şahlandırıyordu. Birinci zâbit, onun gibi iri yarı, yakışıklı değildi. Kara kuru bir şey... Uzun saçları kırdı. Köse yüzü hem zayıf, hem buruşuktu. Neşeli kumandan, hora tepenler geçince, yine atını ileri sürdü.  
— Kansız bir zafer kazandık!  
Dedi. Siyah atının yelesini okşayan zâbit:  
— Kansız zafer olmaz!  
Diye başını salladı.  
— Niçin olmasın?  
— Benim Türkler'e emniyetim yok...  
— Kuşkulanmaya da hacet yok! Biz daha resmen ihtilale kalkmadan onlar haber gönderdiler: "Gidiniz bir şef tayin ediniz" dediler. Biz zaten prensimizi tahtına çıkarmıştık. Şimdi, işte bize bir de "cemîle" yapıyorlar.  
— Berat, sancak, davul, topuz göndermek bir "cemîle" mi?  
— Ya ne?  
— Tabiiyet alâmetleri...  
Coşkun kumandan, görünmeyen bir surata tokat atacakmış gibi elini yukarı kaldırdı. Hiddetli bir tehâlükle:  
— Asla! diye bağırdı. Biz artık müstakiliz! Berat, istiklâlimizi tasdik etmektedir. Sancak, davul, topuz da padişahın prensimize hediyeleri...  
— ......  
Zâbit cevap vermedi. Kumandan kadar içmediği için Türkler'in hakikatini hâlâ hatırlayabiliyordu. Elini kalçasına dayadı. Atının siyah yelesine daldı gitti. Kiliselerin çanları beyninde ötüyordu. Halkın gürültüsü taşmış, bir tûfan gibi sarayın saçaklarına çarpıyor, muh&afız neferlerin yüksek atlarını huylandırıyor, tepindiriyordu. Oynayanların içinde zorla kendine yol açan bir atlı kumandanı selamladı:  
— Elçi, maiyetiyle beraber menzilinden çıktı, dedi.  
— Pekala... Maiyeti kaç kişi var?  
— Üç yüz atlı!  
Kumandanın solundan neferin sözünü işiten zâbit:  
— Üç yüz atlı mı?  
Diye sapsarı kesildi.  
— Evet...  
Bugünkü teşrifata memur olan kumandan güldü:  
— Gidi Türkler... Sıkıya geldi mi nasıl küçülürler. Hani eski gururları? Şimdi dünya değişti. Rumeli'nde kuvvvetleri yok. İşte prensimize büyük bir imparator muamelesi yapıyorlar!  
Birinci zâbit, daha beter sarararak sordu:  
— Nereden anladınız?  
— Elçilerin derecesi maiyetin adediyle münasiptir. İşte bak, padişahın hediyelerini, beratını üç yüz atlıyla bir elçi getiriyor!  
— Elçi bunları yalnız getirseydi, daha iyi olurdu.  
— Niçin?  
— İşte öyle...  
— Ama biz kabul etmezdik.  
— Neden?  
— Çünkü şanımızla mütenasib olmazdı. Bir emir, lütuf, bir ihsan gibi... Halbuki böyle maiyetinde üç yüz atlı bulunan bir elçi... Ne demektir? Biliyor musun?  
— Ne demektir?  
— Padişah, bizim prense: "Benimle müsâvîsin!" demek istiyor.  
— Keşke müsâvî olmasaydı da, bu üç yüz atlı Eflâk'a girmeseydi!  
— Sen bunamışsın, Dimko...  
Birinci zâbit acı acı gülümsedi. Tüysüz yüzünü ekşitti. Atının yelesinden kaldırdığı dalgın sönük gözleriyle kumandanına baktı:  
— Ben bunamışım ha?  
Dedi.  
— Koca Eflâk'ın içinde üç yüz atlıdan kuşkulanıyorsun. Bunlar elçi maiyeti.. İşlemeli mızraklarına, süslü esvaplarına, altın haşalarına, sırma eyerlerine aldanma... Göze parlaklıklarıyla çarparlar ama, ellerinden bir şey gelmez.  
— Bunlar Türk değil mi?  
— Türk... Ne olacak?  
— Kılıçları ne kadar süslü olsa yine keser..  
— Sen korkaksın! Bir avuç atlı, üç yüz kişi, koca bir devletin içinde ne yapabilir?  
— .......  
Kumandan, sarayın önündeki atlılarına, onların etrafında sıkışık nizamda duran dalkılıç piyadelerine bir göz gezdirdi. Sonra atını oynatarak zâbite döndü:  
— Yalnız şu meydanda dört binden fazla askerimiz var! Türkler teşrifatta bir kabalık yaparlarsa hepsini tükürükle boğarız.

Gaydalar sustu. Meydanın gürültüsü birdenbire durdu. Hora zincirleri dağıldı. Ortadan geniş bir yol açıldı. Padişahın gönderdiği Türk, ak bir atın üstünde, yüksek kavuğu ile geliyor, uzun kaftanının etekleri iki tarafında çırpınıyordu. Arkasından tırıs süren sırma takımlı, murassâ kılıçlı maiyeti, yeni gördükleri bu halka gülerek bakıyorlardı. Saraya elli altmış adım kalınca, muhafızların meşhur kumandanı, al atını yine şahlandırarak ileri sürdü. Elçinin tâ önüne geldi. Selamladı. Öyle durdu. Yanına koşan yayan tercümanına söyletti: — Burada attan ineceksiniz. Prensimizin sarayına yürüyerek gideceksiniz. Mütevazi Türk: — Pekâlâ..., dedi. Atından indi. Geniş omuzlu, orta boylu, düşük bıyıklı, esmer bir adamdı. Parlak ipek kaftanının altından görünen sırma kenarlı neftî esvaplarının, murassâ kemerinin ihtişamı, kalın vücuduna pek uymuyordu. Tavrında ince bir çelebilik değil, durgun bir askerlik vardı. Kalabalık meydan üç yüz Türk ile ağzı ağzına dolmuş gibiydi. Teşrifatçı kumandan kabararak tercümanla bir teklif daha etti: — Maiyetiniz burada kalacak. Huzura yalnız gireceksiniz. Türk, tercümana sordu: — Padişahtan getirdiğim şeyleri ben nasıl yalnız taşıyayım? Tercüman, kumandana anlattı. Aldığı cevabı Türkçe tekrarladı: — Maiyetinden üç nefer alacaksın. Onlar da yaya olarak arkandan huzura hediyeleri sokacaklar. — Pekâlâ... — Haydi. .......... Kumandan, atını şahlandırarak "Hurrâ, hurrâ!.." diye kendisini alkışlayan keyifli halka boyun kırarak kabarıyordu. Bu ne zaferdi! İşte koca bir Türk elçisi arkasından yaya geliyordu. Sarayın kapısına gelince attan atladı. Tercüman vasıtasıyla nasıl arkasından huzura  gireceklerini, nasıl selam vereceklerini, nasıl dîvân duracaklarını, elçiyle "meşin kılıflı bir davul, kırmızı torbaya konulmuş bir sancak, ağır bir topuz" taşıyan üç askere anlattı. Kılıcını çekti. Taş basamakları bir hamlede çıktı. Büyük dehlizi geçti. Yeni mâbeyinin adamları, Türk elçisini görmek için kapılara üşüşüyorlardı. Elçi, büyük kavuğunu sallaya sallaya yürüyordu! Adımları hem seyrek, hem ağırdı. Etrafında kendine bakanlara gülümsüyor, selamlar veriyordu. İri, siyah gözleri pek şen, pek parlaktı. Sağ kaşı yukarı kalkıktı. Kavuğunun kenarına dokunuyordu. Kumandan taç salonuna gelince durdu, döndü. Türkler'in kıyafetinde teşrifata mugâyir bir şey var mı gibi dikkatle hepsini bir süzdü. Sonra eliyle elçinin pek öne eğilmiş kavuğunu düzeltti. Biraz geri itti. Prensin huzurunda nasıl eğileceklerini işaretle anlattı. Sonra iki tarafında yalın kılıç nöbetçiler duran yüksek kapı perdesini açtı. Önden girdi. Tahtta oturan prense ilerledi. Yerlere kadar eğildi. Geri çekildi. Dışarı çıktı. Elçiyle üç Türk ortada kaldılar... Yüksek tahtın etrafına bütün Boyar reisleri, meşhur muharipler, voyvodalar dizilmişlerdi. Hepsi ayakta duruyorlardı. Açık pencerelerden giren çiğ bir aydınlık, bu ağır saray sükununa karışıyor, kalabalık salona tenha bir mâbed hali veriyordu. Elçi koynundan çıkardığı beratı öptü. Başına koydu. Sonra yere bakarak ilerledi. Tahtta murassâ bir heykel gibi kımıldamayan prense uzattı. Prensin sağ elinde altın bir asâ vardı. Sol eliyle aldığı bu kağıda gayet ehemmiyetsiz bir şeymiş gibi baktı. Sonra solundaki mavi sorguçlu genç mâbeyincisine verdi. Elçi yine gözleri yerde, geri geri gitti. Ortadaki neferin omuzundan topuzu aldı. Bu gayet ağır, altın yaldızlı, sarı parlak kabzalı bir aletti. Yere bakarak yürüyor, gülümsüyordu. Bütün gözler hareketini takip ediyordu. Tahtın önüne geldi. Ansızın... Gözle görülmeyecek bir çabuklukla havaya kaldırdığı bu müthiş topuzu prensin elmaslı tacına öyle bir indirdi ki...

...Salonun içinde kimse kımıldayamadı. Hepsi olduğu yerde dondu. Taş kesildi. Akabinde kaftanının altından büyük bir kılıç sıyıran elçi, Ulahça: — İşte gördünüz ya... İstiklâl sevdasına düşen asi cezasını buldu! Diye haykırdı. Gözleri alevlenmiş, boyu birdenbire bir dev kadar büyümüş, kavuğu sivrilmiş, düşük bıyıkları kabarmıştı. Boyar reisleri, zırhlı muharipler, kahraman voyvodalar, cansız gibi kımıldamıyorlar, tahtında kafası ezilmiş ölü hükümdarlarına baka baka titriyorlardı. Elçi, salonun ortasındaki askerlerine döndü: — Hasan, dedi, git kapıdan davul çal. Mustafa! Sen de Ulahça nara at. Meydandaki askerler hemen silahlarını bırakıp teslim olsunlar. Sonra sancağı tutana da: — Haydi, çabuk koş, meydana sancağı dik! Emrini verdi. — Başüstüne... — Başüstüne... Diye, üçü de koşarak dışarı çıktı.

Saray halkı karanlık duvarlara yapılmış parlak, muhteşem yldızlı resimler gibi sessiz, sakin, cansız duruyorlardı. Hâlâ içlerinden kimse kımıldanamıyordu.

Mum rengi çehrelerin şaşkın gözleri karşısında, bu tek Türk, kaftanının uzun eteklerini omuzlarına attı. Kılıcını kınına koydu. Uzandı, ezdiği başın üstünde duran kanlı topuzu aldı. Yere bıraktı. Sonra tahttaki ölüyü aşağı çekti. Onun yerine oturdu.

Gayet fasîh bir Ulahçayla:  
— Haydi padişah namına bana itaat edin!  
Dedi...

Sebebi bilinmez bir korkunun şaşırtıcı heyecanıyla dilleri tutulmuş kurt kürklü zengin Boyar reisleri, büyük kılıçlı cesur muharipler, çelik zırhlı voyvodalar, iki dakika evvelki hükümdarlarının daha soğumayan naaşını çiğneyerek, bir anda, bir darbeyle bütün Eflâk'ı zaptediveren bu korkunç Türk'ün elini öpüyorlar, yüzüne bakamıyorlardı.

Sarayın dışındaki muhafızlar da, içerdekiler gibi şaşırdılar. Korkudan kımıldayamadılar. Silahlarını yerlere atıp teslim oldular. Yalnız iki kişinin... Davul çalana "Teşrifatı bozuyorsunuz!" diye kılıç kaldıran sarhoş kumandanla, dolu dizgin kaçmak isteyen birinci zâbitin kelleleri uçuruldu! İşte bu kadar..

# Tos

İki saattir eski geyik postu seccadesinin üstünde "Salâtüselam" çeken Fatma Hanım, tüneğinden inecek bir anaç tavuk edasıyla ayağa kalkınca, birdenbire hiddetlendi. Pencereden gözü nasılsa bahçeye kaçmıştı. — Lahavle velâ kuvvete illâ billâh... Dedi. Başını salladı. "Estağfirullah, estağfirullah" diye geğirdi. İşte yine kocası onun kurbanlığıyla uğraşıyor, bu mübarek hayvanı kızdırıyor, zavallıya tos vurduruyordu.

Fatma Hanım'ın yedi ceddi de hacı-hocaydı. Sarıklılar içinde doğmuş, sarıklılar içinde büyümüştü. Çok sofuydu. Çok zengindi. Bir kassam kızı olan anasıyla bir şeyhülislam oğlu olan babasından kendisine, Erenköy ahalisinin "hesapsız..." dedikleri bir miras kalmıştı. On dönümlük koca bir bahçenin ortasında süslü beyaz bir türbeye benzeyen küçük köşkünde sessiz sedasız oturuyor, gece gündüz ibadet ediyor, paralarını tekkelere, dervişlere, fakirlere, mollalara, öksüzlere dağıtıyordu. Hiç dışarı çıkmıyor: — Gâvurlukları görüp günaha girmekten korkarım, diyordu. Onun nazarında yüzlerini açan, yeldirme giyen, sinemaya, çarşıya, tiyatroya giden her kadın gâvurdu.

Evine yalnız sofu ahbapları, ana dostu ihtiyar kadınlar gelirler; Ramazan, Kandil, Kadir geceleri ölülerinin canı için verdiği ziyafetlerde bulunurlar, meşhur güzel sesli Hafız Saime'ye tanesini beşer liraya okuttuğu mevlûtleri dinlerlerdi. Kırk yaşına yaklaştığı halde henüz Allah ona evlat ihsan etmemişti. Daima kocasını hatırlar: — Elbet bunda bir hikmet var! Der, asla meyus olmazdı. Dualarında hep hayırlı, dindar evlat isterdi. Fakat, fakat kocası... Ah bu, işte onun yegâne derdi idi. Aynı zamanda dayısının oğlu olan bu adam, çekilir şeylerden değildi. Ama "ehline itaat ibadetin en büyüğü" idi. Ne yapacaktı?.. Her münasebetsizliğine tahammül ediyordu. İşte ona varalı hemen hemen yirmi sene oluyordu, daha hiçbir işin ucunu tutmamıştı. Dur bugün, dur yarın... Hep hazırdan yiyor, içiyor, her gün Fatma Hanım'ın bin türlü bahanelerle parasını çekiyor, zavallının irat larında oturan kiracılarla uğraşarak kırmadığı koz, çevirmediği dolap kalmıyordu. Fatma Hanım onun yaptıklarının hep farkında idi.

Fakat renk vermiyor, sabrın, tahammülün de bir ibadet olduğunu bildiği için, büyük bir sevap işliyormuş gibi, sevine sevine susuyordu. Kalbi o kadar temiz, o kadar hayırsever, o kadar sofu idi ki, uzaktan yakından kendini tanıyanlar: "Bu insan değil, bir melâike!" derlerdi. Evinin içinde bile namaz bezini çıkarmaz, kocasını abdestsiz yatağa almaz, "besmele"siz bir şey yapmaz, "Yarabbi şükür!" süz hiçbir işi bitirmezdi. Hatta Erenköy'ün ihtiyar, eski kibar takımından kadınları Balkan bozgunluğunda ona müracaat etmişlerdi. Biliyorlardı ki, o ne isterse Allah hemen verir... — Fatma Hanım, dua et de, bizim asker gâvuru bozsun! Dediler. Lâkin o korktu. Allah'ın işine karışılır mıydı? Çünkü Allah ne yaparsa iyi yapardı. Artık kadınlar sokaklara açık saçık çıkıyorlardı. Camiler cemaatsizlikten çın çın ötüyordu. Küçük çocuklara şapka giydiriliyordu. Yarın ihtimal ki bu zavallı yavrucakları sünnet de ettirmeyeceklerdi. İşte bütün bu fenalıklara kızan Allah, gâvurlarıyla bizim terbiyemizi veriyordu. Zelzele, yangın, kıtlık, zulüm, muharebe, kolera, veba, Allah'ın en meşhur cezalarıydı.

Bize gönderdiği Dört Kitap'ta, kendine isyan eden, emirlerini dinlemeyen milletleri hep bu cezalarla tedip ettiğini söylemiyor muydu? Mütenekkiren -yani tebdil olarak- memleketlerinden geçen melâikelere karşı yaptıkları o rezilce tecavüz için "Lut" kavmini yerlere geçirmemiş miydi? Çok şükür artık melâikeler, evvel zamandaki gibi, yeryüzüne inmiyorlardı. Yoksa şimdi İstanbul'un yerinde yeller eser; öyle ufacık göller değil, nihayetsiz ummanlar dalgalanırdı.

Fatma Hanım kocasının bile "başına, kendisini imtihan için Allah tarafından gönderilmiş" hususi bir bela olduğuna inanırdı. Bu ilahî imtihanda tam numara almak hırsıyla onun her şeyine tahammül ediyordu. Amma iki hali vardı ki... bunları hatırlayınca göğsü daralır: "Estağfirullah, estağfirullah, estağfirullah!" diye tespihinin imamesini çenesine dayar, gözlerini kapar, ateşsiz bir cehennemin, tutuşturup da yakmayan azaplarını duyardı. Evinde anadan ve babadan kalma ihtiyar, emektar bir Arap aşçısından başka, on yedi yaşında, tombul, beyaz, oynak bir ahretliği vardı. Her gün beş vakitte abdest aldırıp dizinin dibinden ayırmadığı, durmadan namaz kıldırdığı, Kur'an okutturduğu bu kıza, kocası iyi bir gözle bakmıyordu. Bunu görüyor, bunu anlıyordu. Kız ne vakit onunla yalnız kalsa hemen alı al, moru mor kesilirdi. Bir gün de ihtiyar aşçısı Nuruşeb: — Size bir şey söyleyeceğim hanımefendi. Bu sabah bahçenin nihayetindeki çam ağaçlarının altında efendinin Makbule'yi sıkıp sıkıp limona çevirdiğini görünce... Diye bir hikâyeye başlarken: — Sus, sus... Diye haykırmıştı. Onun ömründe kulakları böyle fena bir şey işitmemişti. Aşçıyı susturdu. Fakat Makbule'yi de bir daha limon haline geçmemesi için gözünün önünden ayırmaz oldu. Geceleyin yatarken onu üzerinden kilitliyor, sabah namazına kalktığı vakit açıyor, her işi gözünün önünde gördürüyordu.

Kocası dışarıda ne halt ederse etsin, o kadar gücüne gitmeyecekti. Amma evin içinde bu ne korkunç bir rezaletti! Aklına geldikçe yüreği atmağa başlar; "Allah'ım, beni ne dehşetli imtihan ediyorsun!" diye dişlerini sıkar, dudaklarını büzer, yine göz yaşlarını akıtmazdı. Kocası, kızdan sonra kurbanlığa da musallat olmuştu. Buna da canı çok sıkılıyordu. Dört beş sene evvel bir camide vaaz dinlerken, kurban edilecek koyunun daha kuzu iken alınarak evde beslenmesinin sevaplarını duymuş, hemen en iyi cinsten bir kuzu aldırmıştı. Bunu üç sene, bahçede eliyle besledi. Fındık, üzüm, kestane yedirdi. Gün aşırı mis sabunlarıyla yıkadı. Boynuna aynalı tasmalar taktı. Âdeta kurbanlık koyun onun evladı yerine geçti. Büyüdü, semirdi, koca bir koç haline girdi.

Her kurban bayramında onu kesmeye kıyamıyor: "İnşallah gelecek seneye..." diye çarşıdan başka kurbanlar aldırıyordu. Fakat bir gün nasılsa kesecekti. Çünkü bu Allah'a hediye olacaktı. İbrahim aleyhisselam kendi gözbebeği evladını bile Allah'ından esirgememişti. Evvelden her sabah gider, kurbanlığı okşar, koklar, öper, onun yumuşak, kar gibi temiz ve beyaz sırtında Sırat köprüsünü nasıl rahat rahat geçeceğini tahayyül ederdi. Ama şimdi artık bu saadetten mahrumdu. Çünkü kurbanlığın yanına kimse yaklaşamıyordu. Huysuz, münasebetsiz kocası, bu melek gibi uslu hayvanın ahlakını bozmuş, tosa alıştırmıştı. Bahçeye birisi çıktı mı hemen kurbanlık üzerine atılıyor, karnına, kafasına, neresine rasgelirse gerilip gerilip tos vurmaya başlıyor, yere düşürünce bile hırsını alamıyor, düşenin köpek gibi eteklerini, saçlarını ısırıyordu. Artık onu gündüzleri zincirle bahçenin bir köşesine bağlıyorlar, yalnız geceleri el ayak çekildikten sonra bahçeye salıverebiliyorlardı.

İşte ikindi tespihinden sonra seccadesinden kalkan Fatma Hanım, pencereden kocasının yine kurbanlığa tos yaptırdığını görmüştü. Münasebetsiz adam, gecelik entarisinin eteklerini toplamış, koçun başına dokunarak geri geri sıçrıyordu: — Tos, tos, haydi tos... Diye hayvancığı delirtiyordu. Ne vakit kocasını böyle kurbanlıkla uğraşırken görse, aklına zehirli, pis cehennem meyveleri halinde sarı sarı, sıkılmış, mıncığı çıkarılmış birçok limon yığınları gelir, ne vakit sofrada, mutfakta, manavda, gezdiricide limon görse, yüreği çarpmaya başlar, kocasının arsız arsız, "tos, tos, haydi tos..." dediğini işitir gibi olurdu.

Onun Makbule'yle kurbanlığa karşı yaptığını hiçbir türlü hazmedemiyordu. İnkisar da bulunsa Allah'ın hemen kabul edeceğinden emindi. Amma kalbi o kadar iyiydi ki, kimseye kendinden bir fenalık geldiğini istemez: — Estağfirullah; estağfirullah... Diye mırıldanır dururdu. Amma işte bugün... Nasıl oldu bilinmez, birdenbire fena halde hiddetlendi. O kadar ki, söylenmedi bile. Kırk beş yaşında kelli felli bir efendiye şu mübarek hayvanı azdırmak yakışır mıydı? Sonra...

Yine hayaline küfe küfe sıkılmış, çürük limon kabukları döküldü: Ah evet, hele bu hiç dayanılacak bir şey değildi. Bu ne müşkül bir imtihandı? Fatma Hanım bir dakika evvel kalktığı geyik postu seccadesinin üstüne tekrar çöktü. Gözlerinden yaşlar akıyordu. Ellerini kaldırdı. Gözlerini yukarı dikti. Hiddet onu o kadar şaşırtmıştı ki, artık Allah'ın işine karışmış olacağını bile düşünmemişti. — Büyük Allah'ım, şu adamı yaptığı şeylerden fena utandır. Başka bir şey dilemem! Dedi. Kalkmadı, ta güneş batıncaya kadar, akşam namazı vakti gelinceye kadar "Salâtüselam"larına devam etti.

Aradan bir hafta geçmedi...

Yine bir Kandil gecesiydi. Fatma Hanım sofu ahbaplarına mevlit ziyafeti veriyordu. Yemekler yenmiş, kahveler içilmiş, akşam namazı kılınmıştı. Mor bir gündüz gibi parlak, mehtaplı bir yaz gecesiydi. Uzaklardan bülbül sesleri geliyordu. Köşkün alt kattaki geniş sofasına yumuşak şal örneği minderler serilmiş, bahçeye çıkan büyük camekânlı kapının ta karşısına Hafız Saime Molla'nın sedefli ceviz rahlesi kurulmuştu. Davetliler, hizmet eden başörtülü sofu komşu kızlarından maada yirmi yedi hanım idi. Hepsi hacı, hoca, ulema karılarıydı. Hepsinin yemenili başlarında yeşil başörtüleri vardı. Alafrangaya benzer hiçbir şey, hiçbir tuvalet göze çarpmıyordu. Camekânın önüne de beyaz keten örtülü büyücek bir masa konulmuştu. Bu masanın üstünde sürahi sürahi şerbetler, irili ufaklı bardaklar, tabak tabak şekerlemeler, şekerler duruyordu. Saime Molla rahlesine geçti. Kitabını açtı, gözünü ovuşturdu. Öksürdü. Bütün davetliler ruhanî bir fısıltı içinde toplandılar. Duvarlardaki yaldızlı büyük harflerle yazılmış "Garîk-i bahri isyanım/Dahîlek ya Resûlallah" "Tevekkeltü alâllah" ve ilâh... gibi levhalar alev alev yanan lambaların aydınlığıyla sanki daha ziyade büyüyor, daha ziyade parlıyor, bu sade sofaya muhteşem bir mabet şeklini veriyordu. Tam mevlit okunmaya başlanacaktı. Fatma Hanım, hemen bir göz gezdirdi. Makbule meydanda yoktu... Kapının yanında divan duran Nuruşeb'e doğru yürüdü, yavaşça:  
— Kız nerede? Diye sordu.  
— Dışarda.  
— Niçin içeri girmiyor?  
— Bilmem...  
Fakat Fatma Hanım biliyordu. Burnuna keskin bir limon kokusu geldi. Hemen dışarı fırladı. Makbule'yi orada ayakta duruyor gördü:  
— Kız niçin içeri girmiyorsun? Dedi. Makbule ezildi, büzüldü, boynunu büktü:  
— Hiç...  
— Haydi gir içeri diyorum.  
— Giremem ki...  
— Niçin?  
— .....  
— Söyle, niçin diyorum?  
Kız daha ezildi, büzüldü boynunu büktü. Ağlar gibi ıslak bir sesle, kolu ile yüzünü kapayarak, utancından hanıma arkasına dönerek:  
— Kirliyim! Dedi.  
— Hay Allah müstahakkını versin!  
Şimdi Fatma Hanım ne yapacaktı? Mevlit okunan yere bu pis kız sokulamazdı. Günahtı. Yukarıya gönderse efendi var... Sonra Nuruşeb'i de nöbetçi gibi kızın yanına bıraksa... Buna da emniyet edemiyordu. İhtiyar Arap hemen uyuyuverirdi  
— Haydi buradan çabuk bahçeye çık. Sofanın camekân kapısına gel. Kapıyı aralık et. Başını sok. Mevlidi dinle. Vücudun dışarıda kalsın. Gözlerini bana dik. Hiç ayırma. Sakın savuşayım deme. Tövbe olsun seni çok fena ederim, dedi.  
Tekrar sofaya girdi. Yavaş yavaş rahlenin yanındaki minderine gitti. "Estağfirullah, estağfirullah" diye diz çöktü. Bir dakika sonra karşıki camekândaki bahçe kapısı usulca açıldı. Aralığından Makbule'nin başı göründü.

Mevlit başladı:

Allah adın zikredelim evvela Vacib oldur cümle işte her kula

Saime Molla'nın sesi o kadar yanık, o kadar müessirdi ki, herkes hüngür hüngür ağlıyordu. Fatma Hanım da hıçkırıyordu. Fakat gözünü kapının aralığında asılı bir maske gibi duran Makbule'nin suratından da ayırmıyordu.

Yukardaki, aşağıdaki odaların hepsini arayan efendi, Makbule'yi bulamayınca, bahçeye çıktı. Mevlit okunurken dışarda kalabilmek için bu "aybaşı" planını kendisi kurmuştu: — Demek bizimki yutmadı... Dedi. Canı sıkıldı. Ayın on dördü her tarafı beyaz, mor sislerle dolduruyordu. Durdu. Açık başını uzun uzadıya kaşıdı. Bol gecelik entarisinin içine pembe, görünmez bir el gibi ılık bir serinlik giriyor, her tarafını kaşıyor, kaşındırıyordu. Yürüdü. Önünde, gölgesi de siyah, yuvarlak bir halı gibi yürüyordu. Haberi olmadan, gölgesine basa basa, yine kurbanlık koçun yanına gitti. Can sıkıntısından patlayacak gibiydi. Bir haftadan beri hep bu mevlidi düşünmüş, hep bu fırsatı beklemişti. Nihaî bir hareketle koçun zincirini çözdü. Elini göstererek: — Tos, tos, haydi tos... Diye hayvancığı kızdırmaya başladı. Parlak ay, sıcak gece, koça da pek fena tesir etmişti. Gündüzdekinden ziyade hiddetleniyor, şaha kalkıyor, üç dört arşın geri giderek dehşetli toslar vuruyordu. Efendinin elleri acıdı: "Ulan, bu akşam sen de azmışsın galiba!" diye güç bela boynuzlarından yakaladı. Tekrar kazığına zincirledi. Geri döndü. Gerindi. Havaya baktı. Ay katılacak gibi gülüyor, arsız bir mahalle çocuğu yılışıklığıyla sanki ona: "Aldın mı gümüşü..." diyordu. Sıkıntıdan patlayacaktı. Bütün vücudunu bir ateş kapladı. Köşke doğru döndü. Camlı kapıda birisinin durduğunu gördü. "Bu acaba kim, bir misafir mi?" diye düşündü. Fakat misafirin dışarda ne işi olabilirdi? Yavaş yavaş yürüdü. Dalgınlıkla koçun zincirini kazığına iyice takamamıştı. Koç da arkasından gelmeye başladı. Bundan haberi yoktu. Kafasız bir vücut gördü. — Tuhaf şey! Tuhaf şey! diyordu. Daha yaklaştı. Makbule'nin tombul vücudunu, kısa etekli beyaz entarisinden tanıdı. İlerledi. Kalbi çarpıyor, camlı kapının aralığından ruhları ürpertecek derecede latif, mukaddes bir ahenk fışkırıyordu:

Geldi bir ak kuş kanadıyla...........

Elini uzattı. Bu "Kesikbaş" değil, başı kesik, canlı bir vücuttu. Dokundu. Makbule'nin birdenbire ödü kopacaktı. Bağırmak istedi. Fakat hanımın gözü ta gözünün içindeydi. Cesaret edemedi. Nefesi durdu. Titremeye başladı. Efendinin yavaşça:  
— Sus, sus, haydi sus...  
Dediğini duyunca bir anda korkusu geçti. Ferahladı.

Fakat efendinin arkasındaki azgın koç, iyi Türkçe bilmediğinden, Makbule'yi ferahlatan bu sözleri: — Tos, tos, haydi tos... Anlamıştı. Birdenbire fena halde gazaplandı. Geriledi, geriledi. Dört arşından şaha kalkarak, efendinin kaba etlerine öyle müthiş bir tos indirdi ki... şangur, şungur, kapının allı yeşilli bütün camları kırıldı. Paldır, küldür devrilen içerdeki şerbet, şeker masasının üstüne evvela ödü kopan zavallı Makbule, onun üstüne de ne olduğunu anlamayan, gözleri çerçevesinden fırlamış biçare efendi, cansız bir ceset gibi yığıldı. Mevlidin ruhanî tesiriyle ruhları gayri nasutî yüksekliklere uçmuş bulunan davetliler, bu nagehanî gürültüden, korkunç manzaradan birdenbire abdestleri bozulmuş, şaşkın, perişan, avazları çıktığı kadar haykırışmaya başlamışlardı. Duasının bu kadar dehşetle kabul olunduğunu gören Fatma Hanım, hemen şak diye bayılmıştı. Camekânın, camların kırılmasından, kadınların bağrışmalarından daha beter hiddetlenen kurbanlık koç ise hâlâ hızını alamıyor, yere serdiği efendiyle Makbule'nin üzerine çıkmış, birinin eteklerini bırakıp, ötekinin saçlarını yakalıyor, ikisini de didik didik ediyordu. ==Dipnotlar==

# Velinimet

«Aklı, insanin külahında bir çividir. Yumruk yemeden kafasının içine girmez...» Arnavut Meseli

Geçen gün hava ne güzeldi! Logaritmacı Hasan'la Hürriyet Tepesi'ne gittik. Bomonti'ye kadar uzandık. Daha kış uykusundan uyanmamış sisli Kâğıthane'ye, mavi mahmur Haliç’e yükseklerden baktık. Hasan hemen Lâle Devri'ne dair hikmetler yumurtlamağa başladı. Damat İbrahim Paşa'nın rakam bilmediğini, hesap hassasından mahrumluğunu, kırk iki isyanını (1) evvelden tahmin etmek şöyle dursun, hattâ kuşbaşı parçalandığı ana kadar anlayamadığını söylüyordu. - Hocam, bırak şu geçmişi! dedim, hâle bakalım. Bu yaz acaba buralarda eğlenebilecek miyiz? - Kâğıthane'de mi? - Evet. Kır düşmüş kalın kaşlarını kaldırdı. Parlak, siyah gözleri sanki derinlerden dışarı çıktı. Küçük, kalıpsız fesinin altında daha büyük görünen ağır kafasını salladı. - Sen deli olmuşsun! Dedi. - Niçin? - Ayol, bir kuzu, o eski devrin on lâle soğanından daha pahalı. Hasan, on beş sene evvel benim riyaziye hocamdı. Mektepten çıktıktan sonra arkadaşım oldu. Şimdi onunla konuşurken kübistlerin yaptığı tuhaf levhalar karşısında hissettiğimiz o «yarı-bediî, yarı-hendesi» zevke benzer bir tat duyarım. Onun nazarında her şey vazıhtır: Mazi, hâl, istikbal.. Dimağının meçhule tahammülü yoktur. Riyazi mantığıyle en karışık, en mudil şeyleri hemen hallediverir. «İki kere iki dört» kadar katî hükümler verir. Sonra, aynı zamanda çekilmez bir nasihatçidir de... Neden bahsetseniz, sizin, yahut bahse kahraman olanın hayatına ait makul bir tarz bulur. Nasihat şeklinde bir prensip ortaya çıkarır. Yalnızca kızarır. Hâlbuki o'nca bütün hayat yanlıştır! Zira düşünüşünün sistemi tabiatta bulunmaz. Tabiatta onun kafasındaki mantık yoktur, hesap yoktur, rakam yoktur! Bununla beraber ben onun çok tuhaf görünen fikirlerini severim. Mücerret mefhumların haricî hakikat karşısında nasıl «Hacer-ı muallâk» gibi sallandıklarını seyretmek pek hoşuma gider. Bugün de İngilizlerin «amal-i erbaa» bilmediklerini söylüyordu. Muharebeyi uzatan sebep hep yanlış bir hesaptı! Ara sıra itiraz eder gibi görünüyor, tenha yolun esmeyen bir rüzgâr gibi serin serin duyulan temiz havasını kokluyordum. Karşımızdan bir otomobil geldiğini gördük. Şosenin kenarına çekildik. Bu, canlanmış büyük bir piyano kadar parlak, siyah, ihtişamlı bir arabaydı. Yanımızdan hızla geçti. Billur camlarının arkasındaki güzel kadınla genç erkeğin çehreleri tıpkı bir hayal gibi sakin duruyordu. Sonra keskin bir benzin kokusu... Arkamızdan bir ses geldi: - Hasan Bey! İkimiz de birden döndük. Otomobil durmuştu. Kesik bıyıklı esmer bir genç bize doğru gülerek koşuyordu. Ben kim olduğunu sormaya vakit bulamadım. Siyah paltosunun şıklığı, yakasındaki ağır «lutr»un parlaklığı, sanki beni manyetize etmişti. Geldi. Hasanın ellerinden tuttu. İki eliyle sarsarak sıktı. - Nasılsın velinimetim! - Çok iyi... - Ne arıyorsun buralarda? - Biraz hava alıyoruz, işte... Ben şaşırmıştım. Birdenbire Logaritmacı'nın ana tüyleri dökülmüş kahverengi paltosuna bakarak bu gencin nasıl velinimeti olabileceğini düşündüm. - Nasıl, bir milyon yapabildin mi? - Yapamadım vallahi... - Ey, şimdi ne kadarlıksın? - Ehemmiyetsiz vallahi... dört yüz bin liram var. Kulaklarıma inanamayacağım geldi. Hasan zaviyeleri görünen mustatil bir gülüşle çırpınıyordu. Soğukkanlı: - Çalış, daha çalış! Dedi. - Çalışacağım. Sen, benim velinimetimsin. Sana ölünceye kadar minnettarım. - Estağfurullah. - Vallahi her yerde, herkese söylüyorum. Sen bana akıl vermeseydin, ben yine eskisi gibi sürünecektim. - Canım. Senin talihin varmış! Ben sana para yerine nasihat verdim. Bir söz söyledim. Bir sözden ne çıkar? - Bir söz amma, pîr söz... Hayretten aptallaştım. Dilim tutuldu. İlerde duran otomobilin arka penceresinde bir kadın hayalinin kımıldadığını fark ediyor, şık gencin Logaritmacı ile konuştuklarını dinliyordum. Kadın nişanlısıymış. Kimin nesi olduğunu söyledi: İstanbul'un en kibar, en eski, en yüksek bir ailesinin ismini işitiyordum. Otomobilini üç bin liraya almış... Susuyor, bakıyordum. Boyu uzundan biraz kısaydı. Yahut semizliğinden öyle görünüyordu. Gülerken azıdişlerinin platin kaplı olduğu gözüme çarptı. Esmer cildi, çok rahat içinde yaşayan her mesut zengininki gibi taptazeydi, parlaktı. İnce kaşlarının altında gülen gözlerinin içinde, vakıa büyük bir zekâ şulesi tutuşmuyordu. Fakat o kalın, o küt burun... Sahibinde tos vuracak bir koç azmi olduğunda şüphe bırakmıyordu. Hasan'la vedalaştı. Bana da başıyla bir selâm verdi. Bekleyen otosuna hızla yürüdü. Arkasından bakıyorduk. Ben hâlâ kendimi toplayamıyor, bir şey soramıyordum. Oto büyük bir gürültü ile kaçtı. - Bu kim? dedim, sen bu dört yüz bin liralık adamın nasıl velinimeti oluyorsun? - Anlatayım. Diye güldü. Tenha şosede deminki gibi, yine yavaş yavaş yürümeye başladık. - Riyaziyede olduğu gibi hayatta da bazı mütearifeler vardır. Doğruluklarına hiç şüphe yokken yine kimse iltifat etmez. Meselâ «herkes kendi işini kendi kendine görürse, kimsenin kimseye ihtiyacı kalmaz!» - Allahaşkına hikmeti bırak, diye yalvardım, bu zengin kim, onu anlat. - İşte onu söyleyeceğim. - Söyle bakalım. - Bu genç, benim, Selanik'teyken uşağımdı! Dedi. Durdum, bir adım geri attım. - Uşağın mıydı? Diye haykırdım. Logaritmacı her vakitki soğukkanlılığıyle, elleri arkasında, yürüyerek cevap verdi: - Evet, uşağımdı. Ben Balkan Harbi'nden sonra İzmir'e gitmiştim. Bir sene sonra İstanbul'a geldim. Bir gün Meserret Oteli'nin önünden geçiyordum. Bir de baktım bizim Ahmet... öpmek için elime sarıldı, üstü başı dökülüyordu. Ne yaptığını sordum. «Hiç, dedi, boştayım.» Sonra sıkılarak benden bir mecidiye istedi. Tekrar niçin, ne sebeple para vereceğimi sordum. «Vallahi iki gündür açım, bari beş kuruş ver. Bugün karnımı doyurayım.» Dedi. O vakit düşündüm. Bu çocuk da birçok muhacirler gibi serserileşmişti. İnceden inceye istintaka çektim. «iki gün evvel karnını doyuracak paran var mıydı?» diye sordum. «Evet» dedi.. Üç gün evvelisinden bir gün sonra aç kalacağını niçin düşünmediğini, sordum. Cevap vermedi, yere baktı. O vakit ona Koton'u hatırlattım. - Koton ne? Diye sordum. - Koton, benim Selanik'teki küçük köpeğimin adı... Bu köpekte en bariz, en kuvvetli seciye «istikbal endişesi» idi. Kendine verilen kemiklerin beşte birini bile yemez, gider, bahçenin tarhlarına gömer, saklardı. Evet, en bol, en neşeli zamanda bile «yarın» kendisine bir şey veremeyeceğimiz ihtimalini aklından çıkarmaz, hep «yarın»ı düşünürdü. Kemikleri saklamak için çiçekleri, tarhları bozuyordu. Çok dövdük, azarladık. Bir türlü bu endişesinden vazgeçiremedik. Ahmet'e: «Senin Koton kadar hissin yok muydu?» dedim. Utandı, başını daha beter eğdi, önüne baktı. Cebimden bir kart çıkardım. Eyüp'te bir ip fabrikasının müdürü sınıf arkadaşımdı. Ona bir tavsiye yazdım. «Al bunu, götür. Çalış, para kazan, ye... Kimseden para isteme!» dedim. Teşekkür etti. Amma yine yakamı bırakmadı. «Bari iki kuruş verin. Şimdi ekmek peynir alayım. Açlıktan ölüyorum.» Azıcık daha verecektim. Elimi cebime götürdüm. Birdenbire bu lüzumsuz merhametle kuvvetli bir gencin azmini kıracağımı düşündüm. Evet, sırf merhametle yapılmış bir muavenet, halis bir cinayetten başka bir şey değildir. Kime acıyıp «bir sâyin mukabili olmayarak» muavenet edersek, onun azmini, iradesini dumura uğratıyoruz demektir. Elimi hızla cebimden çektim. «Şuradan sap, soluna ilk gelen sokağa gir. Biraz yürü. Orada Kosova Oteli vardır. Sahibi ahbabımdır. Benden selâm söyle, de ki: «Ben şimdi bütün oteli süpürmeğe, yıkamağa hazırım. Bütün apteshaneleri temizleyeyim. Bana beş kuruş ver.» O, bu pazarlığa razı olur. Razı olmazsa, ben Valde Kıraathanesi'ndeyim. Gel. Beni gör. Sana bugün ekmek parasını getirecek başka bir iş bulurum.» dedim. Reddedemedi. Açlığı yüzünden belliydi. Gözlerinin altı simsiyahtı. Dudakları bembeyazdı. Baygın baygın bakıyordu. Yarım saat kadar Valde Kıraathanesi'nde bekledim. Gelmedi. Ona altı gün sonra rasgeldim. Hemen elime sarıldı. Öptü «Eğer bana o gün ekmek parası verseydin, ben fabrikaya gitmeyecektim. Bana ağır bir iş gördürdün, amma çalışmayı öğrettin. Çok minnettarım!» dedi. Çabucacık ilerlediğini, ustabaşı olduğunu, günde yarım lira aldığını söyledi. Zaten müstaitti. Yalnız azminin uyanması için «Hanya'yı» Konya'yı anlaması icap ediyordu, ben ona anlattım. Her rasgelişimde onu daha değişmiş, daha akıllanmış, daha kanlanmış, daha semizlenmiş gördüm. Sonra sâyini karşılık koyarak bir zengine ortak oldu. «Fanila, çorap» fabrikası açtı. Sonra muhtelif dairelere müteahhit oldu. Faaliyetleriyle doğruluğuyle, namusuyle kendini tanıttı. Zenginleştikten sonra kibirlenmedi de... Şimdi beni nerede görse koşar, «velinimetim» der. Sermayesinin esası olan azmi benden aldığını hiç unutmaz... Yavaş yavaş yaklaştığımız Hürriyet Tepesi'nin yapraksız ağaçları, uzak kıtlık kâbuslarını hatırlatan çelimsiz, siyah, gamlı iskelet gölgeleri gibi görünüyordu. Logaritmacının azme, iradeye, saye, hesaba dair söylediği hendesî hikmetleri dinlerken, artık göğsümün, görünmez kesme kaya yığınları altında ezildiğini duyuyordum. Rüşdiye tahsili bile görmemiş yalınayak, başıkabak, bir uşak yamağının ip ameleliğinden ustabaşılığa, ustabaşlıktan fabrikatörlüğe, fabrikatörlükten müteahhitliğe sıçradığını, müteahhitlikten otomobille milyonerliğe doğru yürüdüğünü görmek -bilmem niçin- bana acı geliyordu. Kıskanıyor muydum?        Evet, kıskanıyor muydum? Amma niçin? Amerika'nın en meşhur, en büyük iktisat kralları da on parasız işe başlamamışlar mıydı? Muhakemem, mantığım hissiyatımı düzeltemiyordu. Uzandığı ciğerin karşısında «pis!» diye yalanan sıska bir kedi kadar zavallıydım. Kendimi tutamadım. Sanki bu zenginliğe, bu saye hiç ehemmiyet vermiyormuşum gibi, istihkarla yüzümü ekşittim. Başımı salladım. - Yeni zengin işte... Dedim. Logaritmacı durdu. Derin siyah gözlerini açtı: - Ne o? Beğenemiyor musun? diye güldü, kuruntuyu bırak. Zenginlik bu! Şarap değil yavrum! Eskisi de bir, yenisi de bir!

==Dipnotlar== (1)  Patrona Halil Ayaklanması (1730).

# Vire

İki senedir Goça taraflarını alan, talan eden on altı bin kişilik Türk ordusundan şimdi, bu kalede yadigâr gibi, yüz elli asker kalmıştı. Onlar da işte iki yazdır padişahın gelmesini bekliyorlardı. Mutlaka alınacak olan "Kızılelma"nın yolu buradandı. Sonbahar başında bir gece Hamza Bey'in ulaklarından bir genç gelmişti. Ondan padişahın Acemistan hudûdunda olduğunu öğrendiler. Vâkıâ cephaneleri çoktu, silahları mükemmeldi. Lâkin sadece üç dört aylık erzakları vardı. Ne yapacaklardı? "Tata"ya giden geçitler kapalıydı. Etrafta her nevi kuşlar uçuşuyor... Ama, hiçbir kervan geçmiyordu.

Yüksek burcun demir saçaklı küçük penceresinden ufukları ormanlarla, dağlarla çevrilmiş ıssız vadiye dalgın dalgın bakan Barhan Bey:  
— Allah kerim...  
Diye başını salladı. Böyle sabahleyin erkenden karşısına dikilen, ihtiyar sipahi zâbiti Mahmud Ağa, çok endişede idi. Daha erzak bitmeden Adelsberg, Riskinç, yahut Breg kasabalarına bir akın yapılmasını teklif ediyordu:  
— "Grobing" çok zengindir. Ah, orasını vurabilsek...  
Dedi.  
— Ey, kaleyi ne yapacağız?  
— İçinde elli kişi muhafız bırakırız...  
— Sonra yüz kişiyle nasıl akın ederiz?  
— Basbayağı...  
— Fakat elli kişi bu kaleyi tutamaz.  
— Biz on gün içinde döneriz.  
— On gün değil, on saat içinde neler olur...  
Barhan Bey, pek çok düşünen, hiç faka basmayan, akıllı cesurlardandı. Küçük, siyah gözleri daima karanlık bir inin derinliklerinden bakar gibi parlardı. Ne asildi, ne de kul.. Şehzâde Beyazıd'ın bütün Anadolu'yu hayrette bırakan meşhur pehlivanı kahraman Kuduz Ferhad'ın üvey kardeşiydi. Lâkin ona hiç benzemezdi. Kuduzun çelik zırhları kağıt gibi yırtan pençeleri, kalın demir kalkanları bir dokunuşta delen yumruğu, çeki taşını pamuk torbası gibi zahmetsizce kaldırıp, yirmi adım öteye atıveren bazusu Barhan Bey'de yoktu. Barhan Bey'in kısa vücudu, yuvarlak omuzları üstünde, hatta biraz sakil görünen kocaman bir başı vardı. Ağırlığından daima bir tarafa eğilmiş gibi duran bu başın içinde sönmez ateş, sönmez bir zekâ alevi tutuşuyordu. İşte bu mukaddes alev, onu daha pek genç iken en namlı kumandanların sırasına yükseltti. Yıllarca süren muharebenin hudutsuz meydanındaki en son nokta, en ileri kale, padişahın emriyle ona emanet edilmişti. Ordu gelinceye kadar ne yapıp yapıp, bu ücra kaleyi bırakmamak vazifesiydi. Halbuki akın için askerinden bir kısmını ayırsa, düşman hemen haber alacak, fazla kuvvetle kaleye yüklenecekti. Hem kuvveti ikiye ayırmak hiç münasip değildi. Zaten kuvvet de ne idi? Yüz  elli kişi...  
Sipahi Mahmud tekrar sordu:  
— Erzak bitince ne yapacağız?  
— Allah kerim...  
— Ama, kışın akın güç olur, beyim.  
— Allah kerim...  
— Nasıl?  
— Mesela bakarsın ki ganimet ayağımıza gelir.  
— Ya ganimet gelmeden bir muhâsaraya uğrarsak?  
— Yine Allah kerim...  
— ...  
Mahmud Ağa'nın hakkı vardı. Burası ummanın ortasında kaybolmuş öksüz bir ada gibiydi. En yakın kasabaya ancak iki üç günde gidilebilirdi. Kış bastırırsa erzak tedariki imkansızdı. O vakit kaleyi bırakıp mutlaka Tata'ya çekilmek icap edecekti. Halbuki yüz elli kişiyle günlerce düşmanın, martolosların, oskofların, morlokların, haydukların arasından nasıl geçilirdi? Mademki padişah henüz Rumeli'ye geçmemişti, artık bu yaz büyük ordu gelmeyecek demekti. Kırk senedir düşman karşısında saç, sakal ağartan Mahmud Ağa, çok itimat ettiği genç kumandanını yine biraz toy buluyordu. "Tevekkül" ile iş bitmezdi. Sıkılarak:  
— Böyle bekleyip durmaktan ne çıkar?  
Dedi. Barhan Bey güldü:  
— Merak etme Mahmud Ağa, Allah kerim...  
— Ama...  
— Allah kerim, diyorum ya...  
— ...  
Tam bu esnada açık kapıdan, kısa boylu, pala bıyıklı, tıknaz bir çavuş girdi.  
— Beyim, dedi, sağ kuledeki nöbetçi, uzaktan bir kervan gördüğünü haber verdi. Gittim. Baktım. Pek kervana benzetemedim. Galiba asker...  
— Çok mu?  
— Üç, dört yüz kişi kadar...  
Mahmud Ağa:  
— Hayduklar olmalı.  
Diye mırıldandı. Dayandığı pencereden hızla doğrulan Barhan Bey:  
— Bakalım.  
Dedi. Odadan fırladı. Mazgallardan sızan hafif bir ziyâyla aydınlanmış dar merdivenleri üçer üçer atladı. Mahmud Ağa'yla çavuş da arkasından koşuyorlardı. Kuleye çıkınca sabah güneşinin henüz dağılmadığı hafif sislerle örtülü ufka dikkatle baktı:  
— Şövalyeler.. dedi; bizi muhâsaraya geliyorlar.  
İyi görmeyen Mahmud Ağa sordu:  
— Nereden anladınız?  
— Mızraklarından, bayraklarından... Yanlarında iki de top var...  
— Şimdi ne yapacağız?  
— Allah kerim... Acele yok. Düşüneceğiz.

İki saat sonra şövalyelerin gürültücü ordusu kaleyi iyice sarmıştı. Barhan Bey, demir kapıyı kapattı. Müdafaadan başka çare yoktu. Zira kalenin medhali pek dardı. Huruç hareketi imkansızdı. Hafif bir yaylım ateşi bile buradan kimseyi çıkartmazdı. Herkes silah başında tetik duruyor, yirmi kişi, hiç dinlenmeden palanganın iç avlusundaki büyük dibekte evvelce hazırlanmış kömürleri dövüyordu. Bu kömürlerin dövülmesi bitince kumandan, cephaneliği açtırdı. Kapının önüne gelen ilk on iki çuvalın üst taraflarından birer karış kadar barut aldırdı. Başka bir çuvala koydurdu. İçlerinden barut alınan çuvalların üst taraflarını da dövülen kömür tozlarıyla doldurttu. Ağızlarını yine eskisi gibi bağlattı. Sonra sarnıcın başına koştu. Yanından hiç ayrılmayan genç silahtarına:  
— Benim odamda, kapının arkasında iki büyük kutu var. Haydi, çabuk onları getir.  
Dedi. Yukarıdan koşa koşa gelen sipahi zâbiti Mahmud Ağa kumandana yaklaştı.  
— Hücum başlayacak, beyim, emret, topları dolduralım!..  
— Hayır, toplara lüzum yok.  
— Onlar toplarını kurdular.  
— Kursunlar.  
— Ey, biz ne yapacağız?  
— Bekleyeceğiz. Gaazîlere söyle, ben yukarı gelinceye kadar ateş etmesinler.  
— Başüstüne.  
Mahmud Ağa ayrılmadan silahtar kutuları getirdi. Barhan Bey kendi eliyle kutunun birini açtı. Sarnıca boşalttı. Bu siyah bir tozdu. Silahtara:  
— Elindekini de git, kuyuya boşalt.  
Dedi. Sonra anlamadan bakan Mahmud Ağa'ya güldü:  
— Artık serbestçe "Vire"yi konuşabiliriz.  
— Ne? "Vire"yi mi?  
— Evet.  
— Sahi mi söylüyorsunuz, beyim?  
— Sahi ya.  
— Cephaneliğimiz barut dolu, silahlarımız mükemmel, gaazîlerimiz hazır, üç aylık yiyeceğimiz de var. Biz nasıl teslim oluruz?  
— .....  
— Kalede kimse buna razı olmaz, beyim.  
— Nene lazım. Sen şimdi benimle gel, yukarı çıkalım.  
Barhan Bey, gülümseyerek, bedenlere çıkan taş merdivene doğru yürüdü. Biliyordu ki Türk askeri çok itaatlidir. Kumandanları ne söylerse hemen yaparlar. Fakat yalnız bir emre karşı itaat göstermezler. O da "teslim emri"dir. Türk, ölmeyi teslim olmaya tercih eder... Evet, "Vire"ye kimse razı olmayacaktı. İçinden: "Ama, kandırırım..." dedi. Kalenin üstüne çıkınca Mahmud Ağa'ya döndü:  
— Zâbitleri, bölükbaşıları, çavuşları çağır. Buraya gelsinler, kendileriyle konuşalım. Haydi...  
Emrini verdi. Sonra beden siperlerini dolaştı. Diz çökmüş dışarıya bakan askerin sırtından şövalyeler ordusunu tetkik etti. Üç yüz kişiden fazla idiler. Formaları, silahları muntazamdı. Hiç çapulcuya filan benzemiyorlardı. İki dakika sonra zırhlarını giymiş, tolgalı zâbitler çavuşlar etrafına toplandılar. Barhan Bey bir elini, padişahın son defa ihsan ettiği murassâ kılıca dayamıştı. Ağır, levent bir sükûn ile:  
— Ağalar, dedi, görüyorsunuz kaleyi saranlar bizden çok. Belki bizim iki mislimiz... Müdafaada kalsak üç aylık erzakımız var. Çok dayanamayız. Halbuki bu sene bize imdat gelmesinin imkânı yok. Huruç da edemeyiz.  
— Niçin?  
— Niçin?  
Diye mırıldandılar.  
— Bakınz niçin? Bu kaleyi biz yapmadık. Vaktiyle düşmandan "Vire" ile aldık. Düşman, galiba burasını yalnız müdafaa için yapmış, çünkü hem kapısı çok dar, hem de bir meydana doğru açılmıyor. Kapının karşısındaki, şu gördüğünüz tümsekte, elli kişi yaylım ateşi açsa, dışarıya kimse çıkamaz.

İhtiyar Mahmud Ağa titriyordu: — Biz teslim olmayız!.. Dedi. — Hayır, teslim olmayacağız. Vuruşmak için bir meydan bulacağız. Buna razı mısınız? — Razıyız, razıyız... — Bana emniyetiniz var mı? — Var, var. — O halde ben düşmanla "Vire"yi konuşacağım. Maksadım teslim olmak değil, muharebe etmektir. Varın yoldaşlara söyleyin. Sakın yanlış fikirlere kapılmasınlar. Benim emrimden dışarı çıkmasınlar. — Başüstüne, başüstüne... Diye ayrılan zâbitler, bölükbaşıları, siperin arasındaki askerin yanına koştular. Mahmud Ağa, Barhan Bey'in yanında kaldı. Tercümanı çağırttılar. Asabî adımlarla kapının üstündeki yüksek sipere gittiler. Barhan Bey, tercümana: — Sor bunlara, ne istiyorlar bizden? Dedi. Tercüman bağırdı. Şövalyelerin saflarından gayet düzgün bir Türkçe ile cevap verdiler. — Biz kaleyi istiyoruz, teslim etmezseniz zorla alacağız. Artık tercümana lüzum kalmadığını gören, Barhan bey, bağırarak kendi konuşmaya başladı: — Pekâlâ... Kaleyi size bırakalım. "Vire"yi söyleşelim. . . . . . — Söyleşelim. — Biz burada yüz elli kişiyiz. Hepimiz harp eriyiz. İçimizde çoluk çocuk, kadın, ihtiyar yok. Siz hücumla bu kaleyi bizden alamazsınız. Cephaneliğimiz ağzı ağzına barut dolu. Erzakımız var. Silahlarımız mükemmel. Adamlarınızdan birini gönderin. İçeri girsin. Biz de size bir rehin veririz. Adamınız cephaneliği, silahlarımızı, askerlerimizi gözüyle görsün, yalan mı söylüyoruz, sahi mi? Anlasın. Sonra "Vire"yi konuşuruz. Aralarında bu teklifin tercümesi biraz uzun sürdü. Şövalyeler kabul ettiler. Kapıdan silahsız bir düşman askeri içeri alındı. Bir sipahi de rehin olarak dışarı verildi. Barhan Bey, kendi eliyle bu askere kalenin her tarafını gezdirdi. Dolu cephaneliği, topları, silahları, askeri ayrı ayrı gösterdi: — Haydi yiğidim, git, kumandanlarına gördüklerini aynıyla söyle... Dedi. Bu asker dışarı bırakılarak, verilen sipahi de içeri alındı. Yarım saat geçti... Barhan Bey siperde bekliyordu. Henüz cevap verilmemişti.

On dakika daha geçti.

Deminki Türkçe ses ansızın sordu:  
— "Vire" için şartlarınız ne?  
Barhan Bey bağırdı:  
— Biz iki senedir burada bekliyoruz. Artık ordumuzun gelmeyeceğini anladık. Bize müsaade edin. Silahlarımızla dışarı çıkalım. Atlarımızı, cephaneliğimizi, erzakımızı size bırakacağız. Aşağıya, memleketimize doğru çekilip gideceğiz.  
. . . . . .

Şövalyeler, bu teklifi kısa bir müzakereden sonra kabul ettiler. Cephaneler, toplar, atlar, erzak ellerine geçtikten sonra muharebeye, hücuma ne hacet vardı? Zaten bu yüz elli Türk yolda açlıktan ölecekti. Tata'ya kadar yollarda binlerce martolos kaynıyordu. Kaleyi bırakmak, sahipleri için muhakkak ölüm demekti. Fakat... Barhan Bey'in sesini yine duydular: — "Vire"yi bozmayacağınıza nasıl teminat vereceksiniz? — ... Şövalyeler, namusları üzerine söz vermek istediler. Barhan Bey bunu kâfi görmedi. Vâkıâ onlar hakikatte "Vire"yi bozmasını düşünmüyorlardı. Türkler'den zorla muharebe ile kale almanın ne çetin şey olduğunu hepsi bilirdi. — Nasıl teminat isterseniz veririz, dediler.

Barhan Bey istediğini söyledi:  
— Biz yüz elli kişiyiz. Siz üç yüzden fazlasınız. Evvela iki kısma ayrılınız. Bir kısmınız bütün silahlarını öteki kısma versin. Silahlarımızın adedi müsâvi olsun. O vakit emniyetle kapıdan çıkarız. Sonra biz çıkınca evvela silahlılarınız, sonra silahsızlarınız kaleye girsin. Biz size birçok cephane, top bırakıyoruz. Siz de toplarınızı içeri alın. Yalnız şu karşıdaki tepelere varıncaya kadar kaleden dışarı çıkmayacağınıza söz veriniz.  
. . . .

Bu teklifin müzakeresi de epeyce sürdü. "Vire"yi zaten bozmayı hiç düşünmeyen şövalyeler, bu teminatı vermekte bir beis görmediler. Sert kumandalarla askeri ikiye ayırdılar. Bir kısmını silahsız bıraktılar. Kalenin açılan kapısından yayan olarak en önde Barhan Bey çıktı. Arkasından, tüfekleri, okları, kalkanları, tolgaları, zırhları parlayan, kaplan postlarına bürünmüş yüz elli cengâver göründü. Silahların, kılıçların şıkırtısından başka hiçbir sada işitilmiyordu. Kapıdan iki yüz adım kadar uzaklaştılar. Düşman askeri, boş kalan kaleye sevinç naraları, zafer hurrâları atarak giriyorlardı. Hemen burcun kulesine bayraklarını çektiler. Çifte katırlara yüklü toplarını da dar kapıdan soktular. Dışarıda, yalnız ağırlıkları, cephaneleri, mekkâre leri kalmıştı.

Barhan Bey ansızın haykırdı:  
— Mahmud Ağa, çabuk tümseği tut...  
Kaleden elli kişi ile bir anda kopan Mahmud Ağa, kale kapısının ta karşısındaki tepeye fırlayıverdi. Barhan Bey'in kumandasıyla yalınkılıç kırk kişi de, sol taraftaki çalılık kenarında duran düşman cephanesinin, mekkârelerinin üstüne canlı bir çığ gibi düştü.

Kaleyi alan galipler, aman verdikleri mağlupların bu garip hareketlerinden evvela bir şey anlamadılar. "Ne oluyor?" diye bedenlerden bakışıyorlardı.

Türkçe sordular:  
— İşte biz kalenin içindeyiz... Neye gitmiyorsunuz?  
Barhan Bey'in kahkahası cevap verdi:  
— Sizi muhâsara ettik. Hemen teslim olun!  
— ! ! ! !  
— ....  
— ? ? ? ?  
Derin bir sükût...Sonra müthiş bir uğultu... Bedenlerin siperlerinde koşuşmalar... Küfürler, kumandalar... Barhan Bey'in bulunduğu tarafa oklar atılmaya başladı. Şaşkın galipler, dışarıdaki ağırlıklarının, cephanelerinin zaptolunduğunu, yük muhafızlarından kesilmeyenlerin bağlanarak esir edildiğini görünce, bütün bütün şaşırdılar. Kale kapısından dışarı atılmak isteyenleri, tümsekteki Mahmud Ağa'nın sipahileri okla, kurşunla birer birer deviriyordu.

Gürültü içinde Barhan Bey'in sert sesi tekrar işitildi:  
— Bre şövalyeler! Yazık size! Son kurşunlarınızı atıyorsunuz, cephanelerinizi zaptettim. Sonra ne yapacaksınız. Tüfekleriniz ellerinizde çoban sopası gibi kalacak. Bu dar kapıdan çıkamazsınız. Kim isterse denesin. Gelin, teslim olun, "Vire"yi konuşalım...  
. . . . .

Yavaş yavaş silah sesleri kesildi. Ama bir cevap çıkmadı. Bir dakika evvelki galiplerin bu acıklı, bu şaşkın sükûtuna parça parça cevap verir gibi, Barhan Bey fasılalı narasına devam etti: — Bıraktığım toplar boştur. Cephanelikte barut diye adamınıza gösterdiğim çuvallar kömür tozu doludur. İsterseniz gidip bakın... . . . . .

— Kuyu ile sarnıcın suları da zehirlenmiştir. İsterseniz alınız bakınız, ölmek isterseniz bir damla tadınız. . . . . .

— Şimdi "Vire"yi reddedip teslim olmazsanız, üç gün sonra susuzluktan öleceksiniz. Yahut yine teslim olacaksınız. O vakit aman vermem... . . . . .

— Düşünün, taşının. Avucumun içindesiniz. Bir yere kaçamaz, kurtulamazsınız." . . . . .

Kalede bir gürültüdür gidiyordu. Dar kapının önünde, zırhlı oklar, çatal kurşunlarla yaralananlar acı acı inliyorlardı. Siperlerde koşuşuyorlar, topları yerlerinden oynatıyorlar, eğilip asabî, korkunç nazarlarla aşağıya, deminden "Vire" ile bıraktıkları müthiş mağluplarına bakıyorlardı. Bir saat sürmedi; kalede akıl, muhakeme, şaşkınlığa galebe çalar gibi oldu. Sarnıçla kuyunun simsiyah suyunu, cephanelikteki açılan çuvalların kömür tozlarıyla dolu olduğunu gören şövalyeler vaziyetlerinin vahâmetini takdir ettiler. Su yoktu. Barut yoktu. Kalenin dar kapısından çıkmak imkânı yoktu. Öyle korkunç bir kündeye gelmişlerdi ki... Artık "Pes" demekten başka çare yoktu!

Biraz evvel şövalye saflarının arasından bedenlere teslim teklif eden Türkçe ses, bu sefer bedenlerden aşağıya, pusulara yatmış yeni muhâsır lara haykırdı:  
— Kaleyi size bırakacağız, "Vire"yi konuşalım.  
. . . . .  
— Konuşalım...  
— ...  
Şövalyeler, şart olarak silahlarıyla beraber cenûba gitmelerini teklif ediyorlardı. Barhan Bey kabul etmedi. Barutsuz, susuz, bir kale ne işe yarardı? Bu kaleyi alıp içine girmek zaten tuzağa düşmek demekti. İşte buna kendileri bir misaldi! Şövalyeler, Barhan Bey'e şartlarını sordular. Onun şartları gayet mâkul, gayet basitti. Kalede kapalı kalanlar tüfek, ok, kılıç, kama, meç, topuz, kalkan, piştov gibi ne kadar silahları varsa hepsini bedenlerden aşağı atacaklardı. Barhan bey bunları sayıp topladıktan sonra kalenin içinde herkesin silahsız kaldığına emniyet getirirse bir "şart" ile canlarını bağışlayacaktı.  
— O şart ne?  
Diye haykırdılar.  
— Silahlarınızın hepsi aşağıya atılmadan bu şart söylenilmez.  
. . . . .

Kalede kapalı kalanlar, Barhan Bey'in karşısında, ümitsiz bir inatla üç gün daha dayandılar. Geceleri dar kapıdan çıkmaya çalışıyorlardı. Fakat aksi gibi ayın on dördü idi. Her taraf gündüzden daha aydınlıktı. Sipahiler, dar kapıdan kayan her gölgeyi hemen deviriyorlardı. İçeride dudaklar kurumuş, susuzluk cana tak demişti. Cephaneleri de tükeniyordu. Sonlarını, akıbetlerini düşünmeye başladılar. Nihayet "Vire" şartını anlamak için silahlarının hepsini kalenin bedenlerinden aşağı atmaya karar verdiler. Dördüncü günü sabahı burcun etrafında ansızın bir ok, yay, kılıç, kalkan, tüfek, meç yağmuru başladı. Bu yağmur beş dakika kadar sürdü. Yeniçeriler, sipahiler, azepler için  bu silahları kucak kucak toplayıp tümseğin arkasına taşıdılar. Barhan Bey, hepsini dikkatle saydırdı. Denk denk bağlattı. Tam üç yüz kişinin silahları olduğuna kanaat getirdi. Sonra askerleriyle beraber kalenin kapısına doğru ilerledi. Bağırdı: — Hepiniz iç avluya toplanın! Silahsız düşman, kendi lisanlarıyla tekrarladıkları bu emre bir koyun sürüsü usluluğu ile itaat etti... Barhan Bey, yalınkılıç sipahilerle kapıdan girdi. Avlu dolmuştu. İstese şimdi hepsini kılıçtan geçirebilirdi. Ama, hayır... Ona kafa değil... Erzak lazımdı. — Şövalyelerle asilzadeler bu tarafa ayrılsın. Dedi. Parlak zırhlı, tüylü tolgalarının etrafında altınlı siperleri göze çarpan cesur şövalyeler, gümüş tokalı kemerler bağlamış zengin asilzadeler bir tarafa toplandılar. Sayıldı. Bunların hepsi elli kişiydi. — Kumandanınız kim? Diye sordu. İçlerinden iri, kırmızı sakallı bir adam ilerledi. Yüzü sapsarıydı. Bu, meşhur muhariplerden Petonleç idi. Uğradığı susuzluk, cephanesizlik vartasından ziyâde, vuruşarak namuskârane ölmek ihtimalinin adem i onu bitirmişti. Barhan Bey, tercüman vasıtası ile dedi ki: — Asilzadelerle şövalyeleri rehin gibi kalede tutacağım. Sen iki yüzelli silahsız askerinle var, git, bir ay içinde bana mutlaka bin çuval un, beş yüz kazevi pirinç, beş yüz koyun, iki yüz tulum yağ, yüz tulum peynir, yüz tulum pekmez getireceksin. Bir ay içinde bu istediklerim kaleye gelmezse, rehin tuttuğum elli kişiyi keseceğim. Prens Petonleç, daha beter sarardı, dudaklarını ısırdı. Bu şart, felaketin en müthiş tarafıydı. Barhan Bey tercümana: — Sararıyor, sor bakalım, çok susamış mı? Dedi. Petonleç cevap vermedi. Barhan Bey'in emriyle sipahiler avlunun ortasındaki kuyuya koştular. Bir kova su çektiler. Kovayı getirince, doldurulan kupayı evvela Barhan Bey içti: — Korkmayınız, ne sarnıç ne de kuyu zehirlidir, dedi, ben sizi aldatmak için yalnız içine biraz siyah boya attım. Siz tatmaya korktunuz. İnsan ölümden bu kadar korkarsa çok yanılır. Kupayı kumandana verdi. Üç gün susuz duran kumandan kendine uzatılan şeyi reddedemezdi. Artık silahsız esirler kuyunun başına üşüşmüşlerdi... Barhan Bey, rehinlerin sol kuledeki taş odaya götürülmesini emretti. Sonra kumandanı alarak cephaneliğe götürdü. Barut çuvallarının üst taraflarını döktürttü. Bir karış aşağılarının kömür tozu olmadığını gösterdi: — Anladın ya... Baruta ihtiyacım yok. Ne vakit istersen beni muhasaraya gel. Dedi. Üç gündür kirli renginden korkup tadamadıkları suları kana kana içince biraz canlanan silahsız düşmanlar, önlerinde yayan kumandanları, gözleri yerlerde, dalkılıç sipahilerin şakaları arasında, dar kapıdan, ikişer ikişer çıkarak, geldikleri tarafa doğru, miskin miskin gittiler.

Bir ay geçmeden rehin asilzadelerle şövalyeleri kurtarmak için Prens Petonleç'in gönderdiği büyük erzak kervanı kalenin önüne yıkıldı. Dolu çuvallar, şişkin kazeviler, ağır tulumlar, birer birer içeri taşınıyordu. İç eyaletlerden çok uzaklardaki bu garip kalecik, mutlaka "Kızılelma"yı alacak büyük ordunun gelmesini, artık birkaç yıl daha rahat rahat bekleyecekti.

# Yalnız Efe

Sabahtan beri yürüyorduk. Düşe kalka geçtiğimiz sarp keçi yolları bazen sel yarıkları içinde kayboluyor, bazen sık fundalıklardan ayrılarak, dibinde sivri sivri çam tepeleri görünen karanlık çukurlara sapıyordu. Ayı avına gidiyorduk. Kılavuzun Kum dere köyünün en namlı nişancılarındandı. Beraber tırmanacağımız yüksek ormanlı dağların daha çok uzağındaydık. Vakit vakit ince bir yağmur serpeliyordu. Güneş yoktu. Nihayetsiz mor bir kubbeyi andıran dumanlı gökten sonsuzluğun geçmiş saatlerini hatırlatır gamlı guguk sesleri aksediyordu. Artık iyice yorulmuştum. Omzumdaki martin gittikçe ağırlaşıyordu.

— Biraz dinlensek, dedim.

Kılavuzum güldü. Onun kır çember sakallı şen çehresi pembeleşti:

— Kesildin mi? diye sordu.

Sırtında çiftesi ile üç günlük yiyeceğimizden başka benim kebemi de taşıyan bu dinç köylüye yorgunluğumu söylemedim.

— Ha biraz gayret! Yarın başına bir çıkalım, oradan öte Akkovuk’a kadar yol iyidir, dedi.

Yarım saat daha tırmandık. Ayaklarımızın altından küçük taşlar, kireçli topraklar dökülüyordu.

Gayet büyük bir çam ağacının yanına gelince kılavuzum:

— İşte yarın başı! dedi.

Yerler çamurdu. Çiseleyen yağmurun dallara çarpan damlaları derin bir fısıltı çıkarıyordu. Ben hemen çöktüm. Çamın kalın gövdesine arkamı dayadım. Cebimden paketimi çıkardım. Sırtından yükünü indiren ihtiyar avcıya uzattım:

— Yak bir cigara bakalım!

Ağır bir tavırla:

— Burada tütün içilmez, dedi.

Sordum:

— Niçin? Namazgâh mı burası?

— Hayır!

— Ya ne?...

Başını salladı. Gizli bir şey söylüyormuş gibi yavaşça:

— Burası Yalnız Efenin “sır olduğu” yerdir, dedi.

Serin bir rüzgâr yağmurun fısıltısını çoğaltarak esiyor, üstümüzdeki siyah bir çadır gibi açılan çam dallarını titretiyordu. Anadolu’nun bu yalçın ufuklu, bu boş, bu kayalık, bu korkunç tarafı, Bozdağı’na giden bu ıssız yol eskiden beri eşkıya uğrağı idi; bunu bilmiyordum. Ben tenha bir geçidin gizli bir köşesinde uyuyan küçük bir köyde doğdum. Ger Ali’nin, Köroğlu’nun, Develi’nin, Cellav’ın menkıbeleri içinde büyüdüm. Bilmem onun için mi, eşkıya hikâyelerini dinlemeyi pek severim. Paketimi cebime soktum.

—Anlat bana baba, bu Yalnız Efe kim? nasıl sır oldu? dedim.

İhtiyar avcı torbasının yanına bağdaş kurdu, çiftesini kucağına uzattı, iri ela gözleriyle dik yarın keskin kenarına, karşıdaki yağmurla ıslanarak koyu kan rengine giren derin granit uçurumlara baktı, baktı. Sonra bana döndü:

—Anlatayım. Ben şimdi elli yaşını geçiyorum. O vakit pek ufaktım. Onu gören kadınları dinlerim. Kendisi hiç erkeğe gözükmezdi.

— Niye gözükmezdi?

— Çünkü kızdı.

— Kız mıydı?

— Evet.

Hayretim boşuna gitti. Geçmişi seven, bütün harikaları geçmişte sanan, geçmişi kut sayan her yaşlı köylü gibi masum bir şevkle hikayesine devam etti:

“Dağa çıktığı zaman daha on altı yaşındaymış. Babası gençliğinde bize köye göçmüş, kızından başka kimsesi yokmuş.

“Bu adam, bir gün nasılsa Ese oğlunun çiftliğinden geçer. Oradaki yabancı korucuların birinde alacağı varmış, onu ister. Vermezler. O da galiba kötü bir laf söyler. Hemen zavallıyı öldürürler. Kızı duyunca babasının ölüsüne gider. Ağlamaz, sızlamaz. Kimin vurduğunu anlar. Sonra kazaya gelir, hükümete koşar. Babamı vuran filandır, tutun! der. Aldıran olmaz. Kız yine köye dönmez. O vakit, nereden geldiği, nereli olduğu belli olmayan sarhoş bir zaptiye mülazım varmış, Eseoğlu’nun ahbabıymış. Kız her gün onu tutar, “Babamı vuranı daha tutmayacak mısın?” diye sorar. Bir gün bu sarhoş, kızcağıza öfkelenir, ağzını bozar, “Bre kahpe, bir daha buraya gelirsen senin kafanı kırarım!” der. Kız korkmaz, zaptiyelerin yanında ona “işte bunlar da şahit olsun sen bu gün babamı vuranı tutmazsan ben seni öldüreceğim!” der. Zaptiye mülazımı bu lafa bütün bütün gazaplanır, fırlar, Yörük’ün kızını iyice döver, zaptiyelere sokağa attırır. Kız bir zamanlar görünmez olur...

“Bir gün sarhoş mülazım, Eseoğlu’nun verdiği bir ziyafete giderken kafasına bir kurşun yer, hemen orada can verir. Vuranı ararlar bulamazlar. “Yörük’ün kızı vurdu” diye bir laf olur. Ama buna kimse inanmaz. Herkes onu İzmir’e birinin yanına evlatlık gitti sanır. Fakat bir hafta geçmeden, Yörük’ü öldüren korucu da vurulur. Biraz sonra hükümete Yörük’ün davasını hasır altı ettiren çiftlik sahibi Eseoğlu’nun boğazlanmış ölüsünü bağdaki yatağında bulurlar. Kasabalı ağaların çiftliklerine koruyucu, hergeleci, çoban gibi gelip silahsız ahali içinde tüfekle gezen ne kadar yabancı varsa yavaş yavaş hepsi vurulmaya başlar. İş o dereceğe varır ki, yabancılar yalnız kıra çıkamaz olur. Nihayet takım takım buralarını bırakırlar, kendi yurtlarına dönerler. Zalim zaptiyeleri, köylüyü soyan memurları, rençperi dolandıran madrabazları hiç görünmeden öldüren bu efenin kim olduğu bir zaman anlaşılmaz.

Bu efe tek başına. Yanına uşak filan almaz. Müracaat edenleri ters yüzüne çevirir. İşte bunun için köylüler ona “Yalnız Efe” derler. Tam on beş sene Yalnız Efe’nin yüzünü kadınlardan başka kimse göremez. Dağda erkekle karşılaşınca, uzaktan “gözlerini yum!” diye bağırırmış, sonra yanına gelirmiş. Kim gözünü açarsa hemen öldürürmüş, gözünü açmayan erkeğe; “size zulüm eden kim? rüşvet alan memurunuz var mı?” diye sorarmış. Onun korkusundan kaza da kimse kötülük yapamazmış. Zenginlere, kadınlara haber gönderir, “filan fakire yardım ediniz. Filan öksüzü evlendiriniz. Filan köprüyü yapınız. Filan köyde bir mektep kurunuz.” gibi emirler verirmiş. Hem çok sofuymuş. Benim teyzem bir gün odundan gelirken onu görmüş. Anlatırdı. Başında yeşil bir namaz bezi sarılıymış. Arkasında erkek elbisesi varmış, yamaçta namaz kılıyormuş, peri gibi güzelmiş...

“Evet, bir zaman onun korkusundan kimse kimseye haksızlık edemez olmuş. Haksızlığa uğrayan düşmanını, “gider Yalnız Efe’ye söylerim!” diye korkuturmuş. On beş sene ne köyümüze, ne kazamıza yabancı, yağmacı gelmez olmuş. Öşürcüler, ağnamcılar, tahsildarlar, zaptiyeler köylerde kuzu gibi namuslu dolaşırlarmış. Rüşvet değil, ikram olunan yemişi bile kimse alamaya cesaret edemezmiş.

“Yalnız Efe’ den kimsenin şikayeti yokmuş. Ne kimseyi dağa kaldırmış ne de fidye istemiş. İstediği hep fakirler, kimsesizler, dullar, öksüzler içinmiş. Camisine bakmayan köye haber gönderir; “Gelecek Ramazana kadar mescitleri tamir etmezlerse samanlıklarını yakarım.” dermiş. Onun sayesinde camiler şenlenmiş, köylü zulümden kurtulmuş, öksüzlerin, yoksulların yüzü gülmüş. Her köyün korusunda gizli bir ağaçta bir heybe asılı imiş. Köy halkı bu heybe boşaldıkça içine sucuk, şeker korlarmış. Yalnız Efe’nin kaza içinde belki elli dalda heybesi varmış. Kimseye ağırlık olmaz, kimseyi sıkıştırmaz, herkesin gönlünden kopanla geçinirmiş.

“Uzatmayalım... İşte tam o sırada Söke tarafında gayet azgın bir Rum eşkıyası türer. Devlet bu haydutlara karşı bir nizamiye taburu çıkarır. Döne dolaşa bu tabur bizim tarafa da gelir, Rumlar’ın izlerini bir türlü bulamazlar. Kasabada Yalnız Efe’nin namını işitirler. Boş durmamak için onu tutmaya kalkarlar. Yerli zaptiyeler kılavuzluğu kabul etmezler. Yalnız Efe bunu haber alır. Boz dağı’na geçmek ister. Bir bölük asker ondan evvel davranır, arkadan dolaşır, Akkovuk’u tutar. Bir bölük askerde aşağıdan çıkmaya başlar. Yalnız Efe’yi tam burada sıkıştırırlar. “Teslim ol!” derler. Yalnız Efe: “siz askersiniz, benim kardeşlerimsiniz, canınızı yakmak istemem. Savulun, yoluma gideyim!” der. Dinlemezler. Üzerine ateş ederler. Yalnız Efe birkaç askeri elinden, kolundan, kulağından hafifçe yaralar. Tekrar: “asker kardeşler, bırakın beni sizin canınızı yakmak istemem!” diye haykırır. Yine dinlemezler. Akkovuk’tan gelip de geçidi saran bölük de ateşe başlar. İki ateş arasında kalınca:”asker kardeşler, benim yüzümden birbirinizi vuracaksınız; ben gidiyorum, ben artık yoğum, ateşi kesin, yürüyün buluşun!” diye haykırır. Bir zaman daha yaylım ederler. Nihayet Yalnız Efe’nin sesi kesilince vuruldu sanırlar. Yavaş yavaş yürürler. Dik yolun önünü arkasını adım adım ararlar. İşte bu çamın dibinde Yalnız Efe’nin martini ile geyik postu seccadesinden, yeşil namaz bezinden başka bir şey bulamazlar. “O vakitten beri Yalnız Efeye rasgelen yok. Yazın yamaçlarında hayvanlarını süren Yörükler buraya her gece nur inerken gördüklerini yemin ederek anlatırlar.”

Akkovuk’a biraz erken yetişmek için davranmak icap ediyordu. Yağmur dinmişti. Kalktım, martinin kayışını omzuma geçirdim. İhtiyar, yemek torbasını, kebeyi sırtlıyordu. Yürüdüm. Yarın kenarına geldim. Aşağısı baş döndürecek kadar derin bir uçurumdu. Yeni geçmiş bir kâbus gecesinden kalma korkunç rüyaları andıran parça parça sisler, birbirine karışmış çamlarla kayaları örtüyordu. Yanıma yaklaşan kılavuza:

—Yalnız Efe askerin eline düşmemek için buradan kendisini aşağıya atmış olmalı... dedim.

— Haşa! Tövbe! O Allah’tan korkardı. Dini bütündü, diye reddetti.

— Ee, havaya uçmadı ya!

— Sır oldu!

Gülerek sordum:

— Ne biliyorsun?

İri ela gözlerini kırptı.Delillerinden emin olan sade insanlara ait saf bir inançla:

— Ne bilmeyeceğim, sır olmasa buraya her gece nur iner mi? dedi.

# Yeni Bir Hediye

Yemekten kalkalı belki bir saat olmuştu. Karı koca, kahvelerini, her vakitki gibi yalının balkonunda içtiler. İçindeki şeyler silinmiş, süpürülmüş de sonra havaya mıhlanmış gümüş bir tepsiye benzeyen ay, her tarafı aydınlatıyor, dargın denize uzun ve yaldızlı yansımasını bırakıyor; yorgun dağları, ışıksız yalıları, bülbülsüz koruları mor ve serin sisle örtüyordu. Sadi Bey üçüncü sigarasını da bitirdi. Bu, otuz yaşına gelmeden altmışını tamamlamış sıska bir gençti. Orta yaşa gelmeden dökülmeye başlayan saçlarından şimdi, tepesinde tek bir kıl bile yoktu. Kafası ayın ışığıyla bir balkabağı gibi parlıyordu. Gözlerini uzaklara, pek uzaklara dikmişti...

Karısı Cevriye Hanım –kocasına inat– gürbüz, şişman, canlı kanlı, genç, dinç bir vücuttu. Yirmi beş yaşında vardı. Ama, o kadar körpe görünüyordu ki... Tanıyanlar hep; "Ancak on dördünde..." yargısını verirlerdi. Hem de şairdi. Kafiye ve milli vezin ona, hayat iksiri gibi tesir ediyor, yeni şiirler okudukça şişiyor, bu yazın dayanılmaz sıcağında Tokatlıyan'ın "framboazlı" dondurmasını yemiş gibi ferahlıyor, iştahı açılıyor, günde on iki defa karnı acıkıyordu.  
— Oh ne ulvi manzara! dedi.  
— ...  
Sadi Bey sesini çıkarmadı. Sanki işitmemişti. Cevriye Hanım kıvrandı. Balkonun kenarını sıktı. Bir elini kalbinin üstüne koydu. Sık sık nefes alıyordu:  
— Ah ölüyorum!.. diye derin derin içini çekti.  
Sadi Bey uykudan uyanmış gibi, sersem bir hayretle sordu:  
— Niçin karıcığım?  
— Teessürden?..  
— Hangi teessürden?  
— Halimi görmüyor musun?  
— Görüyorum.  
— Ne görüyorsun?  
— Çok yemek yedin. Biraz hazımsızlık sıkıntısı...  
— Ah, işte erkekler!.. diye Cevriye Hanım hüngür hüngür ağlamaya başladı.  
Tepiniyor, hayali bir bisikletin görünmeyen tekerleklerini çevirir gibi ayaklarını hareket ettiriyor,  
— Ah Sadi! Sen hiç beni anlamadın! diyordu.  
Sadi Bey, gerçekten karısını iyice anlamamıştı. O kadar hassasiyetine, teessür kabiliyetine rağmen, her gün şişmanlıyor, hiç zayıflamıyordu. Sadi Bey, pek maddi, pek ciddi idi. Her şeyi soğukkanlılıkla düşünürdü. Yine öyle iken savaşın başından beri her sene donlarının kemerinden beşer parmak kasılmak mecburiyeti baş gösteriyordu. Otuz dokuz numara yakalık kullanırken, şimdi otuz iki numara yakanın içindeki boynu, İsveç jimnastiğinin en güç hareketlerini bile rahatça yapabilirdi.

Karısı tekrar sordu: — Bu halim çok yemek yemekten mi? — Bilmem. — Bilmiyorsan, ne iftira ediyorsun? — ... Sadi Bey cevap vermedi. Yine derinlere daldı, gitti. Fakat Cevriye Hanım'ın öfkesi geçmedi. Kocasına ters ters bakarak, — Sende saksağan kadar duygu yoktur... dedi. Aklın fikrin hep yemekte... Balıkpazarı çığırtkanı mısın, nesin? Pirinç, bulgur, yağ, peynir fiyatı... Düşün babam, düşün... Sanki senin düşünmenle fiyatlar düşecekmiş gibi... Halbuki benim teessürüm ne kadar duygusal, ne kadar ruhsal... Şu havada parlayan aya bakıyorum, bu gülümseyen ay şimdi dünyanın yarısına bakıyor... Kimbilir ne kadar aşk ve alaka tablosu seyrediyor... Sadi Bey omuzlarını büzerek sinirli bir tavırla. — Bize ne? dedi. Ne seyrederse etsin... Cevriye Hanım, kocasına baktı. Sonra ellerini aya kaldırarak: — Ey, ilahi çehre! Gülen gözlerinin altında ne kadar hayvanlar bulunduğunu anlıyor musun? dedi. Yıldızsız semada yalnız başına bakan ay, "Anlıyorum, anlıyorum..." der gibi sanki daha beter gülümsüyor, hafif bir rüzgar denizdeki uzun aksini genişletiyordu.

Sadi Bey, — Benim başkalarının aşklarıyla uğraşacak vaktim yok... dedi. Cevriye Hanım cevap verdi: — Balıkpazarı çığırtkanlarının işleriyle uğraşacak vaktin var ama... Karı koca birbirlerine baktılar.

Sadi Bey sordu:  
— Sen benim ne düşündüğümü biliyor musun?  
— Biliyorum.  
— Ne?  
— Et.  
— Hayır.  
— Pirinç.  
— Hayır.  
— Yağ.  
— Hayır.  
— Bulgur.  
— Hayır.  
— Eh, öyle ise fasulye.  
— Hayır.  
— Kuru fasulye.  
— Hayır diyorum, hanım.  
Cevriye Hanım kocasının başka bir şey düşüneceğine hiç ihtimal vermezdi.  
— Şüphesiz bir saattir şairane hayallere dalmamıştın ya?  
— Doğru... Şairane değil...  
— Ne düşünüyordun, öyleyse sen söyle...  
— Ne düşüneceğim? Yeni bir masrafı...  
— Ne gibi?  
— Bütçemizi altüst edecek bir masraf... Bu ay üçüncü hediyeyi alacağız.  
Cevriye Hanım birden anlamadı.  
— Ne hediyesi?  
— Dayının çocukları sünnet oldular. Yarın akşam davetliyiz... Ne hediye götüreceğiz? Bu ay düğünleri olan iki akrabamıza beşer liralık hediye götürdük.  
Cevriye Hanım,  
— Mutlaka maddi bir hediye götürmek lazım mı? dedi. Manevi bir hediye götürelim. Bedava, fakat çok kıymetli bir şey...  
— Ne gibi?  
— Ben bir şiir yazayım. Onu götürelim.  
— Böyle bir maskaralık olmaz.  
— Vay, sen şiiri küçük görüyorsun ha...  
— Canım... şey...  
— Ne?  
— Böyle şey olur mu?  
— Niçin?  
— Sonra bize...  
— Ne diyecekler?  
— Deli derler..  
— ...  
Karı koca yarım saat kadar tartıştılar. Her tartışmada olduğu gibi, onların tartışmalarından da hiçbir sonuç çıkmadı. "Fikirlerinin çarpışmasından —deta hakikat şimşeği söndü." Ay, onları daha iyi görebilmek için yavaş yavaş, çaktırmadan daha tepeye, göğün ta ortasına çıkıyordu. Cevriye Hanım,  
— Boş laflarınla şairane hayallerimi dağıtıyorsun! diye kocasına darıldı.  
Kederinden, gerine gerine yatak odasına çıktı. Balkonda yalnız kalan Sadi Bey, karısının içine fenalık verecek derecede etkili bu ulvi manzara içinde, yarın alacağı hediyeyi düşündü. "Ne alayım? Ne alayım..." diyordu.

İki tane sünnet çocuğu... Birer kol saati alsa... Üçer liradan altı lira... Birer hokka takımı... Beşer liradan on lira. Pigmalyon'da kemik bir kâğıt bıçağının fiyatını sormuş ve tenekeden ürken cesur bir spor beygiri gibi iki adım geriye fırlamıştı... Düşündü, düşündü. Dünyada ucuz bir şey kalmamıştı. Bu ay hediye için on lira mümkün değil veremeyecekti. Ayın sonuna daha on sekiz gün vardı. Gözlerini havadan denize indirdi. Ayın aksi, içinden bir karartı geçiriyordu. Dikkat etti. Bir torpido...  
— Havada ay... Denizde ayın aksi... Ayın aksinin içinde de yaldızlı, gümüş köpükler saçarak yürüyen sessiz, kahraman bir torpido... Bir ressam olsa şu manzaraya deli olurdu.  
Sadi Bey, böyle düşünürken sanki ressammış gibi deli oldu.  
— Buldum! Buldum!... diye haykırdı.  
Karısı henüz uyumamıştı. Yatak odasının penceresinden dağınık saçlı başını çıkardı:  
— Ne buldun?  
— Alacağımız hediyeyi...  
— Ne? Ucuz bir şey mi?  
— Hem ucuz, hem pahalı...  
— Pahalı... Kaç kuruş? Bin kuruş mu?  
— Hayır, bir milyon kuruş...  
— Tanesi mi?  
— Evet.  
— Sen deli olmuşsun? Bu parayı nerde bulacaksın?  
— Bir milyon kuruş kıymetinde, ama tanesi bir liraya...  
— O ne?  
— Bil bakayım...  
— Benimle eğleniyorsun...  
— Hayır, vallahi doğru söylüyorum.  
— Söyle Allah aşkına ne?  
— Söylemem, sen de düşün, bul...  
— Söyle diyorum, şimdi kafam dağınık...  
— Canım, sende hiç sürati intikal yok mu?  
— Sende sürati intikal yoktur.  
Sadi Bey balkonda bir kahkaha attı.  
— Pekâlâ, bende sürati intikal yoktur. Sende vardır. Öyle ise işte sana söylüyorum. Bir milyon kuruş değerinde bir hediye! Fakat alırken bir liraya alacağız. Nedir? Bul...  
— Eğleniyorsun benimle...  
— Hayır, eğlenmiyorum.  
— Yenir mi? Yenmez mi?  
— Yenmez be... Bir milyon liralık şey hiç yenir mi?  
— Büyük mü, küçük mü?  
— El kadar.  
Cevriye Hanım, pencereden yarı beline kadar sarkarak balkona atılacakmış gibi kocasına bakıyor, düşünüyor düşünüyor, bir türlü bulamıyordu.  
— Yumuşak mı, katı mı?  
— Yumuşak, ama pamuk gibi değil. Kâğıt gibi.  
— Baş harfini söyle.  
— Dal...  
Cevriye Hanım "Dal" harfiyle başlayan birçok şey saydı: "Dondurma, davul, dama, def, damızlık koyun, duvar saati, dev aynası, darı, diba, demir, dem çeken güvercin, dikiş makinesi... vs..." O söyledikçe Sadi Bey gülüyor; "Bu milyon kuruş kıymetinde mi?" diye karısını üzüyordu. Cevriye Hanım, bu hediyenin ne olduğunu bulamadı. Canı öyle sıkıldı ki.. Sonunda cevaben:  
— Söyle, nedir, yoksa vallahi kendimi aşağı atarım! diye haykırdı.  
Sadi Bey, gülmekten katılıyor, parlak kafası sarsılıyordu.  
— Kendini atmaya gerek yok, de ki, "Bende sürati intikal yok!" söyleyeyim.  
— Pekâlâ, yok...  
Sadi Bey, sandalyesinden kalktı. Meraktan kıvranan karısının yüzüne bakarak şen ve keyifli bir kahkaha attı.  
— Donanma piyangosu be!..dedi.  
Ağır bir masraftan birdenbire kurtulan züğürtlere mahsus samimi bir sevinçle ellerini oğuşturarak içeri girdi ve o gece pek rahat bir uyku uyudu.

# Yuf Borusu Seni Bekliyor

Aksaraylı Câbir Paşa'yı bir zamanlar tanımayan yoktu; zevcesi, Cennetmekan'ın gözdelerinden mi, hazinedar ustalarından mı ne imiş... İşin içyüzünü bilenler, o kolunda taşıdığı kat kat sırmaları Saraylı Hanımın sayesinde kazandığını; yani, düğün olmadan evvel el öpmelik binbaşılığı, sonra da kandillerde, bayramlarda münasebet düştükçe kaymakamlığı, miralaylığı, livâlığı, Meşrutiyet'ten bir sene evvel de ferikliği yakalamış olduğunu hikâye ederler...

Orduyu gençleştirmek sevdasına düşen akıllılar iş başına geçince, birçoklarıyla beraber onu da tekâüde sevkederek mağdurlar arasına karıştırdılar. İlk günler tekâüt muhassasâtıyla geçinmek kabil oluyordu. Doğruyu söylemek lazım gelirse, paşanın on para serveti de yoktur. Zaten Devr-i Saadet'te, harem-selamlık o koca daireyi eline geçen ihsanlar, maaşlarla ancak idare edebiliyordu. Bu musibetten sonra evin kadrosu kendi kendine küçüldüğünden ilk günleri tekâüt maaşı biraz işe yarıyordu. Sonra maîşet derdi sarpa sarıp da herkes başının çaresine düştüğü zaman, paşa da, ilk tedbir olarak köşkün selamlık tarafını kiraya verdi. Bu da derde derman olamayınca, zemin katını bakkal dükkanına tahvil etti. Ufak bir sermaye ile ticarete koyuldu. İş başa düşünce ne yapılmaz? Bak şu hayatın cilvesine!

Bir zamanlar paşanın yanına kuş uçmazdı. Perde çavuşları, odacılar, yaverler, nöbetçiler, atlar, arabalar, dalkavuklar, arasında geçen debdebelerle; şimdiki kırk paralık bulama, altmış paralık peynir müşterilerine meram anlatmak arasında ne büyük tezat vardı. Hele o eskiden etek öpmek için fırsat bekleyenlerin bugünlerde yan gözle bakıp bıyık altından gülmelerini görüp de kalpler sızlamamak kâbil değildi. Fakat paşa, "sabrın sonu selamet" diyerek büyük bir metanet ile kendini bu hayata da alıştırdı, hatta biraz kanıksadı bile...

Fakat günün birinde vesika şekerini tevzi ederken köyün sayılı sulularından, hatta azılılarından Takunyalı Fitnat namında bir kadın, ona bir bayrak açtı, bütün mahalleyi bir anda başına topladı. Fitnat'ın bir eli belinde, diğeriyle birtakım işaretler yaparak: — Seni istiskalar paşası, seni.. Aç gözünü, yoksa açarlar gözünü... Sen hükümet kapısında yetim hakkı yemeye alışmışsın. Galiba şimdi de mahalle bakkallığını mı yiyim yeri yaptın? Hiçbir şeycik demem. Benim gibi ağızsız, dul kadınların, saçı bitmedik yetimlerin beş, on dirhem şekeri sana kan olsun, irin olsun... Yüzünü halka doğru dönerek devam etti: — A dostla.....rr, buna hangi can dayanır? Bizden ufaladığını bari hayırlı bir işte kullansa canım yanmaz... Bu kaparozlar, sokak sokak fink atan kokona kızlarının tango çarşaflarına, havaleli iskarpinlerine gidiyor... Hele dur sen, benim kafam kızmasın, yoksa... İnşallah o kokorozlar nasibimden geçmesin, eğer onları tükürüklere boğmazsam, bana da Fitnat demesinler...

Câbir Paşa, bu vakadan sonra mahalle bakkallığına tövbekâr oldu. Makamını Karamanlı Bodos'a terkederek, ertesi günü tası tarağı topladı, kaçış hâlâ o kaçış. Tabiî boş durmak kâbil değil. Paşa birkaç gündür İstanbul'a geldikçe, işlere âgâh olmaya başladı. Hay Allah layığını versin! Meğer o, köyde, Takunyalı Fitnatlar, Belalı Ayşeler ile uğraşırken, açıkgöz tekâütler rahat kârın kolayını bulmuşlar da, onun haberi yok! Aştan kalanın kaşığı kırılsın. Paşa da derhal Ömer Âbid Hanı'nda bir yazıhane, ticaret tezkeresi vesaireyi yoluna koydu. Şimdi bir taklit tüccar da o olmuştu. Tüccar olmak bir şey değil, asıl işin tatlı tarafına bakalım. Tavsiyeler, himmetler, biraz da etek öpmelerle, paşam da, muradına nail oldu. Sizden laf çıkmaz, açıkçası ihracat vesikası işine kayırıldı.

Allah bin bin bereket versin. Meğer fincancı katırlarını ürkütmeyenlerin bu kadarcık olsun mükafatı varmış. Hem ne hoş... Bu işin batakçı defteri, eli bayraklı kadınları da yok. Arada sırada bir adam gönderip listeye baktırmak... Bu sefer de bize yarım vagon çıkmış, buna da bereket versin. Çağır Yasef'i, Halil Efendi ver aşağı, tut yukarı, bayıl paraları. Kısa günün kârı az olur. Paşam müsrif de değildir. Eğer iş devam etseydi, beş on para sahibi de olacaktı. Nerede?.. Kör talih geldi, ona da yetişti, günün birinde bu işin de modası geçti. Vesikacılıktan mahrum kalan bazı açıkgöz arkadaşlar iaşe dalaverelerine dahil oldular, fakat paşam bir türlü bunun pundunu bulamadı. Bu kabiliyetsizliği az kaldı aile politikasını da bozuyordu. Çünkü kızlarıyla büyük hanım, kendisini açıktan açığa mıymıntılıkla itham ettiler. Paşada ne kabahat var? Her iş sık sık şeklini değiştiriyordu. O da ne yapacağını şaşırdı. Hakiki ticaretin hiç ehli değildi. Aczini bilmek de bir meziyettir. Paşa bu hallerle bocalarken, evdeki itibarı azaldıkça azaldı. Zavallı paşa hanımlara yaranmak için her şeyi yapıyor, kuyudan su çekiyor, bahçe suluyor, sebzevat ayıklıyor, yine makbul olamıyordu. Paşa, kendisini görenler tanımayacak kadar zayıflamıştı. O kuruluğa bir de karalık ârız oldu. Şimdi paşa eski ölçüsüne göre yapılan elbiselerinin içinde yabancı bir iskelet gibi kalmıştı. Evvela yakalık ve boyunbağını defetti. Sonra da yakın yerlere, bakkala çakkala, mahalle kahvesine entari ve hırka ile gider ve soranlara "Artık derviş olduk", derdi...

Mütareke, müsâlâha, derken işler bütün bütün değişti... Her geçen günle beraber yeni bir şekle giriyorduk. Yine herkesin lisanı kökünden döndü. — Kahrolsunlar, kaçmışlar, yahu neler oluyormuş da ruhumuz duymuyormuş. Oh olsun... Oh olsun... Eden elbet bulur, tıksınlar haini, assınlar katili, hamiyeti varsa artık çekilsin... Onu da bir adam zannettikti yahu. Sen kasavet etme birader, yine bu öksüz milleti yine bir mucize kurtarır...filan derken Bekirağa Bölüğü dolup dolup boşalıyor, katiller, kanlılar bacadan kaçıyor, kaçıyordu... Ama, şimdi ma-hüvelhakkını söylemeli. Mağdurlar da bucak bucak aranıyordu ya... (!) Hele şu cilve-i kadere bak. Meğer devlet kuşu yakınlara gelmiş de haberimiz yok.

Bir sabah çarşı boyuna erken inenler, Câbir Paşa'yı senelerce sandık içinde durmadan açılmaz buruşukluklar peydâ etmiş, formaları kararmış, saltanat devirlerinin yadigarı olan paşalık esvabının içinde buldular. Şişmanlık günlerinin hatırasını saklayan bu esvabı paşa giymemiş, belki de içine düşmüştü. Hele seyf-i mücellâsını beline dolayan sırmalı kayışın hâsıl ettiği buruşukluklarla, bir insandan ziyade, bostan korkuluğuna benziyordu. O, bu halden bîhaber, yalnız öne doğru birkaç derece meyleden vücudunu doğrultmaya gayret ederek arada sırada boyalı bıyıklarına çeki düzen vererek, mehâbet-i askeriyesine yakışan bir gururla tren yoluna doğru ilerliyordu.

Eskisi gibi sağdan sola selamlar saçıyor ve mukabilini de bekliyordu. Meğer hakkı da varmış. Hakikat bu geçiş, her günkü geçişlere benzemedi, herkes iki keçeli ayağa kalktı, adeta küçük bir merasim oldu. Paşa içinden: "Ah fırsat düşkünleri, ah!" diyordu. Bak, bak, her gün bir omuz silkmekle geçen aşinalar şimdi kandillli temennâlarla yerlere kadar eğilerek: — Efendim memuriyet-i cedîdenizde muvaffakiyetler temenni eder ve arz-ı tebrikat ederim. İrfan-ı âlînizi ihmal edenler cihana maskara oldular paşam... gibi yağlı ballı hulûslar savurarak geçip gidiyorlardı. Bunlar arasında yalnız biri fikrini değiştirmemişti. Tam paşa trene ayağını atacağı sırada yine en son sözü o, Takunyalı Fitnat söyledi: — Yürü bakkallar paşası, yürü... Yuf borusu seni bekliyor...

# Yüksek Ökçeler

Hatice Hanım, pek genç dul kalmış zengin bir hanımcağızdı. On üç yaşında iken altmış yaşında bir kocaya vardığı için "izdivaç" denen şeyden nefret etmişti. İşte hemen hemen on sene vardı ki, erkeğin hayali zihnine, romatizma, balgam, pamuk, vandoz, tentürdiyot yığınlarından yapılmış pis, abus, lanet bir heyulâ şeklinde gelirdi. "Gençler başkadır!"  diyenlere: — Aman, aman! Onlar da bir gün olup ihtiyarlamazlar mı? Sonra dertlerini kim çeker? Diye haykırırdı.

Başlıca merakı temizlik ve namusluluktu. Göztepe'deki köşkünü, hizmetçi Eleni ve evlatlığı Gülter'le her sabah beraber temizler, aşçısı Mehmet'i her gün tıraş ettirir, zavallı Bolulu oğlanı tepeden tırnağa kadar beyazlar giymeye mecbur ederdi. Eleni de, Gülter de son derece namusluydu. Kileri kitlemezdi, paraları meydanda dururdu. Hele Mehmet'in namusuna diyecek yoktu. Konuşurken gözlerini kaldırıp insanın yüzüne bile bakamazdı. Hatice Hanım, köşkten hiçbir yere çıkmadığı için işi gücü adamlarını teftişti. Habire odaları dolaşır, tavan arasına çıkar, mutfağa inerdi. Derdi ki: — Benim gibi olun! Ben kimse ile görüşüyor muyum? Sakın siz de komşuların hizmetçileriyle, uşaklarıyla konuşmayın. El, insanı azdırır! Mehmet bile bu nasihati noktası noktasına tutmuştu. Arka bahçedeki mutfağına değil misafir, hemşeri filan, hatta yabancı bir kedi bile girmiyordu. Hatice Hanım, belki günde on defa iner, onu yapayalnız tenceresinin başında bulurdu. Hatice Hanım'ın temizlik, namus merakından başka bir de yüksek ökçe merakı vardı. Güzeldi, tombuldu, cıvıl cıvıl bir şeydi. Fakat boyu çok kısa olduğu için evin içinde de bir karışa yakın ökçeli iskarpinler giyerdi. Âdeta bir cambaza dönmüştü.

Bu yüksek ökçelerle merdivenleri takır takır bir hamlede iner, ayağı burkulmadan bir aşağı, bir yukarı koşar dururdu. Nihayet bir baş dönmesi geldi. Çağırdığı doktor ilaç filan vermedi: — Bütün rahatsızlığınıza sebep bu ökçelerdir, hanımefendi dedi, onları çıkarın. Rahat, yünden, yumuşak bir terlik giyin. Hiçbir şeyiniz kalmaz. Hatice Hanım, doktorun tavsiye ettiği bu yünden terlikleri aldırdı. Hakikaten rahattı. İki gün içinde başının dönmesi filan geçti. Dizlerinde, baldırlarında sızı kalmadı. Fakat böyle, tam vücudu rahat ettiği sırada, ruhu derin bir azap duydu. Dokuz senelik adamlarının iki gün içinde birdenbire ahlakları bozulmuştu. Eleni'yi kendi diş fırçasıyla dişini fırçalarken, Gülter'i kilerde reçel kavanozunu boşaltırken görmüştü. Mehmet'i et günü olmadığı halde bol bir sahan külbastıyı yerken yakaladı. — Ne oldu bunlara Yarabbim? Bunlara ne oldu? Diyordu. Bir hafta içinde adamlarının on beşten fazla hırsızlığını, yolsuzluğunu tuttu. Hele Mehmet'i, komşu paşanın neferleriyle koca bir lenger pirinç pilavını atıştırırken görünce, hiddetinden ne yapacağını şaşırdı. O gün her tarafı kilit kürek altına aldı. — Bakalım şimdi ne çalacaklar? Dedi. Hakikaten çalınacak hiçbir şey kalmamıştı. Ertesi gün biraz geç kalktı. Aşağıya indi. Gülter'le Eleni meydanda yoktu. Yürüdü, mutfağa doğru gitti. Gözleri aralık kapıya ilişince, az daha nefesi duracaktı. Mehmet, ocağın başındaki kısa iskemleye çökmüş, bir dizine Eleni'yi, bir dizine Gülter'i oturtmuş, kalın kollarını ikisinin bellerine halattan bir kemer gibi sarmıştı. Hatice Hanım, bu levhanın rezaletini görmemek için hemen gözlerini kapadı. Fakat kulaklarının kapağı olmadığı için, konuştuklarını duymamazlık edemedi.

Mehmet diyor ki:  
— Ülen Gülter, artık sen şeker filan getirmeyon?  
Gülter:  
— Her taraf kitli, ne yapayım?  
Diyordu. Mehmet, tuhaf bir şapırtı içinde Eleni'ye de:  
— Ülen gece niçin gelmiyon? Sana helva yapıp saklayon!  
Sualini soruyor, Eleni:  
— Yakalanazağiz vire! Sonra hanım bizi kovazak diye çırpınıyordu.

Aralarında çıtır pıtır bir hasbihal başladı. Hatice Hanım, gözünü açmıyor, yüreği çarparak merakla dinliyordu. Gülter: — Ah o terlikler! dedi, her işimizi bozdu. Hanımın geldiği hiç duyulmuyor. Ne yapsak yakalanıyoruz. Eskiden ne iyiydi. Yüksek ökçelerin takırtısından evin en üst katında kımıldadığını duyardık. Hasbihal uzadıkça, kendi göremediği başka rezaletlerin mufassal hikâyelerini işitiyordu. Dayanamadı. Gözlerini açtı: — Sizi alçak, hırsız, namussuzlar! Defolun şimdi evimden! Diye haykırdı. Bu dokuz senelik sadık hizmetçilerini hemen kapı dışarı etti.

Aşçı, işçi, artık eve ne kadar adam aldıysa, hepsi arsız, hırsız, yüzsüz, namussuz çıkıyordu. Tam iki sene bir adamakıllısına rastgelmedi. Malı mülkü varken, hiçbir sıkıntısı yokken, bu hizmetçi üzüntüsünden zayıflıyor, sararıp soluyordu. Baktı olmayacak! Yine yüksek ökçeli iskarpinlerini giydi. Hizmetçilerinin hırsızlıklarını, uğursuzluklarını, namussuzluklarını göremez oldu.

Benzine kan geldi. Vâkıâ yine, başı dönmeye başladı. Fakat sesi işitilmeyen ökçesiz terlik giydireceğini düşünerek doktora kendini göstermiyor: — Hiç olmazsa şimdi yüreğim rahat ya, diyordu.

# Yüzakı

Mehmet Efendi, on senedir kasabada oturuyordu. Köydeki tarlaları, bağları, bahçeleri ortak elinde kalmıştı. Aziz ahbabı Müftü Hacı Ali Efendi ile dertleşirken: — Hepsini yanmış, kül olmuş farz ediyorum. Artık dünyada bir tane olsun doğru adam yok, dedi. Faziletin, iyiliğin varlığına dini gibi iman eden Müftü: — Var ama, sen bulamıyorsun, diye başını salladı. Mehmet Efendi taştı: — Yok, yok, yok! Vallahi, billahi yok! Herkes yalancı, herkes dolandırıcı. Denemediğim ne hısım kaldı, ne akrabam. Kardeşim bile beni aldattı. — Öyleyse git, malının başında otur. — Doğru söylüyorsun. "Gemin oldu, kıçında... Çiftin oldu, içinde..." Ne yapayım ki, burada işlerimi bırakamıyorum. — Köydekilerini sat. — İttifak etmişler. Kimse almıyor. . . . . . . Müftü Efendi, dünyada doğruluğun, faziletin hâlâ var olduğunu biliyordu. Fakat nasıl ispat etmeliydi? Mehmet Efendi gibi, kötülerin hilesine tutulanlar, imanlarını da bozuyorlardı. Gel zaman, git zaman, bir gün gelecekti ki, artık kimse kimseye inanmaz olacaktı. — Benim tanıdığım bir çoban var. Çok doğrudur! dedi. — Çoban mı? — Evet... Mehmet Efendi, yarasının üzerine yeni bir yara açılmış gibi, suratını acı acı ekşitti: — Hele o çobanlar? diye derin derin bir ah çekti, bin beş yüz koyunumdan nihayet elli tane bıraktılar. — Pekâlâ, bu elli koyunu benim söylediğim doğru adama ver. Yüz yapsın! . . . . . .

Mehmet Efendi güldü:  
— Şaka etme.  
— Sahi söylüyorum.  
Müftü, tanıdığı çobanı anlatmaya başladı. Bu, dünyada yalan nedir bilmez bir adamdı. Gayet saftı, dervişti. Ömrünü dağlarda, meralarda geçirirdi. Beş vaktine beş daha katardı.

Müftü methettikçe Mehmet Efendi yumuşadı:  
— Bari şu benim koyunları ona versek, dedi.  
Ertesi gün yaylaya haber gönderdiler. Çobanı kasabaya çağırttılar. Mehmet Efendi, Müftü'nün karşısında onunla anlaştı. Elli koyunu bu çoban gezdirecek, elli koyunun verdiği kârdan beşte biri kendine ait olacaktı. Koyunlar köyden getirtildi. Bu küçük sürü ile çoban çıktı, gitti. Günler, haftalar, aylar geçiyordu. Mehmet Efendi, Müftüye rastgeldikçe:  
— Bu çoban doğru çıkarsa, köydeki bütün işlerimi de ona bırakacağım, diyordu.  
— Göreceksin, göreceksin!  
— İnşallah...  
Bir sene sonra, bir cuma sabahı Mehmet Efendi evinin alt katındaki odada otururken "Doğru Çoban"'ı karşısında gördü. Elinde büyük bir toprak kapla ıslak bir post vardı. Bunları selam vermeden sedirin yanındaki pencerenin içine bıraktı:  
— Hoş geldin?  
— Hoş bulduk!  
— Otur bakalım...  
— Eyvallah!  
— Koyunlardan ne haber? Doğurmadılar mı?  
Çoban:  
— Hepsi kısırmış! dedi.  
— Hiçbiri doğurmadı mı?  
— Hayır.  
— Yünlerini ne yaptın?  
— Daha kırpmamıştım.  
Mehmet Efendi anlamadı:  
— Ne demek?  
— On iki tanesini çaldılar.  
— Ey?  
— Geriye ne kaldı?  
— Otuz sekiz.  
— Otuz ikisi geçen sonbahar kelebek oldu, öldüler.  
— Ey?  
— Geriye ne kaldı?  
— Altı.  
— Beşini kurt yedi...  
— Geriye ne kaldı?  
— Bir!...  
— İşte bu bir koyuna da gözüm gibi bakıyordum. Evvelki akşam sağdım. Sütüyle şu yoğurdu yaptım. Dün sabah yayladan inerken zavallı uçuruma yuvarlandı. İndim, başına gittim, bir de gördüm ki, ölmüş. Daha soğumadan yüzdüm. İşte postu.  
Çoban eliyle pencerenin yanındaki ıslak deriyi gösteriyordu. Mehmet Efendi, kır sakalını sol eliyle tuttu. Önce kızardı, sonra sarardı. Çoban susmuyordu:  
— Yoğurt iki buçuk okka.. Yarım okkası benim. Pöstekideki hakkımı size bağışlıyorum!  
Mehmet Efendi hiç sesini çıkarmadı. Ayağa kalktı. Yoğurt kabını eline aldı, yavaş yavaş "Doğru Çoban"'ın önüne geldi. Dolu kabı bütün kuvvvetiyle kafasına geçirdi:  
— Al hakkını kerata! diye yumruklamaya başladı. Tekmeleye tekmeleye kapıdan dışarı attı!  
Bu esnada Müftü Efendi, dostunun ziyaretine gelmişti. Kapıda çobanı, suratı yoğurt içinde görünce şaşırdı, sordu:  
— Ulan, bu ne hal?  
Saf çoban, uğradığı haksızlıktan şaşırmış gibiydi. Fakat yine mantığını kaybetmemişti. Acı bir serzeniş tavrıyla:  
— Ne olacak efendim, dedi, hesabını doğru veren işte böyle yüzünün akıyla dışarı çıkar.

# Zeytin Ekmek

Vermeyince Mabut, neylesin Mahmut? Atasözü

Genç, beyaz, gürbüz kadın, tıpkı zalim âşığının hışmına uğramış evvel zaman cariyesine benziyordu... Soluk basma entarisi parça parçaydı. Gür, kıvırcık, kumral saçları, mermer kadar beyaz omuzlarına dökülmüş, celladını bekleyen bir masum gibi, derin derin düşünüyor; çürük kafesli, çarpık cumbadan sokağa bakıyordu. Zeynep Kâmil Hastanesi'ne inen bu yol pek tenhaydı. Komşu duvarların üstünden aşan bahar çiçekleriyle süslenmiş sık dallar, bozuk kaldırımlara, ince tül gölgelerini yaymışlardı. Saçaklarda, kırık kiremitler arasındaki yuvalarının insani sefaletini duymayan mesut serçeler, sanki başka bir bayramın zevkini sürüyorlarmış gibi cıvıldıyorlar, uçuşuyorlar, sevinçlerinden kaplarına sığamıyorlardı. Genç, beyaz, gürbüz kadın birdenbire,  
— Aaa...  
Diye haykırdı.

Kalçalarını sarsan hızlı bir hareket ile toplandı. Dizlerinin üzerine kalktı. Sonra dirseklerini pencerenin kenarına dayadı. Canlanarak, uzandığı dayanağından birdenbire doğrulmuş bir heykel kadar bediî ve şirindi. Seslendi:  
— Sabire, Sabire!  
Sokaktan geçen iki şık kadın hemen durdu. Uzun boylusu, biraz şaşkın, sesin geldiği tarafı aradı. Siyah kaşlarını çatarak cumbaya baktı. İnce şifon çarşafının altında şekli görünen uzun oyluğuna altın el çantasını vurarak sordu:  
— Kim o?  
— Ben.  
— Sen kimsin ayol?  
— Naciye!  
Altın çantayı avuçlarına aldı. Asabi asabi sıktı. İyice cumbaya döndü. Tekrar sordu:  
— Hangi Naciye?  
— Bahtiyar Efendi'nin kızı!  
— Hangi Bahtiyar Efendi'nin?  
— Sandık emini Bahtiyar Efendi'nin.  
— Ne!  
— Ya...  
Bir an öyle kaldı. Bu yer odasının kopuk, perişan kaplamalarına baktı. Kırık camlara gazete kâğıtları yapıştırılmıştı.  
— Ayol burada ne arıyorsun?  
— Hiç.  
— Ne demek hiç?  
— Evimiz işte!  
— Eviniz mi?  
— Evet.  
Uzun boylu kadının yanındaki de şaşırmıştı. Birbirlerine bakıştılar. Bir şaka işitmiş gibi gülümsediler. Uzun boylu, cumbadakine,  
— Yalancı seni! Aç bakayım kapıyı!.. Ben senin burada ne aradığını anlarım, dedi.  
Üzerine mahalle çocuklarının tebeşirle kuş resimleri yapmış oldukları çürük kapıya yaklaştı.

Sabire ile Naciye çocukluk arkadaşıydılar. Balkan bozgunu başladığı zaman, aynı kazada, birisinin babası hâkim, birisininki sandık eminiydi. Kaçarken birbirlerini kaybettiler. İşte altı sene sonra yine karşı karşıya geliyorlardı. Fakat Sabire, Naciye'nin üstünü başını görünce,  
— Bu ne hâl kız! Sana kuduz köpek mi saldırdı? Diye haykırdı.  
Naciye de, onun şık siyah çarşafına, açık boynundaki iri zümrüt taşlı platin pantantifine, elindeki büyük altın çantaya bakarak şaşıyordu. Hâlinden birdenbire sıkıldı:  
— Fakirlik, diyebildi.  
Sabire, gözlerini etrafa bir gezdirdi. Sıvaları dökülmüş bölmeler, kaplamasız tavan, buraya ahırdan bozma, sefil bir kümes manzarası vermişti. Yanındakine döndü,  
— Ne kadar güzel değil mi? Dedi.  
— Maşallah.  
Bu kendinden biraz yaşlıca, fakat daha şık, daha kokot bir kadındı, kumral yüzünde bir Çerkez gururu vardı. Bu kadar berbat bir eve girmeyi gereksiz görüyor gibi kapıdan bakıyor, içeri giremiyordu. Şaşkın bir suskunluk içinde, üç kadın, birbirini tekrar süzdüler. Sabire, içinde,gayri ihtiyârî bir merhamet sedası duyulan şefkatli bir sesle,  
— Vah Naciye, vah...dedi. Annen nerede?  
— Öldü.  
— Baban?  
— O da öldü.  
— Kardeşin?  
— O da öldü.  
— Ee, sen burada ne oturuyorsun?  
— Burası kocamın evi.  
— Kocanın evi mi?  
— Evet.  
— Neci bakayım, kocan?  
— Duvarcıydı, ama şimdi asker.  
— Nerede?  
— Burada. Haydarpaşa'da. Amele taburunda.  
Tekrar sustular. Zavallı kız, bu şık hanımları tek odacığına çağıramıyordu. Fakat Sabire, zenginlere, kibarlara mahsus o gaddar tevazuyla güldü:  
— İçeri girelim, seninle konuşalım, dedi. Vah Naciye, vah... Kız, sen ne talihsizmişsin.  
— Buyurun.  
Sabire, arkadaşı hanıma döndü:  
— Gel azıcık oturalım. Gördün ya şu kızı.... Bu kadar güzel bir kadına rastgeldin mi? Allah aşkına söyle. Şu saçlara bak.. Bu kıvırcıklar doğal. Öyle yapma değil, dikkat et Allah aşkına...  
Ciddi kadın gülümsüyor,  
— Maşallah, maşallah, diyordu.  
Dar, pis, karanlık, toprak döşeli sofayı geçtiler. Odaya girince fakirliğin sefaleti, bu iki kadını donmuş gibi dimdik bıraktı. Bir yerde oturamıyorlar, oturacak yer bulamıyorlardı. Naciye bütün bütün büzülmüştü. Sanki bu sefalet kendi cinayetiymiş gibi önüne bakıyor, utanıyor, sıkılıyor, kızarıyordu. Köşede yırtık bir hasırın üstüne birkaç yatak yığılmıştı. Hasırın ucunda bir gaz sandığı vardı. Büyücek bir testi, yanında bir vesika ekmeği, yeşil bir çanak dolusu zeytin duruyordu. Cumba ile perdesiz pencerenin önündeki tahtadan sedirin üstüne ince, eski bir yol keçesi örtülmüştü.

Naciye, "Buyurun! Temizdir!" diye burasını gösterdi.

İki kadın tahta sedire iliştiler. Arkadaşı, basık tavana, badanasız duvarlara bakarken, Sabire, eski çocukluk arkadaşıyla yine konuşmaya başladı:  
— Şöyle yanıma gel bakayım.  
. . . . .  
— Gel otur yanıma!  
Naciye de sedire oturdu.  
— Ne oldu sana böyle kız?  
— Talih işte!  
... Yavaş yavaş anlatmaya başladı. Babası Selanik'te hastalanmış, İstanbul'a geldiklerinin ayında ölmüştü. Annesiyle Üsküdar'da bir oda tutup, başlarını sokunca, yine hastalık peşlerini bırakmamıştı. Annesi de zatürreden ölmüştü. Naciye yalnız kalınca, ev sahipleri olan dul kadın, haline acımış, ona çarşıya gidip bekâr odalarından bir kocacık buluvermişti. İşte dört senedir onunla yaşıyordu, bu adamcağız iyiydi, fakat çok fakirdi. Muharebeden evvel bir mecidiye gündelikle yapılarda çalışıyordu. Asker olunca, Naciye'ye otuz kuruş maaş bağlanmıştı. Eve izinli geldiği akşamları, bazı karavana çorbası da getiriyordu.  
— Allah'a çok şükür, geçinip gidiyoruz! deyince, Sabire coştu:  
— Bu haline şükrediyorsun ha?..  
— Elhamdülillah!  
— Kız, sen budala imişsin! Gece gündüz, vesika ekmeği... Katık zeytin... Sonra üstüne de dua ha?  
Birden yaşlı, kumral kadına döndü.  
— Gördün ya, Füsun Hanım, Allah'ın ne iyi kulları var, dedi.  
İkisi de Naciye'ye tereddütlü gözlerle bakıyorlardı. Açlık, sefalet içinde bu renk, bu güzellik, bu vücut nasıl dayanıyor, solmuyordu. Kendileri, zenginler, bol yemeklerle, şırıngalarla, şaraplarla kansızlıktan kurtulamıyorlardı. Naciye sıkılarak,  
— Senin baban nerede? diyebildi.  
Sabire,  
— Bilmiyorum. Dışarlarda bir yerlerde! dedi.  
Naciye, şık kadının ta gözlerinin içine baktı.  
— Annen?  
— O da beraber...  
— Sen?  
— Ben mi? Uzun hikâye! Evvela, bir zâbitle evlendim. Sonra ayrıldık.  
— Şimdi kiminle oturuyorsun?  
— Akrabalarımla.  
Fakat Naciye, Sabire'nin İstanbul'da akrabaları, hem de zengin akrabaları olduğunu bilmiyordu. Zaten o da kendi gibi Rumeliliydi. Fakat daha ziyade sormadı. Sustu. İki kadın onun güzelliğine şaşıyorlar, gür saçlarını okşuyorlardı. Sabire dayanamadı. Basma entarinin altında parlayan ensesini tuttu, boynundan öptü. Naciye utanıyordu. İki kadın, talihin bu güzel vücuda nasıl musallat olduğuna kızıyorlar, çirkin zenginlerden bahsediyorlardı.

Sabire, — Refika'yı düşün Füsun! O kazık kadar karı... Köşklerde, otomobillerde! İnsan yüzüne bakmaya korkar. Bir de şu Naciye'ye bak! Acaba Cemil, öyle bir kadını rüyasında görse ne yapar? — Gözlerine inanmaz! — Vallahi inanmaz... Sabire, yanında kızaran, sefaletinin mahcubiyeti, zenginliğin şaşaası karşısında bunalan, biten Naciye'ye, — Doğru söyle, ayda yalnız otuz kuruşla mı geçiniyorsun? diye sordu. — Geçen sene asker dikişi de dikiyordum. Bu sene bulamadım. — Vah zavallı! . . . . — İnanamıyorum. Nasıl yaşarsın! — Bayağı! — Canım, nasıl yaşarsın? Otuz kuruşla küçük bir kanarya geçinemez. — Kocam, her hafta ne yapıp yapıyor, yarım okka zeytin getiriyor. Ben de idare ediyorum. Buna Sabire ile Füsun inanamıyorlardı. Evlerindeki hizmetçilerin vesika ekmeği yemediklerini hatırlıyorlar, acı acı gülüyorlardı.

Füsun, — Ne diyeyim, dünya işte bu! diye başını salladı. Demek o ekmek de yeniyormuş. Vallahi bizim Bobi'ye verdik, yemedi. Hem de kızdı. Öyle acı acı havladı ki... Kudurdu sandık... Sabire sinirli bir hareketle, — Ben seni burada bırakmam vallahi Naciye! diye haykırdı. Haydi kalk... — Nereye!.. — Bize gideceğiz... — Aaa, nasıl olur? — Nasıl olacak, bayağı! — Kocamdan izin almadan... — Haydi, deliliği bırak, gel bir gece bizde kal. Ye, iç sonra bak bir daha buraya dönebilir misin? — A, aaa... — Haydi, haydi diyorum. Naciye'nin evden çıkıp izinsiz bir yere gitmeyi aklı almıyordu. Vâkıâ, kocası bu gece gelmeyecekti. Fakat nasıl olurdu? İki kadın ona acıyor, dört senedir kulübesinde sıcak yemek pişmediğini duydukça, üzüntülerinden ne yapacaklarını bilemiyorlardı. Kendileri bugün araba ile Kadıköy'den buraya bir aşçı aramaya gelmişler, bu kadının evini bulamamışlardı. Evdeki aşçı, hizmetçilerle geçinemiyordu. Onun için savmak istiyorlardı. Füsun, bu akşamki, yemeklerden başladı. Yaptırdığı tatlıları söylüyordu. Şaraptan, şampanyadan bahis açtılar. Naciye, çocukluk arkadaşının her sofrada kırk liralık şampanya içtiğini duyarken, kulaklarına inanamıyor, tatlıların, böreklerin, külbastıların hikâyesiyle midesi uyuşur gibi oluyordu. Onlarla konuştukça, kendi talihsizliği, sefaleti gözünde daha ziyade büyüyor, felaketinin birdenbire farkına varıyordu. İçinden, "Bir gecelik misafirlik! Ne olur? Bari doya doya bir yemek yerim!" diyordu. Yıllar vardı ki, ta bozgundan beri tatlıya, böreğe hasretti. Hatta zeytinden peynirden başka bir şeyin tadını unutmuş gibiydi. Dayanılmaz bir yemek hasretinin sarsıcı nöbetleri onu hıçkırtmaya başladı. Sabire'ye bu gece gidecekti. Fakat üstü başı yoktu. Sıkıla sıkıla bu mazereti söyledi. Füsun'la Sabire birbirlerine bakıştılar. Sabire, — Naciye'yi alır, Doğancılar'a Muazzez Hanım'a gideriz. Onu bir güzel giydiririz. Muazzez de iridir. Etekleri, çarşafı Naciye'ye tam gelir! Dedi. Füsun, — Vallahi iyi akıl ettin. O deliyi de, bugün bize götürürüz, cevabını verdi. Kalktılar. Naciye, sabahtan beri bir şey yememişti. Son derece acıkmadan vesika ekmeğiyle zeytini midesine indiremiyordu. Artık dört senedir zavallıya bir tiksinme gelmişti. Naciye'nin yemek, aşçı, tatlı, börek laflarıyla hayali alevlenmişti. Artık bir şey düşünemiyor, "Ah, bu gece kimbilir neler yiyeceğim?" diyordu. Birdenbire evine gelen bu talihli arkadaşının nasıl zengin olduğunu muhakeme edemiyor, dimağında sabit bir fikri, altın bir sofra gibi doluyor, ağırlaşıyordu. Gayri ihtiyarî gözünün önüne beyaz örtülü bir masa geliyor, bu hayali masanın üstünde dumanlı külbastılar, hoşaflar, tepeleme pilavlar, kompostolar, dondurmalar görüyor gibi oluyordu. Daldığı yemek hülyasıyla tamamıyla sersemlemiş gibiydi. Onlar kalkınca, o da meçhul bir sevinçle doğruldu, yatağın arasından eski, yamalı, siyah yünden bol bir çarşaf çıkardı. Utana utana giydi. Sabire ona bakıyor, bakıyor, — Allahaşkına Füsun, bir kere şuna bak! Bu paçavraların içinde bile sultan gibi durmuyor mu? diyordu. Kapıdan çıktıktan sonra çok yürümediler. Küçük caddenin önünde bir araba onları bekliyordu. Binerken Sabire arabacıya, — Doğancılar'a çek! Dedi. Naciye karşılarına oturdu. Yolda hep eğlenceden, esvaptan, modadan konuştular. Fakat Naciye pek bunları dinlemiyor, bu akşam bir zengin yemeği yiyeceğini hayal ediyordu. Ötekiler hep onun güzelliğine bakıyor, kollarını tutuyorlardı.

Füsun,  
— Naciye Hanım'ın elleri de bozulmamış... diyordu. Sanki her gün sütle yıkanmış gibi...  
Hakikaten Naciye'nin elleri, kolları son derece güzeldi. Her akşam mahalle çeşmesinden taşıdığı soğuk sularla bol bol yıkanırdı. Sabun çok pahalı olduğu için kirlenmekten korkar, kara kışta abdestini soğuk suyla alırdı. Beyaz boyalı büyücek bir evin önünde arabayı durdurdular. Bu ev, bu mahallenin eski ahşap, boyasız evleri arasına misafirliğe gelmiş yabancı bir konağa benziyordu. Kapıyı gayet beyaz önlüklü bir kız açtı. Sabire sordu:  
— Hanım evde mi, Eleni?  
— Evde.  
— Haydi, geldiğimizi haber ver.  
— Buyurun...  
Mermer döşeli bir taşlığa girdiler. Hizmetçi kız koşarak yukarı çıktı. Merdivenlerden çıkarlarken deli gibi bir kadın onları karşıladı.  
— Ah hainler! Nereden estiniz böyle...  
Evvela Füsun'a sarıldı. Sonra Sabire'yi kucakladı. Öpüştüler.  
— Nereden estik, bil bakalım?  
— Bilmem... Gece burada mısınız?  
— Hayır.  
Bu, fazla boyanmış, oldukça yaşlı, oldukça güzel, yorgun bir kadındı. Büyük gözlerine kuyruklu sürmeler çekmişti. Naciye'ye baktı. Sonra gözlerini kapayarak misafirlerine sordu:  
— Bu tebdil hanım da kim?  
— Tebdil değil, kendi üstü başı...  
— Eğlenmeyiniz.  
Sabire yemin ediyordu.  
— Vallahi tebdil değil! Senden giyecek; etek, çarşaf, ayakkabı almaya geldik. Bu gece bizim misafirimiz!  
— Yalan, yalan...  
— Vallahi diyorum...  
Kadın, kızaran Naciye'ye bakıyor, inanamıyordu. Bir erkek tavrıyla,  
— Ne güzellik yahu! diye haykırdı.  
Hepsi birden tekrar dönüp Naciye'ye baktılar. Füsun,  
— Giyinsin de, siz ona o vakit bir bakın!  
Geniş bir yatak odasında, gayet büyük bir aynalı dolabın karşısında, üç kadın Naciye'yi soydular. Onu çıplak görünce deli oluyorlardı. Ev sahibi Muazzez, ellerini oyluklarına vuruyor,  
— Ah yarabbi, erkek olsaydım! diye haykırıyordu.  
Şık, beyaz ipekten, gayet ağır bir elbise giydirdiler. Çoraplarını giydirirken ayaklarının, bacaklarının beyazlığı, güzelliği onlara çığlık attırıyordu. Saçlarını kaldırdılar. Bu kumral, kıvırcık, parlak saçlar o kadar çoktu ki... Sahte kıl koymaya hacet bırakmıyordu. Sonra hemen oraya, şezlonga oturarak eserlerine hayran kalan sanatkârlar gibi, süsledikleri bu vücudu seyre daldılar. Naciye bir şey söyleyemiyor, gülümsüyor, güzelliği için söylenen sözleri biraz mübalağalı buluyor, "Acaba sahi mi?" gibi yan gözle, yavaşçacık, aynadaki hayaline bakıyordu.

Hizmetçi kız, gümüş bir tepsi içinde çay getirdi. Küçük bir mangalın başına mavi, ipek kaplı sandalyeleri çektiler, oturdular. Naciye'yi de karşılarına oturttular. İnce yaldızlı cigaraları yaktılar. Hep erkeklere dair konuşuyorlardı. Naciye dinliyor, saf bir kadın düşüncesiyle içinden "Galiba bunlar kötü" diyordu. Fakat, işte ne kadar zengindiler! Giydikleri ipek, oturdukları ipekti. Ayağının altında yumuşaklığını duyduğu parlak, pembe halı da hiç şüphesiz ipekliydi. Kim bilir sofraları nasıldı? Gümüş tepsinin üzerinde altın kakmalı şeker kutusuna bakıyor, sabahtan beri ağzına hiçbir şey atmamış bir oruçlu muhayyilesiyle külbastılar, pilavlar, tatlılar, börekler düşünüyordu. Yine hıçkırmaya başladı. Evet, bu akşam o da bu sıcak, bu yağlı yemeklerden yiyecekti. Hıçkırırken sarsılıyor, sanki bu gayri ihtiyarî hal büyük bir ayıpmış gibi utanıyordu. Hıçkırığını tutmaya çalışırken sanki kulakları yeni açılmış gibi, Sabire ile arkadaşlarının sözlerini duyuyordu:

Biri diyordu ki:  
— Rıza, bu kıza bir gece için bin lira verir.  
Muazzez reddediyordu:  
— Vermez! Pis, kurum satar, ama paraya gelince cesareti yoktur.  
— Miloviç'e on bin lira vermiş!  
— O başka...  
— Niçin başka!  
— İnat üzerinedir belki..  
— Ey, Hacı İbrahim görse ne yapar?  
— İşte ondan korkarım. Para vermez, ama o saatte köşk filan almaya kalkar.  
Naciye, pahasından bahsolunan kızın kendisi olduğunu anlayınca kalbi çarpmaya başladı. İşte onu, ihtimal bu gece, birisine peşkeş çekeceklerdi. Aniden kalkıp soyunmak, yine kendi paçavralarını giymek, koşa koşa evine kaçmak istedi. Kımıldadı. Ona da bir cigara yaktırmaya çalışıyorlardı.  
— İçmem, vallahi! dedi.  
Israr etmediler. Fakat bu ipek esvaplar içinde o kadar rahat etmişti ki, kolundaki pembe tül, tarif olunmaz bir lezzetle cildine dokunuyordu. "Bir geceden ne olur? Hemen birisinin kucağına atmazlar ya... Bu akşam biraz sıcak yemek yerim, yarın erkenden yanlarından kaçarım!" diye düşündü. Midesi tıpkı bir kalp gibi atıyordu. Yine onların sözlerini duymuyor, dört senedir hasret kaldığı etleri, tatlıları, muhallebileri hatırlıyordu. Karnı fena hâlde acıkmıştı. Şimdi kalkıp kaçsa, evinde ne yiyecekti? Gözünün önüne odasında, gaz sandığındaki yeşil çanak geldi. Bu siyah zeytinler sanki birer azap aletiydi. Vesika ekmeğini çiğniyor gibi, bir an dişleri gıcırdadı... Yutkundu. Ne olursa olsun, bu gece, bunlarda kalacaktı. İçinden, "Yemek için... Yemek için..." diyor, tehlikede kalacak namusunu aklına getirmek istemiyordu. Sabire, Füsun, Muazzez yapacaklarını ondan gizlemiyorlar, kendini birtakım beylere göstererek hepsini deli edeceklerini söylüyorlardı.

Muazzez,  
— Hemen arabaya binin. Dört vapuruna yetişin! Moda'da dolaşın. Mutlaka birine rastgelirsiniz... diyordu.  
Kalktılar. Çarşaflandılar. Naciye'ye de siyah ipekten bir çarşaf giydirdiler. Eline kadifeden, altın kenarlı, şık bir çanta verdiler. Sonra uzun uzun öpüşmeye başladılar. Muazzez, Naciye'yi de öptü. Kapıya kadar hepsini indirdi. Sabire ile Füsun, bu sefer Naciye'yi karşılarına almadılar. Sıkıştılar. Ortalarına oturttular. Arabayı kuvvetli atlar, tenha yolda uçuruyordu. Naciye, yine yemek hülyalarına dalmıştı. Sabire ile Füsun'un konuştuklarını duymadan işitiyordu. Haydarpaşa'da deniz kenarından geçerlerken etrafına görmez nazarlarla bakıyordu. Kadıköy'ü hiç bilmezdi. Üsküdar'ın, mahallesinin harap evlerine alışan gözleri, temiz parke döşeli sokakları yabancı görüyor, kâgir binalara bakarken, kendini bir ecnebi memleketinde sanıyordu. Yolda gayet şık beyler, onlara eliyle selam veriyorlardı. Araba nihayet bir meydanlıkta durdu. Burası yüksek bir yerdi. Âdeta bir seyir yeri gibi kalabalıktı. Kenarında büyük ağaçlar vardı. Ağaçların arkasında nihayetsiz deniz görünüyordu. Başka arabalar da duruyordu. Kadınlarla erkekler karmakarışıktı. Geziyorlar, konuşuyorlar, gülüşüyorlardı. Naciye, etrafına bakarken birdenbire Sabire'nin birisiyle konuştuğunu duydu. Başını çevirdi. Bu siyah, kesik bıyıklı, zayıf, sarışın bir gençti. Ayağında beyaz pantolon, arkasında lacivert bir ceket vardı.  
— Allah aşkına bu kim, diyor, Sabire gülüyordu.  
— Bilmem! Yanımıza binmiş işte.  
Naciye kulak kabarttı. Gencin gözlerine gözleri rastgelince ürkmüş gibi yüzünü Füsun'dan tarafa çevirdi. Bu kadın gayet ciddi duruyor, delikanlıyı görmemiş gibi davranıyordu.  
— Allah aşkına söyle, kim?  
— Bir insan işte...  
— Melâike be...  
— Ne zannettin?  
— Kuzum Sabire, tanıştır...  
— Erkekle konuşmaz yavrum. O bize mahsus...  
— Allah aşkına diyorum.  
— Bize gel bu gece.  
— Siz kalabalıksınız. Biliyorsun ya, ben artık içemiyorum. Siz eğlenirsiniz. Son vapurla geldim. Karnım da tok. Sonra aranızda ben seyirci kalırım.  
— İyi ya işte, seyirci kal.  
— Yağma mı var?  
— Ey, sen de bu peri kızını al götür, yağma mı var?  
— Sabire, aksilik etme. Bizimkiler bir haftadır Büyükada'da. Köşkte kimseler yok. Bu fırsat bir daha ele geçmez. Takdim et, şunu bana; birkaç gün sayende yaşayayım...  
Çok yavaş konuşuyorlardı. Fakat Naciye, kalbinin sesiyle beraber ikisinin sözlerini, noktası noktasına işitiyordu:  
— Benim sayemde yaşarsan, bana ne yaparsın?  
— Sen söyle! Ne istersin!  
— Hayır söylemem!  
— Şimdi sana yüz lira veririm...  
— Daha çık! Daha çık!  
— Yüz yirmi.  
— Bitpazarı'nda mısın yahu! Neden kuruş kuruş çıkarsın.  
— Yüz elli Sabire!  
— Çık, çık! Gözünün önüne o kart Miloviç'i getir de, sonra dikkatle istediğin kıza bir bak. Çık bakayım biraz.  
— İki yüz...  
— Ona ne vereceksin!  
— Sen karışma.  
— Söyle, söyle.  
— Vallahi Sabire, ben ömrümde böyle güzel görmedim. Belki kapatırım, yahut alırım.  
— Haydi defol oradan, üç senedir her gördüğünü kapatmaya kalkarsın. Biliyorsun ya, beni de öyle altı ay kadar aldatmıştın.  
— Ama bu pek güzel!  
Âdeta kendi üzerine pazarlık ediyorlardı. Canı sıkıldı, yine arabadan atlayıp kaçmak aklına geldi. Fakat nereye gidecekti. Açlıktan içi bayılıyordu. Evini hatırladı. Dişini sıktı. Yine yemek kokuları duyar gibi oldu. Sabire ile konuşan genç, onları gezmeye davet ediyordu. Füsun'a rica etti. Arabadan indiler. Sabire, garip bir acele ile geri döndü.  
— Çocukluk arkadaşım Naciye Hanım! dedi.  
Naciye'ye de,  
— Paşa babasının paralarını bol bol yiyen Fasih Bey... derken, iki kat oldu.  
Şaşalayan Naciye gülümsedi. Kalabalığa kapıldılar. Dolaşmaya başladılar. Yeldirmeli kadınlar, gençler hep onlara bakıyorlardı. Bu dolaşma epeyce sürdü.

Naciye'nin karnı o kadar acıkmıştı ki... Âdeta midesinde bir sızı duymaya başladı. Gözlerinin önünde siyah siyah lekeler uçuyordu. Güneş ağaçların arkasında kayboluyor, denizin sonunda gök, pembe, kırmızı bulutlarla doluyordu. Kalabalığın içinde bazı bisikletli çocuklar da geçiyorlardı.

Sabire,  
— Haydi, artık çocuklar, gidelim, dedi. Yoruldum. Bu gece ziyafetimiz de var. Bizi beklerler.  
Füsun sordu:  
— Fasih Bey de gelecek mi?  
— Sor kendine. Gelmiyor.  
Fasih cevap verdi:  
— Beni affediniz efendim.  
Sabire,  
— Fasih! Bu gece bizde kalabalık çok, Naciye gürültüye alışmamıştır. Bu gece sende misafir kalacak! dedi.  
— Memnuniyetle, tenezzül ederlerse!  
. . . . . . . .

Naciye cevap vermedi. Yorgunluktan sanki hastalanmıştı. Kımıldayacak hali yoktu. İradesiz bir hayal gibiydi. Yalnız gülümsedi. Eğer Sabire'de kalsa, çalgı çağanak, içki, gürültü içinde ihtimal yemek zamanı uzayacak, gece yarısında bile sofraya oturulamayacaktı. Halbuki bu delikanlının evi tenhaydı. Artık işte gece oluyordu. Ellerinden kaçmak, kurtulmak ihtimali kalmamıştı. Onunla gitmek daha hayırlı değil miydi? İçinden, "Hemen gidip sofraya otururuz. Karnımı doyururum! Sonra bir mazeret uydurur, belki sabaha kadar teslim olmam. Sonra kaçarım!" diyordu. Fasih'in arabası bu meydanlığın sonunda duruyordu. Sabire'yle Füsun'la vedalaştılar. Delikanlı hemen koluna girmişti. Arabaya bindiler. Lambalarını yakmış dükkanlar arasından geçmeye başladılar. Genç de ona güzelliğinin fevkaladeliğinden bahsediyordu.  
— Aman yarabbi! Siz nerde doğdunuz? Nerde büyüdünüz? Ne letafet! diye tuhaf sualler soruyordu.  
Kendisini bir takdim için Sabire'ye iki yüz lira veren gencin zenginliğini düşünen Naciye, bu akşam oturacağı sofrayı da gözünün önüne getirmeye çalışıyordu. Altıyolağzı'nı, Yoğurtçu'yu, Bağdat Caddesi'ni dörtnala geçtiler. Fasih Bey, onun dalgınlığını çok güzel buluyor;  
— Ne düşünüyorsunuz, Allah aşkınıza... Bir kederiniz mi var? diyordu.  
— Hiç efendim.  
— Ne böyle dalgınsınız?  
— Hiç efendim!  
Gence, dönüp, "Hemen doğru sofraya oturalım, olur mu?" diyeceği geliyordu. Sağ tarafında batan güneşin hâlâ gölgeli kızıllığı silinmemişti. Ihlamur'u geçtiler. Araba durunca, derin uykudan uyanmış gibi sarsıldı. Fasih yere atlamış, ona elini uzatıyordu.  
— Buyurun...  
İndiler. Demir parmaklıklı bir kapının önünde duruyorlardı. İçerde karanlık, ağaçlık bir yolun sonunda bir bina gölgesi görünüyordu. Kapıdan girince Fasih,  
— İslam! İslam! diye bağırdı.  
Uzaktan bir Arnavut sesi cevap verdi:  
— Efendum?  
— Haydi salonun gazlarını yak!  
Karşılarına çıkan uzun boylu, bahçıvan kılıklı bir herifti.  
— Başüstüne efendum.  
Fasih, Naciye'ye döndü:  
— Bahçıvandan başka kimse yok. Sakın sıkılma cicim!  
. . . . . .  
— Serbest ol artık...  
— Peki...  
Geniş taş merdivenlerden çıktılar. Antrenin, salonun gazları yakılmıştı. Naciye, ömründe görmediği bu ihtişama, bu süslere hayretle baktı. Hele salonda, âdeta açlığını unutur gibi oldu. Halılar, duvarlarda resimler, vazolar, ağır perdeler, ortadaki masa.... Hepsine ayrı ayrı bakıyordu. Salonda görecek şey kalmayınca yine karnının açlığını duydu. Tabii yemek odası da burası kadar süslüydü. Kimbilir ne yemekler vardı. Şiddetle et, börek kokuları duyar gibi oluyordu. Fasih bülbülleşmişti. Anlamadığı birçok şeyler söylüyor, ona ebedi aşklarından, hatta izdivaçtan, doğacak çocuklardan, sonsuz saadetlerden bahsediyordu.

Ne kadar vakit geçti. Naciye'nin haberi yoktu. Fasih,  
— Haydi, artık cicim, yukarı çıkalım! dedi. Aklında hep yemek olan Naciye, gayri ihtiyarî sordu:  
— Nereye?  
— Yatak odamıza cicim!  
— Fakat...  
— Ne cicim?  
Naciye kendini sıktı:  
— Biraz bir şey yesek... diyebildi. Fasih,  
— Ay! diye haykırdı. Ne kadar eşeğim! Güzelliğiniz beni şaşırttı. Karnınızın aç olup olmadığını soramadım. Allah aşkına affediniz. Ben İstanbul'da yemiş de gelmiştim. Durunuz bir şey uyduralım.  
Sonra kalktı. Açık pancurdan kafasını çıkardı. Yine,  
— İslam, İslam! diye haykırdı.  
— Efendum.  
— Gel buraya ulan, çabuk diyorum.  
. . . . . .  
— Efendum!  
— Haydi biraz yiyecek bir şey uydur.  
Naciye yemek lafına iyice kulak kabarttı.  
— Ne yapalım efendum?  
— Ne yaparsan yap!  
— Gece yarısı oldu efendum, şimdi her taraf kapalı.  
— Ulan kafa ağrıtma, diyorum, git, ne bulursan bul, çabuk yemek odasına getir.  
— Efendum her taraf şimdi kapalu...  
— Uzatma lafı diyorum be! Ne halt edersen et!  
Arnavut çekildikten sonra, Fasih, Naciye'ye döndü. Güzel elini tuttu. Öpmeye, koklamaya başladı.  
— Kusura bakma cicim. Yarın lokantadan getirtiriz, ben akıl edemedim. Affet.  
— Estağfurullah...  
— Hakikaten eşeklik ettim.  
— Estağfurullah...  
— Öyle ya, yemeği hiç düşünmedim. Amma sizi görünce şaşırdım vallahi...  
İçeri giren Arnavudun ayak sesleri işitildi. Fasih'in söylediklerini artık duymuyor, hep ayak sesleri işitiyor gibi oluyordu.

Arnavut kapının dışından,  
— Hazırdır begüm, buyurun! dedi.  
Kalktılar. Sofadaki masanın yanından dolaştılar. Fasih, bir kapının önünde durdu.  
— Buyurunuz efendim! dedi.  
Naciye hızla girdi. Burası geniş, mükemmel bir yemek salonuydu. Büfelerin billurları içinde, yanan lambanın akisleri parlıyordu, büyük dört köşe masanın kenarına, karşı karşıya iki sandalye konulmuştu. Yalnız bir sandalyenin önünde bir tabak duruyordu.  
— Buyurun efedim!  
. . . . . .

Fasih, Naciye'yi sandalyeye oturttu. Naciye, gözlerini tabakta duran şeye indirince, acı bir çığlık kopardı. — Aaaaaa!.. Evet bu, siyah zeytin taneleriydi. Yanında da, dört senedir yemekten artık tiksindiği bir vesika ekmeği dilimi duruyordu. Kollarını masaya dayadı. Başını kollarının üstüne kapadı. Ağlamaya başladı. Avazı çıktığı kadar hıçkıra hıçkıra ağlıyordu. Fasih, bu ani tebeddülden bir şey anlamamıştı. "Ne oldu?" diyemiyor, Naciye'nin arkasına attığı pelerinin altından görünen beyaz ensesine bakıyor, vesika ekmeğiyle tabaktaki zeytinleri göremiyordu. Arnavut, köşkün köpeğine verilen, vesika ekmeğinden başka bir şey bulamamıştı. Akşam fasulyesini de bitirmiş, hiç bırakmamıştı.

Buhran şiddetlendi, Naciye'nin gözyaşları kollarını ıslatıyordu.

Fasih hiç durmadan,  
— Ne oldun cicim? Ne oldun? diyordu.  
Genç kadın,  
— Hiç! diye ayağa kalktı.  
Kapıya doğru yürüdü. Fasih, önlemek istedi.  
— Allah aşkına beni bırakınız. Sonra fena olur! diye haykırdı.  
Güzel, ela gözleri çerçevesinden fırlamıştı. Delikanlı çekindi. Genç kadının kapıdan çıkıp gidişine bakakaldı. Bahçenin kumlarına basan adımlarını işitirken,  
— Ne isterik kadın! Âdeta bilmece... dedi.  
Naciye, karanlığın içinde yürüyordu. Bir yemek için bu gece namusunu feda ediyordu. Kendisini yalnız bir takdim için iki yüz lira veriliyordu. Sonra, işte bu cennet kadar muhteşem, saraylardan süslü köşkün altınlı, gümüşlü, billurlu yemek odasında, karşısına yine zeytin, ekmek çıkıyordu. Yürüdü, yürüdü. Artık ağlamıyordu. Kalbi taş kesilmiş gibiydi. Göğsünde onun ağırlığını duyuyordu. Caddeden daha karanlık bir sokağa saptı. Bu bir yokuştu. Daha hızlı yürüdü. Nereye gideceğini bilmiyordu. Sonra yine bir caddeye çıktı. Uzaktan dalgaların seslerini işitti. Karanlığın içinde daha karanlık ağaçlar rüzgarla hışırdıyordu. Deniz sesinin geldiği tarafa yürüdü. Bir gölge, denizin ortasına doğru uzanmış gitmişti. Bu gölgenin uzanmış üzerinden yürüdü, yürüdü. Bir binanın altından geçti. Yürüdü. Serin bir rüzgar yüzüne çarpıyordu. Bu gölge yol artık bitmişti. Durdu. Karanlık denize baktı, baktı, baktı.

Evet, buraya kendini atmaktan başka çare yoktu. Cennete gitse, sefalet yine onun yakasını bırakmayacaktı. Fakat atılacak kuvveti kendinde bulamadı. Oraya yıkıldı. Karşısında kocaman bir yıldız gibi parlayan fenere gözlerini dikti. Baktıkça bu ziya gözlerinin içinde büyüyor, altın tepsi gibi kırmızılaşıyor, sanki gözlerinden giren tatlı baygın aydınlığı, taş kesilmiş donuk kalbini yavaş yavaş ısıtıyor, eritiyordu.

# Çakmak

— Ulan İboş, sen be?!..  
— Vay Mıstık sen ha?...  
— Ben ya...  
İki hemşeri hemen kucaklaştılar. Makedonya'dan çıktıkları günden beri görüşmemişlerdi. Şimdi bu ücra Anadolu kasabacığının dışarısında, bu inleyerek akan çakıllı dereciğin başında, böyle karşı karşıya gelmek... Onlar için umulmadık bir saadet oldu! Hayretle karışan sevinçleri pek samimiydi. Terkettikleri eski vatanlarında ikisi de sürücülük yapardı. Senenin her mevsimine göre ayrı bir ticaretleri vardı. Sonbaharda Sırbistan'a geçerler; at, katır, eşek alırlar... Kış gelince cambazlığı bırakarak Bulgaristan'dan zahire taşırlardı. Vâkıâ hiç ortaklık etmemişlerdi. Ama gayet iyi tanışırlardı. Birbirlerinin hakkında nihayetsiz bir itimat beslerlerdi. Mıstık kirli sarı yüzünde gayet temiz birer canlı mücevher gibi mavi mavi parlayan küçük gözlerini oynatarak sordu:  
— Ne yapıyorsun bakalım?  
— Hiç...  
— Burada ne yapıyorsun?  
— Hiç. Geçiyorum. Ey sen?  
— Ben de.  
— Nereye gidiyorsun?  
— Daha belli değil. Sen nereye?  
— Benim de belli değil.  
— Ne vakitten beri buradasın?  
— Bir ay var...  
— Ben de aşağı yukarı bir aydır buralardayım...  
İkisi de henüz gençtiler. Çolukları çocukları yoktu. Sermayeleri, sırtlarındaki iplerle bellerindeki kuşakları idi. Anadolu'da şehir, kasaba, köy beğenmiyorlardı. Çiftçi olmadıkları için çarşıya ehemmiyet vermiyorlardı. Aradıkları kalabalık bir ticaret yeriydi! Yüzde üçyüz kâr bırakacak bir ticaret yeri...

İboş:  
— Gözünü sevdiğim Rumeli'si... dedi. Nerede o günler?  
Mıstık başını salladı:  
— Nerede!... Eski çamlar bardak oldu. İşin yoksa burda on kuruş gündelikle eşek gibi çalış...  
— ....  
Derenin kenarı düz bir çimenlikti. İhtiyar söğüt ağacı alaca gözlerini sudaki aksine karıştırıyor, etraftaki nihayetsiz tarlalar, tenhalıklarıyla zümrüt, kumlu bir çölü andırıyordu.  
— Çökelim şuraya, be can!..  
— Çökelim be!...  
Çimenlerin üstüne bağdaş kurdular. Mıstık hazin hazin akan dereye bakarak:  
— Ah, nerede bizim Mesta?  
Dedi. Sonra, Anadolu sularının midesine dokunduğunu, sıtma yaptığını anlatmaya başladı. Kara kaşlı, kara gözlü, tıknaz insan esvabı giymiş bir öküz kadar kuvvetli İboş, hep sıska arkadaşını tasdik ediyor, yanaklarından kan damlarken Anadolu'ya geldi geleli hastalıktan baş kaldıramadığını söylüyordu. Sulardan sonra sırasıyla, havadan, yollardan, şimendiferlerden, dağlardan, hanlardan, jandarmalardan bahsettiler. İboş büyük kırmızı kuşağından meşin bir kese çekti. Dar poturunun yamanmış bir yırtığa benzeyen cebinden nikel bir çakmak çıkardı. Kirden rengi belli olmayan bu keseyi Mıstık'a uzattı:  
— Yap bakalım bir cigara...  
Mıstık keseyi daha açmadan; zayıf, traşı uzamış pis suratını fena halde ekşiterek:  
— Tütün değil, mübarek tezek!  
Dedi.  
— Ah, bizim tütünler!  
— Dilber saçı sanırdın...  
— Tutam tutam sırmaydı...  
. . . . .

Cigaralarını sardılar. Anadolu tütünlerinin, rejinin, kaçaklarının aleyhinde küfürler savurarak içmeye başladılar. Her şeyden ziyâde Anadolu'nun ahlâkından, hilekârlığından, geçimsizliğinden şikayet ediyorlardı. Mıstık:  
— Tövbe, tövbe! dedi. Hele yalan yere yemin etmeleri...  
— Evet, bu en fena tabiatları...  
— Bir gün yer yarılacak, vallahi hepsi batacak.  
— Batacak!..  
Tutulacak işleri, hükümetin himayesini, muhacirlik imtiyazlarını konuştular... Belki bir saatten ziyâde... Beğendikleri tütünden, birbiri arkasına onar cigara içmişlerdi. Kalkarlarken tütün kesesini kuşağına sokan İboş arandı, tarandı. Eğildi, üstünde oturdukları çimenleri elleriyle yokladı. Doğruldu. Kaşlarını çattı. Yumruklarını böğrüne dayadı. Çok kirpikli gözlerini süzdü. Mıstık'a baktı:  
— ......  
— Ver, diyorum.  
— Ne istiyorsun?  
— Bilmiyor musun?  
— Yoook!..  
— Çakmağı ver diyorum.  
— Hangi çakmağı ver diyorsun?  
— Ulan, inkar mı ediyorsun?  
— Neyi be?  
— ....  
İboş dişlerini sıktı. Açılan yumrukları titremeye başladı. Bu, âdeta insanı eşek yerine koymaktı! Sakin bir tatlılıkla sordu:  
— Biz burada otururken yanımıza kimse geldi mi?  
— Hayır.  
— Ben tütün kesesiyle beraber bir çakmak çıkardım mı?  
— Çıkardın.  
— Cigaralarımızı çakmakla yakmadık mı?  
— Yaktık.  
— Buradan kalkıp bir yere gittik mi?  
— Hayır.  
— Öyleyse çakmak nerede?  
— Ben ne bileyim?  
— Sen aldın...  
— Hâşâ!..  
İboş, üstünü, başını, yerleri, çimenlerin arasını dikkatle, tekrar aradı. Çakmağı Mıstık'ın çaldığından artık hiç şüphesi kalmadı. Bunun hemşeriliğe yanaşmayacağını söyledi. Yalvardı, yakardı. Mıstık: "Hâşâ!... Kabul etmem vallahi!.." diye birbiri arkasına yeminleri basıyor, arkadaşının bu ithamını ağır bir hakaret sayarak kabarıyor, kavga çıkarmaya kalkıyordu. İboş'un eski memleketinde tuhaf bir şöhreti vardı. Ona "Bir pire için yorgan yakan" derlerdi. En ufacık hakkını bile kimsede bırakmazdı. Hatta bir defa eşyasını taşıdığı bir savcı bozukluğu olmadığı için sürücü ücretinden iki kuruşcuğunu eksik vermişti. Bu iki kuruşu bırakmamak inadıyla İboş o vaktin genel müfettişliğine, İçişleri bakanlığına, vilayete tam beşyüz kuruşluk şikayet telgrafı çekmişti.

Bu vaka bütün Rumeli'nce meşhurdu.  
— Sen beni bilirsin Mıstık, dedi. Ben kimsede bir şeyimi bırakmam. Ver şu çakmağı...  
— Almadım vallahi!  
— Ey, sen almadın, ben de almadım; ecinniler mi gelip aldı?  
— Bilmem.  
— Ben senden bu çakmağı çıkarırım.  
— Anlamadım ki, ne çıkaracaksın...  
İboş, mahkemeye müracaatla dava edeceğini söyledi. Hiddetle kasabaya doğru giden yola çıktı. Halbuki Mıstık çakmağı çalmıştı.

İçinden: "Görmeden aldım. Şahit yok, sepet yok. Bir yemin değil mi? Ederim." dedi. Dışından —bir dakika evvel o kadar tatlı tatlı muhabbet ettiği arkadaşına— acı acı haykırdı: — Haydi beraber gidelim, ben de senden namus davası edeceğim! — Haydi gel!.. Etrafı derin hendeklerle çevrilmiş tozlu yoldan yanyana yürümeye başladılar, ama iki şaşı göz gibi biri sağa, biri sola bakıyordu.

Yarım saat sonra, hükümet konağındaki küçük mahkeme salonunda idiler. Alt kattan azgın zaptiye beygirlerinin kişnediği tepindiği işitiliyor, açık pencerelerden birbirlerini öldürmek için kovalıyorlar sanılan kırlangıçlar gidiyorlar, siyah tahtalı eski tavanın çatlaklarında çamurdan delikleri andıran yuvalarına konuyorlardı.

Ak sakallı hâkim enfiyesini çekerek bu iki yabancının davasını dikkatle dinledi.

İboş'a sordu:  
— Bu adamın çakmağını aldığına şahidin var mı?  
— Yok.  
— Sen de, çalmadım, diyorsun...  
— Evet. Hem de namus davası ediyorum. Bana hırsız demek istiyor. Ben bunu kabul etmem.  
— O başka mesele.. Şimdi sen çalmadığına yemin edeceksin. Eder misin?  
— Ederim.  
— Öyleyse, evvela senin istediğin dava görülmüş olur. Yani hırsız olmadığın meydana çıkar. Namusun temizlenir.  
— Pekala!  
Gayet soluk, lekeli bir yeşil çuha örtülmüş kürsüye yaklaşan Mıstık yine yeşil bir bohçaya sarılı kitaba elini bütün kuvvetiyle bastı, çakmağı almadığına yeminler savurdu. O anda onun kazandığı davayı İboş kaybetti. Tam dışarı çıkarken sevinen Mıstık'a, hâkim:  
— Oğlum, sen on kuruş vereceksin, dedi.  
Mıstık ağzıyla gözlerini açtı:  
— Niçin! Ben davayı kazanmadım mı?  
— Kazandın.  
— Çakmağı benim almadığım meydana çıkmadı mı?  
— Çıktı.  
— Öyleyse ne parası istiyorsun?  
— Evvela senin davan görüldü. Mahkeme parası...  
— !...  
Mıstık vurulmuş gibi durdu. Önüne baktı. Ağzını yüzünü buruşturarak düşündü. Sonra İboş'a döndü. Yavaş yavaş elini koynuna soktu.  
— !  
— ?  
— Altmış paralık şey için on kuruş veremem! Al malını, uğursuz...  
Diye biraz evvel katiyen çalmadığı tahakkuk eden çakmağı arkadaşının suratına fırlattı!

# Çirkinliğin Esrarı

Bilmiyorlar da sevmediklerini,  
Ediyorlar büyük büyük yemini;  
Bana gösterme, sen de nefretini,  
Ne şifalar veren yalanlar var!

Genç kızlarla bir odada yalnız kalmak ne tehlikelidir! Bahusus bizim gibi başı yorgun adamlar için... İşte geçen sene, bu vakit, ben böyle bir tehlike atlattım. Sonbaharda Büyükada'yı çok severim. Tenha çamların altında tek başıma gezmek, uzak sislerden savrulan rutubetli rüzgârın ölümü hatırlatan feryadını dinlemek pek hoşuma gider. Hava, penceresiz bir türbe kubbesi gibi karanlık, gamlı, meyus tur. Her tarafta solan yazın naaşından kopmuş yapraklar sürünür. Gölgesiz dalların arasında sanki zavallı aldatanlarla aldananların görünmez hayalleri dolaşır... Fakat o gün, bu gamlı kubbe, birdenbire yıkıldı. Bir tufan boşandı. Sırsıklam oldum. Yağmurun altında Sermet'in halasının oturduğu köşke kendimi dar attım. Kapıdan girince halime gülen hizmetçi kız, evde küçük hanımdan başka kimse olmadığım söyledi.  
— Ey, büyük hanımefendi?  
— Bu sabah erkenden gitti.  
— Nihat Bey?  
— Galiba kulüpte.  
— Şu yağmur geçinceye kadar oturacağım. Küçük hanıma haber verme. Rahatsız olmasın, dedim.  
Pardösümü çıkardım. Mendilimle üstümü başımı sildim. Soldaki salona girdim. Çılgın yağmur, pancurları, camları tokatlıyor, fasılalı ıslıklarla acı bir fırtına gürültüsü koparıyordu. Ben tabiatın bu münasebetsiz hiddetini dinlerken kapı açıldı. Başımı çevirdim. Sütûde'nin girdiğini gördüm. Bence İstanbul'un en güzel kızı odur! Siyah, iri, parlak gözler...Gür siyah saçlar... Sonra inanılmaz derecede saf bir beyazlık! Mukaddes bir rüya beyazlığı! Acaba on altı yaşında var mıydı? Zannetmiyorum. Fakat yirmi yaşında sanılacak kadar olgun bir vücut... Bir göğüs ki... Bir boyun ki...  
— Neye benden kaçıyorsunuz? Dedi.  
Kalktım. Uzattığı bembeyaz elini sıktım. Sıcacıktı. Ta gözlerimin içine bakıyordu. Arkasında beyaz bir bluz vardı. Kısa, siyah etekliğinin altından gözüken bacaklarının, o insanı heyecandan titreten bedii şekline baktım. Kurşuni podösüet iskarpinleri, ince ipek çoraplarıyla öyle muharrik öyle füsunlu bir ahenk hâsıl ediyordu ki... Sanki "şiir" mefhumunun mücessem bir manasıydı.  
— ... Geldiğinizi niye ben duymayayım?  
— Rahatsız etmek istemedim.  
— Beni mi?  
— Sizi.  
Diye nazik bir cümleye başlayacaktım. Birdenbire tavrımdan sıkıldım. Elimde büyüyen, birkaç sene evvel denizde kucağıma alarak yüzme öğrettiğim çocuğun karşısında küçülüyor muydum? Vâkıâ işte o büyümüş, koca bir kız olmuştu. Fakat ben, ağabeysinin ağabeyisi... Belki kendimi sıksam, babası da olabilirdim. Teklifsizce güldüm:  
— Kızımı rahatsız etmek ister miyim ya...  
— Kızınız kim?  
— Sen...  
Çılgın bir kahkaha attı:  
— Ben mi?  
— .....  
— Ben ha...  
— .....  
Sol elini kalçasına koymuş, şuh bir şımarıklıkla gülüyordu. Koltuğun birisine oturdu. Sade esvabı onu daha ziyade güzelleştirmişti. Gülümsüyor, ne diyeceğimi kestiremiyordum.  
— Siz hakikaten tuhaf bir adamsınız! dedi. Beğendiğiniz kadınlara mı, yoksa beğenmediklerinize mi, böyle büyükbaba tavrı takınırsınız?  
— .....  
Cevap vermediğimi görünce birdenbire ciddileşti. Yüzünü bir heykel sükûtu kapladı. Büyük gözlerini yumdu. Keskin bir bakışla beni bir süzdü. İçimden: "Rol, rol, isterik rolleri!" diyordum.  
— Kaç yaşındasınız?  
— Herhalde Sütûde'ciğim, senden yirmi yaş büyük.  
— Onun için mi bana "kızım!" diyorsunuz?  
— Hakkım yok mu?  
...Karşısına oturdum. Onu küçükken nasıl sinemaya götürdüğümü, orada nasıl dizime başını koyarak uyuduğunu hatırlattım. İşitmiyor gibi dinliyordu.

Yavaş yavaş renginin solduğunu, dudaklarının titrediğini görüyordum. Acaba hasta mıydı?  
Gevezeliğime, şakalarıma devam edemedim.  
— Ne var Sütûde?  
— Hiç! Dedi.  
Sonra gözlerini önüne indirdi:  
— Ben sizi ne vakitten beridir yalnız görmek isterdim.  
Niye beni yalnız görmek istediğini bilmem niçin soramadım. Şaşaladım. Hafifleyen yağmurun camlardaki sızışlarına bakmaya başladım. Ne kadar böyle durduk, hatırlayamıyorum. Birdenbire onun hıçkırdığını işittim. Kolunu oturduğu koltuğun yanına dayamış, başını ellerinin içine almış, ağlıyordu. Dolgun omuzları, siyah parlak saçları, bir zambak gibi beyaz, nefis elleri hıçkırdıkça sarsılıyordu. Bir sinir buhranı mıydı? Dört beş ay vardı evlerine gelmemiştim. Bu esnada, Sermet'in spor arkadaşı Tevfik Çesban tarafından Sütûde'nin, istenildiğini, sonra reddolunduğunu duymuştum. Gizli bir aşk faciası mı vardı? Çesban çok güzel, çok yakışıklı, çok zengin bir gençti. Sütûde'yi alamadığı için Ada'dan kaçmış, Beykoz'un halî tepelerinde bir eve kapanmıştı. İstanbul'a hiç inmiyor, memleketi bütün bütün terketmek için yolların açılmasını beklediği söyleniyordu. Ayağa kalktım. Elimle omuzunu okşadım:  
— Ne var Sütûde, niye ağlıyorsun?  
Hıçkırarak, yaşlı gözlerini kaldırdı. Bakışında sanki bir alev, siyah bir alev vardı.  
— Ben, seni seviyorum! Dedi.  
— Beni mi?  
— Seni.  
Birdenbire yüreğim hop etti. Ben, bu yeni kızlardan bir ejderhadan ziyade ürkerim. Korktuğumu belli etmemek için güldüm:  
— Sen deli olmuşsun! Dedim.  
Gayri ihtiyarî geri çekildim. Kanepenin ucuna büzüldüm. Kapıya baktım.  
— Vallahi, billahi seni seviyorum. Hem üç seneden beri. Eğer beni almazsan, vallahi, billahi kendimi öldürürüm.  
— Sen deli olmuşsun, sen deli olmuşsun...  
Diye gülüyordum. Kalkıp kaçmak aklıma geldi. Zavallı kızın zihninde bir bozukluk mu vardı? Gözlerini bana dikmiş, garip bir ısrarla bakıyordu. Doğruldu. O bakışla beni bir tesir altına almak istiyor gibi yürüdü. Ta yanıma geldi. Oturdu. Kucağımda büyüyen bu kızın ağzından benim vaziyetimdeki, benim yaşımdaki bir adama karşı –bir romanda okusam hayal olduğuna bile inanmayacağım– tuhaf şeyler çıkıyordu. Dizlerime kapandı. Ellerimi tuttu. Çektim, eğildi, ayaklarımı öpmeye çalışıyordu. Kaldırmaya uğraştım. Ağlıyor, hıçkırıyor, "Allah aşkına, beni reddetme, beni kovma, senin esirin olacağım!" diyordu. Fakat niçin? Fakat niçin? Ne genç, ne güzel, ne zengindim. İsterik bir çocuğun elinde oyuncak olmak hiç işime gelmezdi. Gülmeyi bıraktım. Gayet ağır bir sesle:  
— Ciddi olalım, Sütûde, dedim, seni kendine hürmete davet ederim.  
Kollarından tuttum. Kaldırdım. Yanıma oturttum. Gözlerinden hâlâ yaşlar akıyordu. Sordum:  
— Çesban'a niye varmadın?  
— Ondan nefret ederim.  
— O genç!  
— Evet.  
— O zengin!  
— Evet.  
— O güzel!  
— Evet.  
— O çok güzel. Tam sana lâyık! Senin kadar güzel. Yüzünü ekşitti. Tekrar:  
— Ben ondan nefret ederim, dedi.  
— Niçin?  
— Evvela güzel olduğu için.  
— Sonra?  
—Genç olduğu için.  
. . . . . .

Çesban'ın hayali gözümün önüne geldi. Kuvvetli, yakışıklı, âdeta eski Yunan heykellerinin canlı bir numunesiydi. İnce, kumral kaşlarının altında iri elâ gözleri necip bir sükût ile bakar, çehresinde herkesi hürmete mecbur eden asil bir vakar parlardı. Eğer birleşselerdi, Sütûde'yle ne bedii bir ahenk teşkil edeceklerdi. Halbuki İstanbul'un bu en güzel kızı gençlik gibi güzellikten de tiksiniyordu. "Güzellik kadınlar içindir. Güzellik erkeklerde iğrenç bir çirkinliktir" diyordu. Münakaşamız epeyce uzun sürdü. Ben arada, beklenmedik izdivaç tekliflerine maruz kaldıkça, tekrarladığım ezelî yalanıma, onu da inandırdım. Sıhhatim, rengim, afiyetim ciddi değildi. Âdeta hepsi bendeki hastalığın zahirî maskeleriydi. Asabım bozuktu. Dimağımdan mustariptim. Sözde doktorlar bana alkolle, yorgunlukla, meşguliyetle beraber aşkı da katiyyen menediyorlar, "kadın senin için zehirli bir hançerdir!" diyorlardı. Bu yalanları o kadar sahih gibi söylüyor, o kadar ciddi tafsilat veriyordum ki, Sütûde bana acımaya başladı. Aşkı birdenbire merhamet oldu. — Evet, her şeyden mahrum. Tıpkı bir mefluç gibi. — Ne yazık, ne yazık... Diyordu. Ben tehlikeyi kolayca savdığım için seviniyor, bu sevinçle beyaz, nefis ellerini tutuyor, öpüyordum. Bu eller, Yarabbi... Bu vücut, bu taşan, bu galeyan eden güzellik... Kimbilir buna sahip olan ne kadar mesut olacaktı. Çesban'ın meyus olmakta çok hakkı vardı. Bu kız sevildikten sonra mümkün değil unutulamazdı.

Yağmur iyice dindiği için müsaadesini istedim.  
— Gece kalsanıza... Ağabeyim şimdi gelir. Annem de gelecek.  
— Bir işim var. Bu akşam mutlaka İstanbul'da bulunmalıyım.  
— Ne vakit sizi bekleyeyim?  
— Mademki burada bana acıyan müşfik bir kalp buldum. Her vakit sizi ziyaret edeceğim. Sütûde'ciğim. Her vakit...  
Eflatunî denemeyecek bir derâguş içinde kalktık... O an bilmem, nasıl münasebetsiz, nasıl uğursuz, nasıl şenî bir fikir dimağımı doldurdu.  
— Hakikaten güzellik, çirkinlik hakkındaki düşüncen doğru mu Sütûde? Diye sordum.  
— Evet, dedi.  
— Yalan.  
— Vallahi sahih.  
— O halde hakikaten fikrinde samimî isen, senin için ideal bir âşık var, dedim.  
— Kim?  
— Son derece çirkin!  
— Oh.  
— Hatta topal!  
— Oh.  
— Hem yaşlı, Benden çok büyük.  
— Oh kim?.. Kim?..  
— Çirkinler kralı!  
İri, siyah gözleri birdenbire bulutlandı. Öyle durdu. Çirkinler kralı şüphesiz gözünün önüne gelmişti. Ada'da her sene en güzel kadına "kraliçe" unvanı vermek âdetti. Kraliçe, her sene değişir, eskisi unutulmazsa bile ikinci derecede kalırdı. Buna mukabil erkeklerin arasında da bir "çirkinlik kralı" intihap olunur. Ali Bey, on senedir bu unvanı muhafaza etmişti. On sene içinde Ada'ya kendinden çirkin bir adam gelmedi. Onun için meşhurdu. Uzvî çirkinliği, ahlâkının berbatlığı yanında mücessem bir kutsiyet gibi pak kalırdı. Son derece sarhoş, politikacı, kavgacı, mütecaviz, dedikoducu, pis bir herifti. Mütemadiyen karı alıp boşuyordu. Bütün hayatı hizmetçi kızlarla, balıkçı kızlanrıyla geçiyordu. Yüzü... Kılları tıraş edilmiş bir orangutan surat! Anlatamam, anlatamam. Çürük dişlerinin, kocaman korkunç ağzında öyle çirkin bir sırıtışı vardı ki... Bana soğuk ürpermeler verirdi. Küçükken çektiği kemik hastalığından sağ bacağı beş santimetre kadar kısa kalmıştı. Uzun, zayıf kollarını sallayarak otuz beş derecelik bir zaviye ile dört tarafa yalpa vurarak yürürken, onu gören çocuklar, korkularından bağırırlardı. Hâsılı bu bir insan değil, bir alâmet, bir rezaletti. Tabiatın bir rezaleti, tabiatın bir küfrüydü. Sütûde, derin bir hülyaya dalmış gibi birdenbire sustu. Veda ettim. Onu öyle bıraktım, çıktım. Çamurlu sokaklardan inerken o kadar hafiflemiştim ki... Kollarımı kanat gibi oynatsam, doğru iskelenin üzerine uçabileceğim sanıyordum.

Geçen yaz...

..... Sütûde'nin çirkinler kralıyle muaşakası herkesi şaşırttı. Kimse inanamıyordu. Fakat iş birdenbire ciddileşti. Bu güzel, bu emsalsiz kız, o gudubet, o bitkin, o iğrenç herifin, kovulmuş yedi karıdan arta kalmış, pis yatağına kaçtı. Ne akrabalarının mümanaat ini ne ailesinin reddini dinledi. Zavallı güzel Çesban da ümitsiz kalınca yaşayamadı. Bu şenî izdivacın ertesi günü, kendini öldürdü. Bana gelince... Tuhaf bir ıstırap içinde üzülüyordum. Çirkinler kralıyle Sütûde'nin birbirlerine sarılmış, dudak dudağa hayalleri zihnimi dolduruyor. İğrenç çirkinliğinin ilâhi güzellikle kaynaşması, ruhumda bir gazap isyan ettiriyor. Şair Fâzıl, "aş"ı, hodgâm tabiat tarafından –cinsimizin temadi si için–  bize insafsızca oynanılmış bir "dek" telâkki eder. Der ki: Bu vücudun heves-i Leylâsı, O vücudun sebeb-i eşfası... Acaba şuh gençlerin hasta ihtiyarları, en güzellerin en çirkinleri böyle delice sevmelerinde de bu ahlâksız, bu menfaatperest tabiatın gizli bir hilesi, gizli bir kârı mı var?

İşte, şimdi ben bunu düşünüyorum...

# Üç Nasihat

— Halk Edebiyatından —

Durmuş'un bir anasından başka kimsesi yoktu. Fakirdi. Ama gençti, kuvvetli idi. Öküzünün biri ölünce tarlasını süremedi. Para kazanmak, tekrar çiftliğini düzebilmek için gurbete gitmeye karar verdi. Gurbet, İstanbul demektir. Köyde kim çaresiz kalırsa, kimin işi bozulursa, İstanbul yolunu tutar. Durmuş da torbasını omuzladı. Çarıklarını sıktı, eline bir değnek aldı, gurbetçilerin arasına katıldı. Dere tepe aştı. Nihayet İstanbul'a geldi. İki gün hemşerilerinin kahvesinde pinekledi. Ne iş tutacağını bilmiyordu. Bir sanatı yoktu. — Bari uşak olayım, dedi. Kapı aramaya başladı. Bir hafta geçti. Münasip bir yer bulamadı. Bir gün kahvede Müstakim Efendi isminde birini salık verdiler; evi Edirnekapı'da idi. Durmuş gitti. Bu efendiyi buldu. Ak sakallı, nur yüzlü bir ihtiyar... Eteğini öptü: — Uşak arıyormuşsunuz, beni alın efendim, dedi. Müstakim Efendi, onu tepeden tırnağa süzdü. Nereli olduğunu sordu. Durmuş: -Kastamonuluyum, dedi. -Evli misin? - Hayır. -Anan, baban var mı? -Yalnız anam var. Babam sizlere ömür... -Ne zaman İstanbul'a geldin? -On gün evvel... -On gün boş mu gezdin? — İş aradım. — Bulamadın mı? — Bulamadım. Kazanacağı parayı ne yapacağını, borcu olup olmadığını sordu. Durmuş'un verdiği cevaplardan memnun oldu. — Peki oğlum, dedi. Ben seni yanıma alayım ama, çok para veremem... Durmuş: — Ben çok para istemem efendim, dedi. — Ama ben pek az para veririm. — Ne kadar verirsiniz? — Bir kuruş. — Günde bir kuruş mu? — Hayır. — Haftada bir kuruş mu? — Hayır. Durmuş biraz şaşaladı. Tekrar sordu: — Ayda bir kuruş mu, efendim? — Hayır! Senede bir kuruş... Durmuş bu ihtiyar efendiyi kendisiyle eğleniyor sandı. Güldü. Önüne baktı. Utandı. Fakat Müstakim Efendi yine: — Senede bir kuruş, dedi. Yalnız bu kadar değil. Bir de öğüt vereceğim. Durmuş gözlerini yerden kaldırdı: — Ben öğüdü ne yapayım? Bana para lazım efendim. — Para kullanılır, biter, yahut kaybolur, oğlum. Ama insanın aldığı öğüt hiç bitmez. Ölünceye kadar işine yarar. Durmuş, mahzun mahzun yine önüne baktı. Kuru lafın işe yarayacağına hiç aklı ermedi. Tekrar Müstakim Efendi'nin eteğini öptü. Çıkıp gidecekti. İhtiyar: — Dur oğlum, dedi. Şöyle duvarlara bak... Görüyorsun ya... Hep kitap dolu... Burada beş bin kitap var. Ben bunların hepsini okudum. Ömrüm ilim ile geçti. Saçım, sakalım kitap üzerinde ağardı. Aklın, paradan daha kıymetli, paradan daha işe yarar bir şey olduğuna kanaat getirdim. Öğüt, hazır bir akıl demektir. Yoksa ben sana senede beş on lira verebilirim. Fakat paradan daha çok kıymetli olan bir öğüt veriyorum. Aklın varsa kal. Bana hizmet et. Durmuş: — Hayır efendim, bana para lazım, öğüt lazım değil, dedi. Dışarı çıktı. Sokakta yalnız kalınca düşündü. Acaba bu paradan kıymetli olan öğüt neydi? Kahveye geldi. O gece merakından uyuyamadı. Acaba tek kuruşa katık olarak vereceği öğüt ne idi? Sabah olunca Edirnekapı'nın yolunu tuttu. Müstakim Efendi'ye gitti. Eteğini öptü: — Vereceğiniz öğüdü merak ettim, dedi, bir sene size hizmet edeceğim. — Pekala oğlum, sene nihayeti kuruşunla öğüdünü alırsın... Durmuş tam bir sene kitap odasını süpürdü. Bahçeyi belledi. Su taşıdı. Merdivenleri yıkadı. Camları sildi. Müstakim Efendi'nin her hizmetini yaptı. Nihayet bir sabah efendisi onu çağırdı: — İşte oğlum yanıma gireli tam bir sene oldu. Kulaklarını iyi aç. Öğüdünü vereyim: "Yolunu, izini bilmediğin yere gitme!.." Al şu kuruşunu da... Durmuş, efendisinin uzattığı kuruşu aldı. Birdenbire canı sıkıldı. Büyük bir öğüt alacağını sanıyordu. Halbuki bu kuru bir laftı. — Ben bu öğüdü zaten biliyordum efendim, dedi. Müstakim Efendi güldü: — Biliyorsan iyi... Şimdi o bildiğini hatırladın, bu daha iyi... Durmuş alık alık bakakaldı. Demek bir sene hep bu iki çift laf için çalışmıştı ha... Efendisinin eteğini öptü. İzin aldı. Çıkıp gidecekti. İhtiyar yine dedi ki: — İstersen bir sene daha kal. Yine bir öğütle bir kuruş veririm. — Hayır, istemem efendim, diye Durmuş çıktı. Hemşerilerinin kahvesine gitti. Gece yine merakından uyuyamadı. Acaba bu vereceği öğüt ne idi? Bir sene sabretmiş, birinci öğüt için çalışmıştı. Şimdi meraktan çatlayacaktı. Acaba ikincisi ne idi? Dayanamadı. Kalktı, Müstakim Efendi'nin evine geldi. Tam bir sene daha hizmet etti. Sene nihayeti yine Müstakim Efendi onu çağırdı. Bu sefer kuruşu peşin verdi. Sonra: — Al öğüdünü: "Emanete hıyanetlik etme!" dedi. Durmuş'un yine canı sıkıldı: — Efendim, ben bu öğüdü biliyordum. — İyi ya işte... Biliyorsan şimdi de hatırladın. Bildiğini hatırlamak, yeniden bir şey öğrenmek kadar faydalıdır. Durmuş giderken efendisi tıpkı geçen seneki gibi: — Oğlum, eğer bir sene daha kalırsan, sana bir kuruşum, ama son bir öğüdüm daha var, dedi. Durmuş kabul etmedi. Çıktı. Hemşerilerinin kahvesine gitti. Bir gece, iki gece, üç gece... Rahat uyuyamadı. Acaba efendisinin bu son öğüdü ne idi? Belki bildiği bir şeydi. Ama ne idi? Hep bunu düşünüyordu. Sersem sersem iş aradı. Bulamadı. "Mademki iki senelik emeğim havaya gitti, bir sene daha uğraşır, şu son öğüdü de anlar, merakta kalmam" dedi. Tekrar geldi. Eski kapısına girdi. Tam bir sene daha Müstakim Efendi'ye hizmet etti. Sene nihayetinde efendisi yine onu çağırdı. Kuruşu eline verdi: — Al öğüdünü de, dedi. "Karını, kendin gitmediğin yere gece yatısına gönderme!" Durmuş, bu öğüde de omuzunu kaldırdı. İçinden "Dipsiz bir laf işte..." dedi. İzin aldı. Çıkacağı zaman efendisi nereye gideceğini sordu. — Artık memlekete efendim. — Başka bir yere girmeyecek misin? — Hayır. — Niçin? — Üç sene oldu gurbetteyim. Anam ihtiyar, gideyim bakayım, ne oldu? — Pekala oğlum; yalnız, yola çıkacağın zaman buraya uğra, sana bir hediye vereyim. Anana benden götür, olur mu? — Olur efendim, dedi. Hemşerilerinin kahvesine düştü. Bu sene memlekete dönecek gurbetçilere başına geleni anlattı. Hepsi güldüler: — Ulan, sen deli imişsin! dediler. Artık İstanbul'da durmak istemedi. Ama memlekete nasıl gidecekti? Cebinde üç kuruşundan başka on para yoktu. Gurbete yayan gelinirdi ama, gurbetten memlekete yayan dönülmezdi. Para lazımdı. Herkes kirayla sürücü atları tutardı. Ayakla bu sılacı kervanına karışmak mümkün değildi. Hemşerileri haline acıdılar. Aralarında ona bir beygir kiralayacak kadar para topladılar. Tam Üsküdar'a geçecekleri akşam, Durmuş, efendisinin evine gitti. — İşte gidiyorum efendim, dedi. İhtiyar kalktı, "Yolun açık olsun. Al şu hediyelerimi, anana götür" diye ona iki büyük somun uzattı. Durmuş içinden, "Hay münasebetsiz herif, şu gönderdiği hediyelere bak!" diye kızdı. Ama belli etmedi. Somunları aldı. Kahveye geldi. Heybesine koydu. Sılacılarla beraber Üsküdar'a geçti. Handa bekleyen beygirlere bindiler. Geceleyin, ay aydınlığında yola düzüldüler. Dere tepe, düz gittiler. Dağlar aştılar. Bir gün, bir ormanın kenarında taşkınca bir suya rastgeldiler. Geçecek yerini bulamıyorlardı. Durmuş, bu kadar bir su karşısında hemşerilerinin ürkekliğine güldü. Atını suya sürecekti. Tam bu esnada efendisinin verdiği öğüt aklına geldi: "Yolunu, izini bilmediğin yere gitme!" Dizgini topladı. Atının ön ayakları suyun içinde idi. Yanındaki arkadaşı durmadı. Atını sürdü. İki adım atmca birdenbire suyun içinde kayboldu. Çıksın diye beklediler. Çıkmadı. O vakit civarda bir çoban buldular. Suyun geçilecek yerini öğrendiler. Meğerse orası bir girdapmış... Durmuş, efendisinin öğüdünü hatırlayarak, atını o zavallıdan evvel sürmediğine şükretti. Bir senelik hakkını helal etti. Yolda hemşerileri ona yiyecek de veriyorlardı. Bir gün karnı çok acıktı. "Efendinin hediye gönderdiği şu somunlardan birisini koparıp yesem" dedi. Elini heybesine atarken tam bir senelik emek sarf ederek işittiği öğüt aklına geldi: "Emanete hıyanetlik etme!" Elini çekti. "Şeytana uymayayım" dedi. Birkaç gün, birkaç gece daha yürüdüler. Nihayet bir gün karanlık ormanın yanından geçiyorlardı. Ağaçların arasından: — Teslim olun! diye bir ses işitti. Durdu. Onunla beraber bütün kervan durdu. Eşkıyalar her tarafı çevirmişti. Efe meydana çıktı: — Canını kurtarmak isteyen üzerinde, başında nesi var, nesi yok buraya bıraksın. Selametle yoluna gitsin, diye haykırdı. Kimse davranamadı. Kimse kaçamadı. Eşkıyalar yolun gerisini de tutmuşlardı. Can maldan tatlı. Herkes nesi var, nesi yok, efenin önüne döktü. Senelerce emeklerle kazanılan lira kemerleri, altın keseleri, gümüş, elmas hediyeler, daha birçok şeyler... Durmuşa sıra gelince: — Benim bir şeyim yok, dedi. Efe inanmadı: — Ne demek, sen gurbetten gelmiyor musun? — Gurbetten geliyorum. — Çalışmadın mı? — Çalıştım. — Para kazanmadın mı? — Kazanmadım... — Yalan. — Vallahi kazanmadım. Hemşerilerime sor, istersen... Efe hemşerilerine sordu. Hepsi Durmuş'un para kazanmadığını, senede bir kuruşa hizmet ettiğini anlattılar. Efe, Durmuş'un aptallığına hem güldü, hem kızdı. Adamlarına: — Şu budalaya bir sopa çekin de, bir daha para kazanmadan gurbette kalmayı öğrensin, dedi. Durmuş'u yere yatırdılar. Canı çıkıncaya kadar dipçiklerle dövdüler.

Sılacıların hepsi Durmuş gibi on parasız evlerine döndüler. Durmuş'un anası daha ziyade ihtiyarlamıştı. Zavallı kadın üç senedir çektiği sefaleti anlattı: — Neye para kazanmadın, a oğlum? diye darılacak oldu. Durmuş: — Hemşerilerim gibi kazansaydım, yine eşkıyalara kaptırarak, elim boş dönecektim, dedi. Karnı çok acıkmıştı. Anasından biraz yiyecek istedi. Kadıncağız ağlamaya başladı: — Bir şey yok oğlum, iki gündür ağzıma lokma girmedi. — Bari, şu heybenin içinde, efendimin sana hediye gönderdiği somun var. Birisini kıralım, beraber yiyelim, dedi. Heybeden bir somun çıkardılar. Kırınca şangır şangır etrafa altınlar yayıldı. Şaşırdılar. Öbür somunu da kırdılar. Onun da içi altın dolu imiş. Sevinerek hepsini topladılar. Durmuş, iki senelik emeğini efendisine helâl etti. Eğer bir sene hizmet ederek aldığı "Yolunu, izini bilmediğin yere gitme!" öğüdünü aklına getirmeseydi girdapta boğulacaktı. İkinci sene aldığı "Emanete hıyanetlik etme!" öğüdünü hatırından çıkarsaydı, yolda somunları kıracak, altınlar meydana çıkacak, sonra hemşerileri gibi soyulacaktı... Yavaş yavaş düşündükçe, efendisinin ne kadar büyük, ne kadar akıllı bir adam olduğunu anlamaya başladı. Ona, İstanbul'da iken aylık verseydi ihtimal ötede beride yiyecek, biriktiremeyecekti. Yahut sılaya dönerken paralan meydanda gezdireceği için bir kazaya uğrayacaktı. Durmuş, daha çok düşündükçe "akıl" ın "para" dan kıymetli olduğuna iman etti. "Akıl" olmazsa "para" hiçbir işe yaramazdı. İşte arkadaşlarının hali!.. Dağ başlarında, eşkıya içinden, dolu kemerlerle geçmenin cezasını gördüler.

Durmuş, zengin olunca tarla aldı. Bağ aldı. Koca bir çiftlik kurdu. Köyünün ağası oldu. Ama bir türlü evlenemiyor, yaşı otuzu geçtiği halde bir kız bulup alamıyordu. Evlenmesini teklif eden köy ağalarına:  
— Ben de isterim ama bir şartla!... derdi.  
— Nasıl şart, ağa?  
— Karıyı kendi bulunmadığım yere misafirliğe göndermem.  
— Akrabalarının yanına göndermez misin?  
— Göndermem.  
— Anasının, babasının yanına da göndermez misin?  
— Kendim bulunmadığım hiçbir yere göndermem.  
— Niçin?  
— Bilmem...  
Durmuş, efendisinin son üçüncü öğüdünü bir türlü aklından çıkaramadı. İlk iki öğüdü de evvela anlayamamıştı. Ama sonra onların ne kadar faydasını gördü. Kendi köyünde, komşu köylerde bu şartla kimse kız vermiyordu. Herkes:  
— Biz evladımızı esir yapamayız, diyordu.  
Nihayet iki saat uzak bir köyde öksüz bir kız bulundu. Durmuş onu aldı. Şanına yakışır düğün yaptı. Mutlu oldu. Bir erkek çocuğu dünyaya geldi. Aradan dört sene geçti. Karısını hiçbir yere göndermedi. "Anca beraber kanca beraber" derdi. Bir gün karısının akrabaları geldi. Köylerinde düğün varmış. Durmuş'tan bir gece için izin istediler.  
— Hayır, olmaz, dedi.  
— Niçin?  
— Bilmem.  
Efendisinin öğüdü aklından çıkmıyordu. Yalvardılar, yakardılar. O razı olmadı. Kendi köylüsü de, karısının köylüsüne karıştı:  
"Zavallı kadın verem olacak" diye laf atmaya başladılar. Hep birden onun üzerine düştüler. Yemin ettiler. Durmuş artık herkesin ısrarına dayanamadı. Bir gece kalmak üzere karısını köye yolladı. O akşam pişmanlığından yemek yiyemedi. "Niçin efendimin öğüdünü dinlemedim" diye sıkılmaya başladı. Dinlediği ilk öğüdünde ne büyük faydalar görmüştü. Şimdi son öğüdü dinlemediği için kimbilir ne büyük bir zarar görecekti? Duramadı. Uşaklarına atını hazırlattırdı. Geceleyin iki saat ötedeki köye yetişti. Düğün evinin önüne gitti. Delikanlılar çitlere dayanmışlar, avluda, meşaleler altında oynayan kızlara, kadınlara bakıyorlardı. O da yaklaştı. Karısının, çocuğuyla beraber bir köşede büzülmüş oturduğunu gördü. Acaba bu gece hangi akrabasının yanında yatacaktı. İçine bir kurt girdi. Döndü. Arkasına baktı. Bir kocakarı geçiyordu. Ondan bunu anlamak istedi.  
— Bana bak nine sana bir şey soracağım.  
— Sor oğlum.  
— Şu köşede çocuğuyla beraber bir taze oturuyor, görüyor musun?  
Kocakarı dikkatle baktı:  
— Görüyorum, dedi.  
— Kimin nesidir o?  
— Ah evladım, sorma. Onu bir zalim herif aldı, zavallı tazeye dünyayı zindan etti. Dört senedir işte, köyüne yeni geliyor...  
— Acayip...  
— Evet, bütün köylü zorladı da, bu sefer izin alabildi. Kocası öyle fena, zalim bir adam ki...  
Durmuş'un yüreği atmaya başladı. Karısının nerede yatacağını sordu. Kocakarı:  
— Bilmem, diye cevap verdi.  
Durmuş düşündü, taşındı, birdenbire dedi ki:  
— Beni bu gece bu kadınla yatırabilir sen, sana beş altın veririm.  
— Yiğidim ondan kolay ne var?  
— Demek beni onunla yatırabileceksin?  
— Elbet.  
— Nasıl?  
— Onun akrabaları benim kapı bir komşumdur. Benim her sözümü dinlerler. Avlularının sonunda tek bir oda vardır. Gider, onları kandırır, bu kadını oraya yatırırım. El ayak kesildikten sonra seni götürür gizlice bu odaya sokarım.  
— Doğru söyle...  
— Sen, hemen altınları ver, yiğidim.  
Durmuş kesesinden beş altını çıkardı. Kocakarıya verdi. Atını onun avlusuna bağladı. Hiddetinden tir tir titriyordu. Gece yarısı geçti. Kocakarı geldi. Onu aldı. Küçük bir bahçe kapısından geçirdi. Bir avlunun en sonundaki tek odaya soktu. Durmuş yüzünü salıyla sarmıştı. Karısı onu tanımadı. Hemen bağırmaya başladı. Durmuş sesini çıkarmadı. Kapıyı kitledi. Üzerine yürüdü. Zavallı kadın köşeye büzülmüş, hem bağırıyor, hem tekme atıyordu. Durmuş'u yanına hiç yaklaştırmadı. Akşamdan uyuyan oğlu yatağın üzerindeydi. Annesinin haykırmasına uyanmadı. Mışıl mışıl uyudu. Durmuş, karısını daha çok bağırtmamak için kapının yanına oturdu. Hiç sesini çıkarmadı. Bütün gece ağlayan kadıncağız sabaha karşı korkudan, yorgunluktan sızar gibi olmuştu. Avluda horozlar öttü. Durmuş yavaşça yatakta uyuyan çocuğunu aldı. Sessizce dışarı çıktı. Avluyu geçti. Atına bindi. Dörtnala köyüne döndü.  
Karısının akrabaları, gece çocuğun çalındığını duyunca, ne yapacaklarını şaşırdılar. "Ağaya ne cevap vereceğiz?" diye düşünmeye başladılar. Kocakarı buna da bir çare buldu:  
— Bu oda zaten eski... Yakınız. "Gece yangın oldu, çocuğu kurtaramadık" dersiniz, dedi.  
Onu dinlediler. Hemen odayı yaktılar. Ağlayarak, sızlayarak, Durmuş'un karısını evine getirdiler. Hepsinin alnında çatkı vardı. Dövünüp duruyorlardı.

Durmuş: — Çocuk nerede? diye sordu. — Ah olan oldu! Gece odamız yandı. Çocuğu kurtaramadık, dediler. Durmuş güldü: — Neye ağlıyorsunuz canım, dedi. Başımız sağ olsun. Elhamdülillah genciz. Allah başkasını verir. Karısının akrabaları, Durmuş'un bu soğukkanlılığından biraz ferahlar gibi oldular.

Tam bu sırada kapı açıldı. Durmuş'un çocuğu içeri girdi. Annesinin kucağına atıldı. Çocuğun yandığını söyleyenler şaşırdılar. O vakit Durmuş: — Gördünüz ya, yalancı alçaklar, niçin karımı kendimin bulunmadığı yere göndermiyormuşum, diye bağırdı. Hepsini, tekme tokat, kovdu. Karısına döndü: — Eğer gece orada bana el sürseydin hemen seni öldürecektim. İşte ibret al da, sakın bir daha kocandan ayrı bir yere gitmek isteme, dedi. İhtiyar efendisine üç senelik emeğinin hakkını da helâl etti.

# İki Mebus

Maî ve serin bir sonbahar gecesiydi. Cesîm ağaçlarıyla hakikaten baîd bir peri ormanına benzeyen muhteşem bahçenin ortasındaki mahfel-i üdebâda bir hafta evvel ölen şair Perviz'in hayat ve hususiyetine, sanat ve muvaffakiyetine dair bir konferans veriliyordu. Münevver bir hiyâbân-ı rüya gibi uzayan ve uzadıkça hayalileşen, muntazam yolun nihayetinde, mahfelin kapısı uzak ve serabî bir saray medhalini andırıyor, beyaz ve cesîm peronun basamakları, yanlarında sıra ile yükselen mermerden masnû esatiri kadınların ellerinde tuttukları nâim ve muzî elektrik kürelerinden yağan donuk ve tatlı ziyâlar altında göz kamaştırıcı bir vuzuh ile parlıyordu. İhtiyar ve bîgâne kamer, seyrek ve ince bulutların arasından, lakayd ve acûl veriyor, dışardan caddenin gürültüleri, eğlenceli bir şehrin, meşhûn-ı serâir bir zevk memleketinin musikî-i ananâtı gibi müphemiyetle aksediyor, büyük ve kesif ağaçların aydınlıkla mezcolan zîhayat ve nur-âlûd zulmetlerinde nâmerî ürpermeler husule getiriyordu. Geniş ve beyaz mesnedleri üzerinde sanki ezeliyeti düşünen beyaz heykeller; bu şimdi yaşamayan meşâhîrin müessir ve mevt-âmiz timsali hatıratı, üzerlerine dudaksız ve gayr-i nâsut buseler halinde düşen yaprak gölgeleri altında, namahsus rüzgarın ketum negamâtıyle sanki canlanıyor, sanki kımıldıyorlardı.

Konferans yarım saat evvel başlamıştı. Münevver yolun tenhaî-i mahzunu içinde, bir zıll-i müteharrik gibi, narin bir genç, elleri cebinde, önüne bakarak ilerliyordu. Galiba, şimdi kuğuları uyuyan büyük ve hali havzın kenarına, bahçenin bu en sık ve hâbîde yerine gitmek istedi; nîm muzlim yola, yekdiğerini derâguş etmiş mühîb ağaçların altına sapacaktı, yanından bir ses geldi: — Nereye evlat, böyle? döndü. Bu temiz ve henüz pek yeni bir statünün musanna ve menkuş mesnedine dayanmış yetmişlik bir ihtiyardı. Tanıdı: — Ne o, aziz üstad, dedi, burada yapayalnız ne yapıyorsun? İhtiyar dayandığı statüyü göstererek: — Arkadaşımla, refik-i şebâbımla konuşuyorum. Diye cevap verdi. Beyaz ve çok saçları ile, yetmiş senenin çöktüremediği kavî ve dik vücuduyla hâlâ dinç ve muârız duran ve gençlerin, bütün İstanbul'un, belki bütün Türkiye'nin "feylesof" dediği bu zatta pek garip bir mizaç, pek tuhaf bir tabiat vardı. Şedîd bir egoizm onun bütün mevcudiyetine hâkimdi. Neden bahsederse kendi söylüyor, muhatabını bîzâr ediyordu.

"Evlat!" diye teklifsizce hitabettiği genç, Vedid İstanbul'un en ateşîn, en alim, en muhterem bir mebusu idi. Talebeliği zamanında umumî bahçelerde, bu ihtiyar feylesofu dinlemekten epeyce hoşlanırdı. Fakat şimdi... En ziyade onun iddialarından, edebiyatından bıkmıştı. Yarım asır evvelki kof ve iptidâî harekat-ı edebiyye artık dinlenemezdi. Zaten bütün bu mânâsız gevezelikleri beş altı sene evvel belki yüz defa bizzat feylesoftan dinlemiş,  ezberlemişti.. Yine bu garip ihtiyara yakalanmamak, onun bir kütüphane kataloğu gibi yalnız lâyetenâhî ve meçhul muharrir isimlerinden, unutulmuş kitap serlevhalarından müteşekkil tâkatfersâ malumat ve musahabâtı altında muztarip olmamak için: — Geziniyordum, dedi, şimdi yemek yedim. Bu gece yazılacak yazım, tertibolunacak nutkum var. Geç kalamayacağım. İhtiyar feylesof hayretle sordu: — Demek Perviz için verilen konferanstan haberin yok? Vedid, omuzunu silkerek cevap verdi: — Var. Fakat dinlemeye tahammülüm yok. Artık edebiyat beni sıkıyor... Feylesof yaklaşmış, kalın adalî kolunu gencin omuzuna atmıştı: — Zavallı Vedid! dedi, acıdım sana. O halde ihtiyarlamışsın. Ne vakit ki insan edebiyattan nefret hissetmeye, kafiyeler, mısralar nazarında boş, vâhî, muacciz görünmeye başlar, ihtiyarlığın soğuk ve kemikten iskelet elleri onun kalbine uzanmış demektir. Ve statüyü göstererek ilave etti: — Evet bu da... Bu zavallı Tevfik Fikret deteab-ı tahassüsle ihtiyarlayınca edebiyattan nefrete başlamış, şebâbındaki bütün hevesât ve tahayyülatını kaybetmiş, bir bedbin olmuştu. Sonra hep elem terennüm etti, dökemediği gözyaşlarını besteledi ve matemlerini ebediyetle bizim ruhumuza bıraktı... Vedid ansızın asabileşmişti: — Rica ederim, üstad, edebiyattan bahsetmeyiniz! Feylesof, muhatabının göremediği sarih bir işmi'zâz-ı nahoşnûdî ile, sanki inler gibi: — Niçin? dedi. — Niçin mi? Çünkü tavrınız pek eski... Pek klasik! Mesela şimdiki sözünüzü, hatta elinizle şu heykeli göstermenizi köhne ve klasik buluyorum. Karşınızda kendimi edebiyat muallimlerinin gayr-ı tabiîliklerine mahkum-ı tahammül bir mektep talebesi zannediyorum. Vedid, bütün sınıflarda birinci olmuş, ulûm-ı iktisadiye ve içtimâiyeden birinci olarak diploma aldıktan sonra ilk neşrettiği makale-i içtimâiyesi değil Türkiye'de, hatta bütün Avrupa'da ve Amerika'da ani bir şöhret kazanmış, hemen beynelmilel mâî lisana tercüme edilerek, yine beynelmilel "Beşeriyet-i Müttehide ve Ulûm" cemiyeti tarafından en büyük mükafata layık görülmüştü. Lakin bütün bu muvaffakiyetler onu değiştirmemişti, mütevazi olmadığı gibi asla mağrur ve mütekebbir de değildi. Şimdi, hissinde ne kadar zayıf bir egoist olduğunu iyice bildiği feylosofu, bu zavallı ihtiyarı gücendirdiğinden birdenbire pişman oldu ve onun dargın bir lisan ile: — O halde hiç konuşmayalım... demesine gülerek: — Hayır, konuşalım, sevgili üstad! diye mukabele etti, konuşalım, fakat biliyorsun ki ben mebusum. Daima mesleğimden bahsetmek, ona dair konuşmak, onu düşünmek isterim, söyleyiniz, siz de evvelden bir mebus değil miydiniz? Gönlünü bütün bütün almak ve kendini tamamıyla affettirmek için feylesofun koluna girdi. Yürümeye başladılar. Genişçe yolun etrafında sıralanan kadim ve müteahhir şairlerin, meşâhîr-i üdebânın mebhut heykelleri derin bir sükun-ı müncemid içinde, muztarip ve mütecessis onlara bakıyor gibiydi. Feylesof mırıldandı: — Evet, hatta ilk Meclis-i Mebusan'da âzâ idim. Vedid, refîkinin hâlâ katı duran bazusunu sıktı: — O halde mesleğimizden bahsedelim. Ben de istifade ederim! Bu "istifade ederim" sözü ihtiyarın bütün zaaflarını okşadı. Lafının dinlenmesi, onun, sabâvetinden beri yegane saadetiydi. Bir çocuk gibi sevindi. Orada, yolun kenarında kesif ağaçların, mebzûl ve münevver yaprakların altında bulunan bir kamış kanepeyi göstererek: — Buraya oturalım da... Dedi. — Oturalım... Oturdular. Vedid, biraz uzakta kalan lambaların tatlılaşan ziyâları içinde ihtiyar refîkine bakıyordu. Bu tıpkı bir lakırdı makinası gibiydi. Mükemmelen dokuz lisan biliyor, bir milyona karîp kitap okuduğu rivayet olunuyordu. Şimdi yanında beliğ, revan bir ifade ile Meşrutiyet'in ilan-ı nagihanîsini, ilk Meclis-i Mebusan'ın nasıl müşkilat ile açıldığını ve kendisinin ilk konferanslarını, nutuklarını, muvaffakiyetlerini, husûle getirdiği heyecanlı alkışları, payitahtın muhafaza-i asayişine nasıl memur olduğunu, o vakitki Sultan'ın karşısına nasıl çıktığını anlatıyorken, Vedid, onun yetmiş senelik hayatını düşünüyor, hayalen senelere, aylara, haftalara taksim ediyor, bir milyon kitap okumak için lâakal her gün üç kitap okuyup bitirmesi lazım geleceğini hesap ediyordu.

Feylesof, o kadar şiddet ve muhabbetle atf-ı ehemmiyet ettiği mazinin hurûş-ı hatıratıyla: — Ah siz, diyordu, siz pek mesutsunuz. Yorulmadan, üzülmeden kazanıyorsunuz. Muntazam ve müsterih çalışıyor, sahih ve mutmain muvaffak oluyorsunuz. Halbuki biz! Hayatımızın en güzel devresini, muazzez ve avdeti muhâl olan gençliğimizi, artık sizin nesl-i ahîrin mümkün değil tahayyül ve tasavvur edemeyeceği bir esaret-i mutlaka içinde geçirmiştik. İlim ve fazilet en büyük cinayetti. Namuslu olanlar mahbeslerde çürütülüyordu. Vatan can çekişiyor, son nefeslerini veriyordu. Evet bugün, yakında teşekkül edecek olan "Avrupa Düvel-i Müttehidesi" heyetine girmesi için bütün diplomatların, parti reislerinin payitahtına koşuştukları kavî ve mehîb Türkiye; bu muazzam ve muhteşem hükümetimiz, komşularımıza daimi heyecanlar veren hevilnâk ve müthiş ordumuz, dünyada o vakit neşrolunan ne kadar mizah gazetesi varsa hepsine sermaye-i istihza olmuştu. Bugün Avrupa'nın en necip, en zeki, en zengin ve faal bir kavmi olmak üzere tanılan Osmanlılar, bilatereddüd "Avrupa'da çergesini kurmuş bir çete!" diye tahkir olunuyor, mevcudiyet-i medeniyyeleri katiyen inkar ediliyordu.

Vedid önüne bakarak: — Mübalağa ediyorsunuz. Dedi. Fakat feylesof, Şeyhûhetin verdiği ateh-i gayr-i ihtiyari ile feveran etti: — Mübalağa mı? Azamet ve muvaffakiyeti içinde büyüdüğümüz bu muazzam hükümetin taksim planı yapılmış. Hatta harita-i mukasemesi bile çizilerek tabedilmişti. Cehalet, yeşil ve siyah bir zulmet, yalnız neşe-i mâîsi ile sizi mest ü zevk-yâb eden bu parlak ufukları örtmüştü. Herkes birbirine garez, düşman, haindi! Yalnız kin, taasup, tenezzül, itisâf vardı. Çalışanlar aç kalıyor, öğrenenler tahkir olunuyor, muhibb-i ulûm olanlara umumî bir nefret besleniyor, vukuf afolunmaz bir küfür addolunuyordu... Vedid yine feylesofun lafını kesti: — Mübalağa, mübalağa... Üstad! Sizin eski edebiyatınızda bir sanat varmış. İşte şimdi onu yaparak mütelezziz oluyorsunuz, yani gulüvv... Mümkün mü bu kadar muzmahil olan bir millet otuz sene içinde bütün milletlere tefevvuk etsin? Feylesof başını salladı ve gülümsedi: — Evet, mümkün, evlad! Bizim inkılâbımız pek tuhaf olmuştu. Muasırlarımızdan birçokları istiâne ve istifâzayı, taklit kanununu inkar ediyor, "kendi muhitimizde, kendi muhit-i milliyemizde mahsur ve muhafazakar itilâ edelim." diyorlardı. Eğer ekseriyet, cehaletin kesâfetinden istifade ederek fikirlerini kabul ettirebilselerdi, hakikaten bu kadar teâlî ve tekamül mümkün olamazdı. Fakat biz, o vakitki gençler galebe çaldık, istifade ve taklidi kabul ettirdik. Avrupa medeniyetini, garbin terakkiyatını titremeden, çekinmeden kabul ediverdik. Nasıl tabir edeyim? Maraz-ı harabiye tedavi için bütün eczaları bizzat yapmak ile, bizzat kimyahâneler inşa ve asırlarca çalışmakla iştigal etmedik. Devalar icad ve tertibine kalkmadık. İlacı müstahzar bulduk. İşte bu haricî ve müstahzar hapı şüphelenmeden, tiksinmeden yuttuk. Ve şifayâb olduk. Evet garpte batınların hazırlayarak mütevâlî dehaların vücuda getirerek tevârüs ettirdiği terakkiyatı biz bir hamlede kendimize malettik. Merdivenin en üstüne sıçradık. Zaten bu da pek tabiî bir hadise-i içtimâiye, bir hâlet-i muaşeriye idi. Gecikmiş kavimler binayı tekamüle yavaş yavaş çıkmaya razı olmazlar, fırlarlar, asırların müterâkim kuvvet-i itilâsıyla yükselirler. İşte Japonya... Filhakika bugün bizden geridedir, fakat daha otuz kırk sene evvel, ani denilebilecek bir sürat-i berkıyye ile o da ihtiyar garbin semerât-ı mesaisini aldı, kendine maletti. Biz daha heyet-i düveliyeden addedilecek kadar bir lakaydî-i muhakkire maruz iken, o, mevcudiyet-i milliyesini isbat etti. Ah, evet, sen Meşrutiyet'ten sonra doğdun, serbesti ve hürriyet içinde büyüdün. Eğer on yaş daha küçük olaydın, bu güzel mahfilin, bu büyük ve bedi bahçenin yerinde viraneler, yıkık kulübeler, harap evler, sefil ve sıska köpeklerle mâlî tenha, dar, meyus sokaklar bulunduğunu derhatır edecektin...

İhtiyar feylesof anlattıkça müteheyyic oluyor, müteheyyic oldukça en küçük teferruatı canlı bir ifade ile tafsil ediyor, ellerini kaldırıyor, bazen ayağa kalkıyor, tekrar kanepeye bîtap düşüyor, hikâyesine hararet ve hareketle devam ediyordu. Vedid dinlemekten yorulmuştu. Zihnen yarınki nutkunu tertibediyor, bu hezeyan-ı pîrîye tutulmuş eski mebusun yanında, yarın yeni bir mebus sıfatı ile gireceği meclisi düşünüyor; otuz senelik bir fark-ı hayatı bu nisbetsizliğe kıyas ederek beşeriyetin önündeki tekamül asırlarını tahayyül ediyordu.

Feylesofun beste-i cûşân-ı kelamını uzak ve tanînendaz bir nutuk gibi işitiyor, güfte-i mânâya bîgane kalıyordu. Halbuki zavallı ihtiyar, ilk meclis-i mebusanın reisi kim olduğunu, vilayetlerden ilk fırkaları, milliyet münakaşalarını, adem-i tefehhümleri, ahalinin tarz-ı garip telakkisini, güzel ezberlenmiş bir müdafaanâmeyi tereddüd etmeden söyleyen serbest ve usanmaz bir avukat masumiyetiyle anlatıyordu. Vedid, başka şeyle meşgul olarak mânâsından kurutlduğu bu sözlerin sedasından da muztarip olmaya başladı. Sıkılıyor ve hafif bir hararet, sıcak ve mahsus bir nefes gibi şakaklarına yükseliyor, küçük serpûşunun altındaki çok saçlı başı kaşınıyordu. Eski ve ihtiyar mebus hâlâ, karşısındakilerin vukufsuzluklarına nasıl hücum ettiğini, traftarlarının azlıklarına rağmen sahip oldukları nüfuzu naklediyor, hatta muarızlardan aldığı cevapları aynıyla tekrar ediyordu. Vedid, saçlarını karıştıran narin elini yeleğinin cebine soktu. Artık boğulacaktı... Küçük ve radyum mineli zarif bir saat çıkardı. Şedîd ü bizzat bir ziyâ ile eşia nisâr rakamlar, parlak yelkovan, aydınlık gecenin mor ve münevver karanlıkları içinde nısful-leyli gösteriyordu. Dayanamadı. — Artık gitsek, dedi, zira üşüyorum. Feylesof meşhur olan hafızasının şiddet-i fevkattabîiyyesine feda olan zayıf sürat-i intikaliyle, her saati kendisine beş lira getiren bu muktedir ve muhterem genci sıktığını anladı. — Evet, evet gidelim, diyordu, hakikaten çok soğuk. Lafa daldık. Konferans da bitmek üzeredir... İstersen bir parça da oraya gideriz. Vedid yine reddetti: — Hayır, ben gideceğim. Feylesof: — Öyleyse ben de giderim. Yalnız sıkılıyorum, dedi. Kalktılar. Rüzgar yoktu. Kamer kaybolmuş, batmıştı. Yolun etrafındaki yüksek ve muazzam ağaçların üstünde siyah sema, mâî ve mebzul elmasları andıran lâyuad ve lâyetenâhî yıldızlarıyla bir nehr-i mutalsam-ı necm-âlûd gibi ebediyetin meçhuliyetine doğru uzanıyor, heykeller mahûf ve beyaz heyulalar halinde câmid ve ebkem nazarlarıyla, önlerinden bir gün yanlarına mermerden vücud-ı timsalîleriyle mutlaka gelip dikilecek olan bu iki zîhayat-ı meşhura, müstehzi ve mütebessim bakıyorlardı.

İkisi de susuyordu. Artık mahfile yaklaşıyorlardı. Zavallı Perviz'in üfûl-i ebedisi için bestelenen hava-i matem, lâhutî ve mübhem bir heyecan ihsas ederek uzaklardan bir ah-ı müterennim samimiyetiyle feylesofun uğuldayan kulaklarına aksediyor, elektrik küreleri zulmette nurdan cesîm inciler, mütekâsif ve mehib gözyaşları gibi parlıyordu.

Feylesof durdu, bu münkesir, ağır, mevt-âmîz terennümden, bütün hayatında gayr-i ihtiyarî bir inad ile varlığını inkar ettiği gayr-ı mevcut ruhu şimdi birden müteessir olmuştu. Ellerini, karanlıkta garip bir galat-ı rüyetle daha beyaz görünen saçlarına götürdü. "Zavallı aziz ölüler!" dedi. Genç mebus hâlâ düşünüyor, asla bir şey duymuyordu. Nutkunu yazacağı bu geceyi bu kıymettar vakti ihtiyar bir geveze ile geçirdiğinden; zamanını telafi için asabileşiyor, ve refîkinin koluna girerek: — Haydi üstad, çabuk yürüyünüz! Sâmiîn çıkmadan acele edelim, boş birer dirijabl bulalım, sonra otomobillere kalırsak, geceden kırk dakika kaybederim...

# İlk Cinayet

Ben hep acı içinde yaşayan bir adamım! Bu sıkıntı âdeta kendimi bildiğim anda başladı. Belki daha dört yaşında yoktum. O gün bugündür, yaptığım değil, hatta düşündüğüm kötülüklerin bile vicdanımda tutuşturduğu sonsuz cehennem sıkıntıları içinde hâlâ kıvranıyorum. Beni üzen şeylerin hiçbirini unutmadım. Anılarım sanki yalnız hüzün için yapılmış.

Evet, acaba dört yaşımda var mıydım? Ondan önce hiçbir şey bilmiyorum. Bilinç, başımıza nasıl yakmayan bir yıldırım gibi düşer? Tolstoy, daha dokuz aylık bir çocukken kendisinin banyoya sokulduğunu hatırlıyor. İlk duygusu bir hoşlanma! Benimki müthiş bir sıkıntıyla başladı. Ben ilk kez  
kendimi Şirket vapurunda hatırlıyorum. Hâlâ gözümün önünde: Sanki dünyaya o anda doğmuşum, annemin kucağı... Annem, yanındaki çok sarı saçlı, genç bir hanımla gülüşerek konuşuyor, cigara içiyorlar. Annem cigarasını ince gümüş bir maşaya takmış. Ben bunu istiyorum.  
— Al ama ağzına sürme! diyor.  
Bana bu ince maşayı veriyor, cigarasını denize atıyor. Galiba yaz. Çok aydınlık, çok güneşli bir hava... Annem, konuşurken mavi tüylü bir yelpazeyi yavaş yavaş sallıyor. Ben kucağından kayıyorum. Beni kollarımdan tutarak yanına oturtuyor. Gümüş maşacığın halkasına parmağımı takıyor, annem görmeden ucunu ağzıma sokuyor, dişlerimle ısırıyorum. Konuştuğu sarı saçlı hanımın çarşafı mavi... Ben beyazlar giymişim. Başım açık. Saçlarım gür. Hem galiba dağılmış. Annem bunları düzeltirken başımı yukarıya kaldırıyorum. Güneşten kum kum parlayan tentenin kenarında el kadar bir gölge kımıldıyor.  
— Bak, bak! diyorum.  
Annem de başını kaldırıyor:  
— Kuş konmuş, diyor.  
Bu kuşu isteyince,  
— Tutulmaz, diyor.  
Ben yine istiyorum. Annem şemsiyesiyle bu gölgenin altına vuruyor. Ama gölgede kımıltı yok. Yine yanındaki hanıma dönüyor:  
— A, kaçmadı.  
— Neye acaba?  
— Yavru olacak mutlaka.  
— ...  
— Anne, ben kuşu isterim! diye tutturuyorum.  
O vakit annem yelpazesini bırakıp ayağa kalkıyor, beni koltuklarımın altından tutuyor ve küçük bir top gibi dışarıya kaldırırken diyor ki:  
— Birdenbire tut ha!  
Başım keten tenteye yaklaşınca, gözlerim kamaşıyor. Ellerimi uzatıyorum. Tutuveriyorum. Bu, beyaz bir kuş... Annem alıyor elimden, öpüyor, sarı saçlı hanım da öpüyor, ben de öpüyorum.  
— Ah, zavallı daha yavru.  
— Martı yavrusu.  
— Uçamıyor olmalı.  
— Denize düşerse boğulur.  
— ...  
Öteki kadınlar da söze karışıyor, "Yaşamaz!" diyorlar. Annem beyaz kuşu "A zavallı, o zavallı!" diye uzun uzadıya okşadıktan sonra benim kucağıma veriyor.  
— Eve götürelim, belki yaşar, diyor, ama sakın sıkma yavrum.  
— Sıkmam.  
— Böyle tut işte.  
Gümüş maşacığına bir ince cigara takıyor. Yanındaki hanımla yine dalıyor söze. Kuşcağızın tüyleri o kadar beyaz ki... Dokunuyorum... Kanatlarının kemikleri belli oluyor. Ayakları kırmızı. Kaçmak için hiç çırpınmıyor, şaşırmış. Gözleri yusyuvarlak. Kırmızı gagasının kenarında sanki sarı bir şey yemiş de bulaşığı kalmış gibi sarı bir iz var. Boynunu uzatarak çevresine bakmaya çalışıyor. Ben o zaman gözlerimi anneme kaldırıyorum. Yanındaki hanımla gülüşerek konuşuyorlar. Benimle ilgili değil. Sonra beyaz kuşun uzanan ince boynunu yavaşça elimle tutuyorum. Bütün gücümle sıkmaya başlıyorum. Kanatlarını açmak istiyor. Öteki elimle onları da tutuyorum. Mercan ayakları dizlerime batıyor. Sıkıyorum, sıkıyorum, sıkıyorum. Dişlerim, kırılacak gibi sıkıyorum, gık diyemiyor. Sarı kenarlı gagacığı titreyerek açılıp kapanıyor. Pembe sivri dili dışarı çıkıyor. Yuvarlak gözleri önce büyüyor. Sonra küçülüyor, sonra sönüyor... Birdenbire, kasılmış ellerimi açıyorum. Beyaz kuşcağızın ölüsü "pat!" diye düşüyor yere.

Annem dönüyor, eğiliyor. Yerden bu henüz sıcak, masum ölüyü alıyor. "A... Aaa... Ölmüş!.." dedikten sonra bana dik dik bakıyor:  
— Ne yaptın?  
— ...  
— Sıktın mı?  
— ...  
— Söyle bakayım?  
— ...  
Karşılık veremiyor, avazım çıktığı kadar ağlamaya başlıyorum. Annemin elinden beyaz kuşun ölüsünü sarı saçlı hanım alıyor:  
— Ah, ne günah!  
— ...  
— Zavallıcık.  
— ...  
Başka kadınlar da söze karışıyor. Karşımızda oturan şişman, yaşlı bir kadın cinayetimi bildiriyor:  
— Boğdu. Gördüm vallahi, ne hain çocuk...  
— ...  
Annem sapsarı kesilmiş, sesi titriyor.

"Ah insafsız!" diyerek bana yine acı acı bakıyor. Daha beter ağlıyorum. O kadar ağlıyorum ki... Beni artık susturamıyorlar. Ne vakit, nerede, nasıl sustuğumu bugün hatırlayamıyorum. Sanki sonsuza kadar ağlıyorum.

Kendimi bilir bilmez yaptığım bu cinayetin üzerinden işte otuz yıldan fazla bir zaman geçti. Şimdi Şirket vapurlarının güvertelerinde otururken ne zaman bir martı görsem, birdenbire, neşemi kaybederim. Bir çocuk haykırışıyla ağlamak isterim. Yüreğimin içinde derin bir sızı büyür, büyür. Göğsümü acıtır.

"Ah insafsız!" diyerek beni azarlayan anneciğimin hiç bitmeyen paylamasını duyar gibi olurum.

# İlk Namaz

1 Aralık 1320

Oh, bu sabah ne kadar soğuktu, yatağımın hararetlerini terk ettiğim vakit, çılgın fırtınalarla haykırarak, tehditkâr rüzgarlarla camları döğerek, geçen gecenin bütün bürûdetini massetmiş olan soğuk terliklere çıplak ayaklarımı sokunca, içimde bakıyye-i leyl bir üşümenin titrediğini hissettim. Hizmetçim tabii ki uyuyordu, onu bu yakıcı soğukta sıcak yatağından kaldırmaya acırdım. Odamın kapısını açtım. Dışarıda kesici ve parçalayıcı kışın, müfteris soğukları yüzümü ve ellerimi tokatladılar. Bu merhametsiz tokatların altında kollarımı sıvadım. Abdestimi aldım. Odama dönünce yalancı bir sıcaklık, bir nefes-i teselli gibi, havlunun altından kollarıma, yüzüme, ıslanmış saçlarıma temas ediyordu. Daha fecr-i sâdık uyanmamıştı. Fecr-i kâzibin donuk, kırmızı sükuneti gecenin serâdik-i zalâm-ı bâridini parçalayarak büyüyor ve genişliyordu. Pencereye dayandım. Önümde, zîr-i pâyimdeki bütün evler, ebedî bir uykunun uyanılmaz kabuslarını itmâm ediyor gibi câmid ve bî-hayat duruyorlardı. Deniz, nâmahdut bir incimâd-ı laciverdi ile uyuyor ve fecrin zâil gölgeleriyle titreyen uzak ve sisli sahillere beyaz dalgalarıyla nihayetsiz bir hatt-ı fasıl çiziyordu.

Evlerin arasında fakir ve nâçiz, fakat bir azamet-i maneviye ile semaya doğru yükselen Eski Cami'in küçük ve ihtiyar minaresi daha boştu. Sonra... Bu dakika-i ezeliyette, bütün o intihâ-i leyâl sincâbî zulmetler, mâî bir şeffafiyet-i sürh gibi takattur ederken, minarenin şerefesinde genç müezzin zıll-ı zâifi hareket etti. Ben hırkama bütün bütün büründüm. Soğuktan büzülmüş ve mütefekkir, bu kainat-ı melul ve esmere karşı unutulmaz bir hitab-ı ulûhiyetin hâtırası gibi derinden akis ve ruhumu lerze-rîz-i haşyet eden ezanı dinlerken, onbeş senedir kalkabildiğim bu büyük ve meşbû-ı ruhaniyet sabahların birincisini düşünüyordum. Ah, onbeş sene evvel...

Şimdi muhit-i tesellisinden ne kadar uzak bulunduğum annem, dünyada en sevdiğim, dünyada yegane prestiş ettiğim bu vücud-ı muhterem, işte derhatır ediyorum, onbeş sene evvel beni ilk sabah namazına kaldırmış idi. Galiba yine böyle bir kıştı. Onun odasına bitişik olan küçük odamdaki küçük karyolamda uyurken bir buse-i esir u hâr gibi alnımı okşayan nazik eliyle, nazik ince parmaklarıyla saçlarımı tarayarak: — Haydi Ömer'ciğim kalk, demişti, kalk, haydi yavrucuğum. Ben gözlerimi açmıştım. Köşedeki küçük yazıhânemin üzerindeki yanan küçük gece kandili —an, bunu unutamam, bu bir kedi kafası idi— iki pencereli olan odamın beyaz, muşamba perdelerinin esmerliklerini aydınlatıyor ve yeşil camdan gözleriyle bakıyordu. — Fakat anneciğim, demiştim, daha gece... Her vakit öptüğü yerden, sol kaşımın ucundan tekrar öperek: — Yok yavrucuğum, saat oniki, sonra vakit geçer... Diye koltuklarımdan tutarak kaldırdı. İçi fanileli küçük terliklerimi giyerek ve gözlerimi yumruklarımla uğuşturarak onu takibettim. Karanlık sofadan bir lahzada geçerek odasına girdik. Bağdaş kurmuş bir zenciye benzeyen siyah ve alçak soba gürüldeyerek yanıyordu. — Aa... Pervin de kalkmış... Pervin —hizmetçimizdi— elindeki sarı güğümü sobanın üzerinden indiriyordu. Onun kalkacağına hiç ihtimal veremezdim. Annem demişti ki: — Pervin her sabah kalkar. Ben hiç kalkmadığım halde onun her sabah kalkmasına taaccüp ettim. Hırkamı çıkardılar, kollarımı sıvadılar, abdest leğeninin yanına çömeldim. Anneciğim: — Öyle yorulursun. Diye küçük bir iskemleyi altıma koydu, ona oturdum: — Haydi, besmele çek!.. Pervin ılık suyu ellerime döküyor, annem baş ucumda. — Yüzünü... Kollarını, yine üç defa... Diye fısıldıyor, unuttukça: — Aa, hani başına mesh? Gibi ihtarlarla yanlışlarımı bana tekrar ettiriyordu. Abdest bitince annemle beraber yavaş bir sesle namaz duâlarını okuyarak kollarımı ve yüzümü kuruladık, Pervin de ayaklarımı kuruladı. Ve çoraplarımı giydirdi. Isınmak için sobanın önüne gitmiştim. Arkama dönünce, annemi, arakiye seccadeyi açıyor gördüm... Sonra başına yeşil baş örtüsünü örterek beni çağırmıştı: — Gel... Gittim. Küçücük ben, onunla bir seccadede, bir yavru samimiyet ve saadetiyle o muazzez, hassas anne vücudunun yanında durdum. İki lakırdı ile, bana, yapacağımı, evvelden öğrettiklerini tekrar etti: — İki rekât sünnet... Gece öğrendiklerini zammet, unutmadın ya? — Hayır... — Haydi... O, iftitah tekbirini ellerini omuzlarına kaldırarak kadın gibi yaparken, ben de gayr-i ihtiyarî onu taklit etmiştim. Sünneti bitirdikten sonra, bana, gözlerinin nûşin ve nafiz bir tebessümü ile gülerek: — Yavrum, demişti, sen kadın mısın? Kadınlar öyle başlar, sen erkeksin, ellerini kulaklarına götüreceksin. Ve hararetli elleriyle benim küçük ellerimi kulaklarıma kaldırarak: — İşte böyle... Diyerek erkek iftitahını öğretti. Ben de tekbiri öyle alıp annemden farkımı, niçin erkek olduğumu, erkekliğin ne olduğunu, erkek olmanın yalnız küçük kızları dövmek ve onlara hâkim olmaktan başka da farkları olacağını düşünerek namazı bitirdim.

Duâ ederken sordum ki: — Nasıl duâ edeceğim anne? O duâ ediyor ve dudakları hareket ettikçe baş örtüsü de ihtizâz eder gibi oluyordu. Başını salladı, duâsını bitirdikten sonra, daha hâlâ hatırımda: — Evvela İslam olduğum için ey cenâb-ı vâcibül-vücut hazretleri sana hamd ederim, de... Sonra vatanımızın düşmanlarını perişan etmeni senden istirham ederim, de... Sonra da bütün eziyet çeken, hasta olan, felakette bulunan, fakir olan Müslümanların selamet ve sıhhatlerini senden temeni ederim, de... Kendin için, kendi iyi olman ve şeytanın yalanlarına aldanmaman için duâ et! Demişti. Ben bu basit ve Türkçe duâyı, annemin dolabındaki birbiri üstüne duran ve karıştırmaklığım "duâ kitaplarıdır, sakın ilişme!" ihtarı ile daima men olunan, yıpranmış, Arapça, ve esreli üstünlü kitapları derhatır ederek içimden söyledim, fâtiha...

Annem seccadeyi toplayarak bana uyuyup uyumayacağımı sordu, uykum var mıydı? Bunu bilmiyordum... Cevap vermedim. — Haydi öyleyse, git kitabını getir, dersini dinleyelim. — Peki. Artık esmer ve duman gibi bir aydınlıkla tenevvür eden sofadan hızla geçtim. Odamın perdeleri biraz beyazlaşmış, küçük gece kandilinin yeşil gözleri sönerek siyah iki nokta gibi kalmış; sanki, geceleri kendisine bakarak uyuduğum bu kedi kafası ölmüş, terk-i hayat etmişti. Yazıhânemin üstünde açık duran kitabımı kaptım, annemin yanına koştum, hiç yanlışım çıkmadı. Annem geceleri derdi ki: — Yatmazdan evvel dersini üç defa oku, yavrum, uyurken melâikeler sana onu öğretir. O melâikeler bu gece de, uykumda bana dersimi öğretmişlerdi. Annem müşfik aferinlerle saçlarımı okşadı. Ve: — Daha mektebe çok vakit var. Diye beni kendi yatağına yatırdı. Uykum yoktu, anneme bakıyordum. Yeşil baş örtüsü başında, bu zulmet-i münevvere içinde, bir hayal gibi hareket ederek Kur'an'ını aldı ve pencerenin kenarına, geniş sedire oturarak mühtez ve rakik sesi ile tilâvete başladı. Ruhumda bir aks-i enîn-i şiir âlûd bırakan bu güzel sesi dinleyerek... Büyük, yeşil baş örtüsünün altında, tıpkı ölen bir hemşireme benzeyen güzel ve âsım çehresini görerek... Ve yavaş yavaş sallanan başının aheng-i hafif-i münâcâtını seyrederek dalıyordum. Perdelerin altından görülen dumanlı sema gittikçe aydınlanıyor, geç kalmış birkaç yıldız koyu lacivert bir atlasa düşmüş mâî ve nadide elmaslar gibi parlıyor, vâpesîn-i mâî neşrederek parlıyorlardı. Annemi bir meleğe benzetiyordum. Bu tahayyülle melâikeleri düşünerek... Kur'an okuyan annemin şimdi etrafına toplanmaları gereken melâikeleri müşahede ediyorum zannederek dalıyordum. Yüzümün üstünde, ahirette güller bitecek ve cehenneme girecek olursam katiyyen yanmayacak olan sol kaşımın ucunda tatlı bir ürperme duyuyor, sonra annemin münevver bir zambak aydınlığıyla parlayan dudaklarının kımıldamasına bakarak.... O görülemeyen melâike kanatlarının saçlarıma, annemin şimdi Kur'an tutan ince parmaklarıyla okşadığı sarı ve çok saçlarıma dokunduklarını hisseder gibi oluyor ve dalıyordum.

Ah, onbeş sene evvelki sabâvet ve şimdiki ben... Tatsız, neşvesiz, muhabbetsiz, aşksız ve heyecansız, her şeysiz, boş bir hiçten daha boş geçen hayat-ı serâyı taabâlûd... Şimdi mülevves emelleriyle, hırslarla, hakikatte kıymetsiz olan baîdül-vusul arzularla, hâsılı bütün bunların bir icmal-i mebhûtu olan o sebepsiz ve tahammülsüz bîkararlılıklarla mecruh olan ruhum, mecruh olan kalbim ve maneviyatım... Şimdi, daha bu gece görülmüş gibi, onbeş saniye evvel görülmüş ruhanî ve bir rüyayı kıymetdar gibi saadetleri unutulamayan ve zaten velveleli ve hüsranhîz bir rüya olan bu ömr-i fâni içinde yalnız kabus olmayan sabâvet ve hâtıratı... Şimdi düşünüyorum ki, hayatta bu muztar ve şefkatsiz mâzilerin güzâriş-i ademinden mütehassıl ne garip bir hiçlik, ne zevalperver ve pür hayal bir beyhudelik, ne müphem, ne esrar âlûd bir sürat var!...

# İlkbahar

Köyde idik... Pâk ve mutedil bir neşve-i cuş ile haykıran küçük çağlayanın o kadar yakınında idim ki sukut-ı abdan uçuşan nâ-mer’i zerreler hayalî bir yağmur gibi yüzümü ıslatıyor ve köpeğim yüzükoyun uzanmış yarım kapalı gözleriyle bu ilk gördüğü manzarayı seyrederek kımıldanmağa cesaret edemiyordu. İhtiyar meşe ağaçlarının; nemnâk taşları örten kesif ve mütevahhiş çalılar üstüne zümridîn ve muhtez benekler hâlinde gölgeleri düşüyor, yeni çıkan narin ve şeffaf otlar çağlayanın muhrik ve muğfil ninnisiyle nazan bir hab-ı masum uyuyordu.

Hiçbir ses, ne bir kuş, ne bir böcek bu sükûnet-nûşîn-i müterennimi ihlâl etmiyordu. Rüzgâr, hareket, hatta hayat; sanki bunlar ebediyen sönmüştü. Ben ve köpeğim mesuttuk. Bu yeşil rüya-yı serab-alûd-ı bahar içinde, her şeyi unutmuş; elemden, emelden, arzulardan uzak; mesuttuk. Ben de onu taklit etmiş, yüzükoyun yatmıştım. Yazın sehhar kokusunu, altımdaki ratip ve temiz toprağın çıkardığı buy-ı sükkerîn-i baharı kokluyordum. Bilmiyorum bu huzuz-ı bî-haber içinde ne kadar kaldık! Fakat çağlayanın seda-yı girizanı değişmeğe, yeşil gölgeler yavaş yavaş dağılarak kararmağa, beyaz köpükler esmerleşmeğe, riyâh-ı şâm gayr-i mahsus mevecatıyla serin bir nefes-i veda gibi esmeğe başladı. Akşam oluyor ve uyanmak lâzım geliyordu. Ayağa kalktım, “Haydi Koton” dedim, “artık gidelim.”

Mutî köpeğim kalkmak istemiyor: “Niçin böyle münasebetsizlik ediyorsun?” gibi manidar ve parlak gözleriyle müstemend ve ricakâr, bana bakıyordu. Zavallıya huzuz ve saadeti mahvolacağından acıyordum. Tekrar yanına oturdum, güzel başını, düşük kulaklarını ellerimle okşayarak “Evet, gideceğiz Kotoncuğum” diye teselli ediyordum; “gideceğiz, burada yaşadığımız ân-ı saadeti de bütün geçen ve geçecek saadetler gibi mazi-i hatırata terk edeceğiz. Birkaç saat sonra gece müphem ve serair-âlûd karanlıklarıyla hulûl edecek; şimdi çakılların, otların arasında saklanan müstehzi kurbağalar madenî ve haşyet-aver naralarıyla zulmette birer görülmez heyulaya münkalip olan ağaçları raks ettirecek, bu güzel ve cennet-âsâ mahal korkunç ve deycûr bir kâbus olacaktır. Ah bilsen ki bütün saadetler, bütün baharlar, bütün telezzüzler ne kadar aldatıcı ve fâni rüyalardır!”

O, söylediklerimi anlamıyor, yalnız gülen yumuk gözlerinin müteşekkir parlaklıklarıyla izhar-ı memnuniyet ediyor ve yanına oturduğumdan, nazikî-i nevazişimden burada ebediyen kalmağa razı oldum zannederek şiddetle kuyruğunu sallıyordu.
