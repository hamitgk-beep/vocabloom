# Gizli Mâbed

Geçen gün Tokatlıyan'da Sermet bana genç bir Frenk takdim etti. Sorbon'dan arkadaşmış! Kumral, çini mavi gözlü, güzel, narin, nazik bir çocuk! Azgın bir "Şark" meftunu! İlk lafı bu oldu:  
— Azizim, siz kendinizi bilmiyorsunuz. Avrupa'yı bir şey zannederek kendi güzelliklerinizi göremiyor, kendi esrarlarınızı yaşamıyorsunuz...  
Birdenbire haklı mı, haksız mı olduğunu kestiremediğim bu tevbîhe gülümsedim:  
— Yaşamadığımızı, göremediğimizi ne biliyorsunuz?..  
— Bunu gözümle gördüm, diye coştu. Üç gecedir Sermet'in evindeyim. Her şey alafranga: Yemek salonu, yatak odası, karısının, kardeşlerinin giyinişleri, hareketleri, hatta zihniyetleri, telâkkileri bile hep Avrupavâri! Ah nerede Loti'nin Türkiye'si?..  
— Loti'nin Türkiye'si karşı tarafta! dedim.  
— Evet öyle söylüyorlar. Fakat içine girilmez bir âlem! Yazık ki siz bu pitoresk âlemi sevmiyorsunuz!..  
— Sevenlerimiz de var...  
Dedim.  
— Siz sevenlerden misiniz?..  
— Evet...  
Diye mübalâğalı bir tehâlükle başımı salladım: "Sabit fikir"lerinin hududunu aşamayan Frenkler ne masumdurlar! Bu genç Avrupalı da bunlardan biriydi. Türkiye'ye dair konuşmaya başladık. İddia ediyordu ki, biz kendimizi tanımıyoruz; en güzel, en zengin, en bediî sokaklarımıza pis diyoruz. Artık güzellikten mahrum Avrupa binalarına, muazzam caddelere; tabiatı öldüren hendese çizgilerine kıymet veriyoruz... Rumlara hiddeti, garez derecesini geçiyordu. Beyoğlu'ndan öyle nefret etmişti ki: "Ne iğrenç Garp karikatürü, yarabbi!" derken âdeta sarararak tiksiniyordu. Kafası Loti'nin muhayyilesiyle doluydu. Bizim sefalet, vahşet, cehalet dediğimiz perişanlıklarımıza o "harika!" diyor, bu nihayetsiz mezbeleler, baykuşlu viraneler karşısında nasıl olup da bediî bir heyecan duymadığımıza şaşıp kalıyordu. Nihayet kendisinin, Avrupalılaşmamış bir Türk evine götürülmesini benden rica etti. Aklıma birdenbire Karagümrük'te oturan ihtiyar süt annem geldi. Bu gayet sofu ve gayet stoik, gayet muhafazakâr bir kadındır, kendinden büyük eski Arap halayıkçığıyla oturur, kocasından kalan ufacık bir iratla rahat rahat geçinir.  
— Öyleyse sizi hiç Avrupalılaşmamış ihtiyar bir dulun evine götüreyim!  
Dedim. Teşekkür etti. Sevindi:  
— Ne vakit?..  
— Bugün, hatta isterseniz şimdi.  
— Bu mümkün mü?..  
— Mümkün, yalnız başınıza bir fes alacağız, dedim.  
Böyle ansızın gitmek, alaturka evde tekliflere, tekellüflere meydan bırakmayacak, tabiatı, pitoreski, bu Şark meftunu Frenge olduğu gibi gösterecekti. Sermet, zavallının sevincine gülmekten katılıyordu. Ona veda ettik, bir arabaya atladık. Beyazıt'a indik. Frenkçiğe bir dükkandan ciğer gibi kıpkırmızı bir fes aldık. Kalıplattık. Tramvaya binmek istemedi.  
— Buradan aşağı hep Türk mahallesi mi?  
Dedi.  
— Evet hep Türk mahallesi.  
— O hâlde rica ederim, yayan gidelim.  
— Pekâlâ!..  
Dedim. Yangın yerlerinden yürüdük. Sisli bir hava, bulutlu, karanlık bir sema harap evlerin, tenha viranelerin sükûnuna sanki acı bir hüzün karıştırıyordu. Yolda ona talimat verdik. Süt anneme kendisi için "Çerkez" diyecektim.

Vâkıâ o horozdan kaçan bir kadın değildi. Fakat belki bir Hristiyanın yanına çıkmak istemezdi. Bu basit entrika genç Frengin muhayyilesini daha beter alevlendirdi. Bir tarafa çarpılmış siyah, çürük tahta evler, yıkık duvarlar, sökük çatılar karşısında duruyor, "Oh, ne manzara, ne manzara!" diye bir türlü ayrılamıyordu. İki saatte eve gelebildik. Bu üç katlı, ahşap, biraz viranca bir binadır. Kapıyı çaldım. İhtiyar Arap açtı: — Süt annem yok mu? Diye sordum. — Komşuda... Buyrun.... — Haydi, Karanfil Dadı, git koş, benim geldiğimi söyle. Yanımda da bir misafirim var. Bu gece sizde kalacağız, dedim. İçeri girdik. Temiz fakat karanlık taşlıktan geçerek koca bir merdivenden çıktık. Misafir odasına genç Frenk bayıldı. Yerde güzel bir Acem halısı yayılıydı. Duvarlar "merhum hattat süt babamın yadigâr bıraktığı" levhalarla süslenmişti.

Yastıklarına fes rengi perdelerin düştüğü sedirler kırmızı velenselerle örtülüydü. Karşı karşıya oturduk. Kafeslere hayran oldu.

"Âdeta kendimi bir rüyanın içinde sanıyorum!" dedi. Süt annem gelince benim gibi elini öptü. Ara sıra başındaki fesi unutuyor; gayr-i ihtiyarî reverans hareketleri izhar ediyordu. Süt annem bunun pek farkına varmadı ama:  
— Konuştuğunuz lâf Çerkezceye benzemiyor, dedi. Ben:  
— Anneciğim, bu senin bildiğin Çerkezce değil, Hicretten sonra çıkmış, Rusça ile Çeçence ile karışık yeni bir Çerkezce!  
Diye kandırdım. Sözde bu Çerkez misafir, hacca gitmek için İstanbul'a gelmişti. Süt annem hac vakti olmadığını hatırlatınca ona da bir kulp buldum. Maksadı daha evvel davranıp İstanbul'da biraz Türkçe öğrenmekti.  
— Ah bu yaşta hacı olmak, ne mutlu, ne mutlu, darısı senin başına!..diyordu.  
— Âmin, âmin!..  
Frenk, ağzımızdan çıkan bu kelimeyi birdenbire tanıyor, aşinalığını göstermek fikriyle kendi şivesiyle tekrarlıyordu:  
— Amen, amen!..  
— .........  
Süt annem bu Çerkezle hacca beraber gitmemi tutturdu. Hâsılı yemek zamanına kadar hep hacdan, hocadan falan bahsettik. Ben süt annemin nasihatlerini çıtır çıtır hep Çerkezceye tercüme ettim. Sofraya oturunca Frenk bütün bütün bediî heyecanının içinde gaşyoldu. Yalnız yabancı misafirlere çıkan gümüş sini, zavallıyı deli edecekti. Çatalı bırakıyor, süt annem gibi eliyle yemeğe çalışıyordu. Ben vazgeçirdim. Elle yemek yalnız ihtiyar kadınlara mahsus olduğunu söyledim. Dünyanın en rahat vaziyeti bağdaş kurmak olduğunu iddiaya başlarken sofradan kalktık. Kahvelerimizi içtik. Süt babamın kütüphanesinde yadigâr gibi duran eski yazma kitapları misafirime gösterdim. Nakışlara, ciltlere, minyatürlere hayran kaldı. Uyku zamanı gelince, onu Karanfil'le beraber en üst kata çıkardık. Yatağını bahçe üstündeki odaya yapmışlardı. Ayakyolunu falan gösterdim. "Bonsoir" dedim. Ben de orta kattaki odaya çekildim. Gece fırtına çıktı. Şiddetli bir yağmur yağdı. Sabahleyin gayet güzel bir hava açılmıştı. Frengi uyanmış, giyinmiş buldum. Yatağın içine oturmuş, bir şeyler yazıyordu.  
— Bonjour...  
— Bonjour, mon ami!..  
— Ne yazıyorsunuz?..  
— Oh, tahassüsatımı!..  
— O kadar mütehassis mi oldunuz?..  
— Tarif edemem, size tarif edemem!..  
— ........  
Aşağı indik, sabah kahvelerimizi içtik. Süt annemin ellerini öptük. Bu Frengi, daha beter Şark pitoreskinin içine batırmak için yayan olarak Fatih'e götürdüm. Caminin karşısındaki kahveye oturduk. Bir nargile ısmarladım. Dışarı üflemesin diye evvelâ ehemmiyetle içmek ameliyesini öğrettim. Keyiflerimiz gelmeye başlıyordu. Zavallıyı yine azıttırmak, coşturmak için:  
— Azizim, şu karşındaki mâbede bak, dedim. Ne letâfet, ne mehâbet değil mi?  
Frenk gülümsedi, o kadar müteheyyic görünmedi. Daha dün yıkık çeşmelerin, eğrilmiş duvarların huzurunda deli gibi çırpınan bu adamın kayıtsızlığı tuhafıma gitti. Sordum:  
— Bu abideyi beğenmediniz mi, yoksa?  
— Bu, bu mâbed hiç...  
Diye mavi gözlerini küçülterek tekrar gülümsedi.  
— Ne demek hiç? Bu İstanbul'un en muazzam bir abidesidir...  
— Bu, hiç... Bu mâbed, hiç...  
— Ne demek?..  
— Ben ondan daha mühimini gördüm.  
— Olamaz, dedim, ne vakit gördünüz?  
— Bu gece...  
— Rüyanızda mı?..  
— Hayır...  
— Ya nerede?..  
— Evde...  
— Hangi evde?..  
— Yattığımız evde...  
Şaşaladım.  
— Ne gördünüz canım?  
— Piyer Loti'nin göremediği bir şeyi! Hiçbir Avrupalının tanımadığı bir sırrı!..  
— .......  
Gülümsüyordum.  
— Evet, ben sizin gizli mâbedinizi gördüm, dedi.  
— Nasıl gizli mâbed, canım?..  
— Nafile saklıyorsunuz. Ben gördüm işte!.. Asırlardan beri Avrupalıların gözlerinden sakladığınız mahrem mâbedinizi, hususî mâbedinizi bu gece gördüm.  
— .......  
— Ama emin olunuz, bu sırrı muhafaza edeceğim. Paris'e gidince gazetelere yazmayacağım, defterimde mukaddes bir şey gibi bu hatıra saklı kalacak.  
— Laflarınızdan bir şey anlamıyorum, dedim.  
— Israr etmeyiniz gördüm, gördüm...  
— Neyi canım?..  
— Gizli mâbedinizi!  
— Bizim gizli mâbedimiz, falan yoktur.  
— Nafile inkâr ediyorsunuz, ben gördüm.  
— Tuhaf, çok tuhaf!..  
Diye başımı sallıyordum.

Frenkçik dayanamadı. Cebinden maroken kaplı bir defter çıkardı.  
— Bak görmüş müyüm, görmemiş miyim?!  
Dedi. Son sayfaları okumaya başladı:

"...Sabah! Büyük bir heyecan, bir haz heyecan içinde şu satırları yazıyorum. Dün Sermet'in takdim ettiği bir Türkle bu İstanbul'un en meçhul yerine geldim. Meğerse Jacques Casanova, Pierre Loti filân konaklarla yalıların selâmlık dairelerinde birer kahve içmekle Şarkı gördük sanıyorlarmış. Asıl Şark görünmeyen tabakalarda... Ben işte hiçbir Avrupalının görmediği şeyi gördüm. Burası ihtiyar, dul bir kadının evi. Gayet dindar bir kadın. Evin içi, sofra takımı, âdet, tarzlar, hâsılı her şey hiç bozulmamış... Tamamıyla alaturka. Gece beni en üst katta bir odaya yatırdılar. Sabahleyin gayet erken uyandım. Yataktan kalktım. Garip bir tecessüs içimi yiyordu. Ayaklarımın ucuna basarak dışarı çıktım. Karşıda bir oda vardı. Kapısı aralıktı. Yavaşça ittim. Bir de ne göreyim? Gizli bir aile mâbedi!..

Beyaz perdeler inik. Aralarından soluk bir aydınlık giriyor. Duvarlarda birçok büyük levhalar asılı. Köşelerde ağır, ceviz ağacından yapılmış, demir çemberli mezarlar duruyor. Şüphesiz bu mezarlarda sevgili ölülerin mumyaları var. Bir tanesini açmaya çalıştım. Mümkün değil, kilitli! Sonra yerde irili ufaklı birçok kaplar duruyor. Bazıları bakırdan, bazıları porselenden! İçlerinde kıymetlileri var. Mesela kapının hizasında, birinci mezarın önündeki gayet kıymetli, etrafı altınla yaldızlanmış bir kap. Köşedeki yeşil bir vazo... Kim bilir nasıl bir topraktan yapılmış, mâbedin içinde mânâsını anlayamadığım bir nisbet dahilinde ipten birtakım dılılarla zâviyeler gerilmiş. Bu mukaddes zâviyelerin üzerinde şüphesiz ölülere ait olan birtakım relique'ler asılı. Kaplarda mukaddes sular duruyor. Bazısında taşacak derecede çok. Mekke'nin, Medine'nin, kim bilir, hangi meçhul, hangi mukaddes köşelerinden gelen bu esrarlı, bu mukaddes sulardan tattım. Biraz kekremsi... Kapların dibinde hafif, ama gayet hafif bir toprak tortusu var. Her kaptan içtim. Hepsinin tadı var. Kalbim çarpmaya başladı. Memnû bir mâbede girmiş bir küfürbaz, bir hain, bir kâfir heyecanıyla dışarı çıktım. Sanki bu mezarlar birdenbire açılacak, içlerinden yüzlerce sene evvel ölmüş ihtiyar Türkler kavuklarıyla, yatağanlarıyla, kalkıp üzerime yürüyecekler sandım. Sanki duvarlardaki levhalar sallandı. Mukaddes kapların içi çalkandı. Sanki o an bir deniz olacak, oralarda beni boğacaklardı. Bu mukaddes suların hiddetini, sükûtunu, ulviyetini şimdi içimde duyuyor gibi oluyorum.

Esrarlı, müphem bir rehavet, bir ateş damarlarıma yayılıyor. Beynimde karanlık, meçhul bir kubbenin derin akislerini işitiyorum. Öyle anlatılmaz bir heyecan duyuyorum ki..."

Kendimi tutamadım. Öyle bir kahkaha attım ki... Frenk marpucunu elinden düşürdü. Az daha nargilesi devrilecekti. Sabah keyfini çatmaya gelmiş müşterilerin afyonlarını patlattım. Dik dik yüzüme bakıyorlardı.

Frenk sordu:  
— Neye gülüyorsun?..  
— Ayol sen gizli mâbede girmemişsin!  
Dedim.  
— Ya nereye girmişim?..  
— Süt annemin sandık odasına!  
— Sandık odası ne?..  
— Bizim evlerde komod, aynalı dolap falan yoktur. Eşyalarımız, birer sandıkta, sandıklar da bir odada durur. O mezar zannettiğin demir çemberli, ceviz tabutlar, bizim çamaşır sandıklarımızdır.  
— Ya duvardaki levhalar?..  
— Süt babamın eserleri! Yadigâr diye süt annem satmıyor.  
Frenk inanamıyordu. Ben hâlâ gülüyordum.  
— Ya ipten yapılmış hendesî şekiller? O "relique"ler?..  
— Yağmurlu havalarda çamaşır asmaya mahsus ip. Zâviyeler, müsellesler, tesadüfen teşekkül etmiş; relique zannettiğiniz de kullanılmayan esvaplar..  
Frenk yine inanamıyordu. Mavi gözleri birdenbire bulutlanmıştı. Yalanımı yakalamış gibi başını salladı:  
— Ya o mukaddes sular? Onlara ne diyeceksin azizim?..dedi.  
— Gece yağmur yağdı. Süt annemin sandık odası, bildim bileli akar. Tavandan damlayacak yağmur suları yerleri ıslatmasın diye geceleyin Karanfil, o kapları odaya sıra sıra dizmiş olmalı...  
Dedim. Frenk evlerimizin üzerindeki "Maşallah" levhalarını millî bir sigorta şirketinin işaretleri, saçaklarımızda sallanan nazarlık pabuçlarını damdan dama kaçan hırsızların oralara takılıp kalmış ayakkabıları zanneden meşhur milletdaşı gibi, bir an durdu, düşündü. Derin derin nargilesini çekti. Yutkundu. Elinde açık kalan defterini cebine soktu. Ben hâlâ duruyor, duruyor, gülüyordum.  
— Gülme azizim, sizin sandık odalarınızda bile öyle esrarlı, öyle anlaşılmaz, öyle müphem, öyle dinî bir hâl var ki...  
— Ne gibi?..  
— Öyle bir şey ki... Siz körsünüz... Göremiyorsunuz vesselam...  
Dedi. Fakat bizim göremeyip de o yalnız kendi gördüğü şeyin ne olduğunu bir türlü söyleyemiyordu.

Malûm ya, Türkler hükümlerinde çok naziktirler! "Biz kör isek, işte siz de dilsizsiniz!" cevabı ta dudaklarımın ucuna gelmişken sustum. Hiç ses çıkarmadım.

# Havyar

Handune hanım eski bir şeyhülislam haremidir. Yaşı bugün altmışı aşmak üzere...Gamsız, kasâvetsiz vaktini geçirir. Hala pembe beyaz durur. Yüzünde bir çizgi olsun göremezsiniz, yirmi sene evvel doksan dokuzunu dolduran efendiciği gözünü kapayınca kendi gibi beyaz, tombul, yetişmiş tam kıvamına gelmiş bir tanecik kızcağızıyla yapyalnız kalmıştı. Mal vardı, mülk vardı. At vardı, araba vardı. Ama bu evde bakacak bir erkek yoktu.

Hamdune hanım paçaları sıvadı. Kendine bir damat aramaya kalktı. - Kız gibi bir delikanlı isterim! diyordu. Tüccarları, erkan-ı harpleri, katipleri, doktorları, mühendisleri, hasılı hiçbirisini beğenmedi. Hele sarıklıların: "Ben onları biilirim, ne hin oğlu hin olurlar..." diye lafını bile ettirmiyordu. - Malı olmasın, mülkü olmasın, parası olmasın, pulu olmasın. Mahçup, namuslu, terbiyeli bir genç istiyorum! şartını adeta manzum, kafiyeli bir nakarat gibi diline virt etmişti.

Arayan mevlasını da bulur belasını da... Nihayet Hüsam efendiyi Topkapı'nın ücra bir mahallesinde keşfetti. Henüz yirmi yaşına giren bu genç o zaman evkafa devam ediyordu. O kadar utangaçtı ki... Selam verseler gelincik çiçeği gibi kızarıverirdi. Rakı, tütün, enfiye, bira, tiyatro, filan ne olduğunu bilmiyordu. Daha ömründe bir defacık olsun köprüyü geçmemiş, karşıya ayak basmamıştı. Fakir bir türbedar olan merhum sufi babasından kalma ödenecek bir borç gibi beş vaktinin arasına habire nafile namazları sıkıştırıyor, Ramazanı tuttuktan başka üç ayları bile bozmuyordu. Mahalleli, Hüsam efendiden bahis olunurken: "Mutlaka bir gün erecek, evliya olacak!" derlerdi. Hamdune hanım bu gencin harikulade iffetine, sofuluğuna, müslümanlığına hayran kaldı. İri, çarpık burununa, koyu, yağlı sarıya çalan kötü renkte, bodur boyuna, seviyenden bozulmuş eğri bacaklarına bakmadı.

- Erkeğin çirkini mi olur, meğer ki züğürt ola... dedi. Fakat bu atasözü de Hüsam efendiyi kurtarmıyordu. Çünkü son derece çürkin olmakla beraber fakirdi de... Hamdune hanım bu kusuru:

- Allah fazlasıyla vermiş, bizim paraya ihtiyacımız yok! diye görememezlikten geldi. Hüsam efendiyi hamamdan gelin kaldırır gibi yalnız üstündeki esvabıyla  aldı. Erenköy'ündeki köşküne getirdi. Nikâhı düğünü bir günde yaptı. Beyaz, gayet beyaz, tombul kızının yatak odasına soktu. Kızının beyazlığı güzelliği kadar meşhurdu. Komşular ona:

- Kaymak hanım! derlerdi. Hamama girdi mi bütün kadınlar bu gözleri kamaştırıcı beyazlığından şaşırırlar: "Tüh, tüh, yaradana maşallah!" diye nazarları değecek kokusuyla ona uzun uzadıya bakmazlardı. Bu kaymak vücutla Hüsam efendi tam yirmi sene koyun koyuna yattı. Hamdune hanım damadından son derece memnundu.

- Büyüdü gitti. Şükür yetiştirene! Kırkına girdi. Saç sakal sahibi oldu. Hala kız gibidir! yüzüne bakılsa terler, kıpkırmızı kesilir. derdi. Hakikaten Hüsam efendi öyleydi. Gözlerini yerden kaldırmaz, dişi, erkek, kimsenin suratına dik dik bakmazdı.

Fakat... Ah bu muharebe! Herşeyini alt üst ettiği gibi Hüsam efendiyi de kaymak gibi karısının koynunda, kaynanacığının dizi dibinde rahat bırakmadı. Kırkını geçtiği halde askere aldılar. Sonra bir kolayını buldu. Kurtuldu. Ama Erenköy halkı fevkalâde  iffetine mükâfat olarak onu kendilerine fahri ekmek müvezzi yapmak istediler. Derken kooperatif şirketine sokmaya kalktılar. Hatta müdür yaptılar. Kaynanacığının parasıyla şimdiye kadar rahat rahat yaşayan Hüsam efendiye ansızın bir ticaret hevesi geldi. Beşyüz lira sermayeyle bin, bin beşyüz, ikibin lira kazandı. Müdürlükten istifasını verdi. Ticarete atıldı. Artık tamamıyla yırtılmıştı. Yüzde onbin kârı bile az görüyor, yüzde yüzbin kazanmak için akla gelmez yüzsüzlüklere cesaret ediyordu. Eski mahçup, sıkılgan Hüsam efendi şimdi çaçaron birşey olmuştu. "vaktim yok" diye namazı niyazı bıraktı. Gülüyor, utuyor, kahkahalar attığı vakit köşkü çıngır çıngır öttürüyordu. Damadının bu hali Hamdune hanımı fena halde müteessir etti. Üzülüyor, sıkılıyor:

- Yarabbim! Bu adam kırkından sonra "yalaka oldu!" diyordu. Eskiden "öyle, hayır"dan başka hiçbir söz bilmeyen sükûti Hüsam efendi, şimdi önüne rastgelene cırcır konuşuyor, alay ediyor, açık saçık latifeler yumurtluyor, daha sonra kocaman ağzının içindeki çürük dişleri gösteren geniş bir kahkaha ile arsız arsız gülüyordu. "Hazırcevap"lığı bir meziyet edinmişti. Kendisine ne sorulsa güya tuhaf bir kelimeyle cevap veriyordu. Karısı, kaynanası bu değişikliğe tahammül ediyorlar, seslerini çıkarmıyorlardı. Lâkin Hüsam efendi, dil münasebetsizliklerine, el münasebetsizliklerini de karıştırmaya başladı. Evdeki hizmetçilerle ağız şakasından tutturdu. Hamdune hanımın kırk yıllık Arap halayığı Servinur'a sataşmaya kadar işi ilerletti. Bu kömür gibi simsiyah ince uzun hala yirmi yaşında gibi dimdik durur, dinç bir Sudan kızıydı. Hüsam efendi Almanlar Paris'e yaklaştıkça daha ziyade azıttı. Öpmekle, sıkmakla kalmadı. Geceleri zavallı Servinur'un odasına hücuma bile kalktı. Hamdune hanım bu rezalete artık thammül edemedi. Zavallı kızının gözleri iki çeşmeydi. Bir sabah damadını kapıdan çıkarken yakaladı.

- Hüsam efendi oğlum, biraz beni görür müsünüz? dedi.

- Ne demek efendim, emriniz baş üstüme! Buyurunuz efendim. Siz benim velinimetim, sebeb-i refetimsiniz, siz benim anam, babam, efendim herşeyimsiniz, siz benim... Evet öyle bir şaklaban olmuştu ki. Hamdune hanım:

- Estağfurullah, estafurullah, buyurunuz azıcık! diye kapının yanındaki kanapeye oturtmasa kim bilir daha ne maskaralıklar edecekti. Kaynana yere baktı. Öksürdü. Acıklı bir çehreyle:

- Oğlum latifeyi bırak. Sana ciddi birşey soracağım! dedi.

- Tabii ciddi. Hiç latif eder miyim? Haddime mi düşmüş, aynı zamanda... Hamdune hanım yine damadının lafını kesti:

- Sorduğum suallere kısaca cevap veriniz.

- Başüstüne efendim.

- Siz kaç senedir benim damadımsınız?

- Yirmi senedir!

- Bundan memnun musunuz?

- Son derecede efendim!

- Hareminizden?

- Allah razı olsun efendim. Hamdune hanım tombul vücudunu geniş kanapenin üzerinde kımıldattı. Yeşil başörtüsünü elleriyle düzeltti. Son darbesini indirecek bir döğüşçü gibi toplandı. Sanki göğsünü nefesle doldurdu. Kelimeleri ayrı ayrı söyleyerek sordu:

- Öyleyse kaymak gibi ıyâliniz dururken bir pis Servinur fellahına sataşmaya sıkılmıyor musunuz? Hüsam efendi yüzünü ekşitti. Bir an düşündü. Sonra iri çarpık burnunu eliyle kaşıyor gibi yaptı. Çatık kaşlarının kaldırdı. Sırıttı. Çürük dişlerinin arasından tükürükler saçan küstah bir edayla:

- Valideciğim, yirmi senedir kaymak yemekten usandım, dedi. Şimdi de biraz canım havyar istiyor! Siyah havyar...

# Hediye...

Üç gündür içimde öyle bir heyecan-ı arzu var ki bunu ve sebebini bir türlü tefsir edemiyordum.

Teskin-i asabiyete muvaffak olamıyordum. En nihayet –zevcimin is’âf-ı hevesime mazhar olamamaktan tevellüt edecek hüzün ve kederi iyice bildiğim halde– karar verdim. O akşam memuru bulunduğu bankadan her vakitki gibi, yine yorgun ve ter içinde geldiği zaman mutat olan buse-i muhabbetimi takdim etmeden “Bir gül!” diye haykırıverdim.

O şaşkın, ve istizahkâr yüzüme bakıyordu: “Bir gül, bir gül.. o kadar ihtiyacım var ki bir gül, bir bahar çiçeği...”

Ve artık anlattım. O başını müteessirâne sallayarak diyordu ki: “Bir köyden... kışın bir gül...”

Ben o kadar ısrar ediyordum ki o akşam hemen darılıvermiştim ve gül gelinceye kadar söz söylemeden ısrar ediyordum.

Nihayet gülerek ve istihzakârane muvafakat etti: “Paris’teki dostumuz Vikont (K.)’a yazalım. Belki buraya kadar solmadan gelir...”

Biz kadınlar tuhafız. Bu muvafakate karşı yine gelinceye kadar olacak dargınlıkta devam edeceğimi aht etmiştim. Gözüm her gün posta arabasına ma’tûf idi.

Tuhaf arzu... Öyle zannediyordum ki bu bir gül bana bir bahar-ı zevk olacak. Fakat bir hafta olduğu halde el’ân bir haber gelmemişti. Artık karşıda bir hiddet ve garez hissediyordum. Tabiî bir keyifsizlik ve bir meşgale bir hafta kadar asabiyetimi teskin etmek üzere iken gözümü ilk dakika-i ıstıraptan sonra açtığım vakit kalbimdeki ilk darbenin bir gül ihtiyacından ibaret olduğunu hissettim. Dargınlığımız el’ân devam ediyordu. Fakat zevcimde o kadar derin bir mesrûriyet hissediyordum ki bunu mutlaka bana karşı bil-iltizâm yapıyor sanıyor ve daha ziyade darılıyordum.

Ertesi akşam Vikont o eski vaz-ı bülent ve vakarıyla posta arabasından indi. Pencerenin önünde uzanmıştım. Heyecanım o kadar şedîd idi ki söz söyleyemiyordum. Şimdi hatırıma geliyordu. Gülü isterken yakında –ıstırabatıma sebep olan– yavrumuzun vaftiz merasimine de Vikont’u davet etmiştik.

Beraber oturduğumuz halde ne o, ne ben, ne de zevcim gül bahsine dair bir şey açmamıştık. Ben cesaret edemiyordum. Fakat canım da fena halde sıkılıyordu... Neticeten gülü getirmemişti, getirse idi şimdiye kadar vermesi icap ederdi. Artık, hakikaten darılmıştım.

Ertesi gün köy rahibiyle birkaç bildik vaftiz merasimini icra etmek üzere idiler. Bir aralık rahip başını zevcime çevirdiği zaman, o mesut, müsterih tebessüm ediyordu.

Zevcim Vikont’a işaret etti ve sol elini –en ziyade memnun olduğu zamanlar yapar– yeleğinin cebine sokarak dikkatli dikkatli bana bakıyor ve gülüyordu.

O vakit Vikont küçüğün üzerine eğilerek ve merasim-i mahsusayı icra ederek dik ve halâvetli bir sesle sertçe “La rose!” dedi.

Zevcim hâlâ mütebessim ve halîm gözüme bakıyordu. Ben hemen intikal ederek titredim ve elimi uzatarak zevcimin o muhterem ve mukaddes dest-i muhabbetini sıkıverdim. Bu barıştığıma delil idi.

Ah bu hediye, bütün asabiyetimi teskin eden bu gül... Ve yolda giderken düşünüyordum: Bir gül, birkaç saniye, en nihayet bir bahar beni ta’tîr ve tesrîr edecekti. Lâkin bu, bütün hayatımı çiçekleyecek, bu gül bana ebedî bir zevk ve saadet olacak...

# Hürriyet Bayrakları

...O akşam Demirhisar'dan Cuma-yi Bâlâ'ya geç ve yorgun gelmiştim. Gündüz hava pek sıcaktı. Başağrısı bana eski ve pis otelin aç tahtakurularını bile duyurmadı. Fakat sabahleyin zurna ve davul seslerine karışan naralar, türküler beni uyandırdı. Gözlerimi açtım. Tozlu ve soluk kırmızı perdelerden yakıcı bir güneş taşıyor, bütün odayı dolduruyordu. Gerinirken yalancı inkılâbımızın, bu kansız ve hakikatte ancak mânâsız alkış tufanlarından ibaret olan zavallı düzme Türk inkılâbının ikinci senesi olduğunu hatırladım. Evet bugün milli bir bayramdı! "Lâkin, acaba hangi milletin bayramı?" diye düşünerek kalktım. Pencereye yaklaştım. Dışarıda karmakarışık bir kalabalık dalgalanarak, kaynaşarak akıp gidiyordu. Karşıki çürük tahta peykeli Ulah ve Bulgar dükkânları açıktı. Sahipleri bu diyara yeni gelmiş hâkim yabancılar gibi önlerinden geçen sırma cepkenli Türk delikanlılarına gülümseyerek bakıyorlardı. Bu "On Temmuz" alayı, bu nümâyiş hakikaten seyre layıktı. Yüzümü yıkamayı sonraya bırakarak sandalyeyi çektim. Camı açtım ve oturdum. Biraz ileride Yahudinin Kızlı Kahvesi'ndeki gramofon bu hareket ve nümâyişlerden haberi varmış gibi bütün kuvvetiyle, eskisinden ziyâde bir gürültü çıkararak haykırıyor; uzaktan, el şakırtılarıyla ve "Yaşasın!" feryatlarıyla, uğuldayan bir mızıka sesi yaklaşıyordu. Cuma-yi Bâlâ piyade alayından bir müfreze, tebrik için hükümete gidiyordu. Binbaşı —kır saçlı, esmer ve saf çehreli bir adam— beyaz atının üzerinde şaşırmış bir gelin gibi sallanarak ve önüne bakarak gidiyor, arkasından dörder dörder gelen ezeli acemiler, amirleri gibi önlerine bakarak, mızıkanın çaldığı;

Ordumuz etti yemin, Titredi hak ü zemin.

parçasını tekrarlayarak geçiyorlardı. Ondan sonra sırmalı Türk esvapları giymiş genç ve fazla sarı bir bey, bir sürü genç arkadaşlarıyla büyük bir muzafferiyetten dönüyormuş gibi kabararak askeri takip etti. Onların arkasından da çingenelerden ve sefillerden mürekkeb diğer bir sürü... Sonra büyük ve kırmızı bir bayrak göründü. Üzerinde üstünlü esreli birtakım yazılar vardı ki, okuyamıyordum. Bayrağın etrafında birçok sarıklı kafalar, büyük ve garip dev papatyalar gibi dalgalanıyor, arkadan hâki esvaplı, ikişer olmuş rüştiye çocukları bağrışarak kaynaşıyorlardı. Tutturdukları;

Arş ileri, arş ileri! Alalım düşmandan eski yerleri...

nakaratını o kadar candan ve gönülden haykırıyorlar ki, önümden geçtikçe hepsinin zayıf boyunlarında ince damarcıklarının şiştiğini, feslerinin altından kırmızı terler aktığını görüyordum.

Bu nümâyiş akıntısı belki yarım saatten ziyâde sürdü.

Afyonunu fazla kaçırmış bir derviş gibi dalmış, gitmiştim. Vatanımın, Türkiye'nin, bu mutlaka öleceğine iman edilen hasta adamın hayatını düşünüyor, yeise pek benzeyen acı bir hisle bütün zihniyetimin büzüldüğünü, işlemez bir hale geldiğini duyuyordum. Odanın kapısı açıldı. Rum otelci atlarımın hazır olduğunu söyledi.

Razlık'a gidecektim. Demek bu geceki milli şenliği orada görecektim... Hemen giyindim. Giyinirken otelcinin getirdiği sütlü kahveyi bir yudumda içtim.

Tekrar deminki garip ve mahzun dalgama düştüm!

Bir saat sonra Papaz Bayırı'na çıkan dik yokuşu tırmanıyordum. Atımdan inmiştim. Hava çok güzeldi. Gökte ufak bir duman bile yoktu. Sırtlarda beyaz hudut kuleleri parlıyor, hafif bir rüzgar estikçe sanki güneşin sıcağını arttırıyordu. Bir sel yarıntısının içinde yürüdüm. İrili ufaklı taşlar ayaklarımı acıtıyor, atların yürümesine mani oluyordu. Buralarda hiç yol yoktur. Hatta bir keçi yolu bile... Etrafıma bakıyordum; gördüğüm yerler küçükken coğrafya kitaplarında o kadar ehemmiyetle okuyarak tahayyül ettiğimiz, o mâhut portakala benzeyen arzı hiç andırmıyordu. Sanki üzerinde insan ve hayvan yaşamayan bir kürenin, mesela ölmüş ve donmuş denilen ayın bir köşesinde idim. Taşlar, taşlar, taşlar.. Sarı ve akim topraklar, cılız ve sıska ağaçlar, çalılar, çalılıklar, yine çalılıklar. Yalnız telgraf direkleri bu iklimlerden vaktiyle yanılıp da bir kerecik geçmiş zannolunan medeniyet heyulasının belirsiz izlerinde dikilmiş büyük ve öksüz taaccüp işaretleri gibi yükseliyor, onun kaçtığı ormanlı ufuklara doğru birbiri arkasına sıralanıp gidiyordu.

Ve yolcular, hep bu güneş, soğuk, rüzgar, tipi ve kar altında kapkara olmuş ölü direklerin dibinden gidiyorlardı. İyice terledikten ve nefesim kesildikten sonra tepeye çıktım. Dinlenmek için duracaktım. Biraz ileride bir atlı gördüm. Esvabından, kılıcının parıltısından bir zâbit olduğunu anladım. O da yere inmiş, dinleniyor ve tabakasından cigara sarıyordu. Yanına gittim. Türkler'de "takdim ve takaddüm"e hacet yoktur. Bu teklifsizliğimi çok sever ve çok samimi bulurum. Yaklaştım. Selam verdim. Nereye gittiğini sordum. Gülümseyerek cevap verdi: — Razlık'a efendim, siz? — Ben de. — O halde beraber gideriz. Bu esmerce, orta boylu, güzel bir mülazım dı. Geniş ve dolgun omuzlarının üstündeki büyük ve dik başı, iri ve siyah gözlerinin mahmurluğu, sirklerde kırbaçla ahlâkı bozulmuş esir kaplanların acıklı sükununu hatırlatıyordu. Konuşmaya başladık. Bütün Türk zâbitleri gibi kendi malumatına ve mantığına, kendi itminanlarına pek büyük bir ehemmiyet veriyor, münakaşa için fırsat arıyordu. Orada bir taşın üzerine oturduk. Cigaralarımızı yaktık. Öteden beriden... Bahsi politikadan açtık. Ben "On Temmuz" un buralarda bile takdir olunduğunu söyledim. Mülazım, hayretime canı sıkılmış gibi: — Ah ne diyorsunuz? On Temmuzu takdir etmek.. Dedi. Bu da laf mı? Bu bizim en büyük, en şanlı, en âlî bir günümüz, en mukaddes milli bayramımızdır. Keşke üç gün olsaydı.... Çünkü bir gün bir gece, pek az... — Demek On Temmuza bu kadar ehemmiyet veriyorsunuz? Diye gülümsedim. İddialarının aksini söyleyerek asabi münakaşacıları kızdırmak hoşuma gittiğinden ilave ettim: — Hem bu nasıl milli bayram? Hangi milletin bayramı? — Osmanlı milletinin... — Osmanlı milleti demekle Türkleri mi kastediyorsunuz? — Hayır, asla... Bütün Osmanlıları.... Genç mülazımın koyu siyah gözlerinde sanki bir taassup ateşi parladı. Dinine küfür edilmiş bir evvel zaman Müslümanı gibi bakıyordu. Birden başlamayarak aklî sualciklerle onun hissi mantığını şaşırtmaya karar verdim: — Bütün Osmanlılar kimlerdir? — Tuhaf sual! Araplar, Arnavutlar, Rumlar, Bulgarlar, Sırplar, Ulahlar, Yahudiler, Ermeniler, Türkler...Hasılı hepsi... — Bunlar demek hep bir millet? — Şüphesiz... Tekrar güldüm. — Fakat ben şüpheleniyorum. — Niçin? — Söyleyiniz Ermeniler, bir millet değil midir? Biraz durdu. Tereddütle cevap verdi: — Evet bir millettir. — Arnavutlar da bir millet? — Arnavutlar da. — Ey Bulgarlar? — Bulgarlar da.. — Sırplar? — Tabii Sırplar da. Gülerek, başımı sallayarak: — O halde sizin riyâzi ve müspet hakikatlere itikadınız yok. Dedim. Ne demek istediğimi anlamadı. Yüzüme baktı. Ben devam ettim: — Hendese den, cebirden, müsellesat tan vazgeçelim. Hatta hesap bilmiyorsunuz. Hesabın "cem" kaidesini bilmiyorsunuz. Yahut biliyorsunuz da, bunların doğru ve esaslı şeyler olduğuna inanmıyorsunuz. Mülazımın bakışı bütün bütün değişti. Kendisiyle eğleniyorum sandı. Hiddetlenmesine meydan vermeden ben yine devam ettim: — Yanlış anlamayınız. Yalnız bana cevap veriniz. Hesaptaki "cem" kaidesini hatırlayabiliyor musunuz? — ! ! ! — Ben size söyleyeyim. Tabii inkar edemeyeceksiniz. Bir cinsten olan şeyler cem olunabilirler. Mesela on kestane, sekiz kestane, dokuz kestane! Hepsi yirmi yedi kestane eder, değil mi? — Evet!!! — Bir cinsten olmayan şeyler cemedilemez. Mesela on kestane, sekiz armut, dokuz elma... Nasıl cemedeceksiniz. Bu mümkün değildir. Ve bu imkansızlık nasıl riyâzi ve bozulmaz bir kaide ise birbirinden tarihleri, ananeleri, meyilleri, müesseseleri, lisanları ve mefkureleri ayrı milletleri cemedip hepsinden bir millet yapmak da o kadar imkansızdır. Bu milletleri cemedip "Osmanlı" derseniz, yanılmış olursunuz. Mülazım cigarasını unutmuştu. Yüzüme şaşalamış gibi bakıyor, onun şüphesiz ilk defa işittiği bu kadar basit ve adi bir hakikatten şaşalamasını sersemliğe çevirmek için ben izahımda, daha mufassal ve hararetli devam ediyordum. Birçok misaller getiriyor, "Osmanlılık" kelimesinin düveli bir tabirden başka bir şey olmadığını; Rumların, Bulgarların, Sırpların, bütün o eski esirlerimiz olan bugünkü uyanık milletlerin Türklerden intikam almak ve kendi öz kardeşleriyle, Balkan hükümetleriyle birleşmekten daha tabii, daha makul, daha mantıklı, daha haklı mefkureleri olamayacağını anlattım. Lâkin mülazımın anlamadığını gözlerinden, birden coşmasından pek iyi anlıyordum. Cigaralarımız bitmişti. Nihayet: — Seninle münakaşa edemem, dedi, çünkü fikirlerimiz taban tabana zıt... Ve ayağa kalktı. Ben de kalktım. Atlarımızı yedeğe alarak keskin ve kayalı bir sırtın kenarından yürümeye başladık. Yan gözle çaktırmadan yüzüne bakıyordum. Pek mustaripti, hep yere bakıyordu. Bir şey söylemek ister gibi bazı duruyor, sonra vazgeçmiş gibi yine hızla yürümeye devam ediyordu. Yine ben sükutu bozdum: — Vâkıâ fikirlerimiz zıt, fakat azizim inkar edemezsiniz, benimkiler doğru değil mi? — Hayır, asla doğru değil, dedi. Tırmandığımız tepeden artık aşağıları görünüyor, Karaali hanlarının üstündeki beyaz jandarma karakolu, Simitli'ye doğru akan çakıllı dere parlıyor, uzakta seyrek ve sık ormanların nispetsiz ve boş alanlarında yanmış tahta yığınları halinde küçük köyler görünüyordu. Ayağa kalkar kalkmaz yine sızmaya başlayan terlerimi ıslak mendilimle silerek yine ısrar ettim: — Lâkin, niçin azizim, niçin doğru değil? Mülazımın canı sıkılmıştı. "Affedersiniz ama..." diye başladı ve coştu; eğer benim iddiam doğru olsaydı o kadar büyük adamlar bunu kabul etmezler miydi? Eski ve yeni bütün hükümetçi memurlara "büyük adamlar" diyordu. Hususiyle "Osmanlılık" fikri söylediğim kadar boş, suni ve hülya olsaydı muvafık ve muhalif bütün siyasi fırkalar programlarına bunu esas yaparlar mıydı? Artık Türkiye'de hiç adam yok muydu? Herkes yanılıyor muydu?

Söyledikçe müdafaasında ve mantığında kendini haklı sanıyor, haklı sandıkça daha ziyâde coşuyor ve biraz eğlenir gibi: — Demek koca Türkiye'de herkes cahil de yalnız siz âlimsiniz. Herkes yanılıyor da, aldanıyor da, hakikati yalnız siz anlıyorsunuz, tebrik ederim, tebrik ederim öyleyse... Diyordu. Yol birdenbire döndü. Derin bir sel yarıntısını geçmek lazım dedi. Durduk. Doğru yürüsek atların ayakları sakatlanacaktı. Belki düşeceklerdi. Etrafımıza bakınıyorduk. Mülazım sevinerek ve gülerek: — Ah bakınız, azizim... diye haykırdı, bakınız, işte Osmanlılığın şahidi! Parmağıyla bin metre kadar ilerde, uçurumlu bir yarın kenarındaki küçük bir Bulgar köyünü gösteriyordu. Siyah ve sürülmüş birkaç tarlacığın içinde süprüntü halinde duran bu viranecikte birkaç da ağaç vardı. Dikkatsiz nazarlarla bakıyordum. Mülazım ellerini çırpar gibi oğuşturarak: — Ah görmüyor musunuz, dedi, görmüyor musunuz? Şu köycükte sallanan kırmızı kırmızı hürriyet bayraklarını görmüyor musunuz? Bugünü, Osmanlıların birbirleriyle en samimi ve hakiki kardeş olduklarını dünyaya anlattıkları bu büyük ve mukaddes günü, On Temmuzu alkışlayan bu kırmızı bayrakları görmüyor musunuz? Dikkat ediyor, dikkatli dikkatli bakıyordum. Köyün orta yerindeki bir binada kırmızı bayraklar asılmış duruyordu! Gözlerime inanamıyordum: — Acaba bunlar hürriyet bayrakları mı? Dedim. Mülazım taştı. Taşmadı; âdeta fışkırdı. — Körsünüz azizim, bakar körsünüz. Nafile zahmet edip bakmayınız. Hakikatler görmek istidâdı sizde yok. Hâlâ şüphe mi ediyorsunuz? Evet bunlar hürriyet bayraklarıdır. Şu dağ başında kaybolmuş Osmanlı-Bulgar köycüğü On Temmuzu takdis ediyor. İnanmıyor musunuz? Onlar Osmanlı değil midir? Yarın Osmanlı vatanına düşmanlar hücum ettiği vakit sizden evvel onlar koşacaklar, Osmanlılık namına kanlar dökecekler, Osmanlılığı kanlarıyla kurtaracaklar... Kendimi tutamadım: — Bu Bulgarlar ha?.. — Evet bu Bulgarlar! Bunlar en sadık Osmanlılardır. Komitacılarla hiç münasebetleri yoktur. Komitacılardan nefret ederler. On Temmuzu en mukaddes bir gün bilirler. Fakat siz müteassıpsınız. İnanmazsınız. Hâlâ akılsız ve cahil babalarımız gibi: "Domuz derisinden post, gavurdan dost olmaz..." der, medeniyetin, büyük yirminci asırın doğurduğu insaniyet, uhuvvet, müsâvât fikirleriyle eğlenirsiniz. Bütün Osmanlıların kardeş olmalarını kabul edemezsiniz. İşte bakınız, ufacık bir köy bugünü kırmızı bayraklarla tebcil ediyor. Kimbilir, akşam bu büyük günün şerefine nasıl eğlenecekler, nasıl içecekler ve "Yaşasın Osmanlılık, kahrolsun nifak!" diye bağıracaklar.. Ben susuyor ve dinliyordum. Mülazım coşuyor, Tanzimat tılsımının hülyalarıyla, seraplarıyla dalgalanan Osmanlılık rüyasını, onun tatlı hezeyanlarını tasvir ediyor, artık büyük Osmanlı milletine kimsenin galip gelemeyeceğini söylüyordu. Hâlâ yarın başında, uzakta kırmızı bayrakları görünen Bulgar köyünün karşısında duruyorduk. Birden elimden tuttu: — İster misiniz, oraya kadar gidelim, dedi, doğruluğuna inanamadığınız Osmanlılığın nasıl kavi ve halis olduğunu kendi gözlerinizle göreceksiniz. Üşenmeyiniz. Gidelim, bu muhterem Osmanlıları, tebrik edelim. Bu büyük gün için öpüşelim. Daha ziyâde rica ediyordu. Vâkıâ köy ancak bin metre kadar vardı. Lâkin aradaki dere pek sarptı. Oraya varmak için en aşağı bir saat lazımdı. Yolumuzdan bir buçuk saat kadar kaybedecektik. İstemiyordum. Razlık'a geç kalacağımızı söyledim. Mülazım rica ve ısrar ediyor, mutlaka bu zavallıların samimiyet ve sadakatlerini bana göstermek istiyordu. Ben vazgeçmesini, kendi fikirlerini kabul ettiğimi, kendisiyle bir fikirde olduğumu, deminki sözlerimin şakadan başka bir şey olmadığını söyledikçe o ısrar etti. Nihayet dayanamadım. — Haydi gidelim. Dedim. O önden, ben arkadan derin bir uçuruma yuvarlanır gibi indik. Dere kupkuru idi. Etraftaki taşları, kumlu toprak yığınlarını güneş kızdırmış, âdeta bir fırına çevirmişti. Atlarımız bu münasebetsiz seyahattan şaşalamış gibi bazı duruyorlar, gelmemek istiyorlardı. Derenin dibinde köye çıkan yolu bulduk. İndiğimiz kadar çıkacaktık. Nefeslerimiz duruyor, her yirmi adımda bir dinleniyor, tekrar taşları ve çalı köklerini tutarak tırmanıyorduk. Ayaklarımızın altında toprak parçaları yuvarlanıyor, kertenkeleler kaçışıyor, fundaların arasına saklanıyorlardı. İnce yol gayet dikleşti. Ve artık tepeyi tutuyorduk. Bir gayret, bir gayret daha... Hafif bir düzlüğe çıktık. Burası köyün önü idi. Yeni açılmış tarlaların kenarlarında büyük gübre yığınları duruyordu. Kırmızı hürriyet bayrakları takan eve ancak yirmi otuz adım vardı. Durduk. Bizi birden gören zayıf, sarı tüylü ve iri bir köpek havlamaya ve üzerimize atılmaya başladı. Gübreleri burunlarıyla karıştıran irili ufaklı domuzlar, minimini gözleriyle "Bunlar kim?" gibi merak ve tecessüsle bakıyorlardı. Fakat biraz ilerde, tarlanın nihayetinde bel ile çalışan Bulgar, köpeğin havlamasını işitmemiş gibi hiç bize bakmıyor, kim olduğumuzu bile merak etmiyordu.

On Temmuz bayramını tebcil için asılan bayraklara baktım. Bunlar hava aldırmak için güneşe asılmış kırmızı biber dizileri idi... Alçak kapıdan gözüken kolları sıvalı, pis, sarı, esmer bir kadın, hain ve mavi gözleriyle kızdırılmış vahşi bir hayvan gibi bizi süzüyor, etrafımızda havlayan, sıçrayan, deliren köpeği mahsustan çağırmıyordu. Şimdi hürriyet bayrakları sandığı şeylerin ne olduğunu gören mülazım dudaklarını ısırıyor, sapsarı kesiliyordu. Şaşkın bir sesle tarladaki Bulgar'a: — Kolay gelsin gospodin! Dedi. Bulgar hâlâ işini bırakmıyor, başını çevirip bize bakmıyordu. Yine yüzünü çevirmeden sert ve bir küfür kadar çirkin bir şive ile: — Nezman Türkçe bre... Diye haykırdı. Ben ve mülazım, donmuş kalmıştık. Öyle duruyorduk. Sanki vurulmuştuk. Tablo değişmiyordu. Kadın aynı hain gözlerle bize bakıyor, etrafımızda çırpındıkça daha ziyâde kuduran köpek havlamasında devam ediyor, domuzlar gayet adi ve ehemmiyetsiz mahluklar olduğumuzu anlamışlar gibi sahiplerini taklit ederek bize bakmaktan vazgeçiyorlar, gübrelerde ezeli gıdalarını araştırmaya başlıyorlardı. Tarlada çalışan Osmanlı-Bulgar vatandaş, bir kere olsun dönüp bakmıyor, çapasıyla uğraşıyordu. Mülazımı kolundan çektim: — Haydi artık gidelim. Dedim, cevap vermedi. Beni takip etti. Dumanlaşan gözleri yerde idi. Artık ne onda ne de bende münakaşa edecek kuvvet ve neşe yoktu. Hali bir cehennemin tenha uçurumlarında kalmış günahsız hayvanlar gibi, gayr-i müdrik ve dalgın, tekrar uçuruma girdik. Tırmandığımız yollardan kaymaya başladık.

Tepeye, Karaali hanlarına giden keçi yoluna çıkınca arkama döndüm. Ta derenin öbür tarafında kalan köye baktım. Hakikaten, zehir kadar acı olan bu kırmızı biber dizileri uzaktan pek cazibeli ve al hürriyet bayrakları gibi parlıyor, insana ne olursa olsun bir şeyi alkışlamak "Yaşasın! Yaşasın!" diye haykırmak arzuları veriyordu.

25 Temmuz 1326 (1910)

# Kaşağı

== Kaşağı == Ahırın avlusunda oynarken aşağıda, gümüş söğütler altında görünmeyen derenin hazin şırıltısını işitirdik. Evimiz iç çitin büyük kestane ağaçları arkasında kaybolmuş gibiydi. Annem, İstanbul'a gittiği için benden bir yaş küçük olan kardeşim Hasan'la artık Dadaruh'un yanından hiç ayrılmıyorduk. Bu, babamın seyisi, ihtiyar bir adamdı. Sabahleyin erkenden ahıra koşuyorduk. En sevdiğimiz şey atlardı. Dadaruh'la beraber onları suya götürmek, çıplak sırtlarına binmek, ne doyulmaz bir zevkti. Hasan korkar, yalnız binemezdi. Dadaruh onu kendi önüne alırdı. Torbalara arpa koymak, yemliklere ot doldurmak, gübreleri kaldırmak eğlenceli bir oyundan ziyade, bizim hoşumuza gidiyordu. Hele tımar... Bu en zevkli şeydi. Dadaruh eline kaşağıyı alıp işe başladı mı, tıpkı... tık... tık... tık... tıpkı bir saat gibi... yerimde duramaz:

— Ben de yapacağım! diye tuttururdum.

O vakit Dadaruh, beni Tosun'un sırtına koyar, elime kaşağıyı verir,

— Hadi yap! derdi.

Bu demir aleti hayvanın üstüne sürter, fakat o uyumlu tıkırtıyı çıkaramazdım.

— Kuyruğunu sallıyor mu?

— Sallıyor.

— Hani bakayım?..

Eğilirdim, uzanırdım. Lakin atın sağrısından kuyruğu görünmezdi.

Her sabah ahıra gelir gelmez,  
— Dadaruh, tımarı ben yapacağım, derdim.  
— Yapamazsın.  
— Niçin?  
— Daha küçüksün de ondan...  
— Yapacağım.  
— Büyü de öyle.  
— Ne vakit?  
— Boyun at kadar olduğu vakit.  
— .....  
At, ahır işlerinde yalnız tımarı beceremiyordum. Boyum atın karnına bile varmıyordu. Halbuki en keyifli, en eğlenceli şey buydu. Sanki kaşağının muntazam tıkırtısı Tosun'un hoşuna gidiyor, kulaklarını kısıyor, kuyruğunu kocaman bir püskül gibi sallıyordu. Tam tımar biteceğine yakın huysuzlanır, o zaman Dadaruh, "Höyt.." diye sağrısına bir tokat indirir, sonra öteki atları tımara başlardı. Ben bir gün yalnız başıma kaldım. Hasan'la Dadaruh dere kenarına inmişlerdi. İçimde bir tımar etmek hırsı uyandı. Kaşağıyı aradım, bulamadım. Ahırın köşesinde Dadaruh'un penceresiz küçük bir odası vardı. Buraya girdim. Rafları aradım. Eyerlerin arasına falan baktım. Yok, yok! Yatağın altında, yeşil tahtadan bir sandık duruyordu. Onu açtım. Az daha sevincimden haykıracaktım. Annemin bir hafta önce İstanbul'dan gönderdiği hediyeler içinden çıkan fakfon kaşağı, pırıl pırıl parlıyordu. Hemen kaptım. Tosun'un yanına koştum. Karnına sürtmek istedim. Rahat durmuyordu.  
— Galiba acıtıyor? dedim.  
Gümüş gibi parlayan bu güzel kaşağının dişlerine baktım. Çok keskin, çok sivriydi. Biraz köreltmek için duvarın taşlarına sürtmeye başladım. Dişleri bozulunca tekrar tecrübe ettim. Gene atların hiçbiri durmuyordu. Kızdım. Öfkemi sanki kaşağıdan çıkarmak istedim. On adım ilerdeki çeşmeye koştum. Kaşağıyı yalağın taşına koydum. Yerden kaldırabileceğim en ağır bir taş bularak üstüne hızlı hızlı indirmeye başladım. İstanbul'dan gelen, ihtimal, Dadaruh'un kullanmaya kıyamadığı bu güzel kaşağıyı ezdim, parçaladım. Sonra yalağın içine attım.  
Babam, her sabah dışarıya giderken bir kere ahıra uğrar, öteye beriye bakardı. Ben o gün gene ahırda yalnızdım. Hasan evde hizmetçimiz Pervin'le kalmıştı. Babam çeşmeye bakarken, yalağın içinde kırılmış kaşağıyı gördü; Dadaruh'a haykırdı:  
— Gel buraya!  
. . . . . .  
Nefesim kesilecekti, bilmem neden, çok korkmuştum. Dadaruh şaşırdı, kırılmış kaşağı meydana çıkınca, babam bunu kimin yaptığını sordu. Dadaruh:  
— Bilmiyorum, dedi.  
Babamın gözleri bana döndü, daha bir şey sormadan:  
— Hasan dedim.  
— Hasan mı?  
— Evet, dün Dadaruh uyurken odaya girdi. Sandıktan aldı. Sonra yalağın taşında ezdi.  
— Niye Dadaruh'a haber vermedin?  
— Uyuyordu.  
— Çağır şunu bakayım.  
— .....

Çitin kapısından geçtim. Gölgeli yoldan eve doğru koştum. Hasan'ı çağırdım. Zavallının bir şeyden haberi yoktu. Koşarak arkamdan geldi. Babam pek sertti. Bir bakışından ödümüz kopardı. Hasan'a dedi ki:  
— Eğer yalan söylersen seni döverim!  
— Söylemem.  
— Pekala, bu kaşağıyı niye kırdın?  
Hasan, Dadaruh'un elinde duran alete şaşkın şaşkın baktı! Sonra sarı saçlı başını sarsarak:  
— Ben kırmadım, dedi.  
— Yalan söyleme, diyorum.  
— Ben kırmadım.  
Babam tekrar:  
— Doğru söyle, darılmayacağım. Yalan çok fenadır, dedi.  
Hasan, inkârında inat etti. Babam hiddetlendi. Üzerine yürüdü, "Utanmaz yalancı" diye yüzüne bir tokat indirdi.  
— Götür bunu eve; sakın bunu bir daha buraya sokma. Hep Pervin'le otursun! diye haykırdı.  
Dadaruh, ağlayan kardeşimi kucağına aldı. Çitin kapısına doğru yürüdü. Artık ahırda hep yalnız oynuyordum. Hasan evde mahpustu. Annem geldikten sonra da affedilmedi. Fırsat düştükçe, "O yalancı" derdi babam. Hasan yediği tokat aklına geldikçe ağlamaya başlar, güç susardı. Zavallı anneciğim benim iftira atabileceğime hiç ihtimal vermiyordu. "Aptal Dadaruh, atlara ezdirmiş olmasın?" derdi.

Ertesi sene annem, yazın gene İstanbul'a gitti. Biz yalnız kaldık. Hasan'a ahır hâlâ yasaktı. Geceleri yatakta atların ne yaptıklarını, tayların büyüyüp büyümediğini bana sorardı. Bir gün birdenbire hastalandı. Kasabaya at gönderildi. Doktor geldi. "Kuşpalazı" dedi. Çiftlikteki köylü kadınlar eve üşüştüler. Birtakım kuşlar getiriyorlar, kesip kardeşimin boynuna sarıyorlardı. Babam yatağın başucundan hiç ayrılmıyordu.  
Dadaruh çok durgundu. Pervin hüngür hüngür ağlıyordu.  
— Niye ağlıyorsun? diye sordum.  
— Kardeşin hasta.  
— İyi olacak.  
— İyi olmayacak.  
— Ya ne olacak?  
— Kardeşin ölecek! dedi.  
— Ölecek mi?  
Ben de ağlamaya başladım. O hastalandığından beri Pervin'in yanında yatıyordum. O gece hiç uyuyamadım. Dalar dalmaz, Hasan'ın hayali gözümün önüne geliyor, "İftiracı! İftiracı!" diye karşımda ağlıyordu.  
Pervin'i uyandırdım.  
— Ben Hasan'ın yanına gideceğim, dedim.  
— Niçin?  
— Babama bir şey söyleyeceğim.  
— Ne söyleyeceksin?  
— Kaşağıyı ben kırmıştım, onu söyleyeceğim.  
— Hangi kaşağıyı?  
— Geçen seneki. Hani babamın Hasan'a darıldığını...  
Lafımı tamamlayamadım. Derin hıçkırıklar içinde boğuluyordum. Ağlaya ağlaya Pervin'e anlattım. Şimdi babama söylersem, Hasan da duyacak belki beni affedecekti.  
— Yarın söylersin, dedi.  
— Hayır, şimdi gideceğim.  
— Şimdi baban uyuyor, yarın sabah söylersin. Hasan da uyuyor. Onu öpersin, ağlarsın, seni affeder.  
— Pekala!  
— Haydi şimdi uyu!  
— .....  
Sabaha kadar gene gözlerimi kapayamadım. Hava henüz ağarırken Pervin'i uyandırdım. Kalktım. Ben içimdeki zehirden vicdan azabını boşaltmak için acele ediyordum. Yazık ki, zavallı masum kardeşim, o gece ölmüştü. Sofada çiftlik imamıyla Dadaruh'u ağlarken gördük. Babamın dışarıya çıkmasını bekliyorlardı.

# Kerâmet

Yangın yarım saatten beri devam ediyordu. Fakat mahallenin ahalisi iki ev sonra söneceğine kâildiler. Çünkü bir zât-ı şerifin türbesi vardı. Mümkün değil, o tutuşmazdı! Şiddetli bir kıble rüzgarı esiyor, alevleri, kıvılcımları saçan tahta parçalarını, türbenin üzerine, türbenin altındaki evlerin çatılarına fırlatıyordu. İtfaiye bölüğü, tulumbalar son gayretlerini sarf ediyorlardı. Polisler etrafı ablukaya almışlar, kaçırılan eşyanın yağmasına meydan vermiyorlardı. Çiroz Ahmet etrafına bir göz gezdirdi. Bu kaşarlanmış bir külhanbeyi idi. Onca yangın demek vurgun demekti. Ama mahalle çok fakirdi. Biliyordu ki, şu yanan zavallı kulübeciklerin içinde yatak yorgandan başka bir şey yoktu. Halbuki vurgunda âdet “yükte hafif, pahada ağır şeyler” i bulmaktı.  
— Allah belasını versin! Faydasız yangın!  
Diye başını salladı. Ahali türbenin önüne toplanmıştı.  
— Buraya gelince söner! Diyorlardı.

Çiroz Ahmet, yeşil boyalı türbenin penceresine sokuldu. Kör bir kandilin hafifçe aydınlattığı sandukaya baktı. Başı ucunda iki büyük şamdan duruyordu. Sandukanın iki tarafında iki seccade yayılı idi. Açık rahlelerde büyük Kur'ân-ı Kerîmler yan gelmiş yatıyorlardı. Çiroz Ahmet kelepir karşısında parlayan bir Yahudi gözüyle bunlara baktı. Asgari bir hesap yaptı. İçinden: — Şamdanlar onar liradan yirmi... Seccadeler on beşerden otuz... Kitaplar mutlaka yazmadır. Yirmi de onlara de, etti yetmiş... Dedi. Yeşil boyalı kapıya gitti. Çiroz, kemikli omuzlarıyla bu kapının kuvvetini yokladı. Sonra kilidine baktı. Yavaş yavaş dayanmaya başladı. Halk yangınla meşguldü. Çiroz Ahmet son derece kuvvetliydi; hani o yalnız külhanbeylerine mahsus, bazusuz, idmansız, sporsuz, gizli, harikulâde kuvvet... Dayandıkça kapı çıtırdamaya başladı. Nihayet küt etti açıldı. Çiroz'un içeri girince ilk işi, kör kandili üflemek oldu. Fakat alacağı şeyler her ne kadar pahada ağır ise de yükte öyle pek hafif değildi. Zihni hemen bir vurgun planı tertibine başladı. Plan zihninde teşekkül ettikçe, Çiroz “netice” yi beklemiyor, teferruatını tatbik ediyordu. Şamdanların mumlarını çıkarıp yere attı. Rahlelerdeki kitapları alıp hepsini belinden çıkardığı Trablus kuşağına sardı. Sonra biraz durdu, burnunu kaşıdı. Yavaşçacık seccadeleri topladı; bunları beygirin üzerine çul vurur gibi, sandukanın üzerine örttü. Şimdi kapıdan çıkmak lazım geliyordu. Ama dışarısı dolu idi. Sandukaya dayandı. Biraz düşündü. Kavukta bırakılacak bir şey değildi. Üzerinde sırmalı bir çevre vardı. Sanduka birdenbire kaydı. Çiroz Ahmet düşmemek için toplandı. Acaba evliya diriliyor muydu? Durdu, baktı, gülümsedi. — Vay canına, yere mıhlı değilmiş be, dedi. Eğildi, altına bakmak için sandukayı kaldırdı. Bu gayet hafifti. İnce tahtadan yapılmış, üstüne yeşil çuha kaplanmıştı. Zihindeki "çıkış planı" tamamlandı. Kitaplarla şamdanları kucakladı. Bu sandukanın altına girdi. Yavaş yavaş yürüdü. Durdu. Sandukanın altından elini çıkarıp yavaşça kapıyı açtı. Sol taraf caddeye çıkıyordu. Yakalanmak ihtimali vardı. Sağ taraftaki sokak tenha idi. Viranelikler çoktu, ama yangın o tarafta idi. Herkes o tarafa birikmişti. Çiroz Ahmet, sandukanın altında uzun müddet düşünmedi. Paldır küldür kapıdan çıktı. Gürültüye başını çeviren halk şaşırdı. Herkes olduğu yerde kaldı. İşte evliya kalkmış yürüyordu. Tulumbalar durdu. Şiddetle esen rüzgar birdenbire durdu. İtfaiye askerleri korkularından ellerindeki baltaları, kancaları, hortumları düşürdüler. Sanduka yangına doğru yürüyordu. İki tarafa açılıp yol veren ahali korkudan titriyordu. Sanduka, korkunç manevî bir heybetle sallana sallana aralarından geçti, karanlıklarda kayboldu.

Türbeden evvelki iki evde ateşten kurtulmuştu. Yanmayıp evliyasız kalan türbe, yine mahalledeki kutsiyetini muhafaza etti. Yalnız, okuyanlar yüzlerini eskisi gibi boş binaya çevirmiyorlar, kıbleye bakıyorlar: “İki gözüm, yangın gecesi bu tarafa gitti!” diyorlardı.

# Korkunç Bir Ceza

Hasan Ağa, başka hemşerileri gibi yapmamış, İstanbul'a karısıyla beraber gelmişti. Para kazanmak iyi şeydi ama, bekarlığa can dayanmıyordu. Senelerce bekar odalarında bir iştiha ile memlekete dönmek doğrusu akıl işi değildi. Adam, dünyaya bir defa gelirdi, gençlik de bir bahar gibiydi. Göz açıp kapamadan geçiyordu.

Fatih'te bir ev tuttu. Açtığı helvacı dükkanı da o civarda idi. Ticareti yolunda gidiyordu. Her ay iki "beşibirarada" yaptırıyordu, karısı Gülsüm'ün kalın boynuna... Daha böyle beş bin tane "beşibirarada" olsa taşıyabilecekti. Dükkanlarının önünden geçen İstanbul hanımlarına baktıkça Gülsüm'ün kıymeti nazarında büyüyordu. İnce belli, ince boylu, ince bacaklı, ince kollu olan bu kadınlar, dar siyah çarşaflarıyla, ayağa kalkmış kır sineklerine benziyorlardı. Gülsüm'ün bir baldırı üç İstanbul hanımına değerdi. Beli değirmen taşı gibi, kalın kolları asma kabağı gibi kaskatıydı. Hele kazan kulpu kaşları... Hasan Ağa, karısının daha başka yerlerini de aklından geçirince: — Gözünü seveyim... diye coşar, uzun uzun gerinir, yatıp dinlenmek için hemen evine koşardı. Bir gün hemşerileri Tavukpazarı'nda verecekleri bir ziyafete onu da davet ettiler. — Olmaz, gelemem! Bizim avrat yalnızdır! Dedi. Arkadaşları ısrar ettiler. "Bir geceden ne olur. Yanına bir kişicik korsun!" dediler. Zorladılar. Nihayet dayanamadı. Razı oldu. Öğleyin eve geldi. Karısına: — Ben bu gece hemşerilerin ahengine gidivereceğim. Sen bir kişicik bul. Onunla yat, sakın korkma... dedi. Çıktı, gitti.

Gülsüm daha İstanbul'a ayak bastı basalı ilk defa evde yalnız kalacaktı. İçine bir ürperme geldi. Nasıl bu gece tek başına yatacaktı? Hemen kendini sokağa attı. Bir can yoldaşı, ona "kişicik bul" demişti. Önüne rasgelene: — Sen kişicik misin? diye soruyordu. Herkes gülüyordu. Galiba onu deli zannediyorlardı. İkindi oldu. Gülsüm, sokaklarda aradığı kişiciği bulamadı. Nihayet mahzun mahzun eve doğru dönerken karşıdan bir külhanbeyinin geldiğini gördü. Son bir ümitle ona da sordu: — Ayol, kişicik sen misin? . . . . .

Külhanbeyi Gülsüm'ü şöyle bir süzdü. Gülerek sordu:  
— Kişiciği ne yapacaksın hanım abla?  
— Kocam bu gece ahenge gitti. Gelmeyecek. Yalnız kalıp korkmayayım diye bana da bir kişicik bulmamı söyledi.  
Cevabını alınca:  
— Benim vallahi işte o kişicik, benim vallahi billahi... yeminlerini savurmaya başladı.  
Gülsüm inandı.

Külhanbeyini aldı. Eve getirdi. Karnını doyurdu. Kahvesini içirdi. Yatağına yatırdı, kendisi de bu kişicağızın yanıcağızına uzandı!

Hasan Ağa, ahenkte, hemşerilerinin yanında hiç eğlenemedi. Aklı hep evde, Gülsüm'deydi. Yanına misafir alacağı bir komşu kadın onu kandırır, ihtimal başka bir kocaya kaçırırdı. Hem iyice hatırlıyordu. Köyden çıkarken Ayan Musa: — Oğul! İstanbul'a avrat götürmek âdet değüldür, emme sen bu işi idiyon... Gumesin gapısı açıh galınca içeri dilki dalar... demişti. Ya boş kalan kümese bir tilki... Düşünmekten eğlenemedi. Gece uyuyamadı.

Artık sabaha iki üç saat kalmıştı. Sabrı tükendi. Kalktı. Evinin yolunu tuttu. Daima yanında taşıdığı anahtarla yavaşça sokak kapısını açtı. Gülsüm'ün koynuna koşuyordu. Odaya girince karısıyla kıvırcık saçlı bir herifin sarmaş dolaş yattığını gördü. Kan beynine sıçradı. Avazı çıktığı kadar haykırdı. Öyle haykırdı ki, yıldırım düşmüş gibi, gök gürlemiş gibi, pencerenin camları zangır zangır titriyordu. — Ülen gahpe garı! Bu kim? Gülsüm, korkusundan koynunda yatana daha beter sarılarak: — Ayol ne oluyon? Dedi. İşte kişicik bu imiş. Sen bana onu bul da beraber yat demedin mi? Hasan Ağa kendine geldi. Fena dakikalarda daima bir atasözünü hatırlardı. "Öfkeyle kalkan ziyanla oturur!" Sesini yavaşlatarak tekrar sordu: — Ben sana erkek bir kişicik mi bul dedim. Bir dişi kişicik bulamadın mı? — Ben ne bileyim! Sen dişi olacağını söylemedin. Hasan Ağa, hakkı, hakikati bütün hemşerileri gibi çok severdi. Başını salladı. — Senin gabahatin yoh! Domuzluh bu kişiciktedir. Ben ona göstereceğim! Dedi. Yataktaki külhanbeyi korkusundan nefes alamıyor, kalbinin çarpıntısı odanın içinden bir duvar saati gibi işitiliyordu.

Atasözünün içten tavsiyesiyle öfkesini geçiren Hasan Ağa külhanbeyine: — Haydi kalk! Esvaplarını gey! Emrini verdi. Zavallı çapkın hemen itaat etti. Bir dakikada giyindi. Saçlarını taradı. Kuşağını sardı. Fesini "yardan ayrıldımvâri" başına yerleştirdi. Hasan Ağa hâlâ yataktan çıkmayan karısına döndü: — Şu keratanın kunduralarını buraya getir! Dedi. Gülsüm kunduraları getirince aldı; yatağın kenarında sessiz, solgun ayakta duran külhanbeyinin önüne gitti. Eğildi. — Bin ülen pezevenk! Dedi. Külhanbeyi yine itaat etti. Hasan Ağa, külhanbeyi sırtında, odadan evin kapısından çıktı. Daha geceydi. Bekçilerle polisler sabah uykusuna dalmışlardı. Tenha sokaklardan geçti. Sırtındaki kişiciğin tirtir titrediğini duyuyordu. Aksaray'dan, Altımermer'den dolaştı. Külhanbeyi artık korkusundan titremiyor, imdat için haykıracak bir ses çıkaramıyordu. Biliyordu ki, karısıyla yattığı bu herif onu kesmeye götürüyor... Acaba ensesinden mi kesecekti? Yoksa boğazından mı? Şehadet getiriyor, tekbir çekiyordu.

Artık horozların öttüğü işitiliyordu.

Fecir, Samatya'nın üstünü mavi ile karışık pembe bir aydınlıkla parlatıyordu.

Kale kapısından dışarı çıktılar. Külhanbeyi "Acaba kesmezden evvel iki rekat namaza müsaade eder mi?" diye düşünüyordu. Hasan Ağa, elindeki kunduraları yere attı. Sırtını sarsarak: — İn ülen! Diye haykırdı. Külhanbeyinin korkusundan mecali kalmamıştı. Artık elleri, ayakları tutmuyordu. Yere düştü: — Aman ağam, merhamet. İmanıma acı! İki rekat... Aman ağam! İmansız gitmeyeyim... Korkunun şiddetinden zavallı külhanbeyi namaz kılmak için abdest almak, abdest almak için de bir gusül abdesti almak icap ettiğini unutuyordu. Hasan Ağa, yine bir ilkbahar göğü gibi gürledi: — Ülen kerata! Ne söyleyip patırtı ediyon? Sakın bir daha bizim eve gelme. İşte bu sefer seni ceza olmak üzere, Yedikule'ye kadar götürdüm. Bir daha evimde yakalarsam, vallahi billahi ta Çekmece'ye kadar götürür bırakırım... Anladun mu? Dedi. Cevap beklemeden kuşağının arasından çıkardığı kırmızı mendille yüzünün, ensesinin terlerini silerek uzaklaştı.

Külhanbeyi bir şey anlayamamıştı.

Fazla yorgun bir ateşle hızlı hızlı evine dönen Hasan Ağa içeri girerken "Boh!" diye karısını korkutmayı düşündü. Fakat yapılan tek bir kabahat için ayrı ayrı iki kişiyi cezalandırmak muvafık mıydı? Eve gelinceye kadar hiç öfkesi kalmadı. Hatta bir eliyle kapısının tokmağını çalarken sebebini bilmediği bir neşeyle sırıtıyor, öteki eliyle sanki çözülmüş gibi kuşağını düzeltiyordu.

# Kurbağa Duası

Reşat Nuri'ye

Taşra âlemi... Yani İstanbul'un dışında geçen hayat, ne hoştur! Bunu ancak yaşayan bilir. Bir taraftan eşraf, ulemâ filan! Öbür taraftan memurlar, zâbitler, muallimler... Sonra kasabanın çift, çubuk sahibi yerli ahalisi... Her sınıfın, her zümrenin ayrı kahvesi, ayrı eğlencesi, ayrı zevki vardır. "Beynessınıf" denilebilecek yegâne adam kazanın belediye doktorudur. O daima herkesle konuşur, düşer, kalkar. Muallimlerin, memurların, zâbitlerin oturdukları kahvelere girer. Eczane ise eşrafın kulübüdür. Büyük rütbeli memurlar da oraya uğrarlar. Avukat yazıhaneleri de bir dereceye kadar eczaneye benzer.

Hâsılı taşra, başlı başına gayet hoş bir âlemdir. Yedi, sekiz, belki dokuz sene oluyor, ben de İstanbul'a pek uzak olmayan bir kasabada idâdi muallimi idim. Başlı başına bir âlem olan taşrada, mektep de, başka bir âlemdir. Âdeta âlem içinde bir âlemdir! Programları, gayeleri birbirine zıt; dört, beş mektebin yetiştirdiği yaşlı, genç, zeki, budala, zevzek, sükutî yirmi muhtelif adam: Müdür, muavin, muallimler, muînler... İdare memurları... Evvel zamandan kalma, hani o bir tarafından güneş batarken öbür tarafından doğan eski kocaman imparatorluğumuzun en uzak köşelerinden gelme leylî talebe.. Her ırktan, her cinsten –lisanlarından başka hiçbir şeyleri Türkleşmemiş– bir sürü çocuk... Fakat, bu kadar bariz tezatlar arasında o ne samimi ahenktir! Mutaassıplar, mürtecîler, liberaller, sonra hiçbir muayyen mesleği, meşrebi olmayanlar birbirleriyle kardeş gibi geçinirlerdi. Bir riyâziye muallimi vardı ki, aşırı derecede açık fikirliydi. Tabiat muallimi hepimize kara cahil nazarıyla bakıp için için acıyan ciddi bir gençti. Ben edebiyat muallimi idim. Fransızca muallimi bir Yahudi idi. Nöbetçi olduğu vakitler, gece müzakeresinde, çocukların kendisine sorduğu lügatları latin harfleriyle cep defterciğine yazar, ertesi günü mânâlarını benden anlardı. Bir kere "cezbe-i Rahman" ın ne demek olduğunu zavallıya sormuşlar. İyi anlamamış, defterine "cezve-i Rahman" yazmış. Muallimlerin odasında beni tuttu: — Cezve-i Rahman ne demek? Dedi. — Öyle şey olmaz! Diye güldüm, ısrar etti. Kendisine soran talebeyi buldurdu. Kitabı açtık. Yanlış anladığı meydana çıkınca, bu aramızda bir alay mevzuu oldu. Biçarenin adı "Cezve-i rahman" kaldı, gitti.

Hele Müdür... Ben dünyada bu kadar intizamperver, kanunperver, usulperver bir adam görmedim. Bir kere maiyetinin hiçbirisiyle hususî münasebette bulunmaz; mektep heyetinin haricinde, tıpkı bir esatir mâbudu gibi ayrı yaşardı. Aramızda lakabı "zımnında" idi. Son derece ehemmiyet verdiği meclis günleri, odasında toplandığımız vakit, hiçbirimize laf söyletmez, hepimize "zımnında, zımnında, zımnında" diye ayrı tahrîratlar yazdırır, herhangi mesele olsa, aynı kelimelerle, aynı cümlelerin nihayetine mâhut "zımnında"yı takarak bir şey kaleme aldırınca hallettim sanırdı.

Arkadaşlarımın içinde en sevdiğim ulûm-ı diniye hocası Bâhir Efendi idi. Medreseden sonra darülfünunu da tamamlamıştı. Yaşı elliye yaklaşıyordu. Fikrinde musır, cerbezeli, açıkgöz, tuhaf, şen bir adamdı. Benimle dostluğuna sebep, terbiye hakkındaki fikirlerimizin bir olmasıydı. Çünkü ben her ne kadar milliyetperver bir liberal isem de, "terbiye"nin daima "muhafazakârâne" olması lazım geldiğine mûtekidim. İçtimâi inkılabın yeri mektep değil, hayattır. Muallimlerin vazifesi çocuklara, eski hayatın terbiyesini ibrâm etmektir. O da işte benim gibi düşündüğü için, meclislerde ikimiz taraftarlarımızla bir kuvvet teşkil eder, liberallere, yeni asrî terbiye taraftarlarına ağız açtırmazdık. Bâhir Hoca'nın en meftun olduğum şeyleri canlılığı ile "mebnî-aleyh, mebnî-bih, mebnî-leh" gibi tâbirleri idi. Kavga eder gibi konuşur, kelimelerine sanki yumruk şeklinde vücutlar vermek istiyormuş gibi sağ kolunu –bir Karagöz çevikliğiyle– sallardı. Kusuru yalnız nargilesiydi. Buna o kadar müptela idi ki, kahvede, mektepte, günde on tane içmeden yapamazdı. Nargile bu... Cigara filan gibi bir şey değil. Havaleli... Müdürden, müfettişlerden gizlemek lazım... Bir gün kahvemizde oturmuş, portatif bir nargile şekli düşünüyorduk. Mesela içildikten sonra üzeri çıkarıldı mı, sürahiye benzesin, lüle cebe girebilsin... Bâhir Hoca:  
— Ya marpuç?  
Diyordu.  
— Cübbenin altına, beline sararsın.  
— Kırılır.  
— Fesinin içine çörekle...  
— Sığmaz...  
. . . . . . . . . .

Böyle konuşurken içeri, belediye doktorunun girdiğini gördük. Bizim yanımıza geldi, selamlaştık. Oturdu. Cuma günü Bektaşî Tekkesi'ne gideceklermiş. Kuzu, saz, biraz da mey varmış. Bizi de davet etti.

Ben:  
— Gidemeyiz!...  
Dedim. Biz muallimdik. Öyle sazlı, sözlü, içkili meclislere giremezdik. Doktor ısrar etti: "Siz içmezsiniz. Kulaklarınızı tıkarsınız. Gözlerinizi bağlarsınız." diyordu. Zaten arkadaşlardan birkaçı razı olmuş... Bâhir Hoca:  
— Nargilemi götürürseniz gelirim.  
Dedi. Doktor:  
— Götürürüz. Hem vallahi ben götürürüm, hocam!  
Diye yemini bastı.

Ne şen, ne babayânî bir delikanlıydı. Adeta kasabanın canlı bir neşesiydi. Hastalar ilacından ziyade onun sözlerinden şifa bulurlardı.

Cuma günü cümbür cemaat Bektaşî Tekkesi'ne gittik. Burası eski mesut zamanlarda taptaze kalmış bir cennetin hayaline benziyordu. Sanki tarih denen fırtınanın rüzgarları bu asırlık çınar ağaçlarının arasından, beyaz münzevî binanın sakin çatısı üstünden hiç geçmemişti. Etrafta setleri olmasa tabii bir göl sanılacak derecede büyük havuz zümrüt gölgeler içinde, nilüfer rüyalar açmış, uyuyordu. Dervişlerin yaydığı hasırlara yan geldik. Telgrafçı udunu, tapu memuru kanununu aldı. Kemancı Aleko da gelmişti. Saz başladı. Doktor: "Sâki benim!" diye herkese sunuyor, Bâhir Hoca'nın önünde dikilip kalıyordu:  
— İşte benim nargilem var?  
— Bir yudum?  
— Ömrümde bir katre ağzıma almamışım.  
— Bir yudum al, gargara et, sonra tükür.  
— Ne faide?  
— Vallahi muzâdd-ı taaffündür.  
. . . . . . . . . . . . . . . .  .

Bâhir Hoca, bu gibi meclislerde kara mutaassıp görünmek istemezdi. Ağzına bir kadeh rakı aldı. Fakat doktor hocayı gıdıkladı. Birkaç damla yutturdu. Yuttuğunu inkar etmekle beraber, bu birkaç damla ona birkaç küp neşesi verdi. Gülüyorduk. Eğleniyorduk. Lâkin kafamız kazan gibiydi! Bu yeşil cennette ardı arası kesilmez bir cehennem gürültüsü vadı: Kocaman havuzun içinde belki bir milyon kurbağa... Avazları çıktığı kadar haykırıyorlardı. O kadar ki, âdeta birbirimizin söylediğini işitemiyorduk.

Doktor:  
— Vay anasını!...dedi, bunları nasıl susturmalı? Kulaklarmız patlayacak.  
Dervişler:  
— Ne yapsanız susturamazsınız.  
Diyorlardı. Bâhir Hoca'dan başka hepimiz kalktık. Çünkü dayanılacak gürültü değildi. Taş, toprak, elimize ne geçtiyse havuza atmaya başladık. Kurbağalar bu tecavüzümüzden hiddetlenmiş gibi daha beter bağrışmaya koyuldular. Doktor, gazeteler tutuşturdu. Korkup kaçsınlar diye üzerlerine attı. Hayır, hayır... Ne yapsak susmuyorlar daha ziyade azıtıyorlardı. Sazı duymak mümkün değildi. İçimizden birisi:  
— Buradan kaçmaktan başka çare yok!  
Dedi.  
— Nereye gidelim?  
— Havuzun uzağında bir yere...  
Biz böyle hicret müzakeresi ederken nargilesinin başında unuttuğumuz Bâhir Hoca'nın:  
— İstersem, ben onları bir anda sustururum.  
Dediğini işittik.  
— Nasıl?  
— Bir nefes ederim.  
— Ey?..  
— Hemen susarlar.  
Gürültüden neşemiz kaçmışken, hepimiz yine güldük. Doktor: "Bu kurbağalar yarım başağrısı değil ki, bir nefeste dursunlar; bunlar baş belası!" diyordu. Fakat Bâhir Hoca, yine hiddetlenmiş bir Karagöz tehâlükü ile yumruğunu sallıyor, hepimizin itikatsızlığına sövüp sayıyordu. Onun bağırtısı bir taraftan, bir milyon kurbağanın kopardığı kıyamet bir taraftan... Hâsılı bir curcunadır gidiyordu. Meclisin neşesi kalmamıştı. Bâhir Hoca:  
— Herkes yerine otursun, dedi, ben havuzun kenarına gideyim, nefes edeyim. Susmazlarsa yüzüme tükürün...  
— Haydi, haydi öyleyse Hoca...  
— ......  
İnanmıyorduk, lâkin "bir alay çıkar" ümidiyle yerlerimize oturduk. Hoca kalktı. Nargilesini eline aldı. Havuzun kenarına gitti. Arkasını bizden tarafa çevirmişti. Sulara doğru üfürdüğünü gördük. Bir dakika geçmedi. Kurbağalar birdenbire susmuşlardı. Koca havuzdan bir çıt bile çıkmıyordu. Şaşırmıştık. O, yumruğunu sıkarak muzafferane döndü, geldi.  
— Ne yaptın Allah aşkına!  
Diyenlere:  
— Görmediniz mi? Gözlerinize de mi itimadınız yok, nefes ettim.  
Cevabını verdi.

Yarım saat geçince kurbağalar yine ötmeye başladılar. Artık korkmuyorduk. Bâhir Hoca kalkıp havuzun kenarına gidiyor, bir nefeste yine hepsini susturuyordu. Giderken sevgili nargilesini "sarhoşsunuz, kırarsınız" diye bizim yanımızda bırakmıyordu. Akşam kadar eğlendik. Bâhir Hoca'nın nefesine Kemancı Aleko bile inandı. Doktor inanamıyor, fakat gözüyle gördüğü neticeyi de inkar etmek cesaretini gösteremiyordu. Yerli memurlar hayretten rakıya bile devam edememişlerdi. Bektaşi dervişleri dalgın dalgın, nefes sahibine bakıyorlar, kimbilir akıllarından neler geçiriyorlardı.

Ertesi akşam, kahvede Bâhir Hoca ile yan yana oturmuş İstanbul gazetelerini okuyorduk. Ben okuduğumu anlamıyor, onun Bektaşi Tekkesi'nde kumanda verir gibi kurbağaları nasıl susturduğunu düşünüyordum. Doğrudan doğruya kendisine sorsam, eminim ki, yine "Gözlerine de mi itimadın yok! Nefes ettim, kör müydün?" diyecek, beni de kurbağalar gibi susturacaktı. Fakat ben enayi değildim. Ona zihnen, ilmî bir pusu kurdum. Evvela gazeteleri bıraktırdım. Gayet tatlı bir ruhiyat bahsi açtım. Böyle şeylere çok meraklıydı. Hayvanlarda ruh olmadığını, mahlukatın maneviyat haricinde tıpkı nebatat gibi yaşadıklarını anlatıyordum.  
— Ben de bu fikirdeyim.  
Dedi.  
— Hayır, yalan söylüyorsun.  
Dedim.  
— Vallahi...  
— Hayır, yalan...  
— Ne biliyorsun?  
— Çünkü sen kurbağalara nefes ettin. Demek ki hayvanların maneviyat haricinde yaşadıklarını bilmiyorsun.  
Kollarını masanın üzerinden çekti. Arkasına dayandı, durdu. Gözlerime dik dik baktı. Aşağı tükürse sakalı, yukarı tükürse bıyığı idi. Öyle bir vaziyete sokmuştum ki... Kalın kaşlarını çattı:  
— Ben kurbağalara nefes etmedim!  
Dedi.  
— Ya nasıl susturdun onları?  
— ....  
Ağzını açamıyordu. Fena sıkışmıştı. Aklı sıra, ya cahilliği kabul edecek, ya hakikati söyleyecekti.  
— Söyle öyleyse, ne yaptın da, kurbağalar sustular?  
— Şey, canım... Budala mısın? Nefes filan olur mu?.. Şey ettim...  
— Ne ettin?  
— Nargilenin marpucunu sarkıttım...  
— Ey?..  
— Kurbağalar onu yılan sandılar. Hemen dibe kaçtılar.  
. . . . . . . . . . . . . .

...Fakat taşra hayatının bir vasfı da sır saklamaktır.

Bâhir Hoca: "Saf adamların itikatlarını bozmamalı. Onlara ilmî hakikatlerin lüzumu yok. Sakın marpucu kurbağalara gösterdiğimi kimseye söyleme! Varsın, nefes ettim diye bilsinler" dedi.

Ben, bu sırrı ağzımdan hiç kaçırmadım. Bütün kasaba halkı hocanın nefes kerâmetini işitti. Hatta Bektaşiler de buna şahitti. Doktorun bile şüpheleri yavaş yavaş gevşedi, eridi. Bâhir Hoca'nın bir üfürüşte kurbağaları susturduğundan bahsolunduğu vakit, zavallı boynunu büküp: — Dünyada ne kadar meçhul var. İlmimiz bu meçhulün yüz milyonda biri bile değil!.. Der, o her vakitki şuh kahkahasını atamazdı...

# Kurumuş Ağaçlar

Deli Murat, memleketin en azılı bir derebeyi idi! Fakat yaşlandıkça aklı başına geldi. İyinin, kötünün farkına varmaya başladı. Artık en küçük bir fenalık bile onun vicdanında sönmez bir azap cehennemi tutuşturuyordu. Elli yaşına girmişti. Hacca gitmek niyetindeydi. Lâkin hangi yüzle?.. Uzun kış geceleri, vahşî bir saraya benzeyen kulesinin tenha odasında, ocağın alevlerine dalarak yaptıklarını düşünürdü. Tam otuz sene... Etmediği kalmamıştı. Soyduğu kervanları, kaldırdığı kızları, vurduğu postaları, yaktığı köyleri, yıktığı hanları, bastığı şehirleri hep birden hatırladı. Hele öldürdüğü insanlar... Bunları unutabilmek imkanı yoktu. Vâkıa çoğunu kendi nefsini kurtarmak için öldürmüştü. Fakat ne olursa olsun, yine kandı! Evet, kırk kan!...

Bir gece sabaha kadar uyuyamadı. Daha şafak sökmeden atlarını hazırlattı. Kasabaya doludizgin koştu. Sabah namazını henüz bitiren Karababa'yı seccadesinde buldu. Bu Şeyh, devrinin en büyük erenlerindendi. Tekkesi ümitsizlerin mâbediydi. Deli Murat'ı görünce gülümsedi:  
— Hoş geldin. Seni bekliyordum, dedi.  
— Beni mi?  
— Evet.  
— Niçin?  
— Hacca gitmek istiyorsun, değil mi?  
— ....  
Deli Murat, bu her şeyi bilen, her şeyi gören, gaipten haberdar, mübarek ihtiyarın eline sarıldı. Öptü:  
— Fakat yüzüm yok, babacığım, dedi.  
— Allah her şeyi affeder.  
— Benim kabahatim çok. Günahlarım çok büyük...  
— ......  
Seccadenin kenarına diz çöktü. Ağlaya ağlaya mazisini anlattı. Bunlar hatırında durdukça, peygamberin mezarına yüz sürmeye cesaret edemeyecekti.  
Karababa:  
— Senin kırk kanın var! Dedi.  
— Evet.  
— Allah bunları bile affeder.  
— Nasıl?  
— Ya ölüme lâyık bir adamı vurursun...  
Deli Murat:  
— Aman aman, diye haykırdı, ben artık adam öldüremem!  
Karababa:  
— Yahut da, büyük bir menzil açar, geleni geçeni fakir, zengin ayırt etmeden doyurursun. Hepsinin gönlünü hoş edersin! Dedi.  
Deli Murat, bu ikinci kefareti muvafık buldu. Parasının sayısını bilmezdi. Bir menzil değil, on menzil açabilirdi.  
— Pekala babacığım, dedi, yarından sonra menzil açıktır. Fakat kanlarımın affolunup olunmadığını nereden bileyim?  
— Bilip de ne yapacaksın?  
— Hacca gideceğim.  
Karababa bir an düşündü:  
— Menzilin iç bahçesine kurumuş ağaçlar dik... Dedi.  
— Kurumuş ağaçlar mı?  
— Evet, bunlar yeşerip çiçek açınca, kanların affedilmiş, kefaretin kabul olunmuştur.  
— Hiç kurumuş ağaç yeşerir, çiçer açar mı?  
— Açar.  
— !...

Deli Murat'ın vahşî bir saraya benzeyen kulesi geniş ovaya inen yolun üstünde idi. Yedi ülke yolcuları önünden geçmeye mecburdu. Burasını hemen menzil haline koydu. Her odaya bir sofra kurdu. Günde yirmi kazan kaynıyordu. Ekmeğinden, etinden, pilavından yedirmeden kimseyi geçirtmezdi. İç bahçeye de Karababa'nın dediği gibi kurumuş ağaçlar diktirdi. Her gün bunları yokluyordu. Aradan bir sene, iki sene, üç sene geçti. Kurumuş ağaçlar yeşermek şöyle dursun, hatta çürümeye, kurtlanmaya yüz tutmuştu. Her gün yine kazanlar kaynıyor, yaz, kış hayrat devam ediyordu. Deli Murat'ın içine şüphe girdi: "Budala mıyım? Hiç kurumuş tahtalar çiçek açar mı? Karababa beni daima hayrat yapayım diye böyle aldatmış olmalı!" Diyordu. Gündüzleri menzilin önündeki çardağa oturur, uşakların, yolcuları nasıl ağırladıklarına nezaret ederdi. Karnı tok olanlara bile mutlaka aşından bir yudum tattırırdı. Bir gün bu çardakta kefaretinin kabul olunup hacca gidebileceğini düşünürken daldı. Tatlı bir rüya görmeye başladı. Bir devenin üstünde, tek başına, çöl ortasında gidiyordu. Deve birdenbire durdu. Deli Murat uğraşıyor, bir türlü yürütemiyordu. Nihayet deve silkindi. Murat kumlara yuvarlandı. Gözlerini açıp, "Hayırdır inşallah!" derken, uşaklarının yol üstünde bir atlı ile uğraştıklarını gördü. Dikkat etti. Bu adam atından inmiyor: — Bırakın beni! Acele işim var. Duramam! Bırakın... İnmem... Diyordu. Uşaklar zorluyorlar, "İn, bir yudum çorba iç. Sonra git, seni bırakırsak, ağa bize darılır." diye yalvarıyorlardı.

Deli Murat doğruldu. Kendisi de inmesi için atlıya ricaya gidecekti. Kalktı. Tam yola doğru yürürken yolcu atını şaha kaldırmış, uşakların elinden kurtulmuştu. Deli Murat'ın inat damarı tuttu. İçinden, "Ulan, ben sana mutlaka aşımdan tattıracağım!" dedi. Belinden tabancasını çıkardı. Havada uçan serçe kuşlarını nişan almadan vurabilirdi. Yolcunun hızla uzaklaşan atına güzel bir nişan aldı. "Hayvan ölünce gidemez. Çorbayı içer. Ben ona en iyi atlarımdan birini hediye ederim, memnun olur..." diyordu. Tetiği çekti. Fakat at durmadı. Bilakis dörtnala kalktı. Üzerindeki adam yere düşmüştü. Uşaklarıyla beraber bu yolcunun imdadına koştu. Bir de ne görsün? Meğerse ata attığı kurşun, zavallı sahibinin ensesinden girip alnından çıkmamış mı? Yüzünden taze kanlar sızıyordu. Az buçuk daha kendini kaybedecekti. İşte kırk kanını Allah'a affettirmeye çalışırken kazara, elinden yeni bir kan daha çıkmıştı. Ağlamaya başladı. Teessürü o kadar müthişti ki... Uşakları ürktü. "Bırakın, kendimi öldüreceğim. Artık dünya bana haram olsun!" diye haykırıyordu. Elinden tabancasını zorla kaptılar. Teskin etmek için menzildeki odasına götürüyorlardı. İç bahçeye girince birdenbire: — Ah!... diye haykırdı, Bakınız bakınız!... — .... Kurumuş ağaçların hepsi aniden ilkbahar bademleri gibi çiçek açmıştı. Bu mucize herkesi şaşırttı. Deli Murat, sevincinden bu bir anda yeşermiş ağaçların diplerini öpüyor, gözlerinden saadet yaşları akıyordu. İşte artık günahları, kırk kanın günahı affedilmişti. Demek kaza ile vurduğu adam ölüme lâyık bir günahkârdı! Bunun kim olduğunu tahkik etti. Menzilde hazır bulunan yolcuların hepsi tanıyorlar: — Dünyada bunun kadar iyi adam yoktu. Allah rahmet eylesin... Diye acıyorlardı. Fakat Deli Murat: — Hayır, hayır, dedi, bu adam ölüme lâyık bir günahkârmış!... Tanıyanlar tekrar reddettiler: — Hayır, mübarek bir adamdı! Hemşerilerinden kimseye fenalık etmedi. Beş vakit namaz kıldı. Üç ay oruç tuttu. Fakire, fukaraya baktı. Öksüzler büyüttü... — Hayır, hayır, dedi, bu adam ölüme lâyık bir günahkârmış!... Ama cesedin başında herkes iyiliğine dair şehâdette ısrar ediyordu. Nihayet Deli Murat: — O halde, bu adam şimdi gayet büyük bir günah işlemeye gidiyormuş! Dedi. Uşaklarına ölünün üzerini aramalarını emretti. Küçük bir mektuptan başka bir şey bulamadılar. Bu mektup, genç ve namuslu bir kadının aleyhinde yazılmış, kocasına gönderiliyordu.

# Külah

Mıstık, katmerli bir muhacirdi. Bulgaristan'da doğmuş, büyüyüp biraz aklı başına gelince hemen sınırın on dakika ötesine kapağı atmıştı. "Türkiye değil mi? Sınırı geçer geçmez Bağdat'a kadar hepsi eşit!" diyordu. Az zamanda Babyak'taki Türkçe bilmez Pomakların akıl hocası oldu. Bulgaristan'da kalan akrabalarıyla mektuplaşmaya gerek yoktu. Onlarla, Bulgar sınır karakolundaki nöbetçinin süngüsü altında, küçük bir hediye karşılığında, saatlerce oturup konuşabilirdi. Kurnazlığı sayesinde memleketinden çıkmadan muhacir olmuştu. Hatta içtiği "Karasu" bile doğduğu kasabadan geçiyordu. Fakat bir gün Babyak mıntıkasında "sınır düzenlemesi" yapıldı. Yerleştiği köy yine Bulgarlara kalınca, yuvasını bozmaya mecbur oldu. Bu sefer hudut kenarının içerilere eşit olmadığını anladı. Ta Nevrekop'a kadar indi. Dört beş sene geçmeden Balkan Harbi patladı. Hemen annesiyle İstanbul'a kaçtı. Dimetoka'nın methiyle kulakları dolmuştu. Kalktı, oraya gitti. Bir köye yerleşti.

İçinden "Artık biz ölünceye kadar savaş olmaz!" diyordu. Köyünün kahvesinde Birinci Cihan Harbi'nin havadislerine inanamadı. Fakat...

— Vay anasını! Yalan be! diye haykırdı. "Sınır düzeltilecek!" deniyordu. Hakikaten bu sınır düzeltildi. Mıstık'ın muhacir gibi yerleştiği köy yine Bulgarlara geçti. Bereket versin ihtiyar annesi ölmüştü. Gamsız bir serseri teslimiyeti ile, tek başına Ergene Köprüsü'nü aşarken "Evveli Şam, sonrası Şam!" dedi. Bu kadar kısa bir zaman içinde, "birbiri üstüne dört defa muhacir olmak" onun yerleşme heveslerini söndürmüştü. Gözünü yumdu. Anadolu'ya atıldı. Aldatılabilecek milyonlarca saf adamlar arasında kalınca, Şam'ı falan unuttu. Şehir şehir, kasaba kasaba dolaşmaya, ticaret yapmaya başladı. Önüne gelene külah giydiriyordu. En kârlı bulduğu ticaret, hayvan alım satımı idi. Bir kasabadan alınan atın, yahut eşeğin pahası, en yakın kasabaya götürülünce değişiveriyordu. Bu pahayı, Mıstık, kurnazlığı sayesinde değiştiriyordu. Kırmızı kuşağında, Rumeli'deki tabancasının yerine sokulu, kara kılıflı makas, her hayvanın değerine yüzde altmış ilave ederdi. En miskin bir beygiri alınca tırnaklarını temizler, yağlar; yelesini, kuyruğunu frenkvâri keser, düzeltirdi. Sonra, torbasındaki o kimseye göstermediği, kimseye ismini söylemediği siyah ottan bir tutam yedirince, zavallı hayvanı yirmi dört saat şaha kaldırır, gözlerini parlatır, azgın bir ejderha haline sokardı. Lakin at pazarlarında daima karşısına çıkan bir rakibi vardı. Onun alacağı hayvanı artırır, en kâr bırakacak fırsatları elinden kapardı. Herkesin "Molla" diye çağırdığı bu herifin ismini bilmiyordu. Yerden yapılı, çember sakallı, kalın çatık kaşlı, kırk beşlik bir softaydı. Küçük siyah gözleri hep önüne bakar, ince beyaz sarıklı kalıpsız fesinin altında tıraşlı kafası, geniş ensesi terden pırıl pırıl parlardı. Mıstık'ın beğenmeyip bıraktığı en miskin, en hasta, en ihtiyar hayvanları bile alıyor, bir gün içinde gençleştiriyor, kuyruğunu, yelesini kesmeden, şeklini değiştiriyor, gözlerini parlatıyor, şahlandırıyordu.

Mıstık, henüz geldiği kasabanın hanından girerken yine bu herifi gördü. Yeni bir zarara uğramış gibi birdenbire canı sıkıldı. Ama bozuntuya vermedi:  
— Merhaba Molla! dedi.  
— Merhaba?..  
Şimdiye kadar hiç konuşmamışlardı.  
— Hayvan almaya mı geldin?  
— Sana ne?  
. . . . . . .  
— Neye geldimse geldim.  
Mıstık, kirli zayıf elini seyrek sarı bıyıklarına kaldırdı. Çakır gözleri bakacak yer bulamadı. Renksiz dudaklarını kısarak gülümsedi:  
— Ortak olalım be, dedi.  
— Olalım...  
Molla da gülümsedi. Döndüler. Hanın avlusuna doğru yan yana yürüdüler. Kahvenin önündeki eski peykeye oturdular. Ayaklarının dibinde iri, alacalı bir tavuk "gut, gut, gut" diye civcivlerini gezdiriyordu. Pazar yarındı.

Mıstık koynundan tütün kesesini çıkardı. Molla'ya uzatırken, peykenin yanındaki pencereden içeriye bağırdı:  
— Bize iki kahve getir.  
Molla:  
— Ben oruçluyum! dedi.  
Mıstık anlamadı:  
— Ramazanda mıyız yahu?  
— Hayır.  
— Üç aylarda mıyız?  
— Hayır.  
— Ey, bu ne orucu?  
— Ben bütün yıl bir gün yer, bir gün tutarım!  
— Sahi mi?  
— Vallahi...  
Mıstık tütün kesesini tekrar koynuna soktu. Eğildi, camsız pencereden kahveciye:  
— İstemez, kahveleri yapma, diye seslendi.  
İçinden, "Bu gebeşin kafasına ben bir külah geçiririm!" dedi.

Kendisinin sofuluğundan, küçükken hafızlığa çalıştığından, ama hastalandığı için vazgeçtiğinden, babasının yirmi yedi defa hacca gittiğinden bahsetti. Molla yere bakarak dinliyor, başını sallıyor, inanıyor, Rumelililerin sağlam Müslüman olduklarını söylüyordu.  
Mıstık sordu:  
— Sen nerelisin?  
— Kayserili.  
— Kayseri nerede?  
— Bu tarafta...  
Molla, kısa parmaklı tombul eliyle hanın kapısını gösteriyordu. Mıstık, geldiği ciheti hatırlayarak:  
— Konya tarafında mı? diye sordu.  
— Hayır canım, daha yukarılarda...  
Mıstık, Kayseri'nin nerede, hem de ne olduğunu pek iyi biliyordu. Rumeli'de bıraktığı çiftlikleri de anlattıktan sonra yaptığı kapıyı kâfi gördü. İşlere geçti. Konuştular, anlaştılar. O günden sonra ortaklığa karar verdiler. Kâra, zarara, sermayeye ortak oluyorlardı. Mıstık yine içinden, "Ben sana bir külah giydireyim de, gör!" dedi.

Ertesi gün pazarda hayvanları beraber sattılar. Molla'nınkiler daha genç, daha dinç duruyordu. Birkaç gün daha burada kalıp çürük hayvanları toplamayı sözleştiler.

İkisi de bir handa, karşılıklı birer küçük odada yatıyorlardı.

Bir gece Mıstık'ın oda kapısı vuruldu. Kalktı, sürmeyi çekti, açtı. Baktı ki ortağı...  
— Hayırdır inşallah, Molla?..  
— Sabahleyin ben bir köye kadar gideceğim. Sana şimdiden unutmadan söyleyeyim. İyi bir iş var.  
Mıstık gözlerini daha ziyade açtı:  
— Ne?  
— Valinin çocuğu için benden bir beyaz eşek istemişlerdi. Seksen liraya kadar satabileceğiz.  
— Ey?  
— Ben yarın burada yokum. Sen ara, bulursan otuz, kırk, hatta elli lira bile ver. Mutlaka al.  
— Beyaz eşek olur mu?  
— Olur ya...  
Mıstık şaşaladı. "Şaka mı ediyor?" diye sofu ortağının yüzüne dikkatle baktı. Hayır, ciddi idi. Sordu:  
— Ey, burada bulunur mu?  
— Ne bilirsin, belki bulunur.  
— Pekala, yarın ararım.  
Molla, saf bir ortak samimiyetiyle ona akıl öğretti:  
— Buranın en birinci cambazı Hacı Hüseyin'dir. Sen tanımazsın. Şimdi çok ihtiyar olduğu için evinden çıkmaz. Şadırvanın karşısına gelen sokaktan git, git, git. Orada birine sor, gösterirler. Çiftlik gibi bir ev... Pazara gelmez... Oturduğu yerde cambazlık eder. Ondan iste. De ki: "Akşama kadar bana mutlaka bir beyaz eşek bul." Elli liraya kadar vaat et.  
— Pekala!  
Mollanın ağzından sert bir rakı kokusu çıkıyordu. Küçük lambanın hafif aydınlığı ile gölgelenen yüzünde yorgun bir neşe vardı. Gözleri dumanlıydı. Mıstık, ortağının gündüz oruçlu olduğunu hatırladı. Bir şaka etmek istedi:  
— Keşke beni de iftara davet edeydin! Beraber içerdik...  
Molla reddetti:  
— Haşa!.. Ben ömrümde bir damla ağzıma koymamışım, elhamdülillah...  
— Ey, bu koku ne be?  
— Dişim ağrıyor, rakı ile ağzımı çalkaladım.  
— Ya!  
— Evet.  
— Öyleyse Allah rahatlık versin!  
— Sana da...  
Mıstık, odasının kapısını kapayınca yine "Gidi gebeş seni!.. Ben sana bir külah giydireyim de, gör!" dedi. Ayakta duramayacak kadar sarhoş olduğu halde, yine sofuluk taslayıp ömründe ağzına bir katre koymadığını söylemesi, Mıstık'ın sanki gururuna dokunmuştu. "Beni aptal yerine koyuyor ha!" diye ellerini kalçalarına dayadı, durdu. Gözlerini küçülterek yere baktı: "Şuna bir külah... İlk fırsatta bir külah..."

Döndü. Kapıyı sürmeledi. Soyunmaya başladı. Kendisi de "sıtma tutmasın" diye torbasında daima birkaç şişe konyak gezdirirdi. Onun için kafası gündüzden tutkundu. Hemen uyuyuverdi.

Sabah olunca kahvesini içmeden dışarı atıldı. Sokakların inek, öküz, kaz, koyun kalabalığı içinde yürüdü. İhtiyar cambaz Hüseyin'in evini buldu. Bu, ak sakallı, kısacık boylu, şeytana benzer bir adamdı. On altı yaşında bir çocuk kadar çevikti. Yürürken zıp zıp sıçrıyordu.

Mıstık selamdan sabahtan sonra beyaz bir eşek istediğini söyledi. İhtiyar, böyle bir hayvanın bulunacağını ümit etmiyordu. Elli senedir cambazlık ettiği halde, ancak ömründe bir defa beyaz eşek görmüştü.  
— Ama, ara sıra bir uğra, dedi, kısmetin varsa bulunur.  
— Akşamları uğrarım.  
— Ne vakit istersen...  
Mıstık o gününü akşama kadar hayvan aramakla geçirdi. Kelepire benzer bir şey bulamadı. Ortağı Molla, gittiği yerden gelmemişti. Akşama yakın canı sıkılmaya başladı. Beyaz eşeği bulup bulmadığını anlamak için değil, sırf kendisiyle konuşup bilgi kapmak için ihtiyar cambazın evine gitti. Kapıyı vurdu, karşısına çıkan Hacı Hüseyin:  
— Oğul, senin talihin varmış! diye bağırdı. Bir beyaz eşek buldum.  
— Ne çabuk?  
— Sen gider gitmez, şişmanca, simsiyah bir Arap geldi. Ama, tuhaf bir Arap. Başında yeşil bir hacı sarığı... Ben Hicaz'da askerlik ettiğim için Arapça bilirim. Arapça konuşmaya kalktım. "Gurbette unuttum" dedi. Allah kimseyi gurbete düşürmesin! İnsan anadilini bile kaybediyormuş! Bu zavallı hacı parasız kalmış. Yedeğindeki süt gibi beyaz eşeği bana sattı. Kırk liraya aldım.  
— Çok be!..  
— Ne yapalım? Sen elliye kadar ver demedin mi?  
— Çok iyi canım! Nerede bakalım, bir görelim.  
— Gel... Ahırda.  
Mıstık, sık adımlarla hızlı hızlı yürüyen ihtiyarın arkasına takıldı. Dış avluyu geçti. Geniş bir ahıra girdi. Köşede hakikaten süt gibi bembeyaz bir eşek duruyordu.  
— Çok güzel, yarın gelir, alırım, dedi.  
— Şimdi neye almıyorsun?  
— Yarın sabah dedim ya... Akşamın hayrı, sabahın şerrinden beterdir.  
— Olur, sabahleyin gel.  
— Güneş doğarken, dedi.  
Çıkarken avlunun çitlerine, kapının kenarlarına, ahırın saçaklarına çaktırmadan dikkatli dikkatli baktı. Gözleri, sokağın karmakarışık izlerinde, hana dönerken: "Bu fırsatı kaçırmamalıyım!" diyordu. İşte beyaz eşek bulunmuştu. Bunu Molla'nın haberi olmadan alıp valiye götürmeli, bütün kârı cebellübe atmalıydı. Ama Molla, eşeğin bulunduğunu haber alırsa, gider, artırır, yine işi bozardı. "Ona duyurmam" dedi. Düşünmeye başladı. Hana gelinceye kadar planını kurmuştu. Odabaşı ile hemen hesabını kesti: "Bu gece ay ışığı var. Ben aşağı köye gidiyorum, iki üç gün gelmeyeceğim" diye heybelerini omuzladı. Gizlice başka bir hana gitti. Sabahı dar etti. Erkenden, ortağına giydireceği külahı düşünerek uyandı. Bir ucunu pencere parmaklığına bağladığı uzun kırmızı kuşağını döne döne sararken, yanında başka birisi varmış gibi kendi kendine konuşmaya başladı:  
— Hacı Hüseyin'e neden kırk lira vereceğim?  
— Ya ne yapmalıyım?  
— Çitler alçak, kapı da harap. Köpek de yok. Gidip gece çalarım.  
— Sonra?  
— Bugün çarşıdan boya alırım. Derenin kenarına götürür, saklarım. Eşeği gece götürür orada boyarım. Sabah karanlığında hanla hesabımı keser, boyalı eşeğe biner, vilayetin yolunu tutarım.  
— Vilayete gidince?..  
— Eşeği sıcak su ile yıkar, valiye satarım.  
— Molla?..  
— Külahı giydiğinin farkında olmaz bile...  
— ...  
Poturunun açık kalmış düğmelerini iliklerken gözünün önüne Molla'yı getiriyor, başındaki beyaz sarığının yerine küçük bir Rumeli külahı geçiriyor, bu külahı hayalinde bir sağa, bir sola, bir arkaya, bir öne eğerek eğleniyordu.

Çarşıdaki dükkanların hepsini dolaştı. Kınadan başka boya bulamadı. İki okka kına aldı. Kasabadan dışarı çıktı. Derenin kenarında kuytu bir yer buldu. Molla'ya rastgelmemek için kasabaya dönmedi. Gece oluncaya kadar orada oturdu. Kesesindeki tütünlerin hepsini içti, bitirdi. Hava bozuktu. Siyah bulutlar bazen ayı örtüyor, her tarafı zaman zaman koyu bir karanlık kaplıyordu. Mıstık, gece yarısından sonra bu karanlığın içinde yürüdü. Düşe kalka Hacı Hüseyin'in evine geldi. Durdu. Dinledi. Ses seda yoktu. Çite tırmandı. Akar gibi avluya indi. Tekrar etrafı dinledi. Bir şey duymadı. Yürüdü. Ahıra doğru gitti. Kapı aralıktı. İtti, içeri girdi. Yine karanlığı dinledi. Cebinden çıkardığı kibriti çaktı. Köşede eşek, tıpkı bir mermer parçası gibi bembeyaz duruyordu. Ayaklarının ucuna basarak yürüdü. Yuların bağı kördüğüm olmuştu. Elleriyle, dişleriyle uğraşarak çözdü. Yavaş yavaş, soğukkanlılıkla kapıdan çıkarken boğazına boğucu bir şey sarıldı. Beyninde bir yaygaradır koptu: — Hırsız var, hırsız var! Koşun çocuklar, hırsız var!.. Mıstık çabaladı, çırpındı, kurtulamadı. Avlunun sağındaki yer odalarından elleri ışıklı kadınlar koşuşuyorlardı. Korkudan patlamış gözleri, boğazına sarılanı tanıdı. Bu, Hacı Hüseyin'di. Dün sabah bir yabancının gelip kendisinden yüksek fiyatla damdan düşer gibi bir beyaz eşek istemesi... Sonra o gider gitmez yine damdan düşer gibi tuhaf kıyafetli, Arapça bilmez bir Arap'ın kendisine bir beyaz eşek getirip satması... Daha sonra, ertesi gün gelip eşeği alacağını söyleyen müşterinin görünmemesi onu şüpheye düşürmüştü. İşte "Bunda bir kurt yeniği var!" diye bu gece uyumamış, kuyu başındaki bostan gölgeliğinde beklemişti. Yakaladığının, gelmeyen müşteri olduğunu görünce öfkesinden deli olacaktı. — İp getirin! diye haykırdı. Çoluk çocuk, damat, gelin, bütün ev halkı uyanmıştı. Kalın iplerle Mıstık'ı sımsıkı bağladılar. Canını çıkarıncaya kadar dövdüler.

Sabahleyin yağmur bardaktan boşanırcasına yağıyordu. Hacı Hüseyin, damatlarıyla, kalın incir ağacından, gece yakaladığı hırsızı çözdü. Ayaklarının bağlarını gevşetti, arkasına kattı. Beyaz eşekle beraber hükümet konağına doğru yürüdü. Ahırdan bembeyaz çıkan eşeğin rengi atıyor, boynunda, sırtında, sağrısında, yol yol siyah çizgiler peyda oluyordu. Eşeğin rengi şakır şakır yağan yağmurla böyle hârelendikçe, Hacı Hüseyin daha beter hiddetleniyor, dönüp Mıstık'ın ensesine tokatları indiriyor: — Gidi sizi dolandırıcılar! İlk önce sen gelirsin, sonra arkadaşın o yalancı Arap!.. Çıkarın altınlarımı!.." diye küfürleri basıyordu. Gören alaya katıldı. Olay hemen duyuldu. Bütün kasaba hükümetin avlusuna toplandı. Bir eşeğe bakıyorlar, bir Mıstık'a... Gülmekten katılıyorlardı. Dün boya aradığı dükkancılar, kına aldığı aktar, hancılar onu tanıdılar. Daha jandarma zabiti gelmemişti. Uzun boylu çavuş, yanındaki neferlerine gülerek emrini verdi: — Tıkın şu uğursuzu bodruma! Yağmur altında eşek gibi onun da rengi değişmesin! Neferler, Mıstık'ı tuttular. Halkın arasından çektiler, kollarının bağlarını çözmeden dar bir kapıdan kapkaranlık bir yere fırlattılar. Mıstık bu karanlıkta yapayalnız kalınca, Molla'nın kendine ettiği oyunu sezer gibi oldu. Gözünün önünde, siyaha boyanmış, çember sakallı bir çehre, kırmızı dilini çıkartarak sırıttı. Bu hayalin tıraşlı başında, giydiremediği külah yerinde yeşil bir hacı sarığı vardı. Şimdi ne yapacaktı? Ne cevap verecekti? Düştüğü bu tuzaktan nasıl kurtulacaktı? Öyle bir tuzak ki... Düşünüyor, düşünüyor, aşık kemiklerine kadar kafasına geçirilmiş üç katlı kurşun bir külahın altında ezilmiş gibi kıvranıyor, karanlıkta ayaklarını yere vurarak, "Tüh bre anasını! Tüh bre anasını!" diye suratını bir sağa, bir sola çeviriyordu.

# Kütük

Alaca karanlık içinde sivri, siyah bir kayanın müphem hayali gibi yükselen Şalgo burcu uyanıktı. Vakit vakit inlettiği trampete, boru seslerini akşamın hafif rüzgarı, derin bir uğultu halinde, her tarafa yayıyor... Kederli bağırışmalarıyla ölümü hatırlatan küfürbaz karga sürüleri, bulutlu havanın donuk hüznünü daha beter artırıyordu. Mor dağlar gittikçe koyulaşıyordu. Yamaçlardaki dağınık gölgeler, kuşsuz ormanlar, hıçkıran dereler, kaçan yollar, ıssız korular, sanki korkunç bir fırtınanın gürlemesini bekliyorlardı.

Burcun tepesinde, beyazlı siyahlı bir bayrak, can çekişen bir kartal ıstırabıyla kıvranıyordu.

İkibin kişilik muhâsara ordusunun çadırları, kaleye giren geniş yolun sağındaki büyük dişbudak ağaçlarının etrafına kurulmuştu. Yerlere kazıklanmış kır atlar, yabancı korkular duyuyorlar gibi, sık sık başlarını kaldırarak kişniyorlar, tırnaklarıyla kazmaya çalıştıkları toprakların nemli çimenlerini otluyorlardı. Dallarda kırmızı çullar, sırmalı eğerler asılı duruyordu. Cemâatle kılınmış akşam namazından dağılan askerler, çadırların arasından gürültü ile geçiyorlardı. Kısa emirler, çağırılan isimler, bir kahkaha, bir söz... Başlayacak sükûnu bozuyor, atların yanında itişen birkaç gencin şen nâraları duyuluyordu. Çifte direkli yeşil çadırın kapısı önüne serilmiş büyük bir kaplan postu üzerinde kehribar çubuğunu fosur fosur çeken koca bıyıklı, iri vücutlu, ateş nazarlı şâir kumandan, gözlerini, alacağı kalenin sallanan bayrağına dikmişti. Karşısında diz çökmüş kethüdâsının anlattıklarını dinliyordu. Ordugâha yarım saat evvel dört nala gelen bu adam, yaşlı, şişman bir askerdi. İşte kaç hafta oluyor, kumandanının "Göndersdref Baronu Erasm Tofl'u beraber vurmak" teklifini hâvî mektubunu, tek başına, Hadım Ali Paşa'ya götürmüştü. Ama, paşa çok meşguldü. Vakit bulup cevap verememişti. Dregley kalesini sarıyordu. Muhâsaranın iptidâsından nihayetine kadar hazır bulunan kethüdâ, şimdi orada gördüklerini söylüyordu; bu kale gayet sarp, gayet dik, bir kayanın zirvesine yapılmıştı. Arslan Bey sordu:  
— Bizim kaleden daha yüksek mi?  
— Daha yüksek beyim.  
Kumandanın ``bizim kale´´ dediği, henüz çırpınan bayrağına hasretle baktığı Şalgo burcu idi. Fakat o, burasını birkaç gün içinde zaptedeceğini iyice biliyordu. Daha birkaç hafta evvel Boze kulesinde hücumlarına karşı durmak isteyen Andrenaki, Mihal Terşi, Etiyen Soşay, nasıl kendisine kuleyi teslim etmişler; nasıl kahramanlığını, cesaretini alkışlayarak, lütfuna teşekkürler ederek çekilip gitmişlerdi...  
— Ben, bir kalenin karşısında çok duramam dedi, hiç sabrım yoktur. Ama Ali Paşa, çok sabırlı... Mâşallah!  
Kethüdâ başını kaldırdı:  
— O da sabırsız... Ama, ne yapsın? Dregley, pek yalçın, pek sarp... Borsem dağları içinde baş kale bu imiş diyorlar.  
— Paşa, muhafızlara evvelâ teslim teklif etmedi mi?  
— Etti.  
— Kabul etmediler mi?  
— Hayır, etmediler.  
— Kalenin kumandanı kimdi?  
— Zondi isminde bir kahraman...  
— Ben onların kahramanlıklarını bilirim. Verdikleri sözü tutmazlar.. Vireyi bozarlar. Elçiye hakaret ederler.  
— Hayır, Arslan Bey, Zondi bildiklerinizden değil. Çok mert bir adam.  
— Paşa, teslim teklifini kiminle gönderdi?  
— Papaz Marten Uruçgalo ile...  
— Ne ise... Türk elçi gönderseydi, mutlaka kafasını keserler, bedenlerden aşağı fırlatırlardı.  
— Paşa, Türk elçisi gönderseydi, Zondi, bunu yapmazdı.  
— Ne biliyorsun?  
— Papaz Marten'e söylediği sözlerden anladım.  
— Ne demiş?  
— Demiş ki: "Git, paşaya söyle. Bana teslim teklif etmesin. Bir askere bundan büyük hakaret olamaz. O nasıl harp adamı ise, ben de harp adamıyım. Ya ölürüm, ya galip gelirim. Ama, görüyorum ki, benim işim bitti. O, durmasın, bütün kuvvetiyle hücum etsin. Ben mutlaka yıkılacak kalenin taşları altında kalmak isterim."  
— Sâhi, namuslu bir askermiş...  
Kethüdâ:  
— Yalnız namuslu bir asker değil, Arslan Bey, dedi, hem de gayet âlicenap bir mert...  
— Nasıl?  
— Bakın anlatayım. Papaz Marten, ordugâha red haberini getirmek için dönerken, Zondi, onu tutmuş. Evvelce esir aldığı iki Türk delikanlısını yanına getirmiş. Bunlara gayet kıymetli erguvanî elbiseler giydirmiş. Ceplerini altınla doldurmuş. "Al bunları paşaya götür. Benimle beraber ölmelerini istemiyorum. Çok yiğit gençlerdir. Terbiyelerine dikkat etsin. Devletine iki büyük asker yetiştirmiş olur." demiş.  
— Sâhi, âlicenap bir adammış...  
— Sonra, elimize diri geçen esirlerden işittik; kalenin avlusuna silahlarını, gümüş takımlarını, en kıymetli eşyalarını yığarak yakmış. Ahırındaki muharebe atlarını, ağlayarak, kendi eliyle öldürmüş. Son hücumda bizim asker kalenin kapısını zorladı. Kırdı. Yeniçeriler, bir kurşunla yaralanan Zondi'yi diri diri yakalamaya çok çalıştılar. Ama mümkün olmadı. O, diz üstü sürünerek, her tarafı kılıçla, mızrakla delik deşik olup ölünceye kadar vuruştu.  
— Demek paşa bu mert düşmanla konuşamadı.  
— Evet, konuşamadı. Vücuduyla kesik başını kalenin karşısına gömdürdü. Mezarının üstüne bir mızrak, bir bayrak dikilmesini emretti.  
— Aşkolsun! Ben olsam bir türbe yaptırırım. Vallâhi...  
Arslan Bey düşmanın cesurunu, kahramanını, yılmazını severdi. Onca harp bir mertlik sanatıydı. Düşman ordusundan kaçıp kendisine ilticâ edenlere hiç aman vermez. "Hain her yerde haindir" diye hemen boynunu vurdururdu.  
Ortalık bütün bütün kararıyor, gece oluyordu.  
Kethüdâ, uzun uzadıya anlattığı Dregley kalesinin hikâyesini hâlâ bitiremiyordu. Yatsı namazı için abdest suyu taşıyan angaryacılar, meş'alelerle geçmeye başladılar. Arslan Bey, Şalgo'nun, ıslanmış, hasta, ateş böcekleri gibi sönük sönük parlayan ziyâlarına bakıyor, kethüdânın sözlerini işitmeyerek, kendi planını düşünüyordu. O biliyordu; düşmanların hepsi Zondi gibi, Plâs Batanyus gibi, Lozonci gibi kahraman değildi. İçlerinde tavşan kadar korkakları da vardı. Mesela; Seçeni kalesinin muhafızları, daha Ali Paşa yaklaşırken, toplarını, tüfeklerini, cephânelerini, erzaklarını, mallarını, hatta ihtiyarlarını, çocuklarını bırakıp bir kurşun atmadan kaçmışlardı. Birkaç güne kadar burası da alınınca Holloko, Boyak, Şağ, keparmat kaleleri kalıyordu. Ama Allah kerimdi.  
— Hepsinin zaptı belki bir ay sürmez.  
Diye mırıldandı. Kethüdâ, kumandanın ne düşündüğünden haberi yoktu, anlamadı. Sordu:  
— Bu kalenin zaptı mı beyim?  
— Hayır, canım... Bu, birkaç günlük iş! Hele hava biraz kapansın... Fulek'e kadar dört beş kale var... Onların hepsini diyorum.  
— Bir ayda dört beş kale... Bu güç beyim.  
— Niçin?  
— Daha bu kaleye bir tüfek atılmamış... Ben attan inerken yoldaşlar söylediler.  
— Ben, burasını, bir kurşun atmadan alacağım.  
— Nasıl beyim?  
— Senin aklın ermez. Hava biraz kapansın, görürsün...  
— Hiç topa tutmadan hücum mu edeceğiz?  
— Hayır.  
— Ya ne yapacağız?  
— Havanın kapanmasını bekle, dedim ya... Göreceksin.  
— ! ! !  
Arslan Bey, planlarını en yakın adamlarından bile saklardı. "Yerin kulağı var." derdi. Ağzından çıkan bir sır mutlaka işitilecekti. Kethüdâ gibi bu sessiz, bu mânasız beklemeden bütün askerler sıkılıyorlar, bir şey anlamıyorlardı. Kumandanın imdat, cephâne, top beklediği söyleniyordu. İhtiyar sipâhîler: "Biz burasını imdat gelmeden alamaz mıyız? İki top yetmez mi? Ne duruyoruz?" diye çadırlarında dedikodu yapıyorlardı. Buraya gelindiği günden beri askere istirahat ettiren Arslan Bey, her sabah erkenden atına biniyor, tek başına gerilerdeki ormanların içine dalıyor, saatlerce kalıyor, gülerek dönüyor:  
— Hava bozmayacak mı? Ah, biraz sis olsa...  
Diye gözlerini gökten, kalenin sallanan bayrağından ayıramıyordu. İşte kethüdânın getirdiği mektupta Ali Paşa da, teklifini kabul ediyordu. Onunla birleşince ordusu yedibin kişi kadar olacaktı. O vakit şüphesiz Tofeli, Pallaviçini'yi diri diri esir tutabilecekti.

Koyu karanlık içinden, uzaktan uzağa, Şalgo burcundaki nöbetçilerin attıkları acı nâralar, acı köpek ulumaları işitiliyordu. Gökte hiç yıldız yoktu. Arslan Bey, hademesinin tuttuğu billûr bardaktaki yakut suyu içti. Yeniden doldurulan çubuğunu çekiyor, kethüdâsıyla öteden beriden konuşuyordu. Konuşurken düşündüğü hep kendi planıydı. Yine göğe dalmıştı. Birdenbire sordu:  
— Hava kapanıyor gibi, değil mi?  
— Evet...  
— Bakalım yarın...  
— Hücum mu edeceğiz beyim?  
— Hayır canım, hava bozsun, görürsün.  
Kethüdâ yine bir şey anlamadı.

Bir sabah...

Binlerce bacadan henüz tütmüş soğuk, nemli bir duman kadar koyu bir sis her tarafı kaplamıştı. Ordugâh, sancaklar, tuğlar, çadırlar, dişbudak ağaçları, atlar, hiç, hiçbir şey görünmüyordu. Evvelâ birbirlerini çağıranların sözleri duyuluyor, sonra iki hayal, ses yordamıyla bu beyaz karanlığın içinde buluşuyordu. Arslan Bey, atını hazırlamıştı. Yine yapyalnız, her günkü gittiği yere doğru kaybolacaktı.

O kadar neşeli idi ki...

Bütün zâbitleri, çavuşları çağırttı. Hepsi hücum var sanıyordu. At dîvanı yapar gibi, bir ayağı yerde, bir ayağı özengide: — Ağalar, dedi, bugün kaleyi alacağız. Ben iki saate kadar geleceğim. Şimdi hepiniz hazır olunuz. Nihâyetleri görünmeyen beyaz, büyük sakalının çerçevelediği yüzü sis içinde muallâkta duruyor sanılan ihtiyar topçubaşı sordu: — Siz gelmeden ben döğmeye başlayım mı, beyim? Arslan Bey güldü: — Hayır... Senin iki topunun güllelerine ihtiyacımız yok. Yalnız bize çok gürültü yap. — Nasıl gürültü beyim? — Toplarını nafile yerinden kımıldatma. Topçularını kalenin bedenlerine doğru yaklaştır. Avazları çıktğı kadar ``heya, mola, yisa..´´ diye bağırt! — ...... — Anlamıyor musun? Yalnız gürültü istiyorum. — Pekala beyim. Sonra diğer zâbitlere döndü: — Siz de bütün askerlerinizi muharebe nizâmıyla bunlara yaklaştırın. Mümkün olduğu kadar çok gürültü yaptırın. ``Heya, mola...´´ çektirin, Angarya nâraları attırın. İş türküleri söylettirin. İhtiyar topçubaşı gibi zâbitler de, çavuşlar da bu emirden bir şey anlamadılar. Fakat onlar anlamadan yapmasını pek iyi bilirlerdi. — Başüstüne, başüstüne.... — Haydi, ama çabuk... — ...... Hepsi iki adım ayrılınca sisin içinde görünmez oldular. Arslan Bey, tepinen atına binince yuları tutan kethüdâsına: — Sen de koş, yanına bir adam al, gerideki Değirmenli Çiftliği'nde biriktirdiğim elli mandayı hemen buraya sür. Burca giden yolun yanında hazır tut... Orada beni bekle. Haydi. — Başüstüne... — Ama çabuk.... — ..... Hızla mahmuzlanan azgın at şaha kalkarak sisin içine atıldı. Üzerindeki, sırmalı kaftanının etekleri altın kanatlara benzeyen Arslan Bey'le, esâtirî bir kuş gibi uçtu.

Biraz sonra....

Nereden geldiği belli olmayan derin bir gürültü sis içinde kaynıyor, ileri geri yaklaşıyor, uzaklaşıyor, dalgalanıyordu. Kös, kalkan, boru sesleri at kişnemelerine karışıyor, alınan emirler, verilen kumandalar yüzlerce ağız tarafından ayrı ayrı tekrarlanıyordu. Bastıkları yerleri görmeyen askerler, harp nizâmında bağırışarak, duyduklarını tekrarlayarak, dirsekleriyle, kalkanlarıyla birbirlerine dokunarak duman içinde ilerliyorlardı.

Sağ taraftan topçuların ``Heya, mola´´ları işitiliyordu. Etrafını saran gürültüden hücumun başladığını kale de anladı. Boru, trampet, hurrâ sesleri aksetmeye, tek tük tabanca, tüfek atılmaya başladı. Gözcüler kale bedenlerinin dibine kadar gidip geliyorlardı. Safların arasında, topçubaşının büyük bir lağım açtığı söyleniyordu.

Askerler, zâbitlerinin emriyle, oldukları yerlerde bağdaş kurmuş bekliyorlar, gürültü ediyorlardı.

Nihayet, Arslan Bey, terden sırılsıklam olmuş atı ile duman içinde harp sıralarının arasında, adım adım göründü. Her adımda: — Yiğitlerim!... Sis açılmaya başladı mı, hemen susun. Hep birden ayağa kalkın, hücum edecek gibi durun. Ama, ileri gitmeyin. Ateş de açmayın. Ben düşmana teslim teklif edeceğim. Diyordu. Topçuların, topçulara karışan angaryacıların ``Heya, mola´´ nâraları gittikçe ziyâdeleşiyor, büyüyor, tüyleri ürpertecek heyecanlı akislerle görünmeyen dağları, taşları inletiyordu.

Öğleye doğru sis açılmaya başladı. Askerler, sallanan siyahlı beyazlı bayrağı ile Şalgo'yu bir hayal gibi gördüler. Sesler kesildi. Şimalden esen bir rüzgar dumanları dağıtıyor; gerilere, ormanlara doğru sürüyordu.

Artık herkes birbirini görüyordu.

Kaleye pek yaklaşılmıştı. Askerler, gözleriyle kumandanlarını aradılar. O, burç kapısına giden yolun gediğinde, atıyla dolaşıyordu. Gediğin önünde büyük bir manda sürüsü vardı. Burcun tepesinde, siperlerin arasında, kalkanlı, tüfekli adamlar geziniyordu.

Cesur Arslan Bey, kır atını ileriye sürdü. Kaleye yüz adım kadar yaklaştı. Arkasındaki kethüdâsıyla, genç tercüman koştular...

Gür sesiyle haykırdı: — Hey bre Şalgo muhafızları!... Ben, padişahımın dedesine sizin kralınızın memleketlerinden büyük yerler zaptetmiş, Bosna valisi Yahya Paşa'nın torunlarındanım. Ceddim Hamza Bali Bey, daha ondört yaşında iken sizin ordularınızı perişan etmiş, Viyana Muhasarası'nda, Viyenberg önünde şan almıştır. Ben, hangi kaleye gittimse geri dönmemişim, daha geçen gün iki küçük topla ``Boza´´ kulesini yerle bir ettim. Mihal Terşi, Etiyen Soşay, Andrenaki gibi kahramanlarınıza canlarını bağışladım. Vadiye çekildim. Geçip gitmeleri için yol verdim. Haydi gelin. Siz de teslim olun. Nafile yere kanınızı döktürmeyin... Kale ile beraber bütün ordunun işittiği bu teklifi, tercüman, avazı çıktığı kadar bağırarak tekrarladı.

Derin bir sükut...

Arslan Bey'in atı duramıyor, şaha kalkıyor, sağa sola tepiniyor, kethüdâ dizgininden tutmaya çalışıyordu.

Burcun tepesinden bir cevap verdiler. Tercüman tekrarladı: — "Ne gibi şartlarla?"diyorlar, beyim. Arslan Bey, deminkinden daha sert bir sesle haykırdı: — Şartım filan yok. Biz teslim olanın canına kıymayız. Teslim olmazsanız, beş dakika sonra kalenin içinde bir canlı adam kalmaz. Karşınızdaki yolun gediği üzerinde gördüğünüz nedir? Anlamıyor musunuz? Babalarınızdan işitmediniz mi? Elli manda ile buraya getirdiğim bu topun iki güllesiyle binlerce Şalgo kuvvetinde olan İstanbul kaleleri tuzla buz oldu. İşte İstanbul'u alan bu top... Bir kere ateş edeceğim. İkinci atıma hacet yok. Ne kaleniz kalacak, ne de kendiniz. Acıyorum size... Genç tercüman, bu sözleri, yine avazı çıktığı kadar tekrarlarken, bütün askerler, gözlerini yolun gediğine çevirdiler. Mandaların yanında, uzun, büyük, gayet büyük, gayet kalın, gayet siyah, gayet müthiş bir topun korkunç bir ejderha gibi uzandığını gördüler. Safların arasında sevinç sadâları yükseldi. Herkes Arslan Bey'in bir haftadır ne beklediğini şimdi anlıyordu. Demek bu top geliyormuş...

Biraz sonra...

Şalgo'nun tepesinde, şan, namus kefeni olan meş'um beyaz bayrak dalgalanıyordu. Demir kapılar açılmıştı. Korkudan sapsarı kesilen tuğlu kumandan, altın kılıçlı asilzâdeler, zırhlı şövalyeler, Arslan Bey'in önünde dize gelmişlerdi. Silahları alınan düşman ikişer ikişer bağlanıyor, takım takım ordugâhın arkasına götürülüyordu. Kalenin içindeki kıymetli şeylerden bir dağ ortada kabarıyor; al yeşil bayraklarla kalenin tepesine dolan askerler bağırışıyorlar, aralarındaki dervişler, bedenlerden sarkarak ezan okuyorlar, tekbir çekiyorlardı.

Teslim olan kumandanla erkânına Arslan Bey: — Korkmayınız. Hayatınız bağışlanmıştır. Biz Vireyi bozmayız. Gelin, size elli manda ile buraya getirdiğim topu seyrettireyim, dedi.

Tercüman bunu tekrarlayınca, hepsi birbirlerine bakıştılar. Bu müthiş, bu korkunç, aleti yakından görmeyi hem merak ediyorlar, hem çekiniyorlardı. Arslan Bey'in arkasına takıldılar. Büyük topa doğru yürüdüler. Yaklaşınca Arslan Bey:  
— İşte, dedi, sizin böyle topunuz var mı?  
Düşman kumandanı tercümanla cevap verdi:  
— Hayır.  
— Niçin yapmıyorsunuz?  
— Bilmiyoruz.  
Genç irisi bir şövalye tercümana bir şey sordu. Arslan Bey:  
— Ne diyor?  
Dedi.  
— "Bey bu topu kaç günde İstanbul'dan buraya getirmiştir?" diyor.  
— Sen de ki: "İstanbul'dan getirmemiş. Burada bir hafta içinde kendisi yapmış."  
Tercüman bu sözleri söyleyince esirler afallaştılar. Arslan Bey, daha ziyâde yaklaşıp elleriyle yoklamalarına, daha yakından görmelerine müsaade ettiğini söyledi. Mağrur kumandan, kahraman asilzâdeler, cesur şövalyeler, büyük topun etrafına toplandılar. Bir elini hançerinin elmas sapına dayayan Arslan Bey, öteki eliyle, gülümseyerek palabıyıklarını büküyor, arkasındaki kethüdâ, başını kaşıyarak gülmekten katılıyor, tercüman aptallaşıyordu. Yirmi adım uzakta duran mızraklı nöbetçiler de gülüşüyorlardı. Esirler topa ellerini sürdüler. Deliğini aradılar. Bulamayınca sarardılar. Sonra kızardılar. Birbirlerine bakıştılar. Öyle kaldılar. Kollarını çaprazlayarak yere bakan kale kumandanı titreyerek mırıldandı. Arslan Bey, tercümana baktı:  
— Ne diyor?  
— "Bu mertlik değil..." diyor.  
— Ona sor ki: "Henüz bir kere patlamayan bir toptan korkarak hemen teslim oluvermek mi mertlik?"  
Tercüman sordu.  
— .....  
— .....  
Kale kumandanı, gözlerini yerden kaldırıp cevap veremedi. Asilzâdeler, şövalyeler birbirlerinin yüzlerine bakmaya cesaret edemediler; âni bir ölüm darbesiyle vurulmuş gibi oldukları yerde donup kaldılar.

Bir güllesiyle kaleyi yıkacak olan bu korkunç top, siyaha boyanmış, kocaman bir kütükten başka bir şey değildi!...  
Gelişmiş  
Özel karakterler  
Yardım  
Başlık  
Biçim  
Ekle

Alaca karanlık içinde sivri, siyah bir kayanın müphem hayali gibi yükselen Şalgo burcu uyanıktı. Vakit vakit inlettiği trampete, boru seslerini akşamın hafif rüzgarı, derin bir uğultu halinde, her tarafa yayıyor... Kederli bağırışmalarıyla ölümü hatırlatan küfürbaz karga sürüleri, bulutlu havanın donuk hüznünü daha beter artırıyordu. Mor dağlar gittikçe koyulaşıyordu. Yamaçlardaki dağınık gölgeler, kuşsuz ormanlar, hıçkıran dereler, kaçan yollar, ıssız korular, sanki korkunç bir fırtınanın gürlemesini bekliyorlardı.

Burcun tepesinde, beyazlı siyahlı bir bayrak, can çekişen bir kartal ıstırabıyla kıvranıyordu.

İkibin kişilik muhâsara ordusunun çadırları, kaleye giren geniş yolun sağındaki büyük dişbudak ağaçlarının etrafına kurulmuştu. Yerlere kazıklanmış kır atlar, yabancı korkular duyuyorlar gibi, sık sık başlarını kaldırarak kişniyorlar, tırnaklarıyla kazmaya çalıştıkları toprakların nemli çimenlerini otluyorlardı. Dallarda kırmızı çullar, sırmalı eğerler asılı duruyordu. Cemâatle kılınmış akşam namazından dağılan askerler, çadırların arasından gürültü ile geçiyorlardı. Kısa emirler, çağırılan isimler, bir kahkaha, bir söz... Başlayacak sükûnu bozuyor, atların yanında itişen birkaç gencin şen nâraları duyuluyordu. Çifte direkli yeşil çadırın kapısı önüne serilmiş büyük bir kaplan postu üzerinde kehribar çubuğunu fosur fosur çeken koca bıyıklı, iri vücutlu, ateş nazarlı şâir kumandan, gözlerini, alacağı kalenin sallanan bayrağına dikmişti. Karşısında diz çökmüş kethüdâsının anlattıklarını dinliyordu. Ordugâha yarım saat evvel dört nala gelen bu adam, yaşlı, şişman bir askerdi. İşte kaç hafta oluyor, kumandanının "Göndersdref Baronu Erasm Tofl'u beraber vurmak" teklifini hâvî mektubunu, tek başına, Hadım Ali Paşa'ya götürmüştü. Ama, paşa çok meşguldü. Vakit bulup cevap verememişti. Dregley kalesini sarıyordu. Muhâsaranın iptidâsından nihayetine kadar hazır bulunan kethüdâ, şimdi orada gördüklerini söylüyordu; bu kale gayet sarp, gayet dik, bir kayanın zirvesine yapılmıştı. Arslan Bey sordu:  
— Bizim kaleden daha yüksek mi?  
— Daha yüksek beyim.  
Kumandanın ``bizim kale´´ dediği, henüz çırpınan bayrağına hasretle baktığı Şalgo burcu idi. Fakat o, burasını birkaç gün içinde zaptedeceğini iyice biliyordu. Daha birkaç hafta evvel Boze kulesinde hücumlarına karşı durmak isteyen Andrenaki, Mihal Terşi, Etiyen Soşay, nasıl kendisine kuleyi teslim etmişler; nasıl kahramanlığını, cesaretini alkışlayarak, lütfuna teşekkürler ederek çekilip gitmişlerdi...  
— Ben, bir kalenin karşısında çok duramam dedi, hiç sabrım yoktur. Ama Ali Paşa, çok sabırlı... Mâşallah!  
Kethüdâ başını kaldırdı:  
— O da sabırsız... Ama, ne yapsın? Dregley, pek yalçın, pek sarp... Borsem dağları içinde baş kale bu imiş diyorlar.  
— Paşa, muhafızlara evvelâ teslim teklif etmedi mi?  
— Etti.  
— Kabul etmediler mi?  
— Hayır, etmediler.  
— Kalenin kumandanı kimdi?  
— Zondi isminde bir kahraman...  
— Ben onların kahramanlıklarını bilirim. Verdikleri sözü tutmazlar.. Vireyi bozarlar. Elçiye hakaret ederler.  
— Hayır, Arslan Bey, Zondi bildiklerinizden değil. Çok mert bir adam.  
— Paşa, teslim teklifini kiminle gönderdi?  
— Papaz Marten Uruçgalo ile...  
— Ne ise... Türk elçi gönderseydi, mutlaka kafasını keserler, bedenlerden aşağı fırlatırlardı.  
— Paşa, Türk elçisi gönderseydi, Zondi, bunu yapmazdı.  
— Ne biliyorsun?  
— Papaz Marten'e söylediği sözlerden anladım.  
— Ne demiş?  
— Demiş ki: "Git, paşaya söyle. Bana teslim teklif etmesin. Bir askere bundan büyük hakaret olamaz. O nasıl harp adamı ise, ben de harp adamıyım. Ya ölürüm, ya galip gelirim. Ama, görüyorum ki, benim işim bitti. O, durmasın, bütün kuvvetiyle hücum etsin. Ben mutlaka yıkılacak kalenin taşları altında kalmak isterim."  
— Sâhi, namuslu bir askermiş...  
Kethüdâ:  
— Yalnız namuslu bir asker değil, Arslan Bey, dedi, hem de gayet âlicenap bir mert...  
— Nasıl?  
— Bakın anlatayım. Papaz Marten, ordugâha red haberini getirmek için dönerken, Zondi, onu tutmuş. Evvelce esir aldığı iki Türk delikanlısını yanına getirmiş. Bunlara gayet kıymetli erguvanî elbiseler giydirmiş. Ceplerini altınla doldurmuş. "Al bunları paşaya götür. Benimle beraber ölmelerini istemiyorum. Çok yiğit gençlerdir. Terbiyelerine dikkat etsin. Devletine iki büyük asker yetiştirmiş olur." demiş.  
— Sâhi, âlicenap bir adammış...  
— Sonra, elimize diri geçen esirlerden işittik; kalenin avlusuna silahlarını, gümüş takımlarını, en kıymetli eşyalarını yığarak yakmış. Ahırındaki muharebe atlarını, ağlayarak, kendi eliyle öldürmüş. Son hücumda bizim asker kalenin kapısını zorladı. Kırdı. Yeniçeriler, bir kurşunla yaralanan Zondi'yi diri diri yakalamaya çok çalıştılar. Ama mümkün olmadı. O, diz üstü sürünerek, her tarafı kılıçla, mızrakla delik deşik olup ölünceye kadar vuruştu.  
— Demek paşa bu mert düşmanla konuşamadı.  
— Evet, konuşamadı. Vücuduyla kesik başını kalenin karşısına gömdürdü. Mezarının üstüne bir mızrak, bir bayrak dikilmesini emretti.  
— Aşkolsun! Ben olsam bir türbe yaptırırım. Vallâhi...  
Arslan Bey düşmanın cesurunu, kahramanını, yılmazını severdi. Onca harp bir mertlik sanatıydı. Düşman ordusundan kaçıp kendisine ilticâ edenlere hiç aman vermez. "Hain her yerde haindir" diye hemen boynunu vurdururdu.  
Ortalık bütün bütün kararıyor, gece oluyordu.  
Kethüdâ, uzun uzadıya anlattığı Dregley kalesinin hikâyesini hâlâ bitiremiyordu. Yatsı namazı için abdest suyu taşıyan angaryacılar, meş'alelerle geçmeye başladılar. Arslan Bey, Şalgo'nun, ıslanmış, hasta, ateş böcekleri gibi sönük sönük parlayan ziyâlarına bakıyor, kethüdânın sözlerini işitmeyerek, kendi planını düşünüyordu. O biliyordu; düşmanların hepsi Zondi gibi, Plâs Batanyus gibi, Lozonci gibi kahraman değildi. İçlerinde tavşan kadar korkakları da vardı. Mesela; Seçeni kalesinin muhafızları, daha Ali Paşa yaklaşırken, toplarını, tüfeklerini, cephânelerini, erzaklarını, mallarını, hatta ihtiyarlarını, çocuklarını bırakıp bir kurşun atmadan kaçmışlardı. Birkaç güne kadar burası da alınınca Holloko, Boyak, Şağ, keparmat kaleleri kalıyordu. Ama Allah kerimdi.  
— Hepsinin zaptı belki bir ay sürmez.  
Diye mırıldandı. Kethüdâ, kumandanın ne düşündüğünden haberi yoktu, anlamadı. Sordu:  
— Bu kalenin zaptı mı beyim?  
— Hayır, canım... Bu, birkaç günlük iş! Hele hava biraz kapansın... Fulek'e kadar dört beş kale var... Onların hepsini diyorum.  
— Bir ayda dört beş kale... Bu güç beyim.  
— Niçin?  
— Daha bu kaleye bir tüfek atılmamış... Ben attan inerken yoldaşlar söylediler.  
— Ben, burasını, bir kurşun atmadan alacağım.  
— Nasıl beyim?  
— Senin aklın ermez. Hava biraz kapansın, görürsün...  
— Hiç topa tutmadan hücum mu edeceğiz?  
— Hayır.  
— Ya ne yapacağız?  
— Havanın kapanmasını bekle, dedim ya... Göreceksin.  
— ! ! !  
Arslan Bey, planlarını en yakın adamlarından bile saklardı. "Yerin kulağı var." derdi. Ağzından çıkan bir sır mutlaka işitilecekti. Kethüdâ gibi bu sessiz, bu mânasız beklemeden bütün askerler sıkılıyorlar, bir şey anlamıyorlardı. Kumandanın imdat, cephâne, top beklediği söyleniyordu. İhtiyar sipâhîler: "Biz burasını imdat gelmeden alamaz mıyız? İki top yetmez mi? Ne duruyoruz?" diye çadırlarında dedikodu yapıyorlardı. Buraya gelindiği günden beri askere istirahat ettiren Arslan Bey, her sabah erkenden atına biniyor, tek başına gerilerdeki ormanların içine dalıyor, saatlerce kalıyor, gülerek dönüyor:  
— Hava bozmayacak mı? Ah, biraz sis olsa...  
Diye gözlerini gökten, kalenin sallanan bayrağından ayıramıyordu. İşte kethüdânın getirdiği mektupta Ali Paşa da, teklifini kabul ediyordu. Onunla birleşince ordusu yedibin kişi kadar olacaktı. O vakit şüphesiz Tofeli, Pallaviçini'yi diri diri esir tutabilecekti.

Koyu karanlık içinden, uzaktan uzağa, Şalgo burcundaki nöbetçilerin attıkları acı nâralar, acı köpek ulumaları işitiliyordu. Gökte hiç yıldız yoktu. Arslan Bey, hademesinin tuttuğu billûr bardaktaki yakut suyu içti. Yeniden doldurulan çubuğunu çekiyor, kethüdâsıyla öteden beriden konuşuyordu. Konuşurken düşündüğü hep kendi planıydı. Yine göğe dalmıştı. Birdenbire sordu:  
— Hava kapanıyor gibi, değil mi?  
— Evet...  
— Bakalım yarın...  
— Hücum mu edeceğiz beyim?  
— Hayır canım, hava bozsun, görürsün.  
Kethüdâ yine bir şey anlamadı.

Bir sabah...

Binlerce bacadan henüz tütmüş soğuk, nemli bir duman kadar koyu bir sis her tarafı kaplamıştı. Ordugâh, sancaklar, tuğlar, çadırlar, dişbudak ağaçları, atlar, hiç, hiçbir şey görünmüyordu. Evvelâ birbirlerini çağıranların sözleri duyuluyor, sonra iki hayal, ses yordamıyla bu beyaz karanlığın içinde buluşuyordu. Arslan Bey, atını hazırlamıştı. Yine yapyalnız, her günkü gittiği yere doğru kaybolacaktı.

O kadar neşeli idi ki...

Bütün zâbitleri, çavuşları çağırttı. Hepsi hücum var sanıyordu. At dîvanı yapar gibi, bir ayağı yerde, bir ayağı özengide: — Ağalar, dedi, bugün kaleyi alacağız. Ben iki saate kadar geleceğim. Şimdi hepiniz hazır olunuz. Nihâyetleri görünmeyen beyaz, büyük sakalının çerçevelediği yüzü sis içinde muallâkta duruyor sanılan ihtiyar topçubaşı sordu: — Siz gelmeden ben döğmeye başlayım mı, beyim? Arslan Bey güldü: — Hayır... Senin iki topunun güllelerine ihtiyacımız yok. Yalnız bize çok gürültü yap. — Nasıl gürültü beyim? — Toplarını nafile yerinden kımıldatma. Topçularını kalenin bedenlerine doğru yaklaştır. Avazları çıktğı kadar ``heya, mola, yisa..´´ diye bağırt! — ...... — Anlamıyor musun? Yalnız gürültü istiyorum. — Pekala beyim. Sonra diğer zâbitlere döndü: — Siz de bütün askerlerinizi muharebe nizâmıyla bunlara yaklaştırın. Mümkün olduğu kadar çok gürültü yaptırın. ``Heya, mola...´´ çektirin, Angarya nâraları attırın. İş türküleri söylettirin. İhtiyar topçubaşı gibi zâbitler de, çavuşlar da bu emirden bir şey anlamadılar. Fakat onlar anlamadan yapmasını pek iyi bilirlerdi. — Başüstüne, başüstüne.... — Haydi, ama çabuk... — ...... Hepsi iki adım ayrılınca sisin içinde görünmez oldular. Arslan Bey, tepinen atına binince yuları tutan kethüdâsına: — Sen de koş, yanına bir adam al, gerideki Değirmenli Çiftliği'nde biriktirdiğim elli mandayı hemen buraya sür. Burca giden yolun yanında hazır tut... Orada beni bekle. Haydi. — Başüstüne... — Ama çabuk.... — ..... Hızla mahmuzlanan azgın at şaha kalkarak sisin içine atıldı. Üzerindeki, sırmalı kaftanının etekleri altın kanatlara benzeyen Arslan Bey'le, esâtirî bir kuş gibi uçtu.

Biraz sonra....

Nereden geldiği belli olmayan derin bir gürültü sis içinde kaynıyor, ileri geri yaklaşıyor, uzaklaşıyor, dalgalanıyordu. Kös, kalkan, boru sesleri at kişnemelerine karışıyor, alınan emirler, verilen kumandalar yüzlerce ağız tarafından ayrı ayrı tekrarlanıyordu. Bastıkları yerleri görmeyen askerler, harp nizâmında bağırışarak, duyduklarını tekrarlayarak, dirsekleriyle, kalkanlarıyla birbirlerine dokunarak duman içinde ilerliyorlardı.

Sağ taraftan topçuların ``Heya, mola´´ları işitiliyordu. Etrafını saran gürültüden hücumun başladığını kale de anladı. Boru, trampet, hurrâ sesleri aksetmeye, tek tük tabanca, tüfek atılmaya başladı. Gözcüler kale bedenlerinin dibine kadar gidip geliyorlardı. Safların arasında, topçubaşının büyük bir lağım açtığı söyleniyordu.

Askerler, zâbitlerinin emriyle, oldukları yerlerde bağdaş kurmuş bekliyorlar, gürültü ediyorlardı.

Nihayet, Arslan Bey, terden sırılsıklam olmuş atı ile duman içinde harp sıralarının arasında, adım adım göründü. Her adımda: — Yiğitlerim!... Sis açılmaya başladı mı, hemen susun. Hep birden ayağa kalkın, hücum edecek gibi durun. Ama, ileri gitmeyin. Ateş de açmayın. Ben düşmana teslim teklif edeceğim. Diyordu. Topçuların, topçulara karışan angaryacıların ``Heya, mola´´ nâraları gittikçe ziyâdeleşiyor, büyüyor, tüyleri ürpertecek heyecanlı akislerle görünmeyen dağları, taşları inletiyordu.

Öğleye doğru sis açılmaya başladı. Askerler, sallanan siyahlı beyazlı bayrağı ile Şalgo'yu bir hayal gibi gördüler. Sesler kesildi. Şimalden esen bir rüzgar dumanları dağıtıyor; gerilere, ormanlara doğru sürüyordu.

Artık herkes birbirini görüyordu.

Kaleye pek yaklaşılmıştı. Askerler, gözleriyle kumandanlarını aradılar. O, burç kapısına giden yolun gediğinde, atıyla dolaşıyordu. Gediğin önünde büyük bir manda sürüsü vardı. Burcun tepesinde, siperlerin arasında, kalkanlı, tüfekli adamlar geziniyordu.

Cesur Arslan Bey, kır atını ileriye sürdü. Kaleye yüz adım kadar yaklaştı. Arkasındaki kethüdâsıyla, genç tercüman koştular...

Gür sesiyle haykırdı: — Hey bre Şalgo muhafızları!... Ben, padişahımın dedesine sizin kralınızın memleketlerinden büyük yerler zaptetmiş, Bosna valisi Yahya Paşa'nın torunlarındanım. Ceddim Hamza Bali Bey, daha ondört yaşında iken sizin ordularınızı perişan etmiş, Viyana Muhasarası'nda, Viyenberg önünde şan almıştır. Ben, hangi kaleye gittimse geri dönmemişim, daha geçen gün iki küçük topla ``Boza´´ kulesini yerle bir ettim. Mihal Terşi, Etiyen Soşay, Andrenaki gibi kahramanlarınıza canlarını bağışladım. Vadiye çekildim. Geçip gitmeleri için yol verdim. Haydi gelin. Siz de teslim olun. Nafile yere kanınızı döktürmeyin... Kale ile beraber bütün ordunun işittiği bu teklifi, tercüman, avazı çıktığı kadar bağırarak tekrarladı.

Derin bir sükut...

Arslan Bey'in atı duramıyor, şaha kalkıyor, sağa sola tepiniyor, kethüdâ dizgininden tutmaya çalışıyordu.

Burcun tepesinden bir cevap verdiler. Tercüman tekrarladı: — "Ne gibi şartlarla?"diyorlar, beyim. Arslan Bey, deminkinden daha sert bir sesle haykırdı: — Şartım filan yok. Biz teslim olanın canına kıymayız. Teslim olmazsanız, beş dakika sonra kalenin içinde bir canlı adam kalmaz. Karşınızdaki yolun gediği üzerinde gördüğünüz nedir? Anlamıyor musunuz? Babalarınızdan işitmediniz mi? Elli manda ile buraya getirdiğim bu topun iki güllesiyle binlerce Şalgo kuvvetinde olan İstanbul kaleleri tuzla buz oldu. İşte İstanbul'u alan bu top... Bir kere ateş edeceğim. İkinci atıma hacet yok. Ne kaleniz kalacak, ne de kendiniz. Acıyorum size... Genç tercüman, bu sözleri, yine avazı çıktığı kadar tekrarlarken, bütün askerler, gözlerini yolun gediğine çevirdiler. Mandaların yanında, uzun, büyük, gayet büyük, gayet kalın, gayet siyah, gayet müthiş bir topun korkunç bir ejderha gibi uzandığını gördüler. Safların arasında sevinç sadâları yükseldi. Herkes Arslan Bey'in bir haftadır ne beklediğini şimdi anlıyordu. Demek bu top geliyormuş...

Biraz sonra...

Şalgo'nun tepesinde, şan, namus kefeni olan meş'um beyaz bayrak dalgalanıyordu. Demir kapılar açılmıştı. Korkudan sapsarı kesilen tuğlu kumandan, altın kılıçlı asilzâdeler, zırhlı şövalyeler, Arslan Bey'in önünde dize gelmişlerdi. Silahları alınan düşman ikişer ikişer bağlanıyor, takım takım ordugâhın arkasına götürülüyordu. Kalenin içindeki kıymetli şeylerden bir dağ ortada kabarıyor; al yeşil bayraklarla kalenin tepesine dolan askerler bağırışıyorlar, aralarındaki dervişler, bedenlerden sarkarak ezan okuyorlar, tekbir çekiyorlardı.

Teslim olan kumandanla erkânına Arslan Bey: — Korkmayınız. Hayatınız bağışlanmıştır. Biz Vireyi bozmayız. Gelin, size elli manda ile buraya getirdiğim topu seyrettireyim, dedi.

Tercüman bunu tekrarlayınca, hepsi birbirlerine bakıştılar. Bu müthiş, bu korkunç, aleti yakından görmeyi hem merak ediyorlar, hem çekiniyorlardı. Arslan Bey'in arkasına takıldılar. Büyük topa doğru yürüdüler. Yaklaşınca Arslan Bey:  
— İşte, dedi, sizin böyle topunuz var mı?  
Düşman kumandanı tercümanla cevap verdi:  
— Hayır.  
— Niçin yapmıyorsunuz?  
— Bilmiyoruz.  
Genç irisi bir şövalye tercümana bir şey sordu. Arslan Bey:  
— Ne diyor?  
Dedi.  
— "Bey bu topu kaç günde İstanbul'dan buraya getirmiştir?" diyor.  
— Sen de ki: "İstanbul'dan getirmemiş. Burada bir hafta içinde kendisi yapmış."  
Tercüman bu sözleri söyleyince esirler afallaştılar. Arslan Bey, daha ziyâde yaklaşıp elleriyle yoklamalarına, daha yakından görmelerine müsaade ettiğini söyledi. Mağrur kumandan, kahraman asilzâdeler, cesur şövalyeler, büyük topun etrafına toplandılar. Bir elini hançerinin elmas sapına dayayan Arslan Bey, öteki eliyle, gülümseyerek palabıyıklarını büküyor, arkasındaki kethüdâ, başını kaşıyarak gülmekten katılıyor, tercüman aptallaşıyordu. Yirmi adım uzakta duran mızraklı nöbetçiler de gülüşüyorlardı. Esirler topa ellerini sürdüler. Deliğini aradılar. Bulamayınca sarardılar. Sonra kızardılar. Birbirlerine bakıştılar. Öyle kaldılar. Kollarını çaprazlayarak yere bakan kale kumandanı titreyerek mırıldandı. Arslan Bey, tercümana baktı:  
— Ne diyor?  
— "Bu mertlik değil..." diyor.  
— Ona sor ki: "Henüz bir kere patlamayan bir toptan korkarak hemen teslim oluvermek mi mertlik?"  
Tercüman sordu.  
— .....  
— .....  
Kale kumandanı, gözlerini yerden kaldırıp cevap veremedi. Asilzâdeler, şövalyeler birbirlerinin yüzlerine bakmaya cesaret edemediler; âni bir ölüm darbesiyle vurulmuş gibi oldukları yerde donup kaldılar.

Bir güllesiyle kaleyi yıkacak olan bu korkunç top, siyaha boyanmış, kocaman bir kütükten başka bir şey değildi!...

# Kıskançlık

Ali Cânib'e

"Adeta, ufacık bir çocukken yazıp da neşre  
cesaret edemediğim bu hikâyeyi, ölen annemin  
kitapları arasında buldum. Garip bir merakla  
okudum. Çok, ama pek çok beğendim. Eskiden  
niçin beğenmemişim de, bir tarafa atmışım?  
Şimdi niçin bu kadar beğeniyorum? Acaba  
zavallı anneciğimin şefkatini bana hatırlattığı  
için mi?

Her neyse... Sevgili Cânib'im, bugün en  
güzel bir eserim sandığım şu yazıyı işte sana  
ithaf ediyorum."

Ahmet Sühran Bey: — O zaman ancak yirmi yaşında bulunuyordum, dedi. Telgraf ve Posta Nezareti'nde büyük bir mevki sahibi olan babam, sefâhatime, rezaletime, çapkınlığıma dayanamadı. Annem, bir de büyükannemle ihitiyar halamdan ibaret olan ailemle müzakere etti. Hepsi ittifak-ı ârâ ile beni dışarıya göndermeye karar verdiler. Yanya vilayetindeki müfettiş, babamın adamlarındanmış! O vilayette bir kasabaya gidecektim. Orada muhabere memuru olacaktım. Fikirlerince uslanacaktım. Bunu annem, gayet yumuşak bir lisanla: — Çok zayıfladın... Hava tebdîli gibi bir şey... Hem memleket görürsün, hem kendini toplarsın. Hem de terakkî... Mukaddemesini terennüm ederek hazırlanmaklığımı söyleyince şaşırdım. — Gitmem, olamaz. Diye mukavemete kalkmak istedimse de, annem, son kabahatimin babamda hâsıl ettiği müthiş tesiri anlatmaya başladı. Birkaç ay sonra mutlaka geri getirileceğimi, bunun için babama yalvaracağını, birçok yeminlerle vâdetti.

Ben, böyle vaade maade kanmazdım ama, galiba o tarafları görmek arzum da vardı. — Peki, dedim, fakat üç aydan ziyâde durmam... Bol bir harcırah... Dört yüz elli kuruş maaş... Bunlar iyi! Fakat sevgili, sefalı İstanbul'dan üç ay ayrılık... Beş sene vardı ki, İstanbul'dan dışarı çıkmamıştım. Doğma, büyüme vatanımmış gibi ısınmıştım. Lâkin her şey için, her türlü teselli insanda, hazırdır. Babamın son memuriyeti olan Girit'ten dönerken uğradığımız iskelelerdeki manzaraları, eğlenceleri hatırlayarak: — Şimdi çok eğlenirim. O zaman çocuktum. Muhakemesiyle tatlı hülyalara düştüm. Evet ilk Beyrut, daha sonra Pire... Atina idi. Mora'yı dolaşarak Preveze'ye, oradan Yanya'ya, oradan da mahalli memuriyetim olan kasabaya gidecektim. Güzel seyahat!

Ailemle muhtasar bir veda... Babamın, yazılsa üç dört tabaka eser-i cedid kağıdı dolduracak olan kıymetli nasihatlerini aldıktan  sonra vapura atladım. Selanik'te iki gün kaldık. Gecelerimin ikisinin de çalgılı, gürültülü bir evde geçtiğini söylemeye lüzum yok. Selanik'ten sonra biraz hastalandım. İzmir'de iki gün kalacaktık. "Paralarımı Atina'da yer, adamakıllı eğlenirim." düşüncesiyle burada eğlenmekten vazgeçtim. Bununla beraber sarıklı yolcular gibi geceleri de vapurda geçirmeye razı olamazdım. Bir otele indim. Akşam sofrada sakallı bir efendinin bana dikkatle baktığını hisseder gibi oldum. Hâsılı, uzun uzadıya meraka lüzum kalmadı. Bu efendi, yemekten sonra kahvelerimizi içerken ismimi sordu. Söyledikten sonra babamın kim olduğunu sordu. Onu da söyleyince, tuhaf bir hareketle elini ağzıma uzattı: — Dayınızın elini öpünüz! Dedi. Ben şaşaladım. Ama tanıdım. Bu tombul eli öperken küçüklüğümde bana Farisî gösteren nazik dayımın Acemistan sefaretinde kâtip olduğunu hatırlıyorum. Senede bir defa Muharrem'i tebrik eden mektupları gelirdi. Tuhaf tesadüf... İstanbul'a dönüyormuş. Benden anneme, babama dair vasf-ı terkîbîli sualler sordu. O gece saat üçe kadar Kordon'da bir kahvede oturduk, konuştuk. Otele geldiğimiz zaman yolculuğa mahsus o sarhoşluğa benzeyen ağır uyku göz kapaklarımı büzüyordu. Dayım birinci katta yatıyormuş. Odasının önüne gelince arkamı okşayarak: — Allah rahatlık versin, oğlum, dedi, ben sabahları erken kalkamıyorum. Lütfen beni uyandır. — Baş üstüne! Diye ayrıldım. Odama çıktım. İşte bir gece sefâhatten vazgeçişim, bana nasıl kıymetli bir tesadüf kazandırmıştı! Yarın kalkan vapurla İstanbul'a gidecek olan dayımın benim için tasavvut edeceğine hiç şüphem yoktu.

.... Sabahleyin geç uyandım. Acele giyindim. Dayımın odasına indim. O da giyinmiş, fesini süpürüyordu. Benim girdiğimi aynanın içinden görünce döndü: — Sabah-ı şerifler hayırlar olsun yavrum, bugün beni teşyî edeceksin ya!.. Dedi. — Maaliftihar efendim. Diye güldüm. Gözüme sarı topuzlu, demir karyolanın yanında bir şey ilişti... Beyaz bir kürk... Yahut... Bir köpek... Merakla yürüdüm. Yaklaşınca iki parlak siyah gözün bana baktığını gördüm. Bu ne köpekti, ne de kedi...

Gayr-i ihtyarî: — A.. Ne güzel şey! Deyiverdim. Dayım, süpürdüğü fesini itinakâr bir takayyütle başına koydu. Yanıma geldi: — Hakikaten güzeldir, dedi, bu maymunu bana bir Hindli tüccar hediye vermişti. Gelirken brakmaya, satmaya kıyamadım. Ben taacüp ettim: — Bu maymun mu? Hiç beyaz maymun görmemiştim! Nazik dayım güldü. Beyaz maymunu okşayarak: — Hindistan'a mahsus bir nevi cins. Fevkalade zeki. Hem nadir. Ben hayret ettikçe marifetlerini, oyunlarını, zekasına delalet eden hareketlerini anlattı. En sonunda: — Bunu, sana yadigar vereceğim. Görüyorum, çok hoşuna gitti. Dedi. Eyvah... Ben maymunu ne yapacaktım? Baş belası! Bari hazzetsem... Bembeyaz br şeydi. Yalnız tuhafıma gitmişti. Reddettim. — İstemem. Dedim. Nazik dayım, istemediğimi nezaketime veriyor, ısrarında devam ediyordu. Ne yapayım? Mecburen kabul etim. O gün dayım İstanbul'a gitti. Ben maymunla yalnız kaldım. Bu beyaz maymun dişiydi. O kadar güzeldi ki... Başka maymunlardaki abusluk yüzünde yoktu. Parlak beyaz tüyleri, ince beyaz ayakları pek sevimli, pek yumuşak görünyordu. Koyu siyah gözleri o kadar tatlı bakıyordu ki... Kucağıma aldım. Pek munis, pek mûtiydi. Sevincinden geğiriyor gibi sedalar çıkarıyordu. Vapura geldiğimiz zaman bütün yolcuları şaşırtık. Benim gibi hiçbiri beyaz, böyle kedi gibi okşanmasını sever maymun görmemişti.

Pire'ye uğradığımız zaman, bu güzel maymunu satmak istedim. On liradan ziyâde veren olmadı. Tama ettim. Elden çıkarmaya karar verdim. Ne olacak, Yunan memleketi! İşte kimse, şu güzelim hayvana, fiyatını vermemişti. Artık yolculuğum, mahalli memuriyetime yaklaştıkça, rüyalaşıyor, hızlaşıyor gibiydi. Preveze'den, Yanya'dan geçtim, Telgrafhaneye geldim. Burası güzel bir yerdi. Bağlık, bahçelik... Uzaklar... Mavi dağlar... Sonra erguvanî dağlar.... Telgrafhanenin yüksek pencerelerinde tatlı bir rüzgar çırpınırdı. Kasabanın hemen bütün ahalisi Rum'du. İlk günler, uzun sıkıntılar içinde, süzülüp geçtiler. Ben annemin: — Üç aya kadar... Vaadine zaten inanmadığımdan, uzunca bir hayata hazırlanarak harekatımı tanzim ettim. Benden evvelki memur galiba biraz feylesof meşrepmiş! Kirli odayı temizlettim. Koltuk pek kirli olduğundan üzerine bir kılıf yaptırdım. Ondan sonra başladım mektuplar yazmaya... Ara sıra da telgraflar...

Etraf telgrafçıları, telgrafla:  
— Hoşgeldin!  
Diyorlardı. Ben:  
— Hoşbulduk...  
Cevabına, muhabereyi uzatmamak için:  
— Çok rahatsızım!  
Yalanını da ilave ediyordum. Bu yalanı, onların gevezeliklerinden kurtulmak için uydurmuşken, daha beter yakalandım. Her sabah hepsi, hemen bütün kazaların telgrafçıları:  
— Bugün iyi misin?  
Diye soruyorlardı.

Bu telgrafçılık âlemi başka bir âlemdir. Makinenin başında yalnız bulunduğunuz halde, fersahlarla uzaktaki bir meslektaşınızla daimi bir temasta bulunursunuz. Birbirinizi görmeden bu temas o kadar sıkışır ki, o kadar büyür ki... Hatta bazen, birbirinize darılır, barışırsınız. Evvela isminizi, yaşınızı, evli misiniz, bekar mısınız gibi içinizi, dışınızı soran bir arkadaş, bir hafta sonra en teklifsiz muhiblerinizin soramayacağı şeyleri sorar.

Ben, bu hali bildiğim için, telgraf muhaberelerinde kısa cevaplar veriyor, onların gevezeliklerini soğuk bir ciddiyet içinde boğuyordum. Koltuğumun bulunduğu pencere gayet geniş bir bahar muhitine açılıyordu. Saatlerce oradan bakardım. Sefâhatle, vakitsiz çapkınlıklarla yıpranan sıhhatim, yavaş yavaş yerine geliyordu. "Uyumayan genç, uyuyan ihtiyar hastadır" düsturunu hatırlayarak bol bol gelen uykulara mukavemet etmez, hemen koltuğumun üstünde dalar giderdim. Maymunum bana uslu, mutî bir arkadaştı. Her işime yarıyordu. Su işaret edersem su verirdi. Ben uyurken, gerek gündüz olsun, gerek gece, muhabere çanı çalınınca koşup uyandırırdı. Yine bir gün öğle yemeğinden sonra idi, hafif bir uykuya dalmıştım. Saçlarımın arasında belirsiz bir temas hissettim. Yavaşça gözlerimi açtım. Maymunum beni seviyordu. Saçlarımı okşuyordu. Bu küçük, zayıf, beyaz, yumuşak ellerin okşamasında garip bir tesir duyarak uyudum. Uyanınca, onu karşımda, gözlerini bana dikmiş, gördüm. Artık bu, her gün böyle idi. Beni okşar, sever, sonra karşıma geçer, uyurken beni seyrederdi.

Bir sabah yüzümü yıkamış... Pencereye dayanarak sisler altında titreyen uzaklara, güneşle parlayan bulutlara bakıyordum. Kapı birdenbire açıldı. Başımı çevirdim. Pek genç, pek güzel bir kız... Yalnız Rum kızlarına mahsus olan o serbest şuhlukla Rumca sordu:  
— Muhabere memuru siz misiniz, Efendi?  
Ben:  
— Evet, dedim, ne yapacaksınız?

İhtiyar babasına buraya sağ ve salim geldiğine dair, tel vuracakmış. Telgrafı çekti. Kız o kadar serbestti ki... On dakika içinde on senelik laflar konuştuk. Babası Atina'da bakkalmış.. Kendisi Yanya'da teyzelerinin yanına misafir gelmiş, burada tebdîl-i hava yapacakmış. Matmazelin hoşuna gittiğimi hissettim. — Burası çok iyidir ama, kalabalığa alıştığınız için canınız sıkılacak. Deyiverdim. Pek çabuk dost olduk. Ertesi gün telgrafhanenin önünden geçerken selam verdim. Gülerek mukabele etti. Dostluğumuz ilerledi. Telgrafhanenin önündeki ağaçlıkta saatlerce beraber geziyorduk. İsmi Elen Teodor idi. Ne çok zekiydi, ne de aptal. ama son derece serbestti. Atina'da Fransızca öğrenmişti, edebiyatı, yalnız mektepte okuduğu Racine, Corneille, Fénelon'dan ibaret sanıyordu.

Bir akşam yine beraber, o gölgeliklerde havai, mânâsız şeyler konuşuyorduk. Maymunun bizden tarafa geldiğini gördük. O:  
— Niçin geliyor?  
Diye sordu. Ben:  
— Bilmem, bakalım ne yapacak?  
Dedim.

Maymunum eteğimden çekiyordu.

Bir sedası vardı ki, onu çıkarınca muhabere çanının çaldığını anlardım. O seda ile haykırdı. — Bana müsaade, matmazel, alınacak telgraf var... Diye ayrıldım. Küçük telgrafhaneye yaklaşırken maymunun pek memnun olduğunu görüyordum. Koşarak içeri girdim. Maymun gelmemişti.

Makineyi yokladım, hiçbir taraftan işaret yok. Çıngırak çalmıyordu. Öteye beriye sordum, hiçbiri beni çağırmamıştı.

Acaba maymun beni aldatmış mıydı?

Elen'in yanına gitmek için kapıdan çıkıyordum. Bir vâveylâ işittim. Uzaktan genç kızın yüzünü tutmuş olduğunu gördüm. Nefes nefese yanına koştum. Parmaklarının arasından kanlar çıkıyordu. Telaşla ne olduğunu sordum.

Canının acısından gözlerini kapamıştı:  
— Maymun yüzümü yırttı!  
Diye cevap verdi. Hemen ihtiyar doktora koştum. Elen'i evine götürdük. Bereket versin ki yarası ehemmiyetli değildi.

Maymuna ilk defa hiddetlendim. Meğerse bu hiddetim sonuncu olacakmış. Odama girince, onun, masamın altına girmiş, parlak, memnun bir nazarla bana baktığını gördüm. Bir köşede duran kalın bastonumu aldım. Şiddetle vurmaya başladım. O korkmuyor, ama sanki şaşıyordu. Öfkemi yenemedim. ensesinden tuttum. Hızla dışarı fırlattım. Yere düşünce bana öyle bir bakışla baktı ki... Hâlâ unutamam.

O gece kapıyı tırmaladığını, beni çağırdığını duydum. Ses çıkarmadım. Ertesi gün kayboldu.

Üç gün görünmedi.

Dördüncü gün bir köylü:  
— Su başında, kayaların arasında buldum.  
Diye onu getirmişti. Lâkin nasıl, biliyor musunuz? Zayıf, hasta, pis, halsiz, perişan...

Mutlaka dört gündür bir şey yememiş olacaktı. En sevdiği fındıklardan verdim. Bakmadı bile... Gözlerini kapadı. Öğürmeye başladı. Sanılırdı ki ağlıyor... Hiddetim tamamıyla geçtiği için bu kıymetli yadigara acımaya başlamıştım. Zorla yedirmeye, can vermeye çalıştım.

Fakat inat etti. Yemedi. İçmedi. Nihayet on gün sonra öldü. Açlıkla intihar etti.

Zavallı nazik maymuncuk, beni kıskanmış, sonra hakaretimden müteessir olarak kendini öldürmüştü. Onun beyaz ölüsü karşısında, beyaz ellerinin, beyaz ayaklarının, beyaz başının mazlum bükülüşü karşısında, o vakte kadar hiç duymadığım bir teessürle ağlamak istedim. Saçlarımın arasında onun okşayışlarını duyar gbi oluyordum.

Beni hakikaten seven, okşayan bir el...

Aradan zamanlar, mukaddes hatıraların gamlı eserlerini dağıtarak, geçti. Ben ki, hâlâ kıskançlık nedir bilmem. Bu maymun deliliğini hatırlayınca garip bir elem duyarım.

Bazı münasebetsiz hisler vardır ki, hayvanlarda insanlardan şediddir! Mesela eşeklerdeki inat, köpeklerdeki sadakat, kedilerdeki nankörlük gibi...

Acaba kıskançlık da böyle bir şey mi?

# Kızıl Elma Neresi?

"...Hemen göstersünler. Dalkılıç olur, düşmanı  
harâb iderüz ve kralın tac ü tahtını başına  
geçürüp Kızıl Elma'ya dek giderüz.."

Kocasekbanbaşı

— Kızıl-Elma'ya...  
— Kızıl-Elma'ya...  
— Kızıl-Elma'ya gideceğiz!  
. . . . . . . .

Zamanın Süleyman'ı, ansızın... Kükremiş bir tufan halinde akseden bu naraları duydu. Otağında yalnızdı. Yarım saat evvel dağılan Dîvân'ın cenk için gösterdiği kahraman arzuyu düşünüyordu. Bugün, yalnız vezirleri değil, kazaskerleri, defterdarları, nişancıları, "ağa, kethüdâ, serdar, yayabaşı, bölükbaşı, vekilharç" gibi, yeniçeri zâbitlerini, hatta solakları bile çağırmış, hepsini huzurunda toplamıştı. Hepsi ".... Kafdağı'na kadar arkandan gelmeye hazırız, padişahım!" diye ayaklarına kapanmışlar, gözlerinden sevinç yaşları dökmüşlerdi. İşte şimdi "sefer kararı" ordu içine yayılmış olacaktı. Otağın biraz uzağında... Küçük meşe ormanının nihayetindeki mahşerde, deminki Dîvân'ın sevinci, büyük bir heyecan ummanı gibi kaynıyor, kabarıyor, kabarıyor; bu ummanın görünmez, işitilir dalgaları, yakın ufukların bulutlu sahillerine değil, sanki bütün cihanın tâk ına çarpıyordu:  
— Kızıl Elma'ya...  
— Kızıl Elma'ya!  
— Kızıl Elma'yacak....  
. . . . . . . .

Padişah, tahtından yavaşça ayağa kalktı. Sağ elini altın koltuğa dayadı. Gökten inen, mânâsı anlaşılmaz bir sese kulak verir gibi başını büktü. Ordunun velvelesini dikkatle dinledi. "Kızıl Elma, Kızıl Elma...." Bu ismi şehzadeliğinden beri binlerce defa duymuştu. Sonra tekrar tahta oturdu. Gözlerinin üstüne kadar eğilmiş yusufiyesini geri itti. Gayet çıkık, geniş alnını, esmer uzun parmaklarıyla tuttu. Düşündü. Düşündü. — Kızıl Elma neresi? Diye mırıldandı. Şarkta olsun, garpta olsun, sefere çıkarken galeyana gelen asker hep "Kızıl Elma'ya!.." diye bağırışıyordu. Bu narayı yeniçeri kışlalarında, sipahi ocaklarında, geçit resimlerinde, hatta İstanbul'da, sarayın iç bahçesinde bile duymuştu. Kızıl Elma neresiydi? Üvez rengi sırmalı perdenin arkasında nöbet bekleyen Mahmud'u çağırdı: — Sadrazama söyle, vezirlerle beylerbeyini, kazaskerleri toplasın. Hemen karşıma gelsin! Dedi.

Yarım saat evvelki büyük Dîvân'dan çıkan vezirler, niçin yine huzura çağırıldıklarını ürkek bir ıstırap ile merak ediyorlardı. Ahmed  Paşa'yla Hadım Ali Paşa'nın arkasından kazaskerler, Sokullu Mehmet Paşa, Haydar Paşa, Ayas Paşa, İskender Paşa, gözleri yerlerde otağa girdiler. Birer birer tahtın saçağını öpüp el bağladılar. Padişah, beyaz tülbent sarılı, çifte tuğlu yusufiyesini yine çok öne eğmişti. Kaşları hiç görünmüyordu, yüzü her vakitkinden daha sertti. İnce murassâ direkler üstüne kurulmuş donuk zümrütten bir kubbeyi andıran otağın loş sükûnunu:  
— "Kızıl Elma" neresi? İçinizden bilen var mı?  
Suali bozdu.  
— !  
— ?  
— !...  
— ?..  
. . . . . .

Kimse cevap veremedi. Herkes önüne bakıyordu.

Padişah:  
— Bunu sormak için sizi çağırdım, dedi, otağımızın etrafında daima bu narayı işitiriz. İşte bakınız. Yine "Kızıl Elma'ya Kızıl Elma'ya..." diye bağırışıyorlar.... Burası neresidir? Binlerce defa ismini işittiğim bu memleketin neresi olduğunu öğrenmek isterim.  
Tamışvar fâtihi Ahmet Paşa kekeledi:  
— Viyana olsa gerek, padişahım....  
Padişah, öteki vezirlere döndü:  
— Öyle mi?  
— ....  
— ....  
— ....  
Ne "evet" ne "hayır" diyebiliyorlar, önlerine bakıyorlardı. Padişah, orduya getirdiği "kaplan postlu, kurt taçlı, çekirdek mahmuzlu, tekne kalkanlı, tepeden tırnağa kadar demire garkolmuş, elleri kostaniçeli, ak kızıl bayraklı", emsali görülmemiş mükemmel alayı ile iki gün evvel teveccühünü kazanan Rumeli Beylerbeyine sordu:  
— Sokullu! Sen söyle, Kızıl Elma neresi?  
— "Roma" olsa gerek, padişahım!  
— Ne biliyorsun?  
— Öyle sanırım.  
— Sanmak bilmek değildir...  
. . . . . .

Padişah, sırasıyla âlim kazaskerlere de sordu. Kızıl Elma için kimi "Çin", kimi "Maçin" diyordu. Ayas Paşa:  
— Hind'dir.  
Haydar Paşa:  
— Sind'dir!  
İskender Paşa:  
— Kafdağı'nın arkası olsa gerektir.  
Dedi. Büyük padişah, anlamak istediği şeyi kimsenin bilmediğini görünce, canı daha beter sıkıldı. Tahtın koltuklarını asabiyetiyle tuttu. Âdeti olmayan bir hiddetle kazaskerle döndü. Acı acı gülümsedi:  
— Yazık sizin ilminize!  
— ...  
. . . . . .

"Her şeyi biliyoruz!" sanan bu "Horasanî" kavuklu başlar uğradıkları hakaretin altında hafifçe sallandılar. Onlar, her şeyi kabul edebilirlerdi. Lâkin cahilliği? Asla.... Ortalarından, kara sakallı, bastı bacak, şişman bir fakih, bir adım ilerledi. Bu hem en âlimleri, hem en cesurlarıydı: — Padişahım! dedi, bu "Kızıl Elma", halk kullarının uydurduğu bir efsanedir. Ne aslı vardır, ne faslı... Bir hakikat değildir ki, biz bilelim. Halk ise, padişahım, bilmez söyler.

Zamanın hâkim Süleyman'ı altın koltuğa dayalı elini kaldırdı:  
— "Halkın dediği! Hakkın dediği!"  
— ...  
Bodur kazasker, bu sözden bir şey anlamadı.

Padişah devam etti:  
— Bu bir hakikattir! Mademki halk söylüyor; halktan gelen ses, Hakk'ın sesidir! Ona efsane denmez. Mutlaka bir aslı vardır. Fakat siz bilmiyorsunuz....  
— Ne şeriatta ne ilimde böyle bir isim yoktur ki, müsemmâsı olsun...  
— Ne şeriatta ne ilimde böyle bir isim yok diyorsun....  
— Evet padişahım.  
— Lâkin örfte yok mu?  
— ...  
Fakih düşündü. Önüne baktı. "Yok!" diyecekti. Fakat, işte sefer eğlentisi yapmaya başlayan büyük ordunun velvelesi içinde "Kızıl Elma'ya" naraları birbiri arkasına çakan şimşekler gibi gürlüyordu. Asker yalnız sefere gideceği, muharebeye gireceği zaman değil, hatta şımardığı, isyan ettiği vakitlerde bile bu narayı savurmuyor muydu? Bu daima taşan, kabaran, coşan bir kuvvetin ne olduğu bilinmeyen bir gayesi idi. Daha medresede minimini bir çömezken sipahi, yeniçeri bölüklerinin bu narayı bastıklarını işitirdi. Bunu iyice hatırlıyordu. Ama, aslının ne olduğunu merak edip öğrenmemiş, okuduğu metinlerde bu isme dair bir şeye rastgelmemişti. Yutkundu. Önünde bağlı duran ellerini sıktı. Artık "Kızıl Elma örfte yoktur" diyemezdi. Çünkü... İşte.... Duyuyordu!  
— Var padişahım!  
Dedi.  
— Öyleyse müsemmâsı da var.  
— ...  
Fakih sustu. Kızardı. Bir adım geriledi. Yine önüne baktı. Örfün hakikatini şeriat da tasdik etmiyor muydu? Padişah, bunu bilen fâzıllardandı. Karşısında safsataya imkan yoktu. Öbür kazaskerler arkadaşlarının mağlubiyetine bakarak, ağız açmadıklarına için için seviniyorlar, "Sükût sözden hayırlıdır!" hikmetini hatırlıyorlardı. Padişah yine acı acı güldü:  
— Dünya ne tuhaftır! dedi. Siz işte bu halkın başlarısınız. Bu halkı idare edersiniz. Halbuki onun istediği şeyin ne olduğunu bilmezsiniz..  
— !...  
— .....  
— .....  
— .....  
. . . . . . .

Lâkin hâkim padişah, kahraman, ârif, fâzıl, şâir olduğu kadar da insaflıydı! Her şeyi evvela kendi nefsinde muhakeme eder; her hükmü, her kararı vermezden evvel bir kere kendi vicdanından geçirirdi. Huzurundaki kulları sualine bir cevap bulamamaktan kıvranırlarken, o da sıkıldı. "Derûnî lisanla" kendi kendine sordu:  
"Ey Süleyman! Bunlara sorduğun şeyin ne olduğunu acaba kendin bilir misin?"  
"Bilmem ama.."  
"Ama?"  
"...Sezerim!"  
Azıcık ferahladı. Sezdiğini düşünmeye başladı. Bu, tabiatın, ilmin, irfanın ötesinde bir hakikattı. Evet, işte "Kızıl Elma", ne olduğunu sanki biliyor, fakat söyleyemiyordu. Halbuki bu vezirler, kazaskerler, beylerbeyleri.... Hayır, hiçbir şey sezmiyorlardı. Birisinin lafı ötekininkine uymuyordu. Kimi Çin, kimi Hind, kimi Sind, kimi Viyana, kimi Roma diyordu. Kızıl Elma bunların hiçbiri değildi! İçinden:  
"Belki hepsinden daha kıymetli bir yer!"  
Dedi. Sonra, utançlarından kızaran kullarına sordu:  
— Kızıl Elma'nın neresi olduğunu kimden öğrenebiliriz?  
— ....  
. . . . .

Herkes önüne bakıyor, yanlış bir şey söylememek için kimse ağzını açmıyordu. Yalnız İskender Paşa: — Padişahım! dedi, kazasker kullarının ilimleri kitaptandır! Vezir kullarınla, biz kölelerine gelince... Öyle derin âlimlerden değiliz! İşte ne kadar bilgisiz olduğumuz sual-i hümâyûnunuzla meydana çıktı. "Bin âlimin bilmediğini bir ârif bilir" derler. İrade buyurun. Bir ârif bulalım. Ona sorun. — Ârif kimdir? — Bilmeyip sezen, padişahım... . . . . .

Sonra İskender Paşa, saf bir askerin basit mantığı ile "Kızıl Elma, Kızıl Elma!" diyen halkın mutlaka bir şey murad ettiğini, kuşların ötüşünde bile kendi dillerince bir mânâ olduğunu söyledi. Kısa boylu, inatçı kazasker, halkın ne söylediğini, ne istediğini asla bilemeyeceğini tekrar iddia etti. Padişah, İskender Paşa'ya, çıkıp gizlice ordunun içine girmesini, nümâyiş alayında bağıranlardan rasgele üç kişi tutup huzuruna getirmesini irade etti. İskender Paşa çıkınca padişah kazaskerlere örfe dair ayrı ayrı sualler sormaya başladı. Vezirlerle beylerbeyleri, anlamadan, dinliyorlardı.

İskender Paşa, biraz sonra, otağa girdi:  
— Üç kişi tuttum, padişahım!  
Dedi.  
— Evvela bir tanesini getir bakalım.  
. . . . .

İskender Paşa, otağın mehâbet inde ürkerek sapsarı kesilmiş, başında perîşânî si dağılmış, tirtir titreyen bir adamı soktu. Bu, uzun boylu, pala bıyıklı, kuvvetli bir garipti. Orduda ayakkabıcılığı yapan serserilerden biriydi. Otağ kapısının dışındaki kapıcıların öğrettikleri gibi, tahta doğru gitti. Yeri öptü. Ayağa kalkmadı. Kolları göğsünde bağlı, dizüstü kaldı. Padişah sordu:  
— "Kızıl Elma, Kızıl Elma" dersiniz, bu, neresi?  
. . . . .  
Garip, işledim sandığı cürümden beraat için:  
— Herkes bağırır, padişahım. Ben de bağırdım, dedi.  
— Neye bağırdığını sormam. Kızıl Elma neresidir? Onu söyle!  
Garip tereddüt etmedi:  
— Padişahımızın bizi götüreceği yer!  
Dedi.  
— Orası neresi?  
— Padişahımız bilir.  
. . . . . .

Padişah, İskender Paşa'ya döndü:  
— İkincisini getir bakalım!  
Dedi.

Dizüstü duran garip, vezirlerin işaretiyle kalktı. Geri geri gitti. Perdenin yanında dikildi. Bu sefer huzura getirilen, tıknaz, esmer, beyaz keçeli, afacan bir yeniçeri neferiydi. Serbestçe yürüdü. Saçağı öptü. Kalktı, el bağladı. Padişahın "Kızıl Elma neresi?" sualine, düşünmeden: — Önümüze düşüp bizi götüreceğin yer... Padişahım! cevabını verdi. — Orası neresi? — Sen bilirsin padişahım! . . . . .

İskender Paşa üçüncüyü huzura soktu. Bu, geniş omuzlarına batarasının uçları düşen genç bir bostancıydı.  
— !..  
— Kızıl Elma neresi?  
— Atınızın gittiği yer... Padişahım!  
— Orası neresi?  
— Neresi olduğunu ancak padişahım bilir...  
. . . . .

Evet... Orası ne Hind ne Sind, ne Çin ne Maçin, ne Viyana, ne de Romaydı. Padişah, huzurundakilere: — Gördünüz ya, dedi, üçünün de cevabında bir fark yok. Hakikat bir! "Kızıl Elma" benim gitmek istediğim yer, işte... Hakk'ın beni göndereceği yer... . . . . . .

Doğruyu söyleyen bu üç kişiye hemen üçer yüz kese akçe ihsan etti. Artık "Kızıl Elma'ya, Kızıl Elma'ya" naraları çoğalıyor, taşıyor, daha ziyâde yaklaşıyordu. Padişah, birdenbire, Hakk'ın kendini göndereceği yeri düşündü. Nihayeti bulunmaz Hak yolunun, hakikat yolunun gittiği "Kızıl Elma" denen bu cennet karşısında, Viyana, Roma, Hind, Sind, Çin, Maçin birtakım fâni harabelerden başka bir şey miydi? Başını salladı. Arkasına dayandı. İri siyah gözlerini ufalttı. İlahî, manevi bir zevke varmış gibiydi! Müdebbir vezirlerinin, âlim kazaskerlerinin, kahraman beylerbeylerinin tekrar saçak öpüp çıkışlarını görmedi bile... Otağın kapısında, onlar da şimdiye kadar asla ulviyetinin, mehâbetinin farkında olmadıkları muazzam bir manzara karşısında donup kaldılar; sefer eğlentisi yapan yüz binlerce asker, kol kol olmuş, cirit oynayarak, kaynaşarak otağ etrafında geniş bir daire çeviriyorlar: — Kızıl Elma'ya... — Kızıl Elma'ya... Naralarıyla, sanki hayalin eremeyeceği derecede yüksek, pek yüksek bir arşa doğru... Kalkanlardan kanatlarıyla uçmaya hazırlanıyorlardı! Ve Osmanlı güçü !

# Mehdi

“Ve likülli kavmin hâd”

Ne tuhaf, fakat ne acıklı bir rastlantıydı! Serez istasyonundan bindiğimiz ikinci mevki kompartımanda beş kişiydik. Ve beşimiz de Türk Müslüman’dık… Geçen felaket ve bozgun yılının (1912, Balkan Savaşı) canlanmış da kalmış uğursuz ve karanlık damlalarına benzeyen birçok karga sürüleri, sahipleri öldürülen boş ve sürülmemiş tarlalarda dolaşıyordu. Tren hareket ettiği vakit hepimiz bir defacık selamlaşmış ve sonra, o yalnız esir ve perişan Müslüman memleketlerinden duyulan yakıcı ve dondurucu ağır tevekkülün taştan sessizliğiyle susmuştuk. Hava pek soğuktu. Kapalı camların ince buğularından, minareleri yıkılmış, mescitlerinin üzerine haçlar asılmış tenha köyleri görüyor gibi oluyorduk. Bu köyler uzaklarda, ta ufkun nihayetindeki mor sislerin içinde idi. Şimdi ezanın sustuğu bu öksüz yurtlara çanlarını ulutmak için, Selânik’e vapur vapur gelen Kafkasya Rumları yerleşiyorlardı. Susuyorduk. Ve sanki bize, milyonlarca kan ve din kardeşlerimizin ölümünü hatırlatan dışarısını, bu düşmanın öz vatanımızdan zorla kopardığı altın sahraları görmemek için önümüze bakıyorduk. Karşımdan bir ses:

— Kendimi Türkiye zamanında zannettim, dedi. Yanımızda hiç yabancı yok!

Gülümsedim. Başımı salladım. Bu ufak bir beydi Daha bıyıklan yeni terliyordu. Ellerini kaputunun bine sokmuş, bir şeyden ürküyor gibi başını omuzlarının arasına çekmiş, kumral ve ince kaşlarını yukarı kaldırmıştı. Zayıf ve kansızdı. Yüzü masivadan gölgelenen ruhani ve masum bir beyazlıkla parlıyordu. Öbür köşede pencerenin dibinde, beyaz sakallı, siyah cübbeli bir hoca, ihtiyar, hasta, güçsüz ve alacalı bir yığın gibi uyukluyordu. Yanındaki şişman ve yeni seyahat elbiseleri giymiş, siyah ve alafranga sakallı beyefendi bana baktı. Güldü. Onun karşısındaki sarı, uzun boylu, son moda elbiseli, kuvvetli ve gözleri parlak bir genç:

— Ah, bu dünya!.. dedi.

Susuyorduk. İki senedir sanki hiçbir şey değişmemişti. Bir an içinde “Türkiye idaresindeki Selânik’e gidiyorum.” hayaline kapılıyor ve kapıyı kırmızı fesli bir kondüktörün açacağım bekliyordum. Ve bilmem nasıl mantıksız bir cesaretle. Serezli ufak bey korkmuyor, içimizden birisinin Yunan hafiyesi olabileceğine ihtimal vermiyordu.

— Acaba buralarını ne vakit Türk askeri gelip alacak? dedi.

Ben daima bilmek, öğrenmek, anlamak, tanımak, anlatmak istemediğimiz şeylerin üstüne attığımız basmakalıp bir sözü ağzımdan kaçırdım:

— Allah bilir!

İhtiyar hocanın önündeki şık ve iri genç, kalın ve al burnunu küçük parmağının uzun tırnağıyla kaşıyarak:

— Allahın bildiği malum bir şey! Diye güldü. Lakin kul da bilir ki, artık buralara Türk ayağı basamaz.

— Niçin basamasın? Diye haykırdım.

Uyuklayan beyaz sakallı hoca uyandı. Başım kaldırdı. Bize ayrı ayrı baktı. Ben Yunanistan’da olduğumu unutmuştum. Ağaçlar, hendekler pencerelerin arkasından hızla geçip gidiyordu. Şişman ve pek zengin olduğu halinden anlaşılan beyefendi etrafına bakınarak:

– Yavaş konuşsak… dedi ve bana dönerek devam etti: Oğlum, eğer iftihar olunacak bir şeyse, hiç zahmet çekmeden ben de sizin kadar Müslüman ve mutaassıp olabilirim. Mülkiye-i Şahane’den çıktım. On sekiz sene kaymakamlık ve mutasarrıflık ettim. İşte size söylüyorum ki, Müslümanların yaşamaya hakkı yoktur. Ve Türkler asla bir daha buralara gelemez. Türkiye’de ağzıma alamayacağım hakikatleri burada sizden saklamaya lüzum yoktur. Zira hür ve medeni bir hükümet misindeyiz. Ne şu muhterem hoca efendi ve ne de siz dinsizliğimi, İslamlığın aleyhinde olduğumu iddia ederek kafamın kesilmesini, asılmamı isteyecek bir evvel zaman adaletini burada bulamazsınız; medeniyetleri, terakkileri, itilaları, tarihleri hep dinler yapar. Dinler bir kâinatı yıkar, yerine, ikinci bir kâinat kurar. Fertlerin bütün hareketlerindeki esasları kımıldatan, sosyolojide büyük hatlarını çizen dindir. İslamlık ise fertlerindeki cemaat ve milliyet eğilimlerini bozarak hepsini karanlık bir taassubun görmez körlüğü içinde yaşatır. Sözüme şahit, işte bütün dünya yüzündeki Müslümanlık… Yüz milyonlarca Müslüman ve bizim milletimiz olan elli milyon Türk, hâlâ on üç-on dört asır evvelki hurafeler ve efsanelerle çırpınıyor. Rusya’daki Türkler, Bosna-Hersek, Rumeli, Hive, Buhara, Acemistan, Türkistan, Afganistan, Bulucistan, Hindistan Mısır, Trablus, Sudan, Tunus, Cezayir, Fas, Sahra-yı Kebir, Zengibar, Cava, Somali, Sumatra… Daha sayayım mı? Hâsılı bütün İslamlık bugün gelişmiş, kuvvetlenmiş, ilerlemiş Hıristiyan milletlerin boyunduruğu altında… Yalnız bizim Türkiye’nin yalancıktan bir bağımsızlığı var. Ama ne bağımsızlık… Gümrüklerine on para zam edemez. Düşmanlarıyla rahat bir anlaşma yapamaz. Başkentteki Hıristiyan okullarının içine giremez. Kısacası İslam tarihinde okuduğumuz yüz şu kadar İslam hükümetinin mahvına sebep olan faktörler hâlâ Türkiye’de duruyor. Aynı kanunlar, aynı şeylere tesir edince neticeler de aynı olur. O halde Türkiye’nin de diğer Müslüman hükümetleri gibi mahvolacağı, tarihten namı silineceği ve biz Türklerin de bütün Müslümanlar gibi yakında İstanbul’u alacak olan Hıristiyan efendilerimize sadakatle dua ederek hayatımızı diğer dindaşlarımız gibi miskin miskin taassup, cehalet ve rezalet içinde geçireceğimiz muhakkak… ve…

Bu ateşli ve mutaassıp bir dinsizdi. Ona mantık ve kıyaslarını yaparken, hissine ve taassubuna kapılmamasını tavsiye edecektim. Susmasını, lafının sonunu bekliyordum. Serezli genç bey, kafasını zayıf omuzlarının arasından çıkarmış, güzel ve şahane gözlerini açmıştı. Mülkiye-i Şahane mezunu eski mutasarrıfın birdenbire sözünü kesti.

— Ya Mehdi? Mehdi çıkmayacak mı?

— Hangi Mehdi?

— Hangi Mehdi olacak? Daha onu bilmiyor musun? Mehdi çıkacak. Müslümanların başına geçecek. Gâvurların hepsini öldürecek. Bütün dünyayı Müslüman yapacak.

Şişman beyefendi tombul ve beyaz elleriyle kamım tutarak gülüyor, al yanakları pençe pençe kızarıyordu. İhtiyar hocanın karşısındaki genç de, zavallı Serez beyinin saflığına gülmekten kendini alamıyor.

— Ey küçük bey, bu Mehdi ne vakit çıkacak? Diye eğleniyor, bari yakında gelecekse nafile çiftliklerimizi yok pahasına gâvurlara satmayalım… Diyordu.

Lokomotif düdüğünü çalıyordu. Ben “Mehdi” bekleyen saf çocuğu nasıl müdafaa edeceğimi düşünüyordum. Öbür köşedeki beyaz ve büyük sarıklı, ihtiyar ve sakin hoca efendi doğruldu. Büyük, derin ve küçük gözlem açtı. Siyah ve kalın cübbesinin temiz eteklerini düzeltti. İlk defa ağzım açıyordu.

— Mehdi’ye gülüyorsunuz ha… dedi.

Ben yeryüzünün dümdüz olduğunu, balığın üzerinde öküzün boynuzunda tıpkı bir tepsi gibi durduğunu fenle ispata kalkacak bunak bir yobazım. Mehdi hakkında saçmalayacağı budalalıkları duymamak için başımı pencereye doğru çevirdim. Hoca efendi, yabancı olmadığını garip bir tecvidin ağır ve hususi ahengiyle lafa başladı. Ama ben de artık dışarı bakamadım. Onu can ü gönülden dinlerken, Serezli genç bey gibi benim de ağzım birkaç santimetre açık kaldı.

— Bu Mehdi kimdir, biliyor musunuz evlatlar? Gaib olan on ikinci imam! Bütün Müslümanlar onun gelmesini bekliyorlar… Bu şüphesiz bir hayal. Bu hayalin nereden ve nasıl tesirlere çıktığım size söyleyeyim: İslamlık bir mefkûredir. Öyle yüce, metin, yüksek bir mefkûre ki… Taarruzi her Müslüman, İslam olmayan memleketleri almak, oralarını hep Müslüman yapmak emelini besler. Zaman, fitneler ve nifaklar arasında geçmiş, İslam hükümetleri birer birer yıkılmış. İslamlar esir düşmüşler. Fakat her esir Müslüman’da İslamlık mefkûresi şuursuz bir anane bir ümit, bir emel bırakmış. Esirliğin ağır ve ateşli zincirleri altında inleyen her Müslüman, bir kurtuluş gününden ümidini kesmemiş. Ve bu ümidinin fiile çıkarılmasını tekrar bir gün meydana çıkacak olan on ikinci imama, Mehdi’ye atfetmiş. Bu Mehdi İslam milletlerini şuursuz bir emniyetle beklediği kurtarıcı çıkıp bütün Müslümanları acıklı durumdan kurtaracak mı? Bütün İslam diyarlarında, Rumeli’nin, Asya’nın, Hindistan’ın köylerinde, Afrika’nın vadilerinde Müslümanlar hep bir kurtarıcıyı, bir Mehdi’yi beklerler; Mehdi ‘ye dair birçok masallar, hikâyeler vardır. Bunlara büyük ve perişan bir ümmetin yaralanmış ruhunda uyuyan en garip ve muhteşem şiirler de karışır. “Ak Minare” vesaire gibi… Lakin bu mehdi sahiden gelecek mi? Hayır ve evet… İslam ruhu şuursuz bir saflık ve güvenle her halasçı gibi sivrilen kahramana bu ad verir. Fakat o muvaffak olma”Mehdi” kelimesi “mütemehdi” olur. Yine hakiki Mehdi beklenilmeye başlanır. Ama… Ama hayır… Öyle bir Mehdi ortaya çıkıp bütün İslamları birleştirerek istilacılardan bir anda intikam alamayacaktır. Lakin bu esirlik de kıyamete kadar sürecek mi? Hayır, hayır. Mutlaka bir gün İslamların öcü alınacaktır. Ama nasıl? Buna büyük ve mukaddes kitabımız Kur’an-ı Kerim cevap veriyor. Diyor ki: “Ve likülli kavmin hâd.. ” Evet, bütün kavimlerin kendilerine özgü hâdileri vardır. Onları hidayete eriştirir. Mesela Bosna-Hersek’teki Müslümanları halife gidip kurtaramaz. Onlar çalışırlar, içlerinden bir fedakâr, birçok fedakâr çıkar. Silaha sarılırlar. Esirlikten kurtulan Hıristiyan milletlerin kurtarıcılarını taklit ederler. Cezayir’dekiler, Fas’takiler, Tunus’takiler, Sudan’dakiler, hatta Mısır’dakiler de öyle… Başka yerlerdekiler de öyle… Kendi içlerinden, kendi kavimlerinden kurtarıcı hâdiler yetişecek. Mensup oldukları kavmin başına geçecekler. Sonra… Esirlikten kurtulan, kafaları ilim ve akıl tutmaya başlayan İslam milletler, Hıristiyan milletler gibi, aralarında bir “Uluslararacılık” teşkil edecekler ki işte bu “İttihad-ı İslam” mefkûresinin hakikatidir. Artık bu “İslam uluslararacılığı” mefkûresi hakikat haline girince, ‘Hıristiyan uluslar aracılığı” yani Avrupalılar, zayıf ve korumasız buldukları küçük İslam kavimlerin üzerine hep birlikte yüklenemeyecekler. İşte bu dengeden dünya yüzünde ancak o vakit “hak ve hukuk” doğacaktır. Bir kavmin hâdileri, o kavmi gaflet cehalet, idraksizlik uykusundan uyandıranlardır. Biz Türkler kurtarıcılarımızın elindeki mukaddes ve hidayet ışıklarının aydınlattığı milli bir mefkûreye doğru yürüyerek, altında inlediğimiz zincirleri kıracak, diğer Türk olmayan İslam kardeşlerimizin bile imdadına yetişeceğiz. Ve bizim gibi her İslam kavim de kendi hâdisini beklemekle haklıdır. Bu müjdeyi biz Müslümanlara Kur’an-ı Kerim vermiştir. Evet. İşte Kur’an-ı Kerim elimizde… Bir Mehdi yoktur. Fakat birçok hâdiler olacaktır.

Halk tabakası, o tek ve hayali Mehdi’yi beklerken biz, Türk, Arap, Fas ve diğer İslam düşünürleri, kendi hâdilerimizi, hakiki Mehdileri beklemeliyiz. Ve onların ortaya çıkıp çıkmayacaklarından bir an için olsun şüphelenmemeliyiz…

Bilmem hangi istasyonda durmuştuk. Trenin kapısı birdenbire açıldı ve ihtiyar hoca susuverdi. Esmer bir kondüktör, silindir şapkalı bir Ruma:

— Buyurunuz… Diyordu.

Bu herif bize tarif olunamayacak derecede derin bir nefret ve tiksintiyle bakarak, Rumca:

— Fakat burada Türkler var! Diye durdu.

Suratını ekşiterek hepimizi ayrı ayrı süzdü. Kahraman kondüktör hemen yararlığını gösterdi:

— Haydi bre… Öbür başa toplanın! Burada pencerenin önünde mösyö rahat edecek…

Hoca ile karşısındaki genç yüzlerini yere eğerek bizim tarafımıza gelip sıkıştılar, giren şık ve küstah mösyö, şapkasını çıkarıp, ayaklarım karşıki kanepenin üstüne uzattı. Adeta yattı. Sigarasını yaktı. Tek gözlüğünü takarak bize bakmaya başladı. Sözünü tamamlayamayan ihtiyar hoca yaralı ve can çekişen düşkün bir aslan gibi yeniden uyuklamaya başlamıştı. Şimdi biz, yine, o yalnız esir ve perişan Müslüman memleketlerinde duyulan yakıcı ve dondurucu ağır tevekkülün taştan sükûnuyla susuyorduk.

Yolcu mösyö, sigarasının küllerini üzerimize fırlatıyor, tükürüyor, sonra avazı çıktığı kadar Bizans İmparatoru ve Yunanistan Kralı XII’inci Konstantin için bestelenmiş Fransızca bir şarkıyı haykırıyordu.

Biz susuyorduk… Tren seyrek ve fasılalı ağaçlıkların arasından geçiyordu. Ve Türklerden kalma san badanalı eski karakollar, bu yollardan kaçarken mahvolmuş gafil bir milletin dinsiz ve yıkık mabetleri gibi, ikişer, üçer kilometre ara ile sıralanmış hâlâ duruyordu. Susuyorduk. Zannederim hepimiz —hatta İslamlıktan ümidini kesmiş olan açık fikirli, şişman mutasarrıf emeklisi bile— hepimiz, mukaddes kitabın her kavme vaat ettiği hâdileri düşünüyor, Türklerin Mehdi’sinin ne vakit çıkacağım kendi kendimize soruyorduk. Yolcu mösyö Türklüğe ağza alınmaz küfürlerle kafiyelenmiş Rumca şarkılar da bağırmaya başlamıştı. Biz susuyorduk. Ve benim gözlerim, hep o beyaz bir kurtuluş ve ümit şafağının uzak bir aksi gibi parlayan beyaz sarığa, ihtiyar hocanın uyanık bir dalgınlıkla sallanan büyük ve nurlu başında dalıyordu.

# Müjde

Sabaha yakındı. Arkamızda bıraktığımız tepelerin üstü morlaşıyordu. Genç şairlerle bizi siperlere doğru götüren arabalar, karanlığın içinde, birbirinden intizamsız kafilelerle ayrılmış tıpkı bir “dargın seyyahlar” kervanı gibi ilerliyordu. Sağımızda siyah körfezin denizi, uyanık dalgalarıyla ötüyor, sazlığa benzeyen karaltılar ta sahile kadar uzanıyordu.

Yarımadanın berzahındaki bu geniş yol biraz tehlikeliydi. Sigara içilmeyecek, kibrit, fener yakılmayacaktı. Ömründe ilk defa harp mıntıkasına giren acemi bir asker heyecanı duyuyorduk! Gözlerimiz görünmeyen ufuklarda kruvazör, torpido hayalleri arıyordu. Araba arkadaşım şairlerin gözlükçülük:

– Bakın, diye açık perdeden parmağını uzattı, bir ziya var. Hafif bir ziya…  
– Nerde?  
– Denizin ortasında…

Öteki şairle beraber ben de onun gösterdiği tarafa dikkatle baktım. Hiçbir şey göremedim. Bu genç gündüz bile çok uzağı görmüyordu. Gülüştük. Sanki şosenin kenarında bizi dinleyen bir kulak varmış gibi yavaş bir sesle konuşmaya başladık:

– Torpido falan olsa zaten aydınlık göstermez.  
– Ama bacasından bir kıvılcım çıksa yine görünür.  
– Tutalım ki kenarda bir torpido var. Yoldan geçen her arabaya ateş eder mi?  
– Eder ya…

Şairlerin en genci bana:

– Niçin edecek? diye sordu.

Latife etmek istedim:

– Düşman her arabayı cephane farz etmeye mecburdur.  
– Yok canım…  
– Ya arabadakiler yaralılarsa?..  
– Yaralılar geceleyin, fenerleri söndürülmüş arabalarla gizlice götürülmez…  
– Eee?..  
– …

Yolun birkaç kilometre süren sahil kısmını, konuşurken nasıl geçtiğimizi duymadık. Yine denizin sesi sustu. Yine küçük tepelerin mahmur sükûnu başladı. Göğün morlaşan kenarı eriyor, menekşe rengine giriyordu. Etrafımızdaki çalılar uyumuş seyirci gölgeler gibi göründü; arabamız durdu. Eğildim:

– Ne oldu? diye arabacıya soracaktım. Bize refakat eden nazik zabiti fark ettim.

– Artık yine toplu gideceğiz. Yol mahfûzdur, sahilden görünmez. dedi.

Geridekilerin yetişmesi için küçük bir mola verilecekti. Hemen aşağı atladık. Her gelen arabayı sanki uzak bir gurbetten dönüyormuş gibi karşıladık. Yarım saat geçmeden kafilemiz yine hareket etti. Göğün menekşe renkli kenarı pembeleşiyor, küçük yıldızlar siliniyordu. Bütün ufuk şimşek çakmış gibi ansızın aydınlandı; havada büyücek bir ateşin parladığını, doğuya doğru yeşil, sarı, sincabî alevler saçarak düştüğünü gördük.

– Top güllesi!  
– Bomba.  
– Tayyareden atıldı.  
– Gece tayyare uçar mı?  
– Ya bu ne?  
– Şahap.  
– Hayır…  
– …

Ben:

– Hacer-i semavî olmalı. dedim.

Gülle, bomba, tenvir tabancası olmadığına şüphe yoktu! Pek yükseklerden tutuşmuş, pek uzaklara, pek çok uzak ufuklara düşmüştü. Ama şahap da değildi. Çok büyük, çok renkli, çok ihtişamlıydı. Ardında bir müddet sönmeyen altın bir iz bırakmıştı.

Genç şairler arabalardan atlıyorlar, gördükleri şeyin ne olduğunu münakaşa ediyorlar, bizi götüren zabitin landosuna koşuyorlardı. Düz yolda arabalar yavaş yavaş gidiyordu.

Bilmem ne kadar gittik. Göğün deminki harikası unutuldu. Artık sabah olmuştu. Hafif, şeffaf bir sis fundalıkları dolanıyor, güneşin damlaları yaprakları yaldızlıyordu. Arabalar sabah molası için durdu. Asker kıyafetine girmiş, kabalaklı muharrirler, genç şairler şoseye indiler. Sanki hepsi arabalarda oturmaktan, yatmaktan yorulmuşlar, şimdi ayakta durmak, dolaşmak, dinlenmek istiyorlardı. Ben daha arabadaydım. Bir ses işittim:

– Havaya bakın, arkadaşlar, havaya bakın!

Eğildim. Gözlerimi yukarı kaldırdım. Hava gayet parlak, gayet açık mavi, gayet saftı. Bulut filan yoktu. Aynı ses tekrar haykırdı:

– Bakın, “fethün karib” görmüyor musunuz?  
– Ne, ne? – Ne tarafta?..  
– ?  
– …  
– !

Herkes yukarı bakıyordu. Ben de aşağıya atladım. Onların yanına gittim. Gökte dolaşmış, şeffaf bir kurdele gibi ince, belirsiz bir duman yığını vardı.

– “Fethün karib” değil mi? işte… – …

Hakikaten havadaki bu ince duman yığını tıpkı girift bir sülüs yazıya benziyordu. Benim gözüm de bana rağmen “fethün karib” terkibini okuyordu.

– Deminki “hacer-i semavî” hadisesinin bıraktığı iz olacak! dedim. Kimse işitmedi bile… Hepsinin gözü gökteydi. Hepsi, Allah’ın işaretini gören müminler gibi dalgındı. Müphem bir vecd içindeydi. Yalnız kafilenin genç doktoru bu büyük manevi işarete sonradan görmeyenleri de inandırmak için, minimini Kodak’ını havaya kaldırmış, “fethün karib” müjdesinin fotoğrafını çekmeye çalışıyordu.

Bu ince, bu şeffaf duman yığını epey müddet gökte durdu. Yavaş yavaş silinirken bile şekli bozulmuyor, sarih bir katiyetle okunuyordu: “Fethün karib”…

Genç şairler karargâhlarında kumandanlara, siperlerde zabitlere, neferlere hep parlak, mavi göğün –o gelirken gördükleri– büyük müjdesini büyük bir imanla, büyük bir samimiyetle anlatıyorlar, onları da kendileri gibi bu büyük mucizeye inandırıyorlardı.

Orada, Çanakkale’de ezeliyet fecrine giden gizli manevi yollara benzeyen uzun, nihayetsiz siperler içinde benim de – bilmem nasıl oldu – gelirken gördüğüm şeyin Tanrı eliyle yazılmış “fethün karib” müjdesi olduğuna şüphem kalmadı!

Hatta yavaş yavaş “Hacer-i semavî izinden kalan duman!” dediğime bile pişman oluyor, sanki ağır bir küfür ettikten sonra mabedine giren küstah bir günahkârın vicdanındaki azapları duyuyordum.

Yeni Mecmua, C. 2, S. 36, 21 Mart 1918, s. 196.

# Namus

Daha geceydi. Çobanyıldızı derinlerden dünya üzerindeki uyumuş sürülere bakan tek bir göz gibi parlıyor, koyu karanlıklara mavi bir ışık akıtıyordu. Hapishanenin ağır, demir kapısı acı bir küfür gürültüsü ile açıldı. Jandarmalar, elleri arkasına bağlanmış zayıf, cılız, ürkek bir adamı dışarı çıkardılar. Siyah arabanın dar kapısından sokmak için kollarından yukarı kaldırıyorlardı. Elleri bağlı adam sağındaki sakallı jandarmaya döndü: — Nereye gidiyoruz be ağam? diye sordu. — Bilmiyor musun? — Bilmiyorum be... — Deminden imam efendi sana ne dedi? — "Lala, ala..." diye bir şeyler söyledi. Ben "Ne diyorsun?" dedim. "Benim dediğimi söyle!" dedi. Ben de onun dediğini anlamadan söyledim. — Öyleyse çok iyi ettin! cevabını veren jandarma, mahkûmu arabanın içine tıktı. Kendi de yanına girdi. Dışarıda kalan genç jandarma üstlerinden kapıyı kilitledi. Mavi alacakaranlığın içinde kamçı sesi, atların nal tıkırtıları, demir tekerlek gürültüleri işitildi.

Penceresiz arabanın içi tıpkı bir kutu gibiydi. Köşesinde küçük bir fener, sarı, ziyasıyla cidarlardaki gölgeleri titretiyordu. Mahkûm susmuyordu.

Tüfeğini yanına dayayan sakallı jandarma, tabakasından bir cigara sarıyordu. Güldü:  
— Yarım saat sonra ısınırsın! diye başını salladı.  
Konuşmaya başladılar. Bozuk kaldırımların sarsıntısı ha bire sözlerini kesiyor, ikiye bölüyordu:  
— Hamama mı gidiyoruz?  
— Hamama ama senin bildiğin hamam değil...  
— Nasıl?..  
— Sabunu var, suyu yok...  
— Benim abdestim var be ağam, niye beni hamama götürüyorsunuz?  
— Abdestini bozdurmak için!  
Mahkûm, jandarmanın alayından bir şey anlamıyordu. Sustu. O susunca, jandarma sormaya başladı:  
— Ulan senin kabahatin neydi?  
Mahkûm, yarasına dokunulmuş bir adam gibi haykırdı:  
— Namus, bre ağam, namus, namus, namus!  
Yerinden kalkıyor, çırpınıyordu. Bu namus heyecanı jandarmanın canını sıktı:  
— Ulan, Çingene'de namus olur mu? dedi.  
— Neye olmasın ağam, Çingene insan değil mi?  
— Karını başkasıyla mı yakaladın?  
— Hayır.  
— Kızını mı yakaladın?  
— Hayır.  
— Öyleyse niçin "namus, namus" diye bağırıp yırtınırsın. Ne oldu ki bakayım?..  
Mahkûm Çingene, felaketini hatırladı. Sarardı. Dudakları titriyordu. Hikâyesini anlattı:  
— Bir akşam dereye, yıkanmaya gitmiştim. Biraz geç kaldım. Çergeye döndüm. Ah namus, bre namus!..Bir de ne göreyim?..  
— Ne gördün?  
— Ah namus bre! Namus ağam.  
— Söyle canım, her vakit gördüğün bir şey olacak!  
— Hayır.  
— Ya ne gördün?..  
— Karım, kız kardeşim, anam,halam, küçük kızlarım, yengem taplanmışlar. Bir şeye bakıyorlar, hem gülüyorlar.  
Jandarma bunu pek merak etti. Cigarasını ağzından çekti:  
— Neye bakıyorlardı?  
Çingene tekrar "namus bre, namus" diye kafasını arabanın cidarına çarptı:  
— Bizim çomara Hasan'ın sarı erkek köpeği yapışmış. İçeri almışlar, seyrediyorlardı.  
Jandarma gülmekten katılıyordu:  
— Ey, sonra?..  
— Birdenbire hiddetlendim. "Sizin hiç utanmanız, arlanmanız yok mu?" dedim. Elime çotranın yanındaki bir balta geçti...  
— Ey?..  
— Hepsinin kafasına ayrı ayrı indirdim. Çomarı da ikiye böldüm. Hiçbiri kaçamadı. Hepsini geberttim. !!!!  
Jandarmanın cigarası parmaklarından düşmüştü. Çingene "namus bire, namus!" diye dövünüyor, araba daha ziyade sarsılıyor, daha ziyade takırdıyordu. Jandarma, karşısındaki sıska, kirli suratlı, pis herife bakarak yüreğinin çarptığını duyuyor, gayr-i ihtiyarî memleketinde Hıdırellez günleri yaptıkları eşek bayramını hatırlıyor, kendi namussuzluğuna şükrediyordu. Evet, bu Çingene gibi içlerinde bir iki namuslu adam olsaydı, bütün kasaba halkını, Hıdırellez günü yaylada kılıçtan geçirmek icap edecekti.

Araba, katilin dokuz insanı baltayla kestiği yerde durdu. Burası bir şose kenarıydı. Küçük kapının kilidini açtılar. Önde elleri bağlı Çingene, arkadan sakallı jandarma indi. Müddeiumumi, komiser, hâkim filan hepsi daha evvel gelmişlerdi. Arabalar bir katar gibi birbiri arkasına dizilmiş, yol boyunda duruyordu. Ortalık tamamıyla ağarmış, çobanyıldızı sönmüştü. Komiserle gelen jandarmalar, bir iskemleye binmişler, gülüşerek darağacının ipini sabunluyorlardı. Çingene, bu manzarayı görür görmez, gölgesinden ürkmüş bir Arap atı gibi şahlandı: — Ay, beni asacak mısınız? diye haykırdı. Kimse cevap vermedi. Herkes önüne bakıyordu. Komiser, elindeki yaftayı katilin boynuna geçirmek için ilerledi. Namus uğrunda şehit olacak bu bîçareye karşı herkesin kalbinde sanki gizli bir muhabbet, gizli bir hürmet vardı! Hele beyaz sakallı hâkimin gözlerinden şıpır şıpır yaşlar damlıyordu. O, kırk senelik memuriyeti esnasında bu verdiği hüküm kadar ağır hiçbir vicdan azabı duymamıştı. Evet, Çingene, mingene... Fakat ne büyük bir namus telakki siydi! Evet, ne büyük bir namus taassubu!.. Ama kanun... İşte o affetmiyordu. Ah, yoksa bizde ``jüri´´ usulü olsaydı, hemen bu dokuz canı birden alan Azrail'den müthiş katili beraat ettirecekti. Gayr-i ihtiyarî komiserin önüne geçti. Acaba bu kadar yüksek bir namus niyetiyle yaşayan bir insanın ölmezden bir dakika evvelki son arzusu ne olabilirdi?.. — Biraz dur! dedi. Şaşırmış Çingene'ye hıçkıra hıçkıra yaklaştı. Dizleri, elleri, dudakları titriyordu. — Allah kusurunu affetsin! diye söze başladı. Ben senin haklı olduğunu biliyorum. Ama ne yapalım? Başımız şeriata, kanuna bağlı! Dünyada son arzun ne? Bana söyle. Ne olsa yapacağım oğlum! Çingene, hâlâ sabunlanan ipe baktı. Sonra gözü yaşlı ihtiyar hâkime döndü: — Ne arzum olacak? Ne olsa sizin gibi namertler yapmazlar, dedi. Hâkim elini kaldırdı: — Vallahi, billahi, ne istersen yapacağım! Canımı istersen vereceğim! Söyle oğlum. — Söylemem, yapmazsın. — Yaparım. — Yapmazsın. Hepiniz yalancısınız. İnsanı aldatırsınız!.. — Aldatmam. Yaparım diyorum, evladım. — Yapmazsın hâkim efendi. İşte bütün buradakiler şahit olsun, yapmazsın!.. Hâkim, kendine bakan memurlara, polislere, jandarmalara bir göz gezdirdi. Vaadini katiyetle tekrarladı: — Bunlar şahit olsun, Allah şahit olsun, yapacağım!.. Ağzında zaptettiği hıçkırıklardan boğulacakmış gibi başını göğe kaldırıyordu. Doğru söylediği sesin azametinden, tavrının heybetinden, heyecanının ulviyetinden belliydi. Çingene biraz ferahlar gibi oldu. Gözleri parladı. Yutkundu. Heyet baştan aşağı kulak kesilmişti. Yaklaşan siyah ölümün soğukluğu hepsini sanki dondurmuş, taş kesmişti. Çingene öksürdü: — Pekâlâ, hâkim efendi, dedi, senden istediğim şu: Hüsmen'in sarı köpeğini buldur, gözlerinin önünde iğdiş yaptır. Herkesin ırzı, namusu kurtulsun. Hâkim, şaşkın şaşkın yüzüne bakarken, mahkûm susmuyor: "Namus, bre namus!.. Yaptırmazsan ahrette iki elim yakanda kalsın!" diye jandarmaların kolları arasında çırpınıyordu.

# Nasıl Kurtarmış?

Kasabada Kadı İbrahim Efendi'den hazzeden kimse yoktu.

Dört parmak siyah, çatık kaşlarıyla, küçük parlak gözleriyle, sık siyah sakallarının, ürpermiş canlı bıyıklarının arasından görünen iri beyaz dişleriyle, insana hemen saldıracak, ısıracakmış gibi gelirdi. Yüzü daima buruşuktu, buz tutmuş sirke kadar ekşiydi, hiç gülmezdi; pek sertti. En sakin lafı bile havlar gibi hamle hamle söyler, sonra birdenbire susuverirdi. Fakat, şöyle bakarken insana yüzüyle, hareketiyle, sözleriyle pek fena tesir bırakan bu doğru kadı, kendi kalbinin çok iyi olduğuna kâniydi. Herkesin iyiliğini isterim sanırdı. Herkesi acı sözleriyle haşlar ama elinden gelecek yardımı da saklamamaya çalışırdı.

Sertliğine, birdenbire alevlenmesine, bazen ağzından çıkan sözü kulağı işitmemesine itiraz edenlere: — Siz ne anlarsınız, halk beni gözü gibi sever! derdi. Bir cuma günü sabehleyin, Şadırvan Meydanında Avukat Hüsameddin Efendi'nin dükkânında oturuyordu. Hemen hemen kasabanın bütün eşrafı oradaydı. Namaz vaktini beklemeye gelmişlerdi. "Tatlı dil, güler yüz"den söz ediliyordu. Ömründe hiç gülmeyen Kadı İbrahim Efendi, işittiklerini hep kendine, kendi üzerine alındı. Müdafaa için ağzını açacak oldu. Düşündü, sustu. Fakat, eşraf efendiler münakaşalarında epey ileri gittiler.

Biri dedi ki:  
— Yüzü gülmeyen insan cehennemliktir!  
Bir diğeri daha beter saçmaladı:  
— Abus çehreli bir adamın ne namazı, ne niyazı, ne zekâtı, ne orucu makbuldür. Kalpte iman nuru sönünce, yüz kararırmış!  
... Hâsılı hepsi ayrı ayrı birer pot kırdı. O kadar ki, Kadı İbrahim Efendi dayanamadı. Tatlı dil, güler yüzün münafıklara mahsus, doğru sözün acı, haklı adamın de sert olduğunu söyledi. Dükkan sahibi Avukat Hüsameddin Efendi aynı zamanda kasabanın şairiydi de:  
— "Ayinesi iştir kişinin lafa bakılmaz..."  
diye kadıya itiraz etti. İnsanın fikrindeki neyse, zikrinde de o olduğunu tekrar ederek, iddiasını ispata girişti. Hazır bulunanların hepsi "tatlı dil, güler yüz" taraftarlığında ittifak etmiş gibiydiler. Kalbe, fiile kimsenin önem verdiği yoktu. Bu esnada dükkânın kapısında genç bir yörük peyda oldu. Elinde kocaman bir lenger tutuyordu:  
— Ne var? diyerek önüne giden Hüsameddin Efendiye sordu:  
— Kadı Efendi burada mı?  
— Burada.  
Kadı İbrahim Efendi, oturduğu minderin köşesinde doğruldu. Acaba bir dava, bir şikâyet miydi?  
— Ne var, söyle bakayım? diye çağırdı.  
Sarışın yörük:  
— Efendim, babam size şu yoğurdu gönderdi, dedi.  
— Niçin?  
— Şey...  
— Ben yoğurt filan ısmarlamadım.  
. . . . .

Dedikoducu eşraf birbirlerine bakıştı. Bu bir rüşvet miydi? Kadı İbrahim Efendi de sıkıldı, bozuldu. Koca bir lenger yoğurt... Ne münasebet! Kan beynine sıçradı. Kaşlarını çattı. Gözlerini zavallı şaşkın yörük delikanlısının üstüne dikti: — Baban kim be? — Hatıloğlu Ehmet Ağa... — Tanımıyorum ben. — O sizi tanıyor efendim. Bu yoğurdu hediye gönderdi. Ona büyük bir iyilik etmişsiniz. Kadının dünyada kimseye iyilik edebileceğine ihtimal vermeyen eşraf, baştan aşağı kulak kesildi.

Kadı İbrahim Efendi de tanımadığı bir adama nasıl iyilik ettiğini merak etti.  
— Ne iyilik etmişim?  
— Koyunlarını kurtarmışsınız efendim.  
— Ne vakit?  
— Dün gece.  
Kadı, yörüğe "Deli olmasın?" diye dikkatli dikkatli baktı. Dün gece evinden dışarı çıkmamıştı. Yalanını tutmak için sordu:  
— Nerede?..  
— Rüyasında efendim...  
. . . . .

Eşraf, gülmekten katılıyordu. Kadı, haysiyetinin incindiğini duydu. Suratını daha beter astı. Fakat "iyilik etmek", reddolunacak bir şey değildi. Rüyada olsa bile!.. Açtı ağzını, "mânâ âlemi"nin hakikat olduğunu, "görüntünün hayalden ibaret" bulunduğunu, acı bir felsefe çeşnisiyle anlattı. Hakikat ancak rüyada tecelli edebilirdi. Kendi iyi idi. İyiliği işte rüyalara giriyordu. Sonra döndü, yörüğe: — Babana selam söyle oğlum, dedi, bırak oraya lengeri. Ben namazdan sonra aldırırım. Delikanlı, yoğurt kabını kapının yanına bıraktı. Gidecekti. Fakat "mânâ âlemi"nin ehemmiyetini ilim diliyle iyice anlattım sanan Kadı Efendi, rüyada yaptığı iyiliğe dair daha ziyade tafsilat almak istedi. — Babanın koyunlarını nasıl kurtarmışım, biliyormusun? Genç yörük, basacak bir yer arıyormuş gibi etrafına bakındı. Sonra arkasına baktı, ellerini önüne kavuşturdu. Mavi donunun üstündeki kocaman kuşağını kollarıyla sıktı. Yutkundu. Gözlerini tavana dikti. Anlatmaya başladı: — Babam dün gece rüyasında koyunları Alabayır'ın üstüne yaymış. — Ey... — Sonra kocaman bir kurt peyda olmuş. Koyunları parçalayacakmış, o vakit siz gelmişsiniz işte...Kocaman, azgın, dehşetli bir yaban domuzu olmuşsunuz. Bu kurda saldırmışsınız. Kurt kaçmış... Siz kovalamışsınız. Sonra... Tutunca kurdun karnını azı dişlerinizle yarmışsınız. Koyunlar da... Şey...

Yörük, rastgele tavandan çektiği sakin gözleriyle Kadı Efendi'nin kararmış suratını görünce, birdenbire hikâyesini kesti. Yüreği hop etti. Hakikaten bir yaban domuzunun azı dişleri altında kalmış gibi korktu. Oradan kaçtı. Halbuki hikâyesini dinleyen eşraf efendiler, birbirlerine bakarak kahkahalarını elleriyle ağızlarında söndürmeye çalışıyorlardı.

Kadı Efendi ise...

. . . . . ==Dipnotlar==

# Niçin Zengin Olmamış?

"Bir Sultanî mualliminin hâtırat defterinden üç dört sahîfe"

7 Kânun-ı sânî 1916 – Derler ki: "Tarihsiz millet mesuttur!" Ben de: "Hatırasız insan mesuttur!" diyeceğim. Beş senedir tarih okuttuğum için birçok kitapları gözden geçirmeye mecbur oldum. Rimbaud'nun, Lavisse'in eserlerini daha mektepten çıkar çıkmaz getirtmiştim. O vakitten beri tedrîcen alıştığım sahaf bezirganlığı, kütüphanemi oldukça büyüttü. Şimdi bu kitapların hemen hepsini okumuş bulunuyorum. Dikkat ettim: Tarih denilen şey felaket nakili! Saadetten hiç bahsetmiyor, yahut şöyle üstünkörü geçiyor. En sevinçli, en talihli devirlerin içinde bile bir facia, bir hıyanet, bir acı, bir zehir bulunmakta, mâhir! İnsaniyetin hatırası olan tarihteki bu hazin temâyül bizzat insanda da var. Felaketler, ıstıraplar, matemler, ruhumuzda adeta bir yara gibi derin bir iz bırakıyor. Saadetlerimiz, sevinçlerimiz, hoş günlerimiz tıpkı bir rüya hafifliğiyle eriyiveriyor, unutuluyor. İşte bu sabah, çekmecemin köşesinde, on sene evvel karalamaya başladığım bu defteri buldum. Yazdıklarıma baktım. Hiç ferah verecek bir şey yok! Kanserden ölen anneciğimin yavaş yavaş nasıl söndüğünü, zavallı, kurtarılmaz bir pençe ile inleye inleye ademe sürüklenirken, nasıl öldürücü elemler duyduğunu uzun uzadıya kaydetmiştim... Zaman, ne dehşetli bir deva! Şimdi o elemlerin binde bir zerresini duyamıyorum. Sonra dışarıya gitmiştim! Buna dair ancak iki satır! Sonra evlendim! Bunun kaydı bile yok! Çocuğum oldu. Onu da yazmamıştım. Güneş görmediği halde bilmem niçin sararan bu sahîfeleri gayr-i ihtiyârî kokladım. Keskin, bayıltıcı, hasta bir sonbahar kokusu! Ah bu eski kağıtlardan, eski kitap aralarından, unutulmuş eski defterlerden çıkan matem kokusu!

Evet, keşke yazacak hâtıratım olmayaymış! Birbirine benzeyen muntazam, vukuatsız günler ne kadar boş! Fakat ne kadar ıstırapsız... Muharebeden sonra, bu boşluk, yani bu rahat ve sükun birdenbire bozuldu. İtiyâdımı kaybetmiş olmalıyım ki, iki senedir çektiklerimi buraya geçirmemişim. Kanaat içinde, say' içinde, ilim mefkuresinin o zevki hiçbir lezzete benzemeyen ruhanî hazzı içinde mesut yaşarken, ansızın korkunç bir maîşet girdabının karanlıklarına yuvarlanmak! Bir açlık kasırgası altında, ümitsiz bir kıtlık çölünde sürünmek, sevgililerin yavaş yavaş, şikayetsiz ölümlerini görmek! Bugün ne kadar bedbahtım! Karımın nesi var, nesi yok, sattık, yedik. Annesinin evinden getirdiği çeyizlerden bir keten havlu bile kalmadı. Yatak takımlarımız, karyolamız, benim baba yadigarı ceviz kütüphanem, hatta çocuğumun, zavallı Orhancığın arabası bile sıra ile Bitpazarı'na gitti. Maaşım onbeş lira... Annemden kalan, bana altı lira irat temin eden evi de rehine koyduk. Yediğimiz vesika ekmeği, mektepten verilen zeytinyağıyla bulgur! Karımın metanetine hayranım. Hem çocuğa, hem evin işine yetişiyor. Hiç durmadan çorap yamıyor. Eskileri bozuyor. Beni, çocuğunu giydiriyor. — İnşallah muharebe bitsin! Hepsi unutulur! Diyor. Fakat, ben, bu bâdireyi öyle yakından bitecek bir halde görmüyorum. Sonumuz ne olacak? Ara sıra dışarı gitmesini düşünüyorum. Fakat oradan gelenler de açlığın daha korkunç bir şekilde olduğunu söylüyorlar. Yarının dehşetini hatırlamak zihnimi altüst ediyor. Şaşırıyorum. İşte şimdi de şaşırdım. Ne yazacağımı toplayamıyorum.

14 Kânun-ı sânî..– Bu uğursuz defteri tekrar yazmaya başlamamalıydım. Dün Orhan hastalandı. Hatır için, vizitesiz bakan komşumuz doktor yalnız süt verilmesini söyledi. Süt... Okkası yarım lira! Ne kadar kitabım varsa hepsini hamallara yüklettim. Götürdüm, sattım. Elime altmış lira kadar bir para geçti. Yirmi lirasıyla odun, kömür aldım. Soğuk pek fena.

30 Kânun-ı sânî...– Biraz düşününce anlıyorum ki, hayat artık yaşanabilecek gibi değil. Akşam potinlerimi boyatırken, boyacıya, ustasından ayda kaç kuruş aldığını sordum. — Yirmi lira! Dedi. On altı yaşında bir çingene çocuğu! Ben otuz bir yaşında, naz ü naîm içinde büyümüş tarihi bir ailenin evladı. Bir karımla, bir çocuğumla onbeş lira içinde nasıl geçinebilirdim? Hoş, bu zaten mümkün değil ya. İki senedir satıp, savup, üzerine onbeş lira daha ekleyip ölümden kurtuluyoruz. Fakat bu böyle devam edemez. Bir ay sonra satacak bir şeyim de yok. Bir iş bulmalıyım. Hocalık artık bir insanı değil, bir tavuğu bile besleyemez.

16 Şubat...– On beş gündür iş arıyordum. Nihayet bir kitapçıdan sahîfesi on kuruşa tercüme buldum. O kadar sevindim ki... Her forma yüzaltmış kuruş getiriyor. Üç yüz sahîfelik bir kitaptan otuz lira alıyorum.

7 Nisan...– Her gece muntazaman, on sahîfelik tercüme etmeye alıştım, bunun için dört saat kifayet ediyor. Neyse... Hayatımız biraz iyileşir gibi oldu. Orhan sütünü içebiliyor. Semiha ile biz de birer vesika potini edinebileceğiz. Fakat her gece fasılasız çalışmak gözlerimi bitirdi. Ama bunun da kolayını bulduk. Geçen hafta göz doktorundan bir gözlük aldım.

2 Mayıs...– Dün bir arkadaşıma rastgeldim. Cenyo'da... Bu çocuk idâdîde iken kovulmuştu. Ara sıra görürdüm. Şimdi tüccar olmuş.  
— Tam, yetmişbeşbin liram var! dedi. İki ay içinde...  
— Şaka ediyorsun!  
Diye güldüm.  
— Vallahi! İstediğin bankaya sor, dedi.  
— Ey, nasıl olur bu?  
— "Taraf-ı takrîb"ini bulursan çok kolay!  
İçimde birdenbire hırs canlandı. İki ay içinde yetmişbeşbin lira... Her gece dört saat, ucuz olsun diye Almanlardan satın aldığım karpit lambasının başında, bir lira için nasıl terler döktüğümü hatırladım. Karşımdaki sıhhatten, candan patlayacak gibi gergindi. Elmas yüzüklü parmakları tombul tombuldu.  
— E, bu "taraf-ı takrîb" ne?  
— Topal'a çatmanın bir kolayı!  
— Topal kim?  
— Yuha... Patagonya'da mısın be mübarek! Topal'ın kim olduğunu bilmiyorsun ha!... Allah be! Tuttuğunu, bir anda milyoner yapar. Bugün bütün Türkiye elinde! Bir sözüyle yetmişbeş milyon lira birden harekete gelir.  
Levazım reisinin faziletlerini, kuvvetini, iktidarını uzun uzadıya anlatmaya başladı. Hayretle dinledim. Nihayet Harbiye Nezareti'nde, İttihatçılar arasında hiçbir tanıdığım olmadığını söyledim. Bana acıdı. Fakat:  
— Meyus olma, dedi. Doğrudan doğruya Topal'a çatmaya da hacet yok. Onun adamlarından birinin adamına çatsan kâfi...  
— İşte sana çatıyorum!  
Diye güldüm.  
— Yavaş gel! Diye bir kahkaha attı, ben onun yedi gömlek uzak adamlarından birinin adamıyım. Ama iş için arkadaş lazım! Senin de cebine, anafordan seksen, doksan lira düşürebilirim.  
. . . . . . . . . . . . .

Günde seksen, doksan lira... Kulaklarıma inanamıyordum. Azıcık daha, bu yeni zenginin ellerine yapışacak, şapur şupur öpecektim. Birdenbire hafifledim. Zenginlik ümidi insana eter gibi birdenbire tesir ediyor. — Öbür gün bana gel! Ömer Âbid Hanı'nda ikinci kata, dedi. Yarın ona gideceğim. Bana para kazandıracak. Sermayesiz para kazanmak! İşte bu dünyada aklımın en ermediği şey! Ben de birçokları gibi birdenbire zengin olacağım. Elveda artık bu sefalete! Bu köhne, siyah ahşap eve! Elveda bu tahtakurusu kolonisine! O kadar müteheyyicim ki, çayı görmeden paçayı sıvıyorum. İki gündür tercümeye devam edemedim. Ah, şu kağıt parçalarını götürüp kitapçı Acem'e: "Al, işte tercümelerini başına çal! Paran da senin olsun. Allah belanı versin!" diyebilecek miyim? Semiha halimden işkillendi. — Sende bir şey var, sende bir şey var! Deyip duruyor. Niçin tercüme yapmadığımı soruyor. Başımın ağrıdığını söylüyorum. Yarın mektepte beni istedikleri kadar beklesinler! Zavallı sermuî kimbilir ne büyük bir ehemmiyetle bulunmadığım saatleri hesap ederek "kıstelyevm" yapmaya çalışacak. Budala...

15 Eylül...– İki gün evvel Büyükada'dan geldik. Bugün de apartmanımıza yerleştik. Seneliğini yediyüzelli liraya tuttum. Fakat öyle mükemmel ki... Banyo, kalorifer, elektrik hepsi var. Altı oda, iki salon... Möblelerim için tam beşbin lira sarfettim. Yine kütüphanemi tamamlayacağım... Evet, saadet rüya gibi çabucak geçer... Bu yazı nasıl geçirdiğimi hatırlayamıyorum bile... Daha mâhut mektebi bırakmadım. Yerime bir vekil tayin ettim. Kendim de hastayım diye bir rapor aldım. Vekilime maaşımı bıraktıktan sonra, on lira da üstüne ilave ediyorum. Mektebi bıraksam askerlik tehlikesi var. Bir an gelir ki, tüccarlık insanı kurtaramaz. Şemsi, ilk ayda, bana, anafordan üçbin lira kazandırdı. Doğrusu kendisine çok müteşekkirim. Beni adam etti. Un işi yapıyoruz. Zaten bundan kârlı bir şey yok. Biraz zahireye de karışıyoruz. Şeker filan kapatıyoruz. Dört ay evvel yazdıklarımı okurken gülümsedim. Vay anasını! O sefaletlere nasıl dayanmışım! Günde yarım liraya kapalı bir dershanede beş saat kafa patlatmak! Sonra bu derece sarih bir eşekliği fazilet zannetmek! Ben, çok şükür bu pîr aşkına sürünmek faziletini kaybettim. Vâkıa şimdi bulunduğum muhit biraz adi. Fakat katiyyen ukala değil... Herkesin emeli, felsefesi, arzusu bir: Para kazanmak! Mücerredat yok! Hayal yok! Oldukça karışık bir piyasa dalaveresi var. Açıkgözlülük en büyük kuvvet... Öyle zannediyorum ki, bir seneye varmadan Şemsi'yi geçeceğim. Ah, şu muharebenin başında niçin elimden bir tutan olmadı? Biz hâlâ bugünün fakirleri sayılırız. Şimdi öyle adamlar var ki, son iki sene içnde on milyon lira kazanmışlar. Amerikalılar haltetsin! Daha muallimlik ederken arkadaşlarımdan biri bana bir kitap okutturmuştu. Fransızca ismini hatırlıyorum: "Zenginlik Elifbesi" Herif zengin olmaya bir dolardan başlıyor! Bir milyon yapmak için otuz sene geceli gündüzlü uğraşıyor. Burada bir açıkgöz için, bu milyonu, lira olarak toplamak işten bile değildir. Topal'la küçük bir ortaklık kâfi! Balkan trenleri, Anadolu hattı bir ay insan için çalışsa...

Artık bu defteri dolduracağımı ümit etmiyorum. İnsan zengin olunca, okumaktan olduğu gibi, yazmaktan da nefret ediyor. Bununla beraber bir hatıra olsun diye atmayacağım. Evet, eski fakirliği unutmak pek asil bir hareket değil. Kütüphanemde saklayacağım.

Ah bu Semiha...

Ne kadar müşkülpesent! Bir türlü yemek odasını yerleştiremiyor. Psalti'nin dekorcusuyla sabahtan beri uğraşıyorlar. Gideyim onlara bakayım.

2 Şubat 1917...– Altı ay sonra, zavallı samimi defter! Seni nasıl heyecanla elime alıyorum; acı, öldürücü bir buhran içindeyim. Söylemek için günahı dudaklarından taşan, kalbine sığmayan bir mücrim gibiyim. Evvelki gün Cerrahpaşa'da bir yeni zenginin evine davetliydim. Alaturka saz vardı. Gece yarısına kadar yedik, içtik. Ben uyuyamadım. Sabahleyin erkenden çıktım. Soğuk dehşetliydi. Araba bulamadım. Aksaray'a indim. Yine araba yok. Küçükken babamla cuma namazına geldiğimiz Valide Camii'nin köşesinden, yukarıya doğru baktım. Unutulmuş bir hâtırat gibi... Bütün virane... Laleli Camii, Hasanpaşa Hanı'nın arkaları gözüküyor. Müteessir oldum. Yavaş yavaş yürüdüm. Laleli'de, Yenikapı'ya inen sokakta, büyük bahçeli, mahzenli, havuzlu bir evde oturmuştuk. Yirmi beş, yirmi altı sene evvel... Karşımızda bir komşumuz vardı. Güzin Hanımlar... Kızlarının sesi o kadar kalındı ki... Tıpkı bombort gibi. Sabahleyin, bu çocukluk günlerini hatırlamak, beni bir çocukluğa sevketti; yangın yerlerinde oturduğumuz evin arsasını bulmak! Ne yapacaktım? Hiç... Acaba havuz duruyor muydu? Viranelerin içine saptım. Kimseler yoktu. Yarım yıkılmış bacalar, ocaklar sahipsiz bir mezar sükutuyla uyuyorlardı. Aradığım evin hizasında bu ocaklar daha sıktı. Baktım, üstü başı perişan dört kişi dolaşıyordu. Eğilip eğilip ocakların içine bakıyorlardı. Merak ettim. Ne arıyorlardı? Yürüdüm. Yanlarına yaklaştım. Ne aradıklarını sordum.  
— Ölü arıyoruz!  
Dediler.  
— Ne ölüsü?  
Aralarındaki kır sakallı, kısa boylu ihtiyar cevap verdi:  
— İnsan ölüsü.  
— İnsan ölüsü mü?  
— Evet...  
Şaştığımı görünce durdu. Beni baştan aşağıya bir süzdü. Sonra başını salladı:  
— Hey, gidi hey! dedi. Efendi, senin de haberin yok galiba. Biz belediye adamlarıyız. Her gün gelip buralarda açlıktan ölenleri toplarız. Sonra şu arabaya doldururuz. Götürürüz, gömeriz.  
— Açlıktan ölüyorlar ha!  
Diye buz gibi dondum. Sanki birdenbire kalbim durdu. Dizlerim kesildi. İhtiyar deşilmek istiyormuş. Ağzını açtı. Zavallı Müslümanların iki senedir nasıl açlıktan kırıldıklarını, aleve atılmış meyus bir hatip heyecanıyla haykırmaya başladı. Herkesin altındakini, üstündekini satıp yediğini, nihayet kimsesiz gariplerin böyle virane ocaklarına düştüklerini ,öyle imdatsız, kimsesiz, ilaçsız ve aç, susuz, ateşsiz, köpekler gibi öldüklerini söyledi.  
— Eğer hainler, Allah'ın gazabına daha uğramazlarsa, dünyada Müslüman kalmayacak!  
Dedi. Gayr-i ihtiyâri:  
— Bu hainler kim?  
Diye sordum.  
— Kimler olacak, millete ekmek diye kum, toprak yedirenler! Katığı dünya yüzünden kaldıranlar! Fukarayı soyup zengin olanlar! Otomobillerde uçanlar!  
— ......  
Sonra bir an durdu. Arkadaşları kendisi gibi müteheyyiç değiller. Ellerini, başını göğe kaldırdı:  
— Bunların ne vakit asıldıklarını göreceğiz Allah'ım!  
Diye derin, acı, karanlık bir ah çekti.

Ben hiç ses çıkarmadım. Evet, insanları böyle açlıktan öldüren bizlerdik! Bize yol gösteren, bize müsaade edip bizimle beraber çalanlardı! Şemsi ile beraber Kağıthane'de uzun bir "Un damarı" keşfetmiştik. Üç aydır orada çıkarttığımız ince killeri iaşeye satıyorduk. İaşe de, bile bile ortaklama bunu alıyor, içine biraz paspal karıştırarak fırınlara dağıtıyordu. Manyetize edilmiş gibi bu ölü arayanların arkalarından yürüdüm. Henüz iki tane bulmuşlardı. Baktım. Ruhumdan zehirlendim. Bu ölüler yarı çıplaktı. İskeletlerinin üzerinde derileri kurumuştu. Hiç etleri yoktu. Birisi kadındı. Sarı saçları keçeleşmişti. Dudaklarımı o kadar hızlı ısırmışım ki, sıcak sıcak, çenemden kanların sızmaya başladığını duydum. Ölünün mavi, aralık gözleri, bana dik dik bakıyor sandım. Birdenbire sanki ödüm koptu. Kendimi kaybettim. Kaçtım. Deli gibi koşmaya başladım. Beyazıd'a nasıl çıktığımı bilmiyorum. Bir arabaya atladım. Eve geldim. Bayılmışım. Doktor filan gelmiş. Açılınca, Semiha'ya gördüklerimi anlattım. O da fena oldu. Ağlamaya başladı. Şimdi yataktan kalkamıyorum. Artık müthiş bir anarşist oldum. Bir milletin açlıktan ölmesi için toplu, tüfekli teşkilat yapan Topal'ı, bu alçağı tutanları öldüreceğim. Yenecek ne varsa, ortadan kaldıran, altıyüz yıllık bir devletle beraber kocaman, masum Türk milletini fakrü'd-dem kılıcından geçirenleri geberteceğim. Evet, bu milleti hükümet mahvetmek istiyor! Bunda artık hiç şüphem kalmadı! Bunda şüphesi olan eşektir! Topal, o bütün kara çete teşkilatı, o bir ejderha gibi memlekete sarılmış! Kanımızı, iliğimizi, kemiğimizi emiyor. Evet, öldürmeliyim. Onlardan bir tanesini öldürmek, siperde bin düşman neferini öldürmekten çok, hem pek çok hayırlı....

19 Mart...– Onları öldüremedim. Onları, ancak yaşarsa, millet öldürecek! Hepsini ipe çekecek! Onları öldürmek bir kişinin harcı değil! Hainler yedi başlı, dokuz canlı bir ejderha kuvvetinde! Korkunç bir teşkilat! Fakat kendimi öldürdüm! Yani muhtekir beni! Nem var, nem yok hepsini sattım. Bütün milletimi açlıktan öldürerek soyduğum paraları aşhanelere, fıkaraperver cemiyetlerine dağıttım. İsmimi vermedim. Apartmanı falan hepsini bıraktık. Semiha ile Orhancığımızı aldık. Üsküdar'da, Çavuşderesi'nde bu minimini evi kiraladık. Şimdi o kadar mesuduz ki.. İyi ki mektebi bırakmamışım! Yine derslerime başladım. Arkadaşlarım beni iflas etti sanıyorlar. Acem'e yine gittim. Benim tercümelerimden memnun. Şimdi sahîfe başına oniki kuruş veriyor! Geceleri ben söylüyorum, Semiha yazıyor. Ayda elli lira kazanabiliyorum. İdaresini bilen bir aile için bu çok bile... Fakat, geçen on ayın hâtırası korkunç bir kabus gibi daima aklımda! Unutamıyorum. Açlıktan öldürdüklerimizi unutamıyorum. Yangın yerinde gördüğüm kadın ölüsünün bana bakışını unutamıyorum. On ay kan, gözyaşı, irin içtiğimi, sütsüzlükten, şekersizlikten küme küme ölen masumcukların hakkını yediğimi unutamıyorum. Siyah bir hayal, her an ruhumu takip ediyor: "Sen de kanlı soyguna karıştın! Sen de, sen de!" diyor. Gözümün öününe birbiri ardına dikilmiş sayısız darağaçları geliyor. Bunların bir tanesinde ben sallansam! Ah, evet, yine vicdanımdaki yakıcı azap sönmeyecek sanıyorum. Yine on ay milletime yaptığım zulmü unutamayacağım, sanıyorum. Bu ıstırap öldükten sonra da, mezarda da beni kıvrandıracak sanıyorum!

# Nâdan

Nâdan ile sohbet etmek güçtür bilene; Çünkü nâdân ne gelirse, söyler, diline!

Atasözü

İstanbul üç gündür sis içindeydi. Topkapı Sarayı'nı, açık kül rengi kalın bir bulut sarmış, sanki bütün dünyadan ayırmıştı. İhtiyar padişah, artık mermer havuzlu küçük bahçenin lale tarhlarını bile göremiyor, gamsız zamanlarında yaptığı gibi murassâ çerçeveli camlara hohlayıp parmağı ile "Çifte vav" yazamıyordu. Yeniçeriler kazan devirmişler, sipâhî zorbaları zâbitlerini parçalamışlar, payitahtı yağmaya hazırlanmışlardı. Serhatteki ordunun hali de perişandı. Ecelin gadriyle tecrübeli vezirler kalmamış, fedakar beyler er meydanlarında can vermişlerdi. Bu korkunç buhranın önünü alacak bir adam yoktu. Son ümit "Köse Vezir"deydi. Vaziyetin fenalığını herkesten ziyâde kavrayan akıllı padişah, işte şimdi onu çağırtmıştı. Mühürünü ona verecekti.

Tahtın karşısındaki sırmalı, büyük perde kımıldadı. Kocaman kavuklu, mini mini, nahif bir ihtiyar, belirsiz, bir gölge gibi içeri girdi. Gözleri yerde, elpençe yürüdü. Tahtın basamağına diz çöktü. Takbîl resminden sonra, padişah, asabi eliyle soldaki erguvanî bir kumaştan yapılmış şilteyi gösterdi. — Otur. Dedi. Sonra, tahtın, sağ kolunu dayadığı altın koltuğuna bakarak ahvalin fenalığını, devletin geçirdiği muhâtarayı, askerin fesadını, ordudaki perişanlığı anlattı. Yavaş yavaş söylüyor, her kelimede başını sallıyordu. Bu zamanı ıslah etmek için demir bir el lazımdı. Gayet doğru, irtikâp etmez, Allah'tan korkar, akıllı, dünyayı bilir, her şeyden ziyâde devletini sever bir adam işleri düzeltebilirdi. Padişah: — İşte bu adam sensin! Seni kendime vekil edeceğim. Deyince, boynunu büküp efendisini dinleyen küçük ihtiyar doğruldu. — Beni affedin padişahım, dedi, ben artık devlet işine karışmamaya ahdettim. Sayenizde geri kalan birkaç günlük ömrümü ibadetle, duâ ile geçireceğim. — Fakat... ... Padişah, mesuliyetsiz rahatın hayvanlarla ölülere yakışacağını, kulların, padişah davetine icabet etmemelerinin bir küfür olduğunu, âyetlerden, hadislerden bürhanlar getirerek tekrarladı. Haklı bir gazabın mehâbetini duyuran sert bir bakışla, kırlaşmış uzun kirpikli, iri, şahane gözlerini, boynu bükük ihtiyara dikti. Bu bakışta sanki Azrail'in kanatlarından aksetmiş ölüm kıvılcımları tutuşuyordu. Köse Vezir, ateş içinde yanmayan bir semender gibi sakindi: — Boynum kıldan incedir! Padişahım, dedi, çoluk çocuğumla veda ettim. Hakkın huzuruna gitmek için iradenizi bekliyorum. Ben mihr-i şerifinizi almam! — . . . . . . . . Padişahın soluk çehresi karardı. Elleri titredi. Tahtın gerisine çekildi. Yüzünü buruşturarak: — Kaldırın şunu! Diye bağırdı.

Sırma perdenin arkasından birer hayal sessizliğiyle koşan hademeler, yere basmıyor sanılacak derecede hafif adımlarla çabucak vezirin başına üşüştüler. Göz açıp kapamadan dışarı çıkardılar.

Bu çıkış, mermer revâkında gece gündüz, keskin tığlı, karayağız cellatların bağdaş kurup bekledikleri balıkhaneye doğruydu.

Hiddeti geçer gibi olan padişah, devletinin, tahtının üstünde bocaladığı fesat tufanını tekrar hatırladı. Düşündü. Köse Vezir de ölürse, sözün, bir gün olup büsbütün ayağa düşmesi ihtimali vardı. Fakat işte, bu küçücük adam, ölümü gözüne almıştı. Kafası kesilince hakkın huzuruna gidecek, dünya gailesinden kurtulacaktı. Ne vakit olsa, yüzlerce yıl yaşasa, yine ölümden kurtuluş olmadığını bilen, bu hakikati unutmayan ariflerdendi. Bir gün sonranın, beş gün evvelin onca hiç ehemmiyeti yoktu. Padişah huzurunda dîvân duran ağasına: — Sarık odasına hapsetsinler. Yanına kitap, kalem, kağıt vermesinler. Dedi. Ağa çıktı. Padişah mutlaka onu iş başına getirmeye azmetmişti. Bu cesareti, muhakkak ölüm karşısındaki bu pervasızlığı, şahsiyetini, ahdını muhafaza etmekteki bu inadı ne kıymetli bir hasletti!

Ancak böyle bir adam, müşkül zamanlarda büyük işler yapabilirdi. Padişah bunu biliyordu. Gözünün önüne zamanenin paşaları, çelebileri geldi. Hepsi iki kat bir rükû vaziyetinde,ölüm korkusuyla benizleri sararmış, yalnız hile, yalnız fesat, yalnız fitne düşünüyorlar; şeytanların bile aldanacağı yalanlar, iftiralar uydurarak birbirlerinin kanlarını içiyorlardı. Fakat Köse Vezir öyle değildi. Ârifti. Alimdi. "Dünya ve mâfihâ"nın ne olduğunu sezmişti. Daima "zeval" uçurumuna giden "ikbal" yolunda hakikati unutmaz, mağrurlanmaz, para, servet, ihtişam, saltanat gibi şeylere de tenezzül bile etmezdi. Orta halli bir molla gibi yaşar, sandık sandık filoriler toplayıp fani dünya evini baki sanan, haris gafillerin budalalıklarına şaşardı. Padişah, böyle haktan başka hiçbir kuvvete baş eğmeyen bir adama mühürünü nasıl kabul ettirecekti? İşte, ölümün onca hiç ehemmiyeti yoktu. Yine kalın kaşlarını çattı: — Ölümden daha beter bir ceza... Diye söylendi. En korkunç işkenceler, dehşetleri nispetinde ölüme daha yakındı.

Padişah saatlerce tahtında düşündü, taşındı. Saatlerce yalnız kaldı. Kılıçla değil, asıl aklın kuvvetiyle galebe çalındığını bildirdi. Fakat aklına, ölümden korkmayan bir adama baş eğdirecek bir vasıta gelmiyordu. Düşünürken tahayyül etmeye başladı. Daldı gitti. Derin uykularda görülen rabıtasız rüyalar gibi şehzadeliği, lalası gözünün önüne geldi. Otuz yıl evvel ölen lalası, hatırında kalan o ak sakallı adama hiç benzemiyordu. Saray kendi sarayı değildi. Ders aldığı rahle, beyaz gül ağacından mıydı? Lalası olduğunu bildiği halde sesini, simasını tanıyamadığı bu müphem hayal, latifsiz bir lisanla: "Nâdanla sohbet etmek, âkile cehennem ateşinden beterdir!..." diyordu. Bu söz bir şiirdi!... Padişah veznini ararken, daldığı derin tahayyülünden uyandı. Başında bir ağırlık vardı. Hareme gidip yatmak için kalktı. Evet, mademki nâdanla sohbet etmek cehennem ateşinden beterdi. Bu ateşte Köse Vezir'i yakmalı, fakat öldürmemeliydi. Koltuğuna giren bendelerine: — Çabuk bir nâdan buldurulsun. Onun yanına kapatılsın! dedi.

Bostancılar, tebdilağaları, bir hafta kadar bütün şehri, civar köyleri, kasabaları, dağları, kırları dolaştılar. Nihayet Karamürsel meralarında, gayet cahil, gayet akılsız, gayet aksi, hâsılı gayet nâdan bir çoban buldular. Bu, otuz beş kırk yaşlarında, çok kuvvetli, hissiz, hayvan gibi bir adamdı. Köyünde kendisine "Eşek Hasan" diyorlardı. Nâdan olduğu kadar inatçıydı da... Terbiye, hürmet, namaz, niyaz, ne olduğunu bilmez; "Allah'ın kim?" dendiği zaman, "Ne bileyim ben ülen..." diye sırıtırdı.

Koyunlarının yanından ayrılmamak için hasekilere mukavemet etmiş; taşla, sopayla birkaçını yaralamıştı. Saraya elleri bağlı getirdiler. Siyaset gününü tesbih çekerek bekleyen Köse Vezir'in yanına koydular. Eşek Hasan, uğradığı haksızlığa karşı üç gün uludu. İşitilmedik küfürler etti. Sonra sustu. Pembe ipek divanların üstüne çarıklarıyla çıktı. Kuşağının arasından çıkardığı kavalı çalmaya başladı. Yalnız başına ölümü bekleyen Köse Vezir'in huzuru, tevekkülü bozuldu. Ama yanına konan bu garip mücrimle bir lakırdı olsun etmedi. Yüzünü pencereden tarafa çeviriyor, odaya yemek içmek getiren hademelere bile gözünü kaçırmıyordu. On gün, yirmi gün geçti. Kapının deliğinden içerisini gözetliyorlardı. Padişah, onun böyle nâdan bir herifle yaşamak azabına da katlandığını görünce ümitsizleniyor, hasekiler çıkararak daha nâdan mahluklar arattırıyor, fakat Eşek Hasan'dan beterini bulduramıyordu. Bir ay geçti. Nâdan çoban kavalı da bıraktı. Hiç ses çıkarmıyor, zindan arkadaşı gibi pinekliyor, susuyordu.

...Bir sabah, Köse Vezir, bu koca herifin hüngür hüngür ağladığını gördü. Çocuk gibi hıçkırması içine dokundu. Zavallı kimbilir karısını, evini, köyünü mü hatırlamıştı. Gayr-i ihtiyari sordu:  
— Ne ağlıyorsun oğlum?  
Bu, vezirin hapsedildiğinden beri söylediği ilk sözdü. Çoban gözyaşlarından sırsıklam olan al yanaklarını kirli yenleriyle silerek ona baktı.  
— Söylemem darılırsın... dedi.  
— Söyle oğlum derdini bana, ne darılacağım?  
— Vallahi darılırsın.  
— Darılmam diyorum.  
— . . . . . .  
Çoban derdini söylemiyor, daha ziyâde heyecana gelerek avazı çıktığı kadar ağlıyordu. Köse Vezir, biraz düşündü. Başkasını ağlatan bir sebebe kendisi nasıl darılabilirdi? Merak etti. Tekrar:  
— Söyle oğlum. Senin derdinden bana ne?  
— Darılırsın baba.  
— Darılmam, söyle...  
— Benim sürümde bir kösemenim* vardı. Senin yüzüne baktıkça o hatırıma geliyor da... İşte onun için ağlıyorum.  
— . . . . . .  
Derdini söyleyen Eşek Hasan, birdenbire ağlarken gülmeye, hıçkırıklara kahkaha karıştırmaya başladı. "Tıpkı sakalı seninkine benziyordu." diye tafsilata bile girişiyordu. Köse Vezir hiç cevap vermedi. Kalktı. Kapıyı vurdu. Başını içeri uzatan sivri kavuklu nöbetçiye:  
—  Efendimize arzedin. Mühr-i hümâyunlarını kabul ettim... dedi.

Bir sene sonra harp bitmiş, yeniçeriler terbiye edilmiş, sipâhîler nizama konulmuş, hırsızlar, uğursuzlar temizlenmişti. Devlet yine, eski kuvvetini buldu. Padişahın gamlı yüzü güldü. Artık neşesi tamamıyle yerine gelmişti. Yalnız sadrazamına, o nâdan herifin yaptığı ölümden beter şeyin ne olduğunu bilmek istiyordu. Bir gün bunu sordu. Geçirdiği kırk günlük azabı birden hatırlayınca, yeni bir tokat yemiş gibi Köse Vezir'in yüzü kıpkırmızı oldu. Verecek bir cevap bulamadı. Kekeleyerek: — Hiç Padişahım! dedi. Bu suçsuz köylünün benim için hapsedilmesine vicdanım razı olmadı... Onu azaptan kurtarayım diye ahdimi bozdum. . . . . . . . . .

kösemen: koç

# Pembe İncili Kaftan

Büyük kubbeli serin Dîvan, bugün daha sakin, daha gölgeliydi. Pencerelerden süzülen mavi, mor, sincâbî bahar ışıkları, çinilerinin yeşil derinliklerinde birikiyor, koyulaşıyordu. Yüksek ipek şiltelere diz çökmüş yorgun vezirler, önlerindeki halının renkli nakışlarına bakıyorlar, uzun beyaz sakalını zayıf eliyle tutan ihtiyar sadrazamın sönük gözleri, gayet uzak, gayet karanlık şeyler düşünüyor gibi, mevcûd olmayan noktalara dalıyordu. — Cesur bir adam lazım; paşalar... dedi. Biz onun sırmalara, altınlara, elmaslara garkederek gönderdiği elçisine, padişahımızın elini öptürmedik; ancak diz öpmesine müsaade ettik. Şüphesiz o da mukâbele etmeye kalkacak. — Şüphesiz. — Hiç şüphesiz. — Mutlaka... Kubbealtı vezirlerinin tamamıyla kendi fikrinde olduğunu anlayan sadrazam, düşündüğünü daha açık söyledi: — O halde bizden elçi gidecek adamın çok cesur olması lazım! Öyle bir adam ki, ölümden korkmasın. Devletin şânına dokunacak hareketlere karşı koysun. Ölüm korkusuyla, uğrayacağı hakaretlere boyun eğmesin... — Evet! — Hay hay. — Çok doğru... Sadrazam, sakalından çektiği elini dizine dayadı. Doğruldu. Başını kaldırdı. Parlak tuğları ürperen vezirlere ayrı ayrı baktı: — Haydi öyleyse... Bir cesur adam bulun, dedi. Hâcegân'dan, Enderun'dan, Dîvan'dan benim aklıma böyle gözü pek bir adam gelmiyor. Siz de düşünün bakalım. — ..... Kaldım... — ..... — ..... — ..... Sofu, sulhperver, sakin padişahın koca devletine sessiz, küçük bir dimağ olan Dîvan düşünmeye başladı.

Bu elçi, yedi sene sonra takdirin "Yavuz" namındaki yaman sillesiyle her gururunun, her cinayetinin cezasını bir anda gören İsmail-i Safevî'ye gönderilecekti! Şehzadeliğini ata binmekten, cirit oynamaktan, silah kullanmaktan ziyade, kitapla geçiren Bayezid-i Veli'nin tabiatı son derece halimdi. Yalnız şiiri, hikmeti, tassavvufu sever; muharebeden, mücadeleden nefret ederdi. Vezirler, sevgili padişahlarının sükûnunu bozmamayı en büyük vazifeleri sanırlardı. Bununla beraber hudutlarda yine kavganın arkası alınamıyordu. Bosna, Eflak, Karaman, Belgrad, Transilvanya, Hırvatistan, Venedik seferleri birbirini takip ediyor; Modon, Koron, Zonkiyo, Santamavro fetholunuyordu. Sanki İstanbul Fâtihi'nin azmiyle dehası -tahta geçer geçmez babasının heykelini "gölgesi yere düşüyor" diye kırdırıp sevaba girmeye kalkan- zâhit halefinin zamanında da sönmüyor; sönmez bir alev, ezeli bir ruh gibi yaşıyordu. Rahat istendikçe, gaile gaile üstüne çıkıyordu. Hele şark... Kan içinde, ateş, zulüm içinde kıvranıyordu. Yıkılan, sönen Akkoyunlu hanedanının enkazı üstünde Şah İsmail serseri bir saltanat kurmuştu. Geçtiği yerlerde dikili ağaç bırakmayan, babasıyla büyük babası Cüneyd'in intikamını aldığı için delice bir gurura kapılan bu kudurmuş Şah, akla gelmedik canavarlarla sağına, soluna saldırıyordu. Kendine iltica eden tarafları bile çağırdığı ziyafette, yemekmiş gibi, kaynattırdığı büyük kazanlara atıp söğüş yapan, mağlup ettiği Özbek padişahının kafatasıyla şarap içen bu gaddar Şah, dünyada hakikaten eşi görülmemiş bir zalimdi. Bayezid Dîvanı'nın edib, sakin, haluk, dindar vezirleri, onun vahşetlerini hatırlamaya tahammül edemezlerdi. Bu zalim, bir gün mutlaka bizim hududumuza da tecavüz edecek, şark eyaletlerini zapta kalkacaktı. Bunu herkes biliyordu. Geçen yıl Zülkadriye hâkimi Alâüddevle'den nikâhla kızını istemişti. Alâüddevle kızını vermedi. İsmail, uğradığı bu red hakaretinden hiddetlendi; intikam için padişahın toprağından geçti. Müdafaasız Zülkadriye arazisine girdi, Diyarbekir, Harput kalelerini aldı. Sarp bir dağa kaçan Alâüddevle'nin oğlu ile iki torunu eline esir düştü. Şah İsmail, bu zavallıları ateşte kızartıp kebap ettirdi. Etlerini kuzu gibi yedi. Böyle bir vahşet şarkta yeni duyuluyordu. Cenk istemeyen padişah, Ankara'ya, Yahya Paşa kumandasında bir ordu göndermekten başka bir şey yapmadı. Bu şah, zalim olduğu kadar da kurnazdı. Osmanlı toprağına geçtiği için özür diliyor, birbiri arkasına elçiler gönderiyordu. O vakit Trabzon valisi bulunan Şehzade Yavuz, babası gibi sabredememiş, Tebriz hududunu geçmiş; Bayburd'a, Erzincan'a kadar her tarafı talan etmiş, hatta Şah'ın kardeşi İbrahim'i esir almıştı. İsmail'in elçisi şimdi bu tecavüzden de şikayet ediyor; Osmanlı toprağına son akınlarının, padişahın devletine karşı değil, sırf Alâüddevle aleyhine olduğunu tekrarlıyordu. İşte Dîvan'da bu kurnaz, bu zalim, gaddar türediye gönderilecek münasip bir elçi bulunamıyordu; çünkü kendini Osmanlı hakanıyla bir tutan, hatta bütün şarkta cihangirlik kuran bu serseri, karşısında devleti temsil edecek adama karşı şüphesiz birçok münasebetsizlikler edecek; münasebetsizliklerine mükâbele edeni ihtimal kazığa vuracak, derisini yüzecek, akla gelmedik kaba bir vahşetle öldürecekti. Sadrazamın sağındaki, deminden beri, bir mezar taşı gibi hareketsiz duran, kırmızı tuğlu kavuk yerinden oynadı. Yavaş yavaş sola döndü:  
— Ben tam bu elçiliğe münasip bir adam biliyorum, dedi. Babası benim yoldaşımdı, ama devlet memuriyeti kabul etmez.  
— Kim?  
— Muhsin Çelebi.  
Sadrazam bu adamı tanımıyordu. Sordu:  
— Burada mı oturuyor?  
— Evet  
— Ne iş yapıyor?  
— Biraz zengindir. Vaktini okumakla geçirir. Tanımazsınız efendim. Hiç büyüklerle ülfet etmez. İkbâl istemez.  
— Neye?  
— Bilmem ama, belki "zevâli var" diye.  
— Tuhaf...  
— Fakat çok cesurdur. Doğrudan ayrılmaz. Ölümden çekinmez. Birçok defa gaza etmiştir. Yüzünde kılıç yaraları vardır.  
— Bize elçi olmaz mı?  
— Bilmem.  
— Bir kere kendisini görsek...  
— Bilmem, çağırınca ayağınıza gelir mi?  
— Nasıl gelmez?  
— Gelmez işte... Dünyaya minneti yoktur. Şahla gedâ nazarında birdir.  
— Devletini sevmez mi?  
— Sever sanırım.  
— O halde biz de kendimiz için değil, devletine hizmet için çağırırız.  
— Tecrübe buyurun efendim.  
.....  
Sadrazam, o akşam kethüdâ sını Muhsin Çelebi'nin Üsküdar'daki evine gönderdi. Devlete, millete dair bir maslahat için kendisiyle konuşacağını, yarın mutlaka tereddüt etmeyip gelmesini yazıyordu.

Sabah namazından sonra sarayının selamlığında, Hint kumaşından ağır perdeli küçük, loş bir odada kâtibinin bıraktığı kağıtları okurken, sadrazama, Muhsin Çelebi'nin geldiğini haber verdiler.  
— Getirin buraya, dedi.  
İki dakika geçmeden odanın sedef kakmalı ceviz kapısından pala bıyıklı, iri, levent, şen bir adam girdi. İnce siyah kaşlarının altında iri gözleri parlıyordu. Belindeki silahlık boştu. Bütün kullarının tekâpû suna, secdesine alışan sadrazam, bir an, eteğine kapanılmasını bekledi. Oturduğu mor çuha kaplı sedirin daima öpülen ağır sırma saçağındaki yumağı, altından, içi boş küçük bir kafa gibi şaşkın duruyordu. Sadrazam söyleyecek bir şey bulamadı. Böyle göğsü ileride kabarık, başı yukarı kalkık bir adamı ömründe ilk defa görüyordu. Kubbe vezirleri bile huzurunda iki büklüm dururlardı. Muhsin Çelebi, gayet tabii bir sesle sordu:  
— Beni istetmişsiniz, ne söyleyeceksiniz efendim?  
— Şey...  
— Buyrunuz efendim.  
— Buyur oğlum, şöyle bir otur da...  
Muhsin Çelebi, çekinmeden, sıkılmadan, ezilip büzülmeden, gayet tabii bir hareketle kendine gösterilen şilteye oturdu. Sadrazam hâlâ ellerinde tuttuğu kıvrık kağıtlara bakarak içinden: "Ne biçim adam? Acaba deli mi?" diyordu. Halbuki... Hayır. Bu çelebi gayet akıllı bir insandı! Merde, namerde muhtaç olmayacak kadar bir serveti vardı. Çamlıca ormanının arkasındaki büyük mandıra ile büyük çiftliğini işletir, namusuyla yaşar, kimseye eyvallah etmezdi. Fukaraya, zayıflara, gariplere bakar; sofrasında hiç misafir eksik olmazdı. Dindardı. Ama mutaassıp değildi. Din, millet, padişah aşkını kalbinde duyanlardandı. Devletinin büyüklüğünü, kudsiliğini anlardı. Yegane mefkûre si: "Allah'tan başka kimseye secde etmemek, kula kul olmamak"tı... İlmi, kemali herkesçe malumdu. İbn-i Kemal ondan bahsederken "Beni okutur!" derdi. Şairdi. Lâkin ömründe daha bir kaside yazmamıştı. Hatta böyle methiyeleri okumazdı bile... Yaşı kırkı geçiyordu. Önünde açılan ikbal yollarından daha hiçbirine sapmamıştı. Bu altın kaldırımlı, mîna çiçekli, cenneti andıran nuranî yolların nihayetinde daima "kirli bir etek mihrabı" bulunduğunu bilirdi. İnsanlık onun nazarında çok yüksek, çok büyüktü. İnsan, arzın üzerinde Allah'ın bir halefiydi. Allah, insana kendi ahlakını vermek istemişti. İnsan, her mevcudun fevkinde idi. Kuyruğunu sallaya sallaya efendisinin pabuçlarını yalayan köpeğe tabasbus pek yakışırdı; ama, insana... Muhsin Çelebi, her türlü zilleti hazmederek ikbal tepelerine iki büklüm tırmanan maskara harislerden, izzetinefissiz kölelerden, zâhifeler gibi yerlerde sürünen mülevves esirlerden nefret ederdi. Hatta bunları görmemek için merdümgiriz olmuştu. Yalnız muharebe zamanları Guraba Bölüklerine kumandanlık için meydana çıkardı. Huzurda serbest, tabii oturuşu sadrazamı çok şaşırttı. Ama, kızdırmadı:  
— Tebriz'e bir elçi göndermek istiyoruz. Tarafımızdan sen gider misin, oğlum?  
— Ben mi?  
— Evet.  
— Ne münasebet?  
— Aradığımız gibi bir adam bulamıyoruz da...  
— Ben şimdiye kadar devlet mansıbına girmedim.  
— Niçin girmedin?  
Muhsin Çelebi biraz durdu. Yutkundu. Gülümsedi:  
— Çünkü ben boyun eğmem, el etek öpmem, dedi; halbuki zamanın devletlileri mevkilerine hep boyun eğip, el etek hatta ayak öpüp, bin türlü tabasbusla, riya ile, tekâpu ile çıktıklarından etraflarına daima hep bu zelil mazilerinin çirkin hareketlerini tekrarlayanları toplarlar. Gözdeleri, nedimleri, himaye ettikleri, hep denî riyakarlar, ahlâksız müdâhinler, namussuz maskaralar, haysiyetsiz dalkavuklardır. Mert, doğru, izzetinefis sahibi, hür, vicdanının sesine kulak veren bir adam gördüler mi, hemen garez olur, mahvına çalışırlar. Gedik Ahmed Paşa niçin hançerlendi, paşam?  
— ....  
Sadrazam yavaşça dişlerini sıktı. Gözlerini süzdü. Tuttuğu kağıdı buruşturdu. Hiddetlenemiyordu. Ama hiddetlendiği zamanlarda olduğu gibi yanaklarına bir titreme geldi. Vezirken değil, hatta daha beylerbeyi iken bile karşısında akranlarından kimse böyle dümdüz laf söyleyememişti. Tekrar "Acaba deli mi?" diye düşündü. Deli değilse... Bu ne küstahlıktı. Bu derece küstahlık, "nizamı âleme" muhalif değil miydi? Gözlerini daha beter süzdü. İçinden, "Şunun başını vurdursam..." dedi. Kapıcılara bağırmak için ağzını açacaktı. Ansızın vicdanının -neresi olduğu bilinmeyen bir yerinden gelen- derin sesini işitti: "İşte, sen de tabasbus, riya, tekâpu yollarından yükselenler gibi, serbest, düz, bir lafı çekemiyorsun! Sen de karşında mert bir insan değil, ayaklarını yalayan bir köpek, zilletinin altında iki kat olmuş bir maskara, bir rezil istiyorsun!"  Süzgün gözlerini açtı. Avucunda sıktığı kağıdı yanına koydu. Tekrar Muhsin Çelebi'ye baktı. Ortasında geniş bir kılıç yarasının izi parlayan yüksek alnı...al yanakları...yeni tıraşlı beyaz, kalın boynu...biraz büyücek, eğri burnu...ince sarığı...tıpkı Şehnâme sahifelerinde görülen eski kahramanların resimlerine benziyordu. Evet, bu, alnında yarası görülen kılıcın yere düşüremediği canlı bir kahramandı. İnsaflı sadrazam, vicdanının ruhuna akseden sesini, gururunun karanlığı ile boğmadı. "Tam bizim aradığımız adam işte..." dedi. Bu kadar pervasız bir adam devletine, milletine yapılacak hakareti de çekemez, ölümden korkarak, göreceği hakaretlere eyvallah diyemezdi. Kavuğunu hafifçe salladı:  
— Seni Tebriz'e elçi göndereceğiz.  
Muhsin Çelebi sordu:  
— Katınızda bu kadar nişancılar, kâtipler, hocalar var. Niçin onlardan intihâb etmiyorsunuz?  
— Sen, Şah İsmail denen habisin kim olduğunu biliyor musun?  
— Biliyorum.  
— Devletini seviyor musun?  
— Seviyorum.  
Hakim sadrazam doğruldu. Arkasına dayandı:  
—  Pekâlâ  öyleyse, dedi, bu habis "elçiye zeval yok" kaidesini kabul etmez. Bizimle rekabet davasındadır. Er meydanında hakkımızda yapamadıklarını bizim göndereceğimiz elçiye yapmak ister. İhtimal işkenceyle idam eder. Çünkü Allah'tan korkusu yoktur. Halbuki elçimize yapılacak hakaret devletimize demektir. Bize öyle bir adam lazım ki, hakaret görünce başından korkmasın... Bu hakareti aynıyla o habise iade etsin... Devletini seversen sen bu fedakarlığı kabul edeceksin!  
Muhsin Çelebi hiç düşünmedi:  
— Ettim efendim, fakat bir şartla, dedi.  
— Ne gibi?  
— Mademki bu bir fedakarlıktır, fedakarlık ücretle olmaz. Hasbî olur. Devlete karşı ücretle yapılacak bir fedakarlık, ne olursa olsun, hakikatte şahsi bir kazançtan başka bir şey değildir. Ben maaş, mansıp, ücret filan istemem. Fahri olarak bu hizmeti görürüm. Şartım budur!  
— Fakat oğlum, bu nasıl olur? Onun elçisi gayet ağır giyinmişti. Atları, hademeleri mükemmeldi. Bizim elçimizin atları, hademeleri, esvabı daha muhteşem, daha ağır olmak icap eder. Bunlar için mutlaka hazineden sana birkaç bin altın vereceğiz.  
Muhsin Çelebi döndü. Önüne baktı. Sonra başını kaldırdı:  
— Hayır, dedi, hazineden bir pul almam. İcap eden muhteşem takımlı atları, süslü hademeleri ben kendi paramla düzeceğim. Hatta...  
— .....  
Sadrazam gözlerini açtı.  
— ... Hatta sırtıma Şah İsmail'in ömründe görmediği ağır bir şey giyeceğim.  
— Ne giyeceksin?  
— Sırmakeş Toroğlu'ndaki, dîbâsı Hind'den, harcı Venedik'ten gelme "Pembe İncili Kaftan"ı alacağım.  
— Ne... O kadar parayı nerede bulacaksın, oğlum?  
Sadrazamın şaşmaya hakkı vardı. Bir ay evvel tamamlanan, üzeri en nadir pembe incilerle işlemeli bu kaftanın namını İstanbul'da duymayan yoktu. Vezirler, elçiler, padişaha hediye etmek için Toroğlu'na müracaat ettikçe, o, fiyatını artırıyordu. Muhsin Çelebi, bu meşhur kaftanı nasıl alacağını anlattı:  
— Çiftliğimle, mandıramı, evimi rehine vereceğim; tüccarlardan on bin altın borç toplayacağım. İki bin altın atlarla hademelere sarf edeceğim. Geriye kalan sekiz bin altına da bu kaftanı alacağım.  
Sadrazam bu hareketi makul bulmadı:  
— Geldikten sonra bu kaftan senin işine yaramaz. Yalnız bir debdebe aletidir. Mallarını elinden çıkaracaksın. Fakir düşeceksin.  
— Hayır. Sekiz bin altına alacağım kaftanı altı ay sonra Toroğlu benden yedi bin altına geri alır. Yedi bin altınla ben çiftliğimi rehinden kurtarırım. Geri kalan borçlarımı ödeyemezsem, varsın babamın yadigar bıraktığı mandıram devlete feda olsun... Devletten hep alınmaz ya... Biraz da verilir!  
— ......  
Muhsin Çelebi ile konuştukça sadrazamın hayreti büyüyordu. Kalbi rahatladı. İşte küstah, türedi bir hükümdara haddini bildirmek için gönderilecek tam bir adam bulunmuştu. Gülüyor, ağır kavuğunu sallıyordu. Dîvan'ın nazik, korkak, hesapçı çelebileri canlarıyla mallarını çok severlerdi. Bunlardan biri elçi gönderilse, devletinin haysiyetinden ziyade alacağı ihsanı düşünerek, hakkında revâ görülen her hakareti kabul edecekti. Sadrazam, Muhsin Çelebi'yi yemeğe de alıkoymak istedi. Muvaffak olamadı, giderken onu tâ sofaya kadar teşyi etti.

......Altı ay içinde Muhsin Çelebi büyük çiftliğini, mandırasını, evini, dükkânını, bahçesini, bostanını rehine koydu. Tüccarlardan para topladı. Atlarını, hademelerini düzdü. Bunların hepsi hakikaten emsali görülmedik derecede muhteşemdi. Dönüşte yedi bin liraya iade etmek şartıyla Toroğlu'ndan meşhur Pembe İncili Kaftan'ı da aldı. Genç karısıyla iki küçük çocuğunu akrabasından birinin evine bıraktı. Altı aylık nafakalarını ellerine verdi. Sonra padişahın nâmesini koynuna koyarak yola düzüldü. Konak konak ilerledikçe bu yeni elçinin debdebesi, dârâtı, hele incili kaftanının şöhreti bütün Anadolu'dan geçerek Şah İsmail'in diyarına taşıyordu. Muhsin Çelebi bir gün Tebriz kalesine büyük bir ihtişamla girdi. Bu küçük pâyitahtın süse, dârâta, renge, ziynete meftun halkı, İstanbul elçisinin kaftanını görünce şaşırdılar. Şehir, saray, bütün encümenler kaftanın hikâyesiyle doldu. Şah İsmail "Pembe İnci"yi yalnız masallarda işitmiş, daha nasıl şey olduğunu görmemişti. Kendisinin daha görmediği şeye sahip olan bu zengin elçiye karşı nefsinde derin bir garez duydu. Onu hakareti altında ezmeye karar verdi. Huzuruna kabul etmezden evvel tahtının arkasına cellatlarını hazırlattı. Tahtın önündeki dibâ şilteleri, ipek seccadeleri kaldırttı. Sağında vezirleri, solunda muharipleri duruyorlardı.

...Muhsin Çelebi, geniş somaki kemerli açık kapıdan serbest adımlarla girdi. Yürüdü. Başı her vakitki gibi yukarda, göğsü her vakitki gibi ileride idi. Koynundan çıkardığı nâme-i hümâyununu öptü. Başına koydu. Sonra altın tahtın üstüne -allı, yeşilli, mavili, morlu, ipek yığınlarına sarılmış, sırmalarla, tuğlarla, sancaklarla bağlanmış gibi- garip bir yırtıcı kuş sükûnetiyle tüneyen Şah'a uzattı. Ayağı öpülmeyen Şah gazabından sapsarı kesildi. Gözlerinin beyazları kayboldu. Nâmeyi aldı. Muhsin Çelebi, tahtın önünden çekilince şöyle bir etrafına baktı. Oturacak bir şey yoktu. Gülümsedi. İçinden: "Beni mecburen ayakta, hürmet vaziyetinde tutmak istiyorlar galiba..." dedi. Bir an düşündü. Bu hakarete nasıl mukâbele etmeliydi? Hemen sırtından Pembe İncili Kaftan'ı çıkardı. Tahtın önüne, yere serdi. Şah İsmail, vezirleri, kumandanları aptallaşmışlar, hayretle bakıyorlardı. Sonra bu kıymettar kaftanın üzerine bağdaş kurdu. İnce dev, ejderha resimleri nakşolunmuş sivri kubbeyi, yaldızlı kemerleri çınlatan gür sadâsıyla: — Nâmesini verdiğim büyük padişahım, Oğuz Kara Han neslindendir! diye haykırdı, dünya yaratıldığından beri onun ecdadından kimse kul olmamıştır. Hepsi padişah, hepsi hakandır. Ecdâdı hilkatten itibaren hükümdar olan bir padişahın elçisi, hiçbir ecnebî padişah karşısında dîvan durmaz. Çünkü kendi padişahı kadar dünyada asil bir padişah yoktur. Çünkü... Muhsin Çelebi, kaba Türkçe nutkunu bağırdıkça, fârisî bilmeyen Şah kızarıyor, sararıyor, morarıyor, elinde heyecandan açamadığı nâme, tir tir titriyordu. Tahtının arkasındaki cellatlar kılıçlarını çekmişlerdi. Muhsin Çelebi bağırdı, çağırdı. Mukarripler, vezirler, cellatlar, muharipler hükümdarlarının sabrına, tahmmülüne şaşıyorlardı. Hatta içlerinden birkaçı mırıldanmaya başladı. Muhsin Çelebi, sözünü bitirince müsaade filan istemedi, kalktı. Kapıya doğru yürüdü. Şah İsmail donmuş, taş kesilmişti. Çaldıran'da kırılacak gururu, bugün, bu tek Türk'ün ateş nazarları altında erimişti. Muhsin Çelebi dışarı çıkarken, kendi gibi hayretten donan nedimlerine: — Şunun kaftanını veriniz, dedi. Muhariplerden biri koştu. Tahtın önünde serili kaftanı topladı. Türk elçisine yetişti: — Buyurun. Kaftanınızı unutuyorsunuz. Muhsin Çelebi durdu, güldü. Çıktığı kapıya doğru dönerek Şah'ın işiteceği yüksek bir sesle: — Hayır, unutmuyorum. Onu size bırakıyorum. Sarayınızda büyük bir padişah elçisini oturtacak seccadeniz şilteniz yok... Hem bir Türk yere serdiği şeyi bir daha arkasına koymaz... Bunu bilmiyor musunuz? dedi.

...Geçtiği yollardan gece gündüz dörtnala döndü. Üsküdar'a girdiği zaman, Muhsin Çelebi'nin cebinde tek bir akçe kalmamıştı. Süslü hademelerine dedi ki:  
— Evlatlarım! Bindiğiniz atları, haşa ları, takımları, üstünüzdeki esvâbları, belinizdeki murassâ hançerleri size bağışlıyorum. Bana hakkınızı helal ediyor musunuz?  
— Ediyoruz.  
— Ediyoruz.  
— Anamızın ak sütü gibi.  
Cevabını alınca onları başından savdı. Geniş bir nefes aldı. Evine uğramadan, deniz kıyısına koştu. Bir kayığa atladı. Sadrazamın konağına gitti. Nâmeyi Şah'a verdiğini, hiçbir hakarete uğramadığını, Şah'ın müsaadesine tenezzül etmeden habersizce kalkıp İstanbul'a döndüğünü söyledi. Zaten Sadrazam, onun vazifesini hakkıyla îfâ edeceğinden son derece emindi. Yollara, derebeylerine, aşiretlere dair bazı şeyler sordu. Çelebi kalkıp çekileceği zaman:  
— Ben satın almak istiyorum, oğlum, kaftanın burada mı? dedi.  
— Hayır, getirmedim.  
— Acemistan'da mı sattın?  
— Hayır, satmadım.  
— Çaldırdın mı?  
— Hayır.  
— Ya ne yaptın?  
— Hiç!  
Sadrazam ısrar etti, tekrar tekrar sordu. Kaftanın ne olduğunu bir türlü anlayamadı. Muhsin Çelebi, yaptığı ile iftihar edecek kadar küçük ruhlu değildi. O akşam Üsküdar'a döndü. Ertesi günü yedi bin altına geri almak için kendisini bulan Sırmakeş Toroğlu'na da kaftanı ne yaptığını söylemedi. Meraklı İstanbul'da, hiç kimse, meşhur Pembe İncili Kaftan'ın "nasıl, nerede, niçin" bırakıldığını öğrenemedi. Tebriz sarayındaki macera, tarihin karanlığına karıştı, sır oldu. Fakat eski zengin Muhsin Çelebi, bu kaftan için girdiği borçları verip çiftliğini, mandırasını, iradlarını rehinden kurtaramadı. Elçilikten yadigar kalan atı ile murassâ takımını satıp Kuzguncuk'ta minimini bir bahçe aldı. Onu ekip biçti. Çoluğunun çocuğunun ekmeğini çıkardı. Ölünceye kadar Üsküdar pazarında sebzevatçılık etti. Pek fakir, pek acı, pek mahrum bir hayat geçirdi. Ama yine ne kimseye boyun eğdi, ne de bütün servetini bir anda yere atmakla gösterdiği fedakarlığa dair gevezelikler yaparak boşu boşuna pohpohlandı!

# Perili Köşk

Sermet Bey döndü, arkasındaki bekçiye:  
— İşte bir boş köşk daha...  
Dedi.

Küçük bir çam ormanının önünde beyaz, şık bir bina. Mermerdenmiş gibi göz kamaştıracak derecede parlıyordu. Tarhlarını yabanî otlar bürümüş. Bahçesinin demir kapısında büyük bir "Kiralıktır" levhası asılıydı. Bekçi başını salladı:  
— Geç efendim, geç!... Orası size gelmez.  
— Niçin canım?  
— Demin gösterdiğim evi tutunuz. Küçük ama çok uğurludur. Kim oturursa erkek çocuğu dünyaya gelir.  
— On iki kişi nasıl sığarız beş odaya! Buraya bakalım, buraya... Tam bize göre...  
Bekçi tekrar, katî bir işaretle:  
— Buraya oturamazsınız efendim...  
Dedi.

Sermet Bey, gözünü köşkten alamıyordu. Her tarafında geniş balkonları vardı. Temellerinin üzerine yaslanmış sanılacaktı. Kuluçka yatan beyaz bir Nemse tavuğu gibi yayvandı. Yirmi senedir, çoluğa çocuğa kavuşalıdan beri, hep böyle bir yuva tahayyül ederdi. Asabî bir isticâl ile:  
— Niçin oturamayız? diye sordu.  
— Efendim, bu köşkte peri vardır.  
— Ne perisi?  
— Bayağı peri! Gece çıkar. Evdekilere rahat vermez.  
Sermet Bey, gözüyle gördüğüne, kulağıyla işittiğine inananlardan değildi. Eliyle sıkı sıkıya tutup hissetmeyince bir şeyin varlığına hükmetmezdi. Gözle kulak onca birer yalan kovuğuydu. Yalanla hep bize bu dört kapıdan girerdi. Fakat el... Fakat lâmise, hiç dolma yutmazdı. Bütün hurafeler, bâtıl itikatlar dimağımıza hücum için gözle kulağa koşardı. Güldü.  
— Perinin bize zararı dokunmaz!  
Dedi. Bekçi bir küfür işitmiş gibi Sermet beyin yüzüne baktı.  
— Her giren evvela böyle söyler, ama bir ay oturmaz.  
— Senin nene lazım. Haydi burasını gezelim.  
— Anahtarı sahibindedir.  
— Sahibi kim?  
— Sahibi Hacı Niyazi Efendi. İşte şu yandaki köşkte oturan...  
— Haydi anahtarı alalım.  
— Peki, ama...  
Döndüler. Sık ağaçlar arasından yalnız üst katının çatısı görünen kırmızı aşıboyalı bir eski eve doğru yürüyorlardı.

İhtiyar bekçi yolda beyaz köşkün tarihini kısaca anlattı. On senedir buraya girenler bir aydan ziyade oturamamışlardı. Evvela peri görünüyor, sonra büyük büyük taşlar atıyor, nihayet gelip camları kırıyor, içeridekilere geceleri hiç rahat vermiyordu. Kiracılardan ikisinin yüreğine inmiş, üçünün evlatlıkları çarpılmış, birisinin karısı korkudan altı aylık çocuğunu düşürmüştü. Gölgelerinde koyunlar otlayan çiçekli badem ağaçlarının altından geçtiler. Kırmızı köşkün  yeşil kapısını çaldılar.

Hacı Niyâzi Efendi eski bir evkaf memuruydu. Hürriyette tazminat olarak daireden çekilmiş, ev alıp satmakla geçinmeye başlamıştı. Fakat çok doğru bir adamdı. Senede belki yüz ev sattığı halde kendi perili köşkünü hariçten gelip Hanya'dan Konya'dan haberi olmayan enayi bir müşteriye sokmuyor: "Allah'tan korkarım neme lazım!" diyordu. Köşkünün perili olduğunu hiç saklamazdı. Kapıyı kendi açtı.  Bekçi,Sermet Bey'in evi gezmek istediğini söyledi: — Pekâlâ, buyurun! Dedi. Önlerine düştü. Bahçeden geçtiler. Hacı Niyâzi Efendi sokakta sarı aba cübbesinin cebinden pirinç bir anahtar çıkardı. Bahçe kapısını açtı. Sermet Bey'e: — Bu anahtar köşkü de açar. Dedi. Yürüdüler, bahçe hakikaten biraz vahşiydi. Bakımsızlıktan, ayak basmamış bir dere içine dönmüştü. Köşkün arkasındaki küçük çam ormanında da vahşi bir sükun vardı. Bekçi köşke girmedi. Kapıda kaldı. Sermet Bey, ev sahibiyle gezdi. Tezyinata hiç diyecek yoktu. Alt kat bütün mermerdi. Sarnıç, banyo, kuyu, kümes, ahır... Hepsi tamamdı. — Kirası ne kadar? — Çok istemiyorum. Yüz seksen lira. Ama üç seneliğini peşin isterim. — Niçin? — Bakınız beyim, niçin: Düşmanlarım, köşk kiracısız kalsın diye peri lafı çıkarmışlar. Birisi girdi mi, herkes fi-sebîlillâh peri propagandasına başlar. Nihayet kiracılar işittikleri yalanı, gördük sanıyorlar. Mesela kış ortası köşkü başıma bırakıp savuşuyorlar. Daha fenası, çıkanlar  da propagandacılara katılıyor. İki sene daha böyle giderse malımı ne satabileceğim, ne de kiracı bulabileceğim.

Sermet Bey sordu:  
— Köşkünüz ne kadar boş kaldı?  
— Vâkıâ şimdiye kadar hemen hiç... Fakat giren, komşuların lafına kapılır. Çok durmaz. Ürker, kaçar.  
— Ben ürkmem.  
— İnşallah.  
— Fakat üç senelik peşin, bu biraz ağır...  
— Ne yapayım beyim. Canım yandı. İsterseniz...  
Sermet Bey köşkü çok beğenmişti. Hem kirası da ucuzdu. Şimdi üç odalı kulübelerin seneliğine yüz elli lira istiyorlardı.

Hemen o gün kontratı yaptılar. Üç senelik kira olan beş yüz kırk lira peşin verilecekti. Hacı Niyâzi Efendi'nin evinden çıktıktan sonra Sermet Bey bekçiyi çıkardı, bahşiş diye bir yirmi beşlik kağıt verdi. Bekçi: — Paranıza yazık oldu efendi dedi, üç sene değil, üç ay oturamazsınız. — Görürsün. — Görürüz. Hacı Efendi her girenden böyle üç seneliğini peşin alır, ama hiçbirisi bir yaz kalamaz. Verdikleri para da yanar.

Sermet Bey bir hafta sonra kalabalık ailesiyle köşke taşındı. Halis bir zevk ehliydi. Her gece çalgı çağanak, yemek, içmek, keyif, sefa gırla giderdi. Daima akrabalarından kadın, erkek, dört beş misafiri bulunurdu. Sermet Bey Türkiyeli'ydi. Fakat Avrupalıların "Gündüz cefa, gece sefa" düsturunu kabul etmişti. Çocukları mektebe giderlerdi. Kızlarını büyük ticarethanelere kâtip diye yerleştirmişti. Karısı kız mekteplerinde piyano dersi verirdi. Evde çalışmayan yalnız yetmiş beşlik annesiydi. O da mutfağa, hizmetçilere, filan bakardı. Yemeği gece yarısına yakın yerler, yemekten sonra hiç oturmazlar, hemen yatarlardı. Aradan on beş gün geçmedi. Bir gece aşağı kattan bir çığlık koptu. Hizmetçi Artemisya, avazı çıktığı kadar haykırarak yukarı koştu. Arkada, çamların arasında beyaz bir şeyin gezindiğini haber verdi.  
— Gözünüze öyle görünmüştür!  
Dedi. Gören diğer hizmetçilere de kanmadılar. Çoluk, çocuk, hepsi arka odanın balkonuna çıktılar. Artemisya'nın parmağıyla gösterdiği beyaz hayaleti gördüler. Ağaçların altında duruyor, sanki köşke bakıyordu. Sermet Bey gözlerini oğuşturdu:  
— Vay anasını! dedi, telkinin kuvvetine bak!  
Karısı, kızları, çocukları korkudan sapsarı kesildiler. Büyük kızı:  
— Ne telkini beybaba! İşte karşımızda, görmüyor musun?  
Dedi.  
— Görüyorum.  
— Ey, o halde telkin ne demek?  
— Buraya girdik gireli peri masalından başka bir şey işittik mi? Her gelen bir şey söyledi. Şimdi biz bu tesirle böyle hepimiz birden, olmayan bir şeyi görüyoruz.  
— Bu mümkün değil.  
— Nasıl değil?  
Sermet Bey, hokkabaz Kazanöv'ün nasıl bütün bir tiyatro halkına ceplerindeki saati yanlış gösterdiğini filan anlattı. "Gözümüz kulağımızdan giren yalanları görür dedi, fakat elimizi bu gördüğümüz şeye sürmeyiz. Hemen kaybolur". Sonra kalktı. Karısının menetmesini filan dinlemedi. Elini görünen hayale sürmek için bahçeye fırladı. Çamlara doğru gitti. Fakat hayal kaçtı. Kayboldu. O gece evin içinde Sermet Bey'den başka kimse uyuyamadı.

... Artık her gece bu hayali görüyorlardı. Sermet Bey, elini sürmeye çıkınca hayal kaçıyordu. Biraz alışır gibi oldular. Fakat bir gece hepsi uyurken müthiş bir sarsıntı köşkü yerinden oynattı. Balkonlara koştular. Bir şey göremediler. Sabahleyin yemek odasının dibinde kocaman bir taş buldular. Sermet Bey'e annesi: "Bizi bu köşkten çıkarmazsan sana hakkımı helâl etmem" demeye başladı. Beşyüzkırk liraya iki ay oturmak... Bu Sermet Bey'in işine gelecek şey değildi. Ama gece aşırı büyük büyük taşlar ev halkına uyku uyutmuyor, hepsini heyecan içinde bırakıyordu. Sermet Bey, her defasında hayalin üzerine gidiyor, bir türlü elini süremiyordu. Taşların başladığını duyan komşular: "Daha çıkmazsanız camlarınızı da kırar" diyorlardı. Sermet Bey kontratın, "Çıkarken bütün tamirat müstecire aittir" maddesini hatırlayarak daha ziyade canı sıkılıyor, bu cam kırma devresinin hulûlünden evvel bir şey yapmayı düşünüyordu. Yavaş yavaş kendi itikadı da bozulmaya başladı. Nihayet çıkmaya karar verdiler. Fakat başka bir ev bulamıyorlardı. Köşke dair daha bin türlü hikayeler işitmeye başladılar. Sözde burası eskiden kabristanmış. Mutfağın olduğu yerde beşyüz senelik bir evliya yatıyormuş... Sermet Bey, atılan taşlara, kırılan camlara rağmen hâlâ periye inanmıyordu. Bu peri daima çamlığın içine kaçıyor, orada sır oluyordu. Sermet Bey, bir gün çamlığın içine saklanıp birdenbire perinin karşısına çıkmayı, yahut arkasından yavaşça gidip elini sürüvermeyi düşündü. Evdekilerin hiçbiri buna razı olmadı: "Seni hemen oracıkta çarpar!" diyorlardı. Fakat Sermet Bey, bulanan gönlüne rağmen, periye, ecinniye filan bir türlü inanmıyordu. Ertesi akşam koruya gitti. Büyük bir çamın alt dallarından birine bindi. Bekledi, bekledi. Gece yarısı oldu. Köşktekiler de meraktan uyuyamıyorlardı. Zavallıların balkonlarda gezindiklerini görüyordu. Birdenbire yüreği hop etti. Hayal sökün etmişti.

Eliyle dokununca gölge gibi uçup silineceğini katiyen bildiği halde yine Sermet Bey'in dizleri titremeye başladı. İçinden: "Ben korkmuyorum, fakat vücudum korkuyor!" dedi. Yavaşça aşağı atladı. Hayalin arkasından yürüdü. Şeklinin hatları pek sarih gözüküyordu. Yaklaştığını hayalet hiç duymadı. Yavaşça elini uzattı. Beyaz cisme dokundu. Hayal birdenbire fena halde ürktü. Ama kaybolmadı. Döndü, Sermet Bey'i görünce alabildiğine kaçmaya başladı.

Sermet Bey, dokununca kaybolmadığı için bu hayalin peri filan olmadığını hemen anlamıştı. Peşini bırakmadı. Kovaladı. Çamlığın sonundaki alçak duvara dayalı bir tahtaya tırmanırken yakaladı. Gayet kuvvetliydi. Hayal, mukâbele olmadığını anlayınca çırpınmaktan vazgeçti. Sermet Bey: — Ben sana elâlemle alay etmesini gösteririm! Diye zavallı hayali sırtladı. Köşke doğru sürükledi. Bağırdı: — Lamba getirin, suratını görelim. — ... Köşk halkı bahçe kapısına inmişti. — İnsanmış kerata! Ben dünyada ecinni filan yoktur, demez miyim? Hayal bir türlü beyaz çarşafı başından bırakmak istemiyordu. Sermet Bey zorla çekti. Sakalı bıyığına karışmış Hacı Niyâzi Efendi'yi görünce şaşırdılar. Biçare, yüzünü göstermemek için elleriyle örtüyordu. Arkasındaki Şam kumaşından gecelik entarisi yırtılmıştı.

Sermet Bey bir kahkaha attı.

Kızlar, çocuklar, hizmetçiler alıklaştılar.

Büyük Hanım, — Niçin ümmet-i Muhammed'i korkutup deli ediyorsun a efendi?... Dedi. Sermet Bey: — Onun sebebini ben bilirim! Cevabını verdi. Sonra büyük kızına hokka kalemle, yazıhanedeki kontrat kağıdını çabucak getirmesini söyledi. Hacı Niyâzi Efendi donmuş gibi, sorulan şeylere hiç cevap vermiyor, hep yüzünü karanlıklara çeviriyordu. Kontrat kağıdıyla hokka kalem gelince, Sermet Bey: — Haydi bakalım, al eline kalemi!... Yüreğine indirdiklerinin, düşürttüğün çocukların cezasını görmek istemiyorsan söylediğimi yaz, imzayı bas! Dedi. Hacı Niyâzi Efendi mihânîkî bir hareketle kaleme kaptı. Sermet Bey'in kelime kelime söylediklerini tereddüt etmeden yazdı:

"Kiracım Sermet Bey'den köşkün altı senelik kirası olan bin seksen lirayı peşinen, aldım".  
— Hah şöyle!  
— ...

İmzasını attı. Beyaz örtüsüne bu sefer yarım bürünmüş olduğu halde, her gece sır olduğu tarafa gitti.

Sermet Bey'in iki senedir köşkte oturabildiğine herkes hayrette kaldı. Komşuları Hacı Niyâzi Efendi'ye: — Galiba senin evin ecinnileri, başka eve göç ettiler. Yeni kiracın hiç çıkacağa benzemiyor! Dedikçe, evvela sararıyor, sonra kızarıyor, şu cevabı homurdanıyordu: — Ne abdest, ne oruç, ne namaz, ne niyaz... Karılı, erkekli, çoluklu çocuklu hepsi akşamdan sabaha kadar sarhoş! Ayol onlara ecinni değil, şeytan bile görünemez!

# Pireler

Aşk filan değil... Hani şu "rastlantı" dediğimiz, tarihi yapan, mutlulukları yaratan, yuvaları kuran belirsiz el yok mu? İşte o, beni Rose Mayer'le birleştirmişti. Yirmi yaşında ya vardım, ya yoktum. Küçücük köpeğim Koton'la İzmir'in ikinci sınıf otellerinden birinde oturuyordum. Bir gün karşımdaki odaya, iri mavi gözlü, sarı saçlı bir Fransız kızı geldi. Kederli olduğu yüzünden belli idi. Otelciye kim olduğunu sordum. — Paris'ten bir Ermeni doktorunun peşine takılmış, doktorun ailesi kabul etmemiş, kovmuşlar. Zavallı şimdi memleketine dönmek için vapur bekliyor, dedi. İnsanın yirmi yaşındayken kalbi ne faaldir! Ben, bu basit serüveni hayalimde büyüttüm. Ağlamaktan kızarmış iri mavi gözlü kızcağızın acılarını, üzüntülerini yaşamaya başladım. Galiba vapurdan daha çok, para bekliyordu. Çünkü gizlice takip ettiğim için görüyordum ki, her gün Fransız postanesine gidiyor, mektup soruyor. Merdivenlerde, koridorlarda karşı karşıya geldikçe birbirimize dikkatli bakmaya... Sonra "bonjur, bonsuvar" demeye başladık. Nihayet bir hafta içinde dost olduk. Bana başına gelenleri ağlayarak anlattı. Teselli verdim. Hayatın felsefesini yaptım. Hiç de toy bir kız değildi. Her şeyi biliyordu. Realistti. Fakat namusuna pek büyük kıymet veriyor, sakin bir ev kadını olmasını her hayali mutluluğa tercih ediyordu. Güya ben de onun gibi sessizliği seviyordum. Bir ay geçmeden anlaştık. Paris'teki ailesinden para geldiği halde gitmedi. Benimle birleşti. İkinci Kordon'un arkasında küçük bir apartman kiraladık. Ah bu serbest evlilikler! O kadar mutlu olmuştum ki... İçimde kapalı kalmış çılgın bir sevinç kumrusunun dem çekerek çırpındığını duyuyordum. Rose, gerçekten hiç sokağı, gezmeyi sevmiyordu. Sabahtan akşama kadar evin işleriyle uğraşıyor, durmak, dinlenmek bilmez bir hırsla her tarafı, her şeyi yıkıyordu. Temizlik merakını adeta delilik derecesine getirmişti. O, ben, köpeğim, üçümüz de günde üç defa banyo ediyorduk. Geceleri Paris Kahvesi'ne veya sinemaya giderdik. Dönüşte, Rose, yorgun argın ayakkabılarımızın altını çamaşır sulu suyla siler, Koton'un ayaklarını yıkamakla kalmaz, bazı geceler zavallı hayvancağızı tepeden tırnağa kadar gıcır gıcır sabunlardı.

Fakat mutluluklar rüyadan başka bir şey midir? Bizim mutluluğumuz da çok sürmedi. Acı bir kederle uyandık. Koton fena halde hastalandı. Yemiyor, içmiyor, oynamıyor, daima yatıyor, zayıflıyor, eriyordu. Rose da benim kadar ümitsizdi.  
— Zavallı verem oldu! diyordu.  
Ne kadar veteriner varsa hepsine gösterdik. Kınakına verdiler. İçiremedik. Müshiller, şunlar bunlar hiçbir fayda vermedi. O vakitler Rahmi isminde bir arkadaşım vardı. Rose'u yalnız onunla tanıştırmıştım. Pazar günleri evimize gelirdi. Felaketimizi, Koton için ne kadar üzüldüğünü gördü.  
— Hiç veterinere gösterdiniz mi? dedi.  
— Gösterdik.  
— Hangi veterinere?  
İzmir'in bütün veterinerlerini saydım. Hele bir tanesinin iktidarını, ilmini de övmeye kalktım. Bu veteriner İslam olduğu halde santur mu, keman mı, mandolin mi ne idi, şimdi unuttuğumuz bir çalgı ismi taşıyordu. Rahmi:  
— Azizim, köpeğini kaybetmek istemezsen, Avrupalı bir veteriner bul, göster, dedi.  
— Veterinerin Avrupalısı ile Asyalısı arasında ne fark olur? dedim.  
— Çok... diye güldü.  
— Ne gibi?  
— Köpeğini gösterince görürsün.  
Bu öneriyi bir paradoks olarak düşündüm. Ama denize düşen köpüğe sarılır! Felaket zamanında, ümitsizlikte en boş, en çürük temeller üzerine ümit bina etmek ne hoş bir tesellidir. Rose da:  
— Boykotaj yapmıyoruz ya... Bir Avrupalı veterinere gösterelim, belki Rahmi Bey'in hakkı var, demeye başladı.  
Sordum, soruşturdum. Punto'da ihtiyar bir İtalyan veteriner varmış. Sığır vebası uzmanıymış. Halsizlikten gözlerini açamayan zavallı Koton'un cesedini kucağıma aldım. Evine gittim. Kapıyı kendisi açtı. Beyaz, çatal sakallı bir adamcağızdı. Galiba sokağa çıkıyordu. Şapkası başında, bastonu elindeydi.  
— Ne istiyor? dedi.  
— Köpek hasta, dedim.  
Kalın bastonunu kapının kenarına dayadı. Titrek zayıf elleriyle Koton'u kucağımdan aldı. Gözlerine, ağzına baktı. Sonra tüyleri kokladı. Elleriyle bu beyaz tüyleri araladı. Dikkatli dikkatli baktı.  
— Bunun üzerine bir avuç pire koy, iyi olacak! dedi.  
— Ne demek?  
— Pire oğlum, bir avuç pire!..  
Koton'u uzattı. Aldım. Birdenbire fena halde canım sıkıldı. Terbiyesiz, bunak, işte benimle eğleniyordu.  
— Bir ilaç vermeyecek misiniz? dedim.  
İhtiyar gülerek yine münasebetsiz tavsiyesini tekrarladı:  
— Bir avuç pire! Yıkamayacaksın. Üzerinde kalsın. Bu ilaçtır!  
Hiddetlendim.  
— Benimle eğleniyor musunuz?  
— Ne eğlenmek? Doğru söylerim. Başka ilaç istemez bu...  
— Bunak herif!  
— Ben, ben bunak ha...  
— Sen ya...  
Canımın sıkıntısından az daha ihtiyarı dövecektim.  
— Ben bunak ha?  
— Hem bunak, hem terbiyesiz! Ben sana insan gibi hasta hayvanı getiriyorum, sen gevezelik ediyorsun.  
Hani Avrupalıların dehşetli cehaletler karşısında acır gibi donuk bir gülüşleri vardır. İhtiyar İtalyan veteriner bu özel gülüşle beni baştan aşağı bir süzdü. Sonra:  
— Haydi bre, kafasız adam, sen anlamaz bir şeyden. Git, benim dediğimi yap. İyi olursa viziteyi getireceksin. İyi olmazsa yine geleceksin. Benim yüzüme "tuh" yapacaksın.  
— ...  
Cevabı beklemedi, kapıyı hızla çekti, önümden uzaklaştı.

Acaba bu ilacı yapmalı mıydım? Bir taraftan ihtiyarın "Türk" diye bana önem vermeyip alay edişine kızıyor, bir taraftan hâlâ bu alayı sahi zanneder gibi oluşuma hiddetleniyordum. Eve geldim. Rose'a, ihtiyarın terbiyesizliğini söyledim. — Belki sahidir, bir kere deneyelim, dedi. — Budala mısın? diye güldüm. — Ümit bu. — Pekala. Fakat pireyi nerede bulmalı? Her gün iki defa yıkanan evde pirenin kendi değil, ruhu bile yoktu. Ertesi gün yine Koton'un hareketsiz cesedini kucağıma aldım. İncir tüccarlarından bir arkadaşımın mağazasına gittim. Pireye ihtiyacım olduğunu anlattım. — Bizim çuval deposunda bir avuç değil, ordularla bulunur,dedi. Koton'u bir ekmekle bu depoya bıraktık! Üzerinden kapıyı kapadık. Bir gün sonra mağazaya Koton'u görmeye gittim. Deponun kapısını açtık. Koton canlanmış, ayağa kalkmıştı. Beni görünce eski, mesut zamanlarında olduğu gibi sıçramaya başladı. O kadar sevindim ki... Kucakladığım gibi doğru eve koştum. Rose, sevgili köpeğimizin tekrar hayata geldiğini görünce benden ziyade sevindi. — Aman pireleri üzerinden uçmasın, dedim. — Nasıl uçurmayalım? — Yıkama. — Yıkamam. Rose bir hafta sabretti. Hakikaten yıkamadı. Koton o kadar canlandı, o kadar iştahı açıldı ki... Hacmine eşit yemekle artık doymuyordu. Doktorun, bu nasıl etki ettiğini hâlâ anlayamadığımız tavsiyesini alay zannettiğime pişman oluyordum. Zavallıya hakaret de etmiştim. Fakat itiraf edilen kusurlar hep affedilirler. Mutluluğumuzu tekrar bize veren bu ihtiyara hem af dilemek, hem bakma ücretini vermek ihtiyacı beni rahatsız etmeye başladı. Bir sabah kalktım, evine gittim. Bu sefer kapıyı genç bir hizmetçi kız açtı. Beni ihtiyarın tül perdeli küçük odasına soktu. Maroken bir koltuğa uzanmış, beyaz porselenden bir pipoyu içiyordu. Yerinden kalkmadı. — Nasıl köpek, iyi oldu? — Oldu, dedim. — Gördün, nasıl sende kafa boş! Ben söyler, sen şaka sanır! Yanındaki masanın üzerine bir lira bıraktım. Çıkarken kendimi tutamadım, döndüm. — Fakat mösyö, dedim, bizim veterinerler o kadar ilaçlar verdiler, etki etmedi. Pireler nasıl etki etti de köpek canlandı? — Buna senin aklın ermez. — Niçin mösyö, ben insan değil miyim? — İnsan ama, başka insan! Cahil adam! — Fakat ben okudum. — Sizin veterinerler kadar okudun? Verirler köpeğe içmek için ilaç! Sacristi! Fransızca söylemeye başladım. Pirenin nasıl etki ettiğini anlamaya iyice kararlıydım. İhtiyar Avrupalı gülmeye başladı. Beni karşısına oturttu. Medli İtalyan Fransızcasıyla: — Aç o boş kafanın kocaman kulaklarını! dedi. Bu emir, beni öyle sarstı ki, adeta kulaklarımın uzayarak sallandıklarını hisseder gibi oldum. Sağ eliyle çatal sakalının birini bırakıp birini tutuyordu. Ders verir gibi söylenmeye başladı: — Siz isterseniz muska... Siz istersiniz üfürük... Siz istersiniz ilaç! Halbuki hastalıkların evvela nedenlerini bulmak lazım. Bu neden bulununca şifa bulundu demektir. Senin köpek hasta. Niçin? Bunu sizin veterinerler düşündü mü? Hayır... Ama yalnız hasta! İlaç lazım... Hayır, nedeni bulmak lazım. Allah dünyada hiçbir hayvanı, hiçbir organı görevsiz yaratmadı. En fena hayvanların, en muzır mikropların bile görevleri vardır. Dört ayaklı hayvanlar çok tembeldirler. Allah bunların üzerine pireleri koydu. Niçin? Uyandıkları zaman rahatsız olup tekrar uyumamaları için... Bu pirelerin ısırmalarından kaşınarak hareket, yani jimnastik yapmak için... Siz ne yaptınız? Bu köpeği yıkadınız. Üzerine kolonya sürdünüz. Vücudunda hiç pire kalmadı. Rahat uyumaya başladı. Uyandı, tekrar uyudu. Uyandıktan sonra onu uyutturmayacak hayvanlar üzerinde yoktu. Uyuya uyuya iştahı kapandı. Midesi bozuldu. Yemedi, içmedi, hareket etmedi. Vücudu toksin doldu. Hastalandı. Bir ay daha üzerine pire koymayaydınız açlıktan, halsizlikten ölecekti!..

İhtiyar veteriner, pirelerin hayattaki bütün görevini sırasıyla anlattı. Sonra sineklere, farelere, vızvızlara, kedilere geçti. Küçük buzağıları koşturmak için tabiat, burunlarının dokunamayacağı bir yere, mesela kuyruklarının dibine birtakım yapışkan sokucu sinekler musallat ediyordu. Darwin'in gerçeklerini dinliyordum. Veteriner, sonra organların görevine geçti. Saçın, bıyığın, kirpiklerin, kaşların görevini söyledi. Sakalın ikinci derecede bir hazım aleti olduğunu anlatırken şaşaladım. — Ah siz Türkler, vücut için, hayat için ne kadar lüzumlu olan organlarını keser, görevlerini bozarsınız! dedi. — Ne gibi? — Mesela koltuğunuzun altındaki kılları kesersiniz. — Onların görevi ne? — Burnunun içindeki, kulağın içindeki kıllar gibi onun da görevi var. Koltuğun altında adale yoktur. Yalnız ince bir deri. Halbuki ciğerlerin uçları burada. Soğuktan, sıcaktan ciğerleri korumak için tabiat, oraya doğal bir kürk koydu... . . . . . . .

Yarım saat içinde bütün vücudumuzun kopardığımız doğal küreklerini, düşünmeden kestiğimiz diğer organlarımızın da hayret verici önemli görevlerini ayrıntısı ile öğrendim. Gerçekten hayatın pozitif esrarı bir Asyalının iman dolu olumsuz kafasına sığacak iş değildi. Rahmi'ye hak verdim! Rose, artık Koton'u yıkamaktan vazgeçti. Sevgili köpeğimizin pireleri az zamanda bütün apartmana yayıldı. O kadar ki... Bizi bile eskisi gibi öğleye kadar yatağımızda uyutmuyor, daha güneş doğmadan erkence kalkıp kahvaltımızı yemeye mecbur ediyordu.

# Piç

Ah Mısır! Bazı Türkler oraya eğlenmeye, hava değişimine giderler! Bilmem o hayata, o manzaraya nasıl tahammül ederler? Ciğerlerine milyonlarca verem mikrobu saldırmış üzgün ve halsiz yatan bir hastanın başucunda hiç eğlenilir, hiçbir yaralının akmış ve daha kurumamış kan selleri üzerinde badeler içilir, keyifler çatılır, naralar atılır mı? Ben, mümkün değil bir hafta oturamam. Geniş ve otomobil dolu caddeler, heykelli meydanlar, içine girilmez bir kuvvet ve bir para kalesi gibi yükselen büyük bankalar, büyük tiyatrolar, peri saraylarını andıran süslü ve billurlu gazinolar... Hep, hep bu yabancı müesseseler bende ağır bir kâbus yaratır. Gözle görülen her şeyin yabancı olduğunu, yabancılara ait bulunduğunu düşünmek sinirlerime dokunur. Sokakları dolduran sayılmaz şapkaların zalim ve kurnaz, gaddar ve namussuz gölgelerinde sararmış solmuş gibi boyunları eğri, zayıf, mahzun dolaşan sarıklı yerlilere, bu zavallı Arap kardeşlerime kalbimde derin bir sızı duymadan bakamam. Necip Araplık, yükselmek isteyen Türklüğün o kuvvetli ve mukaddes kanadı, orada kendi vatanında esirden başka bir şey değildir. Türklerin çekilmesiyle beraber hain ve zehirli bir çekirge bulutu gibi oraya üşüşen Avrupalılar, bu zavallı İslam memleketinin bütün hayat damarlarını ellerine geçirmişler, doymak bilmez kudurmuş bir açlıkla, azgın bir hırsla din kardeşlerimizin kanlarını emip dururlar... Bütün servet, bütün kuvvet, bütün mutluluk onlarındır... Ben Mısır'da çok sıkılır, kendimi adeta bir zindanda sanırım. Bu manevi zindandaki tutuklu kardeşlerimin arasında serbest gezmek hoşuma gitmez. Daima otele kapanırım. Hakiki bir zindan hayatı geçirir, yıllardan beri düşmanların eline düşmüş olan bu kıymetli vatanın sönmez matemlerini tutar, elemler içinde kıvranmaktan acı bir zevk duyarım.

Bu sefer de yine kendimi böyle hapsetmiştim. Bingazi'deki muharebeye karışmak için beraber yola çıktığım arkadaş Kahire'de hastalanmıştı. Doktor on gün istirahat lazım geldiğini söyledi. Onu beklemeye mecburdum. Hem Türk düşmanlarının, yani Avrupalıların hâkim bulunduğu bir yerde zaten yakalanmak için aranan bir Türk'ü, bir kan kardeşimi yalnız bırakabilir miydim?

Bu on gün bana on senelik bir kürek cezası gibi geldi. Yatakta duramazdım. Gündüz garsona gazeteleri aldırır, okur, bir koltuğa uzanarak saatlerce adı dünya yüzünden kaldırılmaya çalışılan Türklüğün talihini düşünür ve terlerdim. İşte Asya'daki Türk hükümetlerini bitiren Avrupalılar, onların din ve şan kardeşlerine, Araplara da saldırmaya başlamışlardı. Bütün Turan, bütün Hindistan esirdi. İngiltere kralı yeniden Hindistan'daki eski Türk İmparatorluğunun tahtına oturmak için Mısır sömürgesinden geçerken, şimdi cihan politikasında bir gölge halinde kalan büyük hakanın oğlunu ayağına getiriyordu. Türklerle beraber Araplar da eziliyor, Sudan, Fas, Cezayir, Tunus ve nihayet Trablus ve Bingazi de alınıyordu.

Kalbim, bunları düşüne düşüne dimağımda ateşlenen kanımdan, yanmaya başlardı. Geceleri uykusuz kalır ve bu ıstırapla balkona çıkar, aşağıda yönünü kestiremeyen bir nehir gürültüsüyle akıp giden ahaliye dalardım. Çokluğu hep şapkalılar, yabancılar teşkil ederdi. Ara sıra, sanki parlak ve medeni esirliklerinin dehşetini duymuş gibi neşesiz ve dalgın geçen tek tük sarıklı ve entarili yerlilere bakarak, Şark'ın hakkını istemeyen, hakkı için vurmayan, hakkı için kırmayan, hakkı için yakmayan, hakkı için öldürmeyen, hakkı için haksızlık yapmayan azimsiz ve budala ruhuna lanetler eder, yalnız Şark'ta yaşayan bu miskin ve alçak "tevekkül"ün granitten ağırlığını kendi omuzlarımda, kendi tembel başımda hisseder gibi olurdum. Ve birden dudaklarımda Türk şairinin:

Her zulmü, kahrı boğmağa bir parça kan yeter, Ey Şark uyan, yeter ey Şark, uyan, yeter...

inlemesi uçardı. Evet, bu tevekkül zindanında yaşamak beni hasta ediyordu. Günler geçtikçe daha ziyade asabileşiyor, sararıyor, yine başıma sanki görünmez oklar saplanıyordu.

...Yine bir akşam, başım böyle fena halde tutmuştu. Boğulacak gibi oluyordum. Gece yarısı yaklaşıyordu. "Biraz hava alayım" dedim. Paltomu giyerek sokağa çıktım. Nereye gideceğimi bilmiyordum. Elektrik ışıklarıyla gündüzden daha aydınlık olan sokaklardan geçiyordum. Kadınlar, erkekler, çocuklar, yerliler, yabancılar birbirlerine karışmış, gülerek, oynaşarak ağır ve yavaş akıp gidiyorlardı. Ve üzerlerinde iğrenç, keskin bir fuhuş, bir sefahat kokusu dalgalanıyordu.

Ben, düz ve parlak yaya kaldırımında yürüyor ve her tarafı görmemek için sağımdaki pastacıları, tuhafiyeci dükkânlarını, içindekilerini seyrediyordum. Ötede temiz ve sade bir lokanta gördüm. Hemen boş denecek kadar tenha idi. Caddenin kalabalığı beni çok sıkmıştı. Ansızın bir Türk lokantasına benzeyen bu tenha yere girmek arzusunu duydum. Açık kapısından girdim. "Bir çorba olsun içerim" diyordum. Oturur oturmaz garson geldi. İngilizce ve Fransızca yazılmış listeyi vererek ne istediğimi sordu. Okumadan: — Çorba... dedim. Ve getirince içmeye başladım. İçerken etrafıma bakıyordum. Bütün duvarlar ayna idi. Aynaların üzerindeki kralının ve kraliçesinin, Galler Prensi'nin büyük ebatta yapılmış resimleri göze çarpıyordu. Yanlarında başka küçük resimler de vardı. Galiba Mısır'ın ehramları, Sfenks'in yağlıboya manzaraları idi. Bunlara dalmıştım. Bu esnada kapıdan bir adam girdi. Başında büyük ve hasır bir şapka vardı. Gayet şık ve uzun boylu idi. Garsonun yardımıyla şapkasını ve paltosunu çıkardı. Tam yanımdaki masaya oturdu. Karşısındaki aynada hayalini görüyordum. Dikkatle bakmaya başladım. Çünkü ben bu çehreyi tanıyordum. Fakat nereden?

O da aynadan bana bakıyordu.

İstanbul'da ve Selânik'te kendileriyle münasebette bulunduğum yabancıları ve Rumları aklımdan geçiriyordum. Bir türlü bunu hatırlıyamıyordum. Çorbadan sonra iki tabak yemek daha yedim. O da bana bakıyordu. Mutlaka o da beni tanımak istiyordu. Artık rahatsız oluyor, halledilemeyen muammaların karşısında bizi üzen o tatsız sıkıntıya benzer bir şey duyuyordum. Onun da benim gibi sıkıldığını görüyor, rahatsızlığının farkına varıyordum. Nihayet yemeğini bitirdi. Bir cigara yaktı. Kalktı. Paltosunu ve şapkasını giydikten sonra garsona para ve bahşiş verdi. Dışarı çıkıyordu. Birden benim masamın önünde durdu. Tavrında âdeta, bir aktör vaziyeti vardı. Adımı söyledi:  
— Siz... değil misiniz?..  
— Evet, benim diye kekeledim.  
Kesik bıyıklarının altından parlak dişlerini göstererek gülüyordu.  
— Beni tanımadınız mı?  
— Affedersiniz, fakat hatırlayamıyorum.  
— Ben Ahmet Nihat'ım...  
Şapkanın altında yabancı ve Şarklılara özgü duran gözlerini hemen tanıdım. Bu, benim okul arkadaşımdı. Fakat hali birdenbire bende fena bir tesir bıraktı. Kalkıp elini tutamadım. Zoraki gülümsedim. Mısır gibi hiç olmazsa isimce Müslüman sayılan bir memlekette bir Türk'ün şapka giymesinde ne vardı? Hatta burada bazı ecnebiler bile fes giymiyorlar mıydı? Bozulduğumu anladı. Ve aradaki soğuk ve sıkıcı sessizliği yırttı:  
— Burada ne arıyorsunuz, gezmeye mi geldiniz?  
Kısaca,  
— Hayır, geçiyordum, dedim.  
Tekrar sordu:  
— Nereye?  
— Bingazi'ye...  
— Ooo, kahramanlık ha... Tebrik ederim. Fakat boşuna çalışıyorsunuz. Artık orası yandı.  
Birden böyle söylemesi canımı daha ziyade sıktı. İstemeyerek biraz kaba cevap verdim:  
— Şapka giyen Türkler öyle sanırlar...  
Daha çok gülümsedi. Ta gözlerimin içine bakıyordu. Biraz yavaşça:  
— Fakat azizim, ben Türk değilim, dedi.  
Ben şaşaladım:  
— Türk değilseniz, Osmanlısınız ya?..  
— Hayır, Osmanlı da değilim.  
— Hiç olmazsa Müslümansınız ya?..  
— Hayır azizim, Müslüman da değilim.  
Bütün bütün şaşaladım. Onun da gülümsemesi garipleşmişti...  
— O halde nesiniz? diye sordum.  
Ve yüzüne baktım. Soğukkanlılıkla cevap verdi:  
— Katoliğim ve Fransız'ım...  
Böyle söylemesi sinirlerime dokundu. Biraz acı ve ekşi, alay etmek istedim. Gülmüyor, yalnız dişlerimi gösteriyordum:  
— Tanıdığım Ahmet Nihat katolik olabilir. İnancını elbise gibi değiştirebilen, vicdanını adi bir eşya gibi satan insanlar bu dünyada az değildir. Lâkin İstanbul'da doğan, anası Türk, babası Türk olan, Türkçe konuşan bir aileden çıkan, damarlarında Türk kanı akan bir Ahmet Nihat milliyetini değiştiremez, Fransız olamaz, yalnız kendini aldatır...  
— Hayır, kendimi aldatmıyorum. Halis bir Fransız'ım.  
— Mümkün mü? Bu ilme, bu tabiata aykırı bir şey...  
— Bilseniz, doğru söylediğimi anlayacaksınız. Ama burada olmaz. Biraz uzundur. Haydi kalkınız. Bir yerde oturalım. Tamamıyla bir Fransız olduğumu anlayınız da, şapka giydiğime kızmayınız, olur mu?  
Sanki alay ediyordu... Söyleyeceği saçmaları zaten biliyordum. Dinlerin, ananelerin, âdetlerin, ırk teorisinin hep efsane olduğunu, milliyetlerine güven, terbiye ve menfaate göre değiştiğini, hangi milletin terbiyesi görülürse, o milletin ruhuna sahip olunacağını ve nihayet medenilik isteyen bir adamın mutlaka Avrupalılaşması lazım geldiğini iddia edecekti. Fakat bu boş ve çirkin iddiayı bir kere de onun ağzından işitmek istedim. Garsona parasını verdim. Ve hemen kalktım. O, yanımda gidiyordu. Bu milliyetinden çıkmış herif, denizden çıkmış veya patlamış ölü bir köpek balığına benziyordu. Âdeta bir kokuşmuşluk duyuyor, iğreniyor, iğreniyordum.

Çok yürümedik, geniş bir gazinoya girdik. Göz kamaşacak kadar aydınlıktı. Kenarda bir masaya oturduk... Yanımızda büyük bir saksı vardı, içinde tanımadığım bir bitki büyük yapraklarını tavana kadar çıkarıyor, iri ve tuhaf gölgelerini üzerimize düşürüyordu. Dirseklerimi mermere dayadım. "Haydi bakalım, seni dinliyorum!" gibi bu Türk kaçığının, bu hissiz Sart'ın yüzüne baktım. Hiç heyecan falan göstermiyor, eski dininden, eski soyundan, eski memleketinden bir arkadaşla bulunmak onda herhangi bir yesir yapmıyordu.

"Hikâyem tıpkı hayali, hissi bir roman kadar gariptir" diye başladı, "ihtimal inanmayacaksınız. Fakat ben sizi sıkmamak için uzatmayarak anlatacağım. Dikkatle dinleyiniz. Gerçi okulda sizinle çok sıkı görüşmezdik. Ruhlarımız, meyillerimiz ayrı idi. Aramızda biraz, biraz değil... çok uzaklık vardı. Fakat yine beni tanırsınız. Hatırlayınız. Siz, Türkler, bana `Frenk Nihat´ derdiniz ve hakkınız da vardı. Ben son moda elbise giyer, tırnaklarımı uzatır, dinsizliğimi meydana vurur, Türklüğe dair ne varsa tahkir eder, Türkçe konuşmayacak kadar nefretimde taassup gösterirdim.

Hep Fransızca konuşur, tatil zamanlarımı Beyoğlu'nda geçirirdim. Türk ve Türklüğe benzer her şeyden tiksinir, iğrenirdim. Okuldan ziyade evde azap çekerdim. Babam, iri vücudu, geniş omuzları, kuvvetli kolları, ablak çehresi, kalın dudaklarıyla tıpkı budala bir Türk pehlivanını andırırdı. Bütün hareketleri adi, kaba ve bayağı idi. Gayet narin ve nazik bir Çerkez olan annem, ondan dehşetle nefret ederdi. Ben bunu anlardım. Akrabalarımın da hiçbirisini sevmezdim. İstanbul bana zindan gibi gelirdi. Levanten arkadaşlarım olmasaydı belki deli olurdum. Geceleri Avrupa ve Batı şehirleri rüyama girer, daima odama kapanır, bağırarak milli parçalar, operalar söyler, kalkar bazı da yapayalnız oynardım. Nihayet hukuk tahsili için Paris'e gittim. Orada kimse bana Türk diyemezdi. Tamamıyla Fransızlaşmıştım. Tatil zamanında İstanbul'a dönmedim. Boş yere annem, babam beni çağırıyordu. Ben okulu bahane ediyordum. İstanbul'da iken rüyalarımı süsleyen batı hayatı o kadar, o kadar hoşuma gidiyordu ki, memleketimi ve Türk olduğumu hatırlayınca mahzunlaşır ve titrerdim. Bir iştiyakım, bir hicranım vardı. Bu hicran dudaklarıma ezelî bir nakarat yapıştırmıştı. Bu nakaratı kalabalıkta içimden, yalnızken yüksek sesle tekrar eder dururdum:

Ah, ben niçin bir Fransız doğmadım...

Ve Türk olduğumu düşünmek, kendimi öldürmek arzuları verirdi. Tahsilimin ikinci senesini bitirdim. Yine tatil zamanında İstanbul'a dönmedim.

İstanbul'a gitsem nefret ve hiddetimden öleceğimi sanıyordum. Bir gece tabiiyet ve dinimi değiştirmek aklıma geldi. Mahkemeye lüzum görmedim. Hemen karar verdim. Bir sene sonra avukat olacaktım. Paris'te ufak bir mevki bulur, rahatça yaşayabilirdim. Artık hep kararımı dalga geçiyor , İstanbul'a, Türk muhitine hiç dönmeyeceğim için tarif olunmaz bir sevinç duyuyordum. Bu esnada İstanbul'dan bir telgraf aldım: `Annenize ameliyat yapıldı. Ölümü muhakkaktır. Yetişiniz. Size bir vasiyeti var.´ Aldırmadım. Yirmi dört saat geçmedi. İkinci bir telgraf aldım: `Anneniz ruhunu teslim ediyor. Size bir vasiyeti var. Gelmezseniz mirasından mahrum kalacaksınız.´ Yine aldırmayacaktım; fakat miras meselesi midemi bulandırdı. En nazik damarımı bulmuşlardı. Küçükten beri son derece menfaatimi bilir, menfaatimi her şeye tercih ederdim. Çaresiz kalktım. Bavulumu bile almayarak şimendifere atladım. Yine o iğrenç ciğer gibi fesi giyecek, yine budala bir Türk'e kırmızı başlı duygusuz bir şampanya şişesine benzeyecektim. Gardan arabaya atladım. Etrafımı görmemek için pencerenin perdelerini indirmiştim. Doğru eve geldim. Ayak üzerinde bana anlattılar. Annemin memesinde seratan çıkmış. İki defa ameliyat yapmışlar. Doktorlar her gün, `Yarına çıkmaz´ diyorlarmış. Beklemedim. Hemen yanına girdim. Zavallı annem sanki ölmüştü. Yalnız gözleri yaşıyordu. Beni görünce güldü, yanına çağırdı. Ellerimi tutmak istedi. Fakat kolunu kaldıramıyordu. — Herkes dışarı çıksın, herkes... diye inledi. Yatağının başucunda bir inek gibi böğürerek ağlayan gecelik entarili babam, ihtiyar halam, halamın şişman ve dul kızı, hizmetçiler, hepsi kapıdan dışarı çıktılar. İkimiz kaldık. Annem zayıf bir sesle: — Kapıyı sürmele... dedi. Bu tedbiri garip buluyordum. Gittim, sürgüyü sürdüm; tekrar yatağın yanına geldim. — Söyleyeceğim şey biraz uzuh Nihat dedi. Altına bir sandalye al. Cevap vermeden itaat ettim. Yüzüne bakıyordum. Sarı ölüm rengi yavaş yavaş soğuk ve korkunç bir menekşe rengine dönüyordu. Ağlamaya başladı. Gözlerinden iri yaşlar dökülüyor, saçlarının etrafına asılıp kalıyordu. — Niçin ağlıyorsun anneciğim? İnşallah iyi olacaksın! diye elimle başını okşadım. Gözyaşları içinde gülerek: — Teselli istemem Nihat, dedi. Ölüyorum; bir saat sonra öleceğim. Bırak ağlayayım. Sevincimden ağlıyorum. Gelmeseydin, yetişmeseydin, mukaddes bir sır da benimle beraber mezara gidecekti. Senin haberin olmayacaktı. Bir şey anlamıyor dalgın dalgın yüzüne bakıyordum. O, zorla kaldırdığı elleriyle gözlerini kapayarak devam etti: — Sakın hiddetlenme, kızma... Düşün ki, işittiklerin bir ölünün ağzından çıkıyor. Ölüler sırlarını saklamazlar. Ölmezden evvel bütün hayatımızca gizlediğimiz şeyleri söylemek insanların en mukaddes vazifeleridir. Ben yine bir şey anlamıyordum: — Anneciğim, dedim, niçin hiddetleneceğim. Ne söylersen seve seve dinleyeceğim. Vasiyetini noktası noktasına yapacağım. İşte vaat ediyorum. — Hayır, biliyorum, darılacaksın, diye cevap verdi. Sağ olsam, ölüm döşeğinde yatmasam, ihtimal beni ayaklarının altına alacaksın, ezeceksin. Ama şimdi eminim, hiçbir şey, hiçbir şey... elini bile kaldıramayacaksın. İşte söyleyeyim: Baban, senin asıl baban değildir... Gözlerimi açtım. Ve şaşırdım. Zayıf kolunu tutarak: — Benim babam değil mi? Öyleyse babam kim? diye haykırdım. Aptallaşmıştım. O, bir elini dudaklarına götürerek rica eder gibi bana baktı: — Yavaş Nihat'çığım, dışarıdan işitecekler. Halbuki ben yalnız sana söylemek isterim. Ben pek gençken kocaya vardım. Ölürken bile başımdan ayrılmayan, beni son nefesimde rahat bırakmayan herif bana o vakitler akla gelmez cefalar çektirmişti. Çocuğu olmuyordu. Her akşam, `Niçin gebe kalmıyorsun?´ diye beni azarlar, tahkir eder, hırpalardı. Üç sene bu hayata dayanamadım. Hasta oldum. Yatağa düştüm. Birçok doktorlar geldi. Beni iyi edemiyorlardı. Nihayet Dubois baktı. Bu bir Fransız'dı. Kırk yaşında kadar vardı. Saçlarına kır düşmüştü. Gayet tatlı ve yanlış bir Türkçe konuşuyor, beni gülmekten katıltıyordu. Uzatmayayım. Ben bu Dubois'yi sevdim. Yataktan kalktıktan sonra bile her hafta beni görmeye geliyor, doktor olduğu için kimse bir şeyden şüphelenmiyordu. Beyoğlu'ndaki evine de gitmeye başladım. Aşkımız bir seneden ziyade sürdü. Ben sana gebe kalmıştım. Evet, ondan sana gebe kalmıştım. Fakat bu talih, bu mutluluk devam etmedi. Mösyö Dubois, memleketine gidiyordu. Orada babası ölmüş, bütün ailesi, evi, küçük çiftliği kendisine kalmıştı. Gayet tenhalığı sever bir adamdı. İstanbul'daki mevkiini bıraktı. Anasının yanına, doğduğu köye çekilmek istiyordu. Beraber kaçmak için beni o kadar zorladı ki... tarif edemem... Ah keşke kaçsaydım... Nihayet beni kandıramayacağını anlayınca meyus oldu. Veda için son defa evine gittiğim gün tam beş saat odasında kapandık. Ve yatağının içinde ağladık, ağladık. Ben gençtim. Ama o yaşlı başlı idi... Ayrılacağımıza yakın eliyle okşayarak: — Ah sevgilim, bu benim çocuğum, fakat yazık ki göremeyeceğim dedi, hayat mutlaka üzüntü ve gözyaşı için yapılmıştır. Bari vaat et, büyüdüğü vakit, hiç olmazsa görmek için bana gönderecek misin? Ağlayarak ve yemin ederek vaat ettim. Bana köyünün ve çiftliğinin adresini verdi. Ölünceye kadar oradan ayrılmayacağını söylüyordu. Eminim ki, hâlâ oradadır. Zira çok hisli ve şair tabiatlı idi. İstanbul'a bile bu tabiatın şevkiyle gelmişti. Bir de hatıra olmak üzere bir fotoğraf bıraktı.

Yine gözlerini kapadı. Ve ağlamaya başladı. Hikâyesi ve mazinin tekrarı zavallıyı çok yormuştu. Hıçkırıklar içinde devam etti: — O vakitten beri yirmi beş sene geçti. Ben her zaman gizli gizli bu fotoğrafa bakarım. Sen büyüdün, tamamıyla ona benzedin... İşte ben ölüyorum. Yastığımın altındaki anahtarları al, şu konsolu aç. Orada mavi bir zarfın içinde fotoğrafı bulacaksın. Arkasında babanın, sevgili Dubois'nin adresi yazılıdır. Git, onu bul. Eğer sağ ise söyle ki, son nefesinde onu hatırlayarak, onun adını söyleyerek, onunla geçirdiğimiz güzel ve tatlı saatleri düşünerek öldüm. Ağlıyor ve tıkanıyordu. Elimi yastığın altına soktum. Mor bir kurdeleye bağlı dört anahtar vardı. En büyüğüyle yatağın başucundaki konsolu açtım. Mavi zarfı aldım. Ellerim titriyordu. Fotoğrafa baktım. Birden: — Oh... dedim. Bu resim tamamıyla bana benziyordu. Sanki tamamıyla benim fotoğrafım idi. Yalnız saçların kırlığı başka idi. Adresi okudum. Paris'in civarında bir köy... Hatta geçen sene oraya gezmeye gitmiştim. Tekrar zarfı kapadım. Anneme döndüm. Hıçkırması falan kesilmişti. Eline dokundum. Düştü. Bayılmıştı. Akşama kadar ayılmadı. Gece de kendine gelmedi. Sabahleyin uyuduğum kanepede gözlerimi açınca, bütün evi bir feryat kaplamış gördüm. Annem ölmüştü. Cenazeden evvel ben evden çıktım. Babama yüreğimin dayanamayacağından bahsetmiş ve kandırmıştım. İlk trene atladım. Paris'e indim. Miras işini babama, pardon... annemin Türk kocasına bırakıyordum. Vakit geçirmeden Mösyö Dubois'yi buldum. Anneme bıraktığı adreste oturuyordu. Küçük ve temiz bir köy evi... İlk görüşmemiz biraz tiyatromsu oldu. O gençlik fotoğrafını görünce her şeyi hatırladı. Annemin son dakikalarını anlattım. — Ne sadakat! Ne sadakat, diyor ve titriyordu. Bu bunamış, ak saçlı ve ak sakallı bir ihtiyardı. Beni iyi buldu. Sevdi. Meğerse o da hiç evlenmemiş. Bana ismini vermeyi teklif etti. Memnuniyetle kabul ettim. Hâsılı uzatmayayım, dinimi de değiştirdim. İsmim bugün Pierre Dubois... Babamın Paris'te çok ahbapları vardı. Hukuktan diplomamı alınca bir ticaret bankasında bana mühim bir memuriyet buldu. Şimdi Mısır'a memuru olduğum bankanın bir işi için geldim. Ey azizim, şimdi halis bir Fransız olduğumu anladın mı?" Gülüyor ve muzaffer bir tavırla yüzüme bakıyordu. Mermere dayalı dirseklerim uyuşmuş, acıyordu. Geri çekildim: — Anladım, lakin zaten Türk değilmişsiniz ki... Piçmişsiniz!.. diyerek ayağa kalktım. O, galiba benden takdir ve hayret bekliyordu. Sordu: — Ne o? Gidiyor musunuz? Bari bir şey içseydiniz. Konuşurduk. Artık asabiliğim, Türk kafamı tutmuş, Türk hareminin erişilmez namusu hakkında beslediğim iman, bu masum ve mukaddes hayal artık kırılmış, artık perişan olmuştu. — Mösyö Pierre Dubois ile konuşacak bir şeyim yok! dedim. Selam vermeden ayrıldım. Sokağa kendimi dar attım.

Otelde, yatağımda o gece sabaha kadar hemen hiç uyumadım. Hep Ahmet Nihat'ın mektepteki tatsız, biçimsiz hallerini ve soğuk reveranslarını, garip vaziyetlerini düşünüyor ve sonra İstanbul'da Türklüğünü inkâr eden, Türklükten nefret eden, Türklüğü hakir görüp bütün varlıklarıyla Avrupalılaşmaya çalışan uzun tırnaklı, son moda giysili, tek gözlüklü züppeleri hatırlıyor, içimden: "Acaba bunların da hepsi piç mi? Hepsinin anneleri Beyoğlu'nda mı gebe kaldı?" diyor; korkunç kâbuslar arasında yırtılmış al ve harap hilaller içinde yükselen tunç ve ateş renginde büyük; siyah ve kanlı haçlar görüyordum.
