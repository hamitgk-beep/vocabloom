# Ocak

Hoca, bir gün evde ocak yakmağa kalkmış. Üfler, üfler, ocağı bir türlü yakamazmış. Ne yaptıysa kâr etmemiş. Buna fena halde kızan Hoca, yukarı çıkıp karısının hotozunu aldığı gibi ocak başına inmiş. Hoca, hotozu kendi başına takarak başlamış yine ocağı üflemeğe. Bu sefer odunlar, bir iki üfleyişte parlayıverince Hoca, söylenmeğe başlamış:

– Meğer ocak da bizim hatundan korkarmış; hotozu görür görmez imana geldi.

# Parayı Veren Düdüğü Çalar

Nasreddin Hoca, bir gün, Akşehir pazarına gitmek üzere yola çıkar. Mahallenin çocukları onu görünce başına toplanıp istekte bulunurlar.

– Hoca Efendi, ne olur bize pazardan düdük al, derler.

Nasreddin Hoca da çocukların dilinden kurtulmak için:

– Peki, alayım, der.

Sadece çocuklardan birisi, elindeki parayı vererek:

– Şu parayı al ve benim düdüğümü sakın unutma Hocam , der.

Parayı alıp cebine koyan Hoca, çocukların yanından uzaklaşarak yoluna devam eder. Çocuklar, akşamüstü, Nasreddin Hoca’nın yolunu gözlerler. Bir süre sonra, Hoca’nın eşeği uzaktan görünür. Çocuklar, onun döndüğünü anlayınca, hep bir ağızdan:

– Hoca Efendi, hani bizim düdüklerimiz, diye etrafına toplanırlar.

Nasreddin Hoca, sadece parayı veren çocuğa düdüğü uzatarak şöyle der:

–  Hiçbirinize bir şey yok. Yalnız bu arkadaşınıza var. Çünkü parayı veren, düdüğü çalar.

# Perdeyi Ben Buldum

Bir ahbap topluluğunda Hoca'nın eline iş olsun diye bir saz tutturmuşlar:

-Hadi bize güzel güzel bir şeyler çal da dinleyelim! Demişler. Hoca sazı eline alınca mızrabı bir aşağı bir yukarı teller üzerinde rastgele dolaştırmaya ve böylece tuhaf tuhaf sesler, gıcırtılar çıkarmaya başlamış:

-Aman Hoca demişler, saz dediğin böyle mi çalınır? Perdeler üzerinde usulüyle gezinmek gerek ... Hoca , elindeki sazı dımbırdatmayı sürdürürken:

-Onlar perdeyi bulamazlar, aramak için gezinip dururlar. Ben buldum işte. Niçin boşu boşuna gezinip durayım?

# Peşin Parayı Gördün Ya

Nasreddin Hoca bir ahbabından borç almış. Elde avuçta olsa Hoca hemen ödeyecek ama yoksulluğun iki gözü de kör olsun. Daha vadesi gelmeden adam alacağı için Hoca'nın kapısını aşındırmaya başlamış. Bir böyle iki böyle derken yine bir gün adam borcunu istediğinde;

– Şu anda yok ama demiş, çok yakında ödeyeceğim,

Böylesi düşman başına, adam yüzsüz mü yüzsüz:

– Söyle Hoca, ne zaman vereceksin, kimden bulup vereceksin!  
– Evin önüne çalı ektim!  
– Niye?  
– Koyun sürüsü geçerken yünleri çalıya takılacak.  
– Sonra?  
– Bizim hatun bu yünleri toplayacak, yıkayacak, tarayacak, eğirecek, dokuyacak, ben de götürüp satacağım.  
– Eee?  
– Ne e'si be adam, sordun ya, senin paranı o zaman öyle ödeyeceğim.

Buna kim gülmez; adam da kasıklarını tuta tuta gülünce Hoca:

– Gidi hâlden bilmez, demiş, peşin parayı gördün ya gül bakalım!

# Peştemal

Timur ile Hoca bir gün hamama giderler. Hoşbeş ederken Timur, Hoca'ya sorar:

"Hoca, ben köle olsam bana kaç para değer biçerdin?" Hoca:

"Ben bu işin tellalı değilim ama bir 15 akçe ederdin!"

Bu laf üstüne Timur çok sinirlenir:

"Hoca, senin dediğini kulağın duyuyor mu? Sadece bu peştemal 15 akçe eder be!"

Hoca hiç istifini bozmadan:

"Ben zaten peştemale biçtim bu fiyatı!" der.

# Pusula

Hoca bir gün ciğer almış giderken ahbabından biri tesadüf edip:

— Bunu nasıl pişireceksin? diye sual eder. Hoca:

— Âdeta, deyince,

— Hayır! Bunun güzel pişmesi var. Size tarif edeyim de öyle yapınız, demiş. Hoca:

— Bu tarif ettiğin şeyler hatırımda kalmaz, bir kağıda yaz da ona bakarak pişirteyim, demekle o adam da tarifeyi yazar, verir.

Hoca, ballandıra ballandıra tarif etmenin verdiği hulya-yı iştiha ile dalgın dalgın eve giderken bir çaylak elinden ciğeri kapar, kaçar. Yıldırım süratiyle havaya uçar. Hoca hiç eser-i telaş göstermeyerek elindeki tarifeyi çaylağa gösterip:

— Nafile, ağız tadıyla yiyemezsin, pusula bende! Demiştir.

# Riyakâr

Bir kimse Nasreddin Hoca´yı her gördüğünde iltifat gösterip, diller dökerek, evine davet eder. Bir gün adamın gönlünü almak için evine gidip, kapısını çalar. Adam pencereden kafasını uzatıp, baktıktan sonra, hemen geri çekilir. Biraz sonra da hizmetcisi kapıyı açıp: "Teşrifinize çok memnun olduk, fakat, efendim biraz önce dışarı çıktı evde yok! Geldiğinizi duyunca, ne kadar üzülecek" der.

Adamın davetinde samimi olmadığını, riyakarlık yaptığını anlayıp, kapıya gönderdiği hizmetçisine:

"Ya öyle mi? Ne yapalım, hayırlısı olsun! Yalnız efendine selam söyle, bir daha dışarı çıkarken, başını içerde unutmasın!" der.

# Rüyamda Komşu Kadınların Evlenme Teklifi

Rüyasında komşu kadınlar toplanarak Hoca'yı yeniden evlendirmek istemişler. Bu bulduğumuz sana layık, evlen, demişler. Hoca kalkıp hanımını uyararak:

– Kalk, niye rahat uyuyorsun, hiçbir şeyden haberin yok, sırtını bana dönüp uyuma, git komşu kadınlarla konuş. Onlar bana tekrar evlenme teklifi getirdiler, hem de genç bir kızla. Sonra pişman olacaksın, söylemedin deme, ben seni uyarıyorum. Genç kadınla evlendikten sonra yaşlı kadına bakılmaz, demiş.

# Sana Ne!

Nasreddin Hoca akşamüstü, yorgun argın evine gidiyordu. Yolda kendine vazife olmayan işlere burnunu sokmayı alışkanlık haline getirmiş biri karşısına çıkıp:

– Hoca Efendi, demin biri bir tepsi baklava ile buradan geçti, gözlerimle gördüm. Hoca, bu zevzekliğe kızmış. Yürümeye devam ederken adamı da terslemiş:

– Bundan bana ne?

Ama zevzek adam Hoca'dan ayrılmaya niyetli değilmiş.

– Sözümü tamamlamaya fırsat vermedin Hoca Efendi, demiş. Baklava tepsisini taşıyan kişi, sizin eve girdi.

Hoca bu haddini bilmeze son sözünü söylemiş:

– İyi, ama bundan sana ne!

# Sarhoş Kadı

Hoca'nın memleketi olan Sivrihisar'ın bekri bir kadısı var imiş. Bir gün bağında sarhoş olup yatmış. Kavuğunu, binişini şuraya buraya atmış. Hoca da tilmizi İmad ile o gün seyrana çıkmış imiş. Kadının o halini görüp binişini almış, sırtına giymiş gitmiş. Kadı ayılıp binişini bulamayınca muhzıra:

— Bak göz kulak ol, bulursan al getir, der.

Muhzır, Hoca'nın sırtında görüp mahkemeye getirir. Bir muhakeme zamanına tesadüf eder. Hoca, kadıya:

— Dün İmad ile gezmeye çıktık, baktık ki bir bağda bir sarıklı adam sarhoş olmuş, kusmuş yatıyor. Ben de binişi aldım, sırtıma giydim. Buna şahit ve emare de gösterebilirim. Bulun sahibini vereyim, deyince kadı:

— Kim bilir hangi sefihtir! Hele sen afiyetle git, giydiğine bak, ben karışmam, demiştir.

# Saç Sakaldan Neden Daha Önce Beyazladı?

Nasreddin Hoca yaşlanmaya başlayınca. İlk olarak saçları ağarmış. Sakalının ise bir tek kılı bile beyazlaşmamış. Bir gün berberde saçlarını kestirip sakalını düzeltirken, dostlarından biri sormuş:

– Hocam! Senin saçların hemen hemen tamamıyla beyazlaşmış. Sakalında ise bir tek beyaz kıl yok. Bunun hikmeti nedir acaba?

Hoca:

– Gayet basit, cevabını vermiş. Saçlarım sakalımdan yirmi yaş daha ihtiyar olduğu için.

# Sen de Dört Ayaklı Olursun

Hoca bir gün kaz pişirip Timurlenk'e götürmüş. Fakat yolda çok acıkınca, dayanamayıp kazın bir budunu koparıp yemiş. Timurlenk:

– Bunun bir bacağı nereye gitti, diye sormuş.

Hoca:

– Bizim diyarın kazları bir ayaklıdır, inanmazsan çeşme başında dikilen şu kazlara bak, demiş.

Timurlenk bir adamına emretmiş. Adam elindeki çomağı çeşme başında tek ayakları üzerinde dikilmiş duran kazlara fırlatmış. Kazlar birden iki ayaklı oluvermişler. Timurlenk onları Hoca'ya göstermiş. Fakat Hoca laf altında kalır mı? Hemen cevabı yapıştırmış:

– O çomağı sen yesen, sen de dört ayaklı olursun!

# Seninle de Konuşulmuyor ki

Nasreddin Hoca bir gün karısına: - "Hatun" demiş, "Şu bizim komşu, çarıkçı, Mehmet Ağa'nın adı neydi? - "Kendin söyledin ya, efendi" demiş karısı, "Mehmet Ağa." - "Canım, dilim sürçtü işte... Ne iş yapar diyecektim." demiş Hoca. - "A efendi" demiş karısı, "kendin çarıkçı demedin mi?" - "Anlasana işte" demiş Hoca, "nerede oturuyor demek istedim." - "Efendi, bugün sana ne oluyor?" demiş karısı "Komşu” dedin ya..."

Hoca artık sinirlenmiş. - "Aman be kadın... Seninle de konuşulmuyor ki!

# Sizin Eve Taşınmıyor muyuz?

Bir gün, Nasreddin Hoca'nın evine hırsız girmiş. Hoca, gürültüden uyanmış. Bakmış ki, adamın biri, evin içinde, eline her geçeni çuvalına dolduruyor. Kapının arkasına geçip hırsızın işini bitirmesini beklemiş. Aradan bir süre geçmiş. Hırsız, alacağını aldıktan sonra dışarı çıkmış. Nasreddin Hoca da onun peşine takılmış. Hırsız çok geçmeden Nasreddin Hoca'nın ardı sıra geldiğini görmüş. Hayretle sormuş:

– Ne o Hoca Efendi? Gecenin bu saatinde, niçin peşimden geliyorsun?

Nasreddin Hoca gülümseyerek cevaplamış:

– Niçin olacak, bizim evdeki bütün eşyaları yüklenip buraya getirdiğine göre, sizin eve taşınmıyor muyuz?

# Solak Hayvan

Hoca bir ara kervanla uzun bir yolculuğa çıkmış. Bir sabah, erkenden herkes hayvanına binerken Hoca’ya da bir at göstererek:

–Haydi, sen de bin, demişler.

Hoca’nın aceleyle hayvana ters tarafından atladığını görenlerden biri:

–Efendi, bu ne şaşkınlık. Hayvana ters bindin! diye uyarıda bulununca Hoca yiğitliği bozmamak için:

–Hayır, ben ters binmedim. Hayvan solakmış. Benim bunda ne günahım var, cevabını vermiş.

# Subaşının Eşeği

Eşeği kaybolan Subaşı, ateş püskürmüş:

-Çabuk benim hayvanımı bulun, yoksa karışmam! Diye bağırmaya başlamış. Herkesi bir telaş , bir korkudur almış. Eşeği aramak için dört bir tarafa dağılan Akşehirliler , yolda Hoca'ya rastlamışlar:

-Aman Hocam, bize yardım et. Yolda sahipsiz bir eşek bulursan hemen yakala n'olur.

-Eşek kimin?

-Subaşının. Demişler.

Hoca da: "Peki ararım" demiş ve türkü söyleye söyleye yolunu sürdürmüş. Karşısına çıkan bir köylü :

-Hocam, böyle türkü söyleyerek ne yapıyorsun? Deyince ,

Hoca:

-Subaşının kaybolan eşeğini arıyorum! Demiş. Adam , yine sormuş:

-Peki , böyle türkü söyleyerek eşek mi aranır a Hoca?

-El elin eşeğini elbette türkü söyleyerek arar...

# Sudan Gelen Sele Gider

Nasreddin Hoca'nın mahallesinde hilekâr bir sütçü vardı. Süte su katarak halis süt diye satardı. Yaptığı yoğurt da, yoğurttan başka her şeye benzerdi. Hele kaymağı yağsız mı yağsızdı. Bu sütçü kendisine insanlar itimat etsinler diye, başına değirmen taşı kadar sarık sarar ve elinden de uzun bir tesbihi hiç eksik etmezdi. Bir sene, kış fazla oldu. Fırtına, yağmur ve sel her tarafı yıkıp götürdü. Bizim sütçü de, o sene iyi haberler almadı. Zira sürülerini seller götürmüş, ağılları da fırtınadan yıkılmıştı. Adam neye uğradığını bilememişti. Artık sütçünün eski neşesi yoktu. Dükkânında eski bolluk kalmamıştı.

Bir gün Hoca, bu sütçünün dükkânının önünden geçiyordu. Her zaman kendisine:

– Buyurunuz Hocam, diyen sütçü, ortalarda yoktu.

Dükkânda da eski neşeyi göremeyen Hoca:

– Heyyy, sütçü baba! Neredesin yahu, diye seslendi.

Biraz sonra, perişan kıyafetiyle, sütçü ortaya çıktı. Hoca hayret etti ve ona: – Ne oldu sana sütçü efendi? Benzin solmuş ve dükkânın da perişan olmuş, diye sordu.

Sütçü de başından geçen felaketleri birer birer anlattı. O anda Hoca, sütçünün bütün hilekârlıklarını gözünün önünden geçirdi ve ciddi bir tavırla:

– Sütçü baba! dedi. Bunlara katlanman gerek. Süte su kattığın günleri düşün de, hiç kederlenme. Çünkü sudan gelen sele gider.

# Tanrı Misafiri

Bir akşamüstü, onun bunun sırtından geçinmeye çalışan bir adam, Nasreddin Hoca'nın evinin önüne gelir, kapısını çalar, Nasreddin Hoca, pencereden seslenir:

– Kim o? Ne istiyorsun?

Adam:

– Benim Hoca Efendi, Tanrı misafiri, der.

Nasreddin Hoca, çok yakından tanıdığı bu yüzsüz adamı, başından savmak ister. Hemen aşağıya iner, kapıya çıkar.

Adama:

– Gel arkamdan. der. Bir süre yürürler. En sonunda, mahallenin camisinin önüne gelirler.

Nasreddin Hoca:

– Efendi, der adama. Sen yanlış kapıyı çaldın.

Adam şaşırıp kalır. Nasreddin Hoca'ya:

– Niçin yanlış kapı çalmışım, diye sorar.

Hoca güler:

– Madem ki Tanrı misafirisin. Al işte, Tanrı'nın evi, burada istediğin kadar kalabilirsin. Ne işin var, yoksul Hoca'nın evinde!

# Tartılan Et mi Kedi mi

Hoca'nın canı et yemek ister. İki okka et alarak eve bırakır ve karısına akşama pişirmesini söyler. Hoca gün boyunca, akşama yiyeceği etin hayalini kurar, iştahı kesilmesin diye o gün öğle yemeği bile yemez. Aksilik bu ya, o gün öğle vakti Hoca'nın evine karısının akrabaları misafirliğe gelirler. Kadıncağız akrabalarına karşı küçük düşmemek için, Hoca'nın getirdiği eti onlara yedirir. Nasreddin Hoca akşam üzeri, eve gelip iştahla sofraya oturur. Ama önüne sade suda pişmiş bulgur pilavı konur. Hoca hem bozulur, hem de şaşırır:

– Et yemeği nerede, diye sorar.

Kadın, eti akrabalarına yedirdiğini söyleyemez. Bahane olarak:

– Kedi yedi, der. Hoca bu bahaneyi yutmaz. Hemen odanın bir köşesinde yatmakta olan kediyi alır, tartıya vurur. Kedi tam iki okka gelir.

Hoca, öfkeli bir sesle:

– Bak, hanım der. Kedi tam iki okka çekiyor. Ben de sana iki okka et bırakmıştım. Eğer bu iki okka çeken, kedi ise, et nerede? Yok, tarttığım et ise, kedi nerede!

# Tavşanın Suyunun Suyu

Köylünün biri Hoca'ya bir tavşan getirir. Hoca, köylüyü elinden geldiği kadar yedirir, içirir. Bir hafta sonra aynı adam yine gelir. Hoca tanıyamaz.

– Geçen hafta size tavşan getiren köylüyüm, der.

Hoca yine güler yüz gösterip çorba çıkarır:

– Tavşan suyundan çorbaya buyurun! diye de ufak bir laf dokundurur.

Aradan birkaç gün geçer, üç köylü gelip hocaya misafir olmak isterler. Hoca:

– Siz kimlersiniz, diye sorar.

– Tavşan getiren köylünün komşusuyuz! derler.

Hoca, la havle çeke çeke bunlara da çorba çıkarır, misafir eder.

Ne var ki, bir hafta sonra yine birkaç kişi gelir. Hoca, bunlara kim olduklarını sorar.

– Tavşanı getirenin komşusunun komşusuyuz! derler.

Hoca bozulur. Ama belli etmez. Misafirlere:

– Hoş geldiniz! der.

Ancak, ortalık kararmadan yemek olarak önlerine bir tas su getirir. Köylüler tasa şaşkın şaşkın baktıktan sonra, bunun ne olduğunu sorarlar.

Hoca, yapılan bir iyiliği istismar eden bu insanlara, gereken dersi şu sözlerle verir.

– Ne olacak? Tavşanın suyunun suyudur.

# Teke Burcu

“Bir gün Hocaya: “Senin yıldızın nedir?” derler. Hoca: “Tekedir”der. “Ey efendi yıldızlarda teke yoktur” derler. Hoca: “Ben çocuk iken anam yıldızıma baktırdıydı da oğlaktır, dedilerdi” der. Hocaya: “Ey ama oğlak teke değildir” dediklerinde, Hoca: “Be şaşkınlar o günden bu güne dek kırk elli yıl oldu. Oğlak teke olmadı mı?

# Terzi

Annesi küçük Nasreddin'i terziye çırak olarak verir. Aradan iki yıl geçmiştir. Bir gün annesi oğlundan bir şeyler dikmesini isteyince, Nasreddin:

– Anneciğim şimdiye kadar işin yarısını öğrendim, bu ise dikilmiş şeyleri sökmektir. Ömrüm yeterse terzi amca elbise dikmeyi de öğretecek

# Tilki

Günün birinde Hoca komşu köyle gitmiş. Köye geldiğinde büyük bir heyecan varmış. Köylüler ona bir tilkinin birçok tavuğu, kazı, ördeği ve hindiyi yediğini anlatmışlar. Köylüler tilkiyi yakalamış, intikam almak için de hayvanı basit bir şekilde değil, aksine işkence yaparak öldürmek istemişler. Hoca'ya sormuşlar:

– Hoca, bize öğüt verir misin?

Hoca cevap vermiş:

– Evet, tabii arkadaşlar. Siz her şeyi bana bırakın.

Köylüler de Hoca'ya güvenmişler. Hoca paltosunu ve kavuğunu çıkarıp her ikisini de tilkiye giydirmiş. Daha sonra tilkiyi salıvermiş. Köylüler Hoca'ya sormuşlar:

– Neden böyle yaptın?

Hoca cevap vermiş:

– Korkmayın, ahali! Tilkiyi gören herkes onu imam zannedecek. Böylece birkaç gün aç kalacak.

# Tıp Bilgisi

Hoca’ya:

–Tıp bilir misin, demişler.

–Bilirim, demiş. Hem de şöyle ifade ederim: Ayağını sıcak tut, başını serin, Kendine bir iş bul, düşünme derin.

# Un Helvası

Nasreddin Hoca, bir sohbet sırasında, un helvasını çok sevdiğini, ama bir türlü yemek kısmet olmadığını söyler. Orada bulunanlardan biri:

– Helva öyle zor pişirilecek bir şey değil, der.

Nasreddin Hoca, adamı doğrular:

– Çok haklısın, ama bir türlü pişirip yiyemedik işte! Bazen un bulundu, ama yağ bulunmadı. Sonra yağ bulundu, ama şeker bulunamadı.

Adam, Nasreddin Hoca’nın sözünü keserek:

– Peki Hoca’m! Bu üç şeyi bir araya getirmek mümkün olmadı mı hiç, diye sorar.

Nasreddin Hoca, bir süre acı acı gülümsedikten sonra şu cevabı verir:

– Bazen belki üçünün bir araya geldiği oldu ama, o zaman da ben helvanın yapıldığı yerde bulunamadım!

# Uykusu Kaçmış da

Bir yaz gecesi Hoca'nın uykusu kaçmış. Uykusuzluktan ve can sıkıntısından evde duramayınca kendini sokağa atmış. Yolda, nöbetçi subaşıya rastlamış.

Subaşı:

– Hoca, böyle gece yarısı burada ne arıyorsun, diye sorunca Hoca, esneyerek cevap vermiş:

– Hiç, uykum kaçtı da onu arıyorum!

# Uyurken Fare Ağzıma Kaçtı

Nasreddin Hoca pazara giderken mahalleden şakacı biri yanına gelip:

-Efendim akşam uyurken fare ağzıma kaçtı. Bunun çaresi nedir?

-Çaresi kolay demiş Nasreddin Hoca, acıkmış bir kediyi ağzınıza sokup yut!

# Ya Kokusu

Birisi Nasreddin Hoca’nın yanında otururken kazara seslice yellenmiş. Sonra kabahatini belli etmemek için ayağı ile tahtayı gıcırdatmış. Hoca demiş ki:

– Haydi sesini onun sesine benzettin diyelim. Ya kokusunu ne yapacaksın?

# Yabancısıyım

Bir gün Nasreddin Hoca, şehrinden pek fazla uzak olmayan bir köyü ziyaret etmiş. Gezerken bir köylü ona:

– Bugün günlerden hangi gündür, demiş.

Bizim Hoca:

– Bilmem ki! Ben buranın yabancısıyım.

# Yarasaydı Sahibine Yarardı

At nalının insanlara uğur getirdiğine inanan biri, Hoca'ya sormuş:

– Hocam, at nalı insana uğur getirirmiş, evin kapısına assak günah olur mu?

Böyle hurafelerin dine aykırı olduğunu her zaman anlatan hoca, bu sefer farklı bir yöntemle cevap vermiş:

– Eğer uğur getiriyorsa, asabilirsin. Ama bence getirmez. Çünkü atlarda bir değil, dört nal olmasına rağmen şimdiye kadar bir faydası olduğunu görmedim, aksine akşama kadar yediği kamçının, taşıdığı yükün ve koşturulduğu yolun hesabı yoktur.

# Yas

Hoca'nın tavuğu kaybolmuş. Bir siyah bez bulmuş, parça parça kesmiş, her parçayı delip diğer tavukların boynuna takmış. Bunları görenler,

– Hoca demişler, bu ne?

– Analarının yasını tutuyorlar, demiş.

# Yaşı Hakkında mı?

Bir komşusu Hoca'ya koşa koşa gelmiş:

– Aman Hoca! Bizim evde karılarımız kavga ediyorlar, çabuk gel, demiş.

Hoca hiç aldırış etmeden şöyle sormuş:

– Yaş hakkında mı, yoksa görünüş hakkında mı?

– Hayır, başka bir şey hakkında, diye cevaplandırmış komşu!

– Öyle ise evine git ve merak etme şimdiye kadar çoktan barışmışlardır.

# Ye Kürküm Ye

Akşehir'in beyleri Hoca'yı yemeğe davet etmişler. Hoca nereden bilsin; davete, günlük kıyafetiyle katılmış. Katılmış ama ne hoş geldin, ne sefa getirdin diyen var. Herkes, allı pullu kıyafetlilere el pençe duruyormuş. Hoca, bir koşu evine giderek, sandıktaki işlemeli kürkünü giyip yemeğe geri dönmüş. Az evvel hoş geldin bile demeyenler, önünde yerlere kadar eğilmişler. Hoca'yı, yere göğe sığdıramayıp baş köşeye oturtmuşlar. Kuzunun en hasını önüne koymuşlar. Herkes Hoca'nın yemeğe başlamasını bekliyormuş. Hoca, bir taraftan kürkünün kolunu sofrada sallamaya, bir taraftan da "Ye kürküm ye, ye kürküm ye!" demeye başlamış.

– İlahi Hoca, demişler, kürkün yemek yediğini kim görmüş?

Hoca taşı gediğine koymakta gecikmemiş:

– Kürksüz adamdan sayılmadık… İtibarı o gördü, yemeği de o yesin.

# Yemesi Kolay Olsun Diye

Timur’un defterdarı hesapta bir yanlışlık yapar. Bunun üzerine Timur o defterdara kâğıtları yedirir ve işten kovar. Yerine Nasrettin Hoca’yı alır. Hoca hesapları yufka üzerinde yapmaya başlar. Timur bunu görür ve sebebini sorar. Hoca aynen şu cevabı verir:

–Yemesi kolay olsun diye!

# Yenisi

Günün birinde Hoca’nın karısı ölür. Fakat Hoca’da ciddi bir üzüntü belirmez. Bir müddet sonra eşeği de ölünce hoca yas tutmaya başlar. Bu işe şaşıran komşuları sorar:

– Bu nasıl iş Hocam, karının öldüğüne bu kadar üzülmedin, eşeğin öldü bir haftadır ağzını bıçak açmıyor?

Hoca:

– Karım öldüğünde hepiniz, “Üzülme daha genç ve güzel yeni bir hatun buluruz.” diye beni teselli ettiniz, fakat hiç kimse yeni bir eşek alalım demiyor.

# Yine Dövülmedi

Nasreddin Hoca bir gün yine kızıp karısına bir tokat atmış ve karısı oracıkta vefat etmiş. Hoca karısına daha çok darılıp:

- Yine dövülmedi bu avrat, demiş.

# Yorgan Gitti Kavga Bitti

Nasreddin Hoca, bir kış günü, gece yarısı, kapısının önünde bir gürültü duymuş. Soğuktan dolayı yorganını sırtına alarak dışarı çıkmış. Birkaç kişinin kavga ettiğini görmüş. Hemen yorganını bir kenara bırakarak onları ayırmaya girişmiş. Bu arada açıkgözün birisi, Nasreddin Hoca'nın yorganını çalıp kaçmış. Az sonra Hoca'nın da gayretleriyle kavga bitmiş, taraflar barışmış. Ama Nasreddin Hoca, evine yorgansız dönmüş.

Karısı:

– Kavga neden çıkmış, öğrendin mi, diye sormuş Hoca'ya.

Nasreddin Hoca, gülerek cevaplamış:

– Hatun, ne sorup duruyorsun. Kavga bizim yorgan yüzündenmiş. Yorgan gitti, kavga bitti işte.

# Yunus Peygamber

Nasreddin'in babası, evlerine üç tane pişmiş balık getirmiş.

Nasreddin'in annesi:

–Balıkları Nasreddin gelmeden yiyelim, gelirse rahat yiyemeyiz, demiş. Tam o sırada Nasreddin kapıyı vurmuş, annesi iki balığı tahtanın altına gizlemiş ve sadece bir balığı görünür bir yere koymuş. Nasreddin bu olayları kapının arasından görmüş ve içeri girmiş. Nasreddin'in babası, konuyu dağıtmak için:

–Sen Yunus Peygamber hikâyesini duymuş muydun, diye sormuş.

–Benim bunu balıktan sormam gerekiyor, diyerek Nasreddin cevap vermiş ve balığın ağzına kulağını dayayıp:

–Bu balık, “Yunus Peygamber zamanında ben küçüktüm, bu soruya tahtanın altındaki balıklar cevap verir.” dedi, demiş.

# Zaman Hesabı

Nasreddin mektepte okurken molla, öğrencilerine tabiatta yaşayışın, mevsimlerin, gündüzle gecenin izlenişi gibi konuları anlatırken:

–Şimdi yaz, gün uzayıp gece de kısalır. Yine bir ay sonra bahar mevsiminde ise gündüz bir saat uzar, demiş.

Bir ay geçtikten sonra tekrar derste mevsimlerle ilgili konuşurken molla, Nasreddin'e:

–Sen söyle, bir gece gündüz kaç saattir, diye sormuş.

Nasreddin:

–Bir gece gündüz başka zamanlar yirmi dört saat olsa da, bugünler yirmi beş saat, diye cevap vermiş.

# Zelzele

Nasreddin Hoca, bir gün tarlasından evine dönerken yolda çok şiddetli bir yer sansıntısı olur. Hoca, hemen eşeğinden yere inip secdeye kapanır. Hoca'yı bu halde görenler:

– Hocam, neden böyle aniden secdeye kapandın, diye sorarlar.

Hocanın cevabı hazırdır:

– Bu zelzelede bizim kulübe sanırım yıkılmıştır. O esnada, ya ben içinde olsaydım? Allah'a onun için secdeye kapanıp şükrettim.

# Çok Gezseydi Bizim Eve de Uğrardı

Bir gün Nasreddin Hoca'nın evine, komşu kadınlardan birisi gelerek:

– Hocam, demiş, senin karın çok geziyor.

Nasreddin Hoca:

– Yanlışın var, demiş.

Kadın iddiasında diretmiş:

– Ben,  senin karının çok gezdiğini, kendi gözlerimle görüyorum, demiş.

Nasreddin Hoca da fikrinde diretmiş:

– Ben de, yanlış olduğunu söylüyorum. Eğer senin dediğin gibi, bizim hanım çok gezseydi, arada sırada bizim eve de uğrardı

# Çömlek

Günün birinde Hoca’nın Kadı’ya işi düşmüş. Hoca Kadı’nın yaptığı her iş için bir hediye istediğini duyunca “Ne vermeliyim acaba?” diye düşünmeye başlamış. Hoca çömleğini yanına alarak nehrin kenarına gitmiş. Çömleği çamurla doldurmuş ve üstüne de bal koymuş. Kadı, Hoca’nın elinde çömleği görür görmez, işi gücü bırakır ve çömleği alıp belgeyi Hoca’nın lehine onaylar. Nasreddin Hoca gittikten sonra Kadı bir parmak alınca anlamış ki çömleğin altı koyu balçıkla dolu. Hemen Hoca’ya bir adam yollamış. Gelen adam:

– Hocam, Kadı Efendi seni çağırıyor. Belgenin bir yerinde bozukluk varmış, onu düzeltecekmiş.

Hoca, bu sözü duyunca demiş ki:

– Bozukluk belgede değil, bal çömleğinde.

# Çömlek Hesabı

Bir Ramazan-ı Şerif geldiğinde Hoca merhum kendi kendine:

— Ne için halka uyup da oruç tutacağım? Bir çömlek tedarik ederim. Günde çömleğe birer tane taş bırakırım. Taş otuzu bulunca bayramımı ederim.

Diyerek peyda eylediği çömleğe günde birer taş atmağa başlar. Kızı görüp bir avuç taş da o doldurur. Bir gün Hoca'ya: "Bugün ayın kaçıdır?", derler. Hoca:

— Biraz sabredin de bakayım, haber vereyim, deyip eve gelir, çömleği boşaltır, saymağa başlar.

Bakar ki taş tam yüz yirmi adet olmuş. Kendi kendine:

— Eğer ben bunun doğrusunu söylersem, sersemliğime hükmederler, deyip halkın yanına gelince: "Bugün ayın tam kırk beşidir", der.

— Hoca Efendi bu nasıl iş? Bir ay topu topu otuz gündür, demeleriyle Hoca cevaben der ki:

— Siz ne söylüyorsunuz, eğer çömlek hesabına bakacak olursanız, bu gün ayın yüz yirmisidir.

# Öküzün Suçu

Bir gün Nasreddin Hoca'nın tarlasına bir öküz girmiş. Ortalığı dağıtmış. Bunu gören hoca da, eline bir değnek alıp hayvanı kovalamaya başlamış. Hayvan, kaçıp kurtulmuş Nasreddin Hoca'nın elinden. Aradan günler geçmiş. Nasreddin Hoca, Akşehir pazarına giderken yolda, aynı öküzü bir kağnıyı çekerken görmüş. Hemen eline almış sopasını ve hayvanın karşısına geçip başlamış azarlamaya. Öküzün sahibi olan köylü şaşmış kalmış bu duruma. Nasreddin Hoca'ya:

– Hoca, Hoca, ne yapıyorsun? Suçu ne bu hayvanın, diye sormuş.

Nasreddin Hoca:

– Sen karışma! diye cevap vermiş adama. Suçunun ne olduğunu o çok iyi bilir!

# Ölünün Eli Ayağı Soğur

Nasreddin Hoca'ya bir gün sormuşlar, ölmüş adam neresinden bellidir, diye.

Hoca da:

–Ölünün eli ayağı soğur, demiş.

# Önsezi

Hoca ormana gitmiş. Oturmuş bir dalın üstüne, başlamış kesmeye. Aşağıdan geçen bir yolcu Hoca'ya seslenmiş:

– Hocam, insan oturduğu dalı keser mi? Şimdi düşeceksin.

Hoca adama aldırmamış; işine devam etmiş. Az sonra dal kırılmış. Hoca, düşmüş. Düştüğü yerden perişan seslenmiş:

– Düşeceğimi bildin, ne zaman öleceğimi de söyle bari.

# Ördek Çorbası İçiyormuş

Nasreddin Hoca, bir pınarın oluğunda yıkanan bir sürü ördek görmüş, içlerinden birini tutmak için koşmuş. Ancak ördekler kaçmışlar. Hoca, eline biraz ekmek alıp pınarın başına oturmuş. Elindeki ekmeği ördeklerin yıkandığı oluğun suyuna batıra batıra yemeye başlamış. Bir adam gelip Hoca'yı bu halde görünce:

– Hocam, ne yaparsın, diye sormuş.

Hoca:

– Ördeğini yiyemedim, ama çorbasını içiyorum, demiş.

# Üç Nesne

Sarı Saltuk, Nasreddin'e Akşehir'de rastlar. Nasreddin, Saltuk'a altın, gümüş tabaklar içinde yiyecek ikram eder. Bu debdebe karşısında Sarı Saltuk, kendi kendine sorar:

-Bu adam acaba bu kadar serveti babasından miras mı aldı yoksa kendisi mi kazandı?

Misafirinin aklından geçenleri sezen Nasreddin der ki:

-Bütün bunlar babamdan kaldı. Benim, bu dünyaya gelirken getirdiğim ve bir gün dünyayı terk ederken de götüreceğim üç nesnedir.

Saltuk sorar:

-Bu üç nesne nedir? -Bir sikimle iki taşağım.

Bu kaba sözler garibine gider ama düşüncesini yüksek sesle anlatmaya cesaret edemez, kendi kendine: "Böyle bilge bir adam manasız şeyler söylemez, her halde sözlerinin gizli bir manası vardır. Acaba ne demek istedi?" der. Nasreddin misafirinin aklından geçenleri sezer ve der ki:

-Kafanı boş yere yorma, söyleyeyim; bu üç şeyden maksadım: Birincisi iman, ikincisi amel, üçüncüsü de ihlâstır.

# İddia

Bir gün Nasreddin Hoca ve arkadaşları iddiaya tutuşmuşlar.

Eğer Hoca karanlık ve soğuk bir gecede, sabaha kadar köy meydanında bekleyebilirse arkadaşları ona güzel bir ziyafet çekecekmiş.

Şayet bunu beceremezse o, arkadaşlarına ziyafet çekecek.

Kararlaştırılan gün Hoca meydanın ortasında, sabaha kadar tir, tir titreyerek beklemiş. Sonra yanına gelenlere :

- Tamam demiş. İddiayı kazandım.

- Ne oldu ne yaptın demişler.

- Bekledim sabaha kadar demiş. - Hayır demişler.

Sen uzaktaki bir mum ışığı ile ısınmışsın. İddiayı kaybettin!

Ziyafetimizi hazırla. Hoca çaresiz kabul etmiş. Ziyafet vakti kocaman bir kazanın altına minicik bir mum koymuş.

Güya yemek pişirecek. - Ne yapıyorsun? demişler. Kıs, kıs gülerek cevap vermiş :

- Bu mum sıcağıyla size yemek pişireceğim arkadaşlar. Uzaktaki bir mum ışığıyla ben nasıl ısındıysam, bu kazandaki yemek de öyle pişecek!...

# İlk Koyduğu Yerde Otlamak

Nasreddin Hoca bir gün eşeğiyle dağa, odun kesmeye gitmiş. Odunları eşeğine yükledikten sonra:

– Haydi, doğru eve git! Bakalım sen mi, yoksa ben mi daha çabuk varacağız, diyerek hayvanı serbest bırakmış, kendi de kestirmeden evin yolunu tutmuş.

Fakat eve vardığında, eşeğinin hâlâ gelmemiş olduğunu görmüş. Ondan önce geldiğine sevinerek beklemeye başlamış. Beklemiş, beklemiş, ama eşek hâlâ görünmeyince meraka düşmüş. Yola koyulup yeniden dağa gitmiş. Bir de ne görsün? Eşek hâlâ ilk bıraktığı yerde otlayıp durmuyor mu? Bu işe fena halde canı sıkılan Hoca:

– Ne biçim hayvansın, diye eşeği paylamış. Ben taa eve kadar gittim, geldim. Sen ise hâlâ ilk bıraktığım yerde otluyorsun!

Hocanın bu sözü, daha sonra atasözleri arasında yer almış.

# İnanmazsan Say

Nasreddin Hoca'nın zamanında, üç ecnebi bilgin, Osmanlı ülkesinde seyahate çıkmışlar. Hoca'nın hazırcevaplığını işiterek onunla da bazı konuları tartışmak istemişler. Meydanda bir ziyafet tertip edilmiş. Hoca ile ecnebi bilginler karşılaşmışlar.

Tanışma merasiminden sonra birinci bilgin sualini sormuş:

– Hoca Hazretleri, dünyanın ortası neresidir?

Hoca, hiç düşünmeden, bastonuyla eşeğinin sağ ön ayağını göstererek:

– İşte, eşeğimin şu ayağını bastığı yerdedir, demiş.

Bilgin:

– Ne ile belli, deyince Hoca:

– İnanmazsanız, ölçebilirsiniz, demiş. Birinci bilgin söyleyecek söz bulamayarak çekilmiş.

İkinci bilgin ortaya çıkmış.

– Gökyüzündeki yıldızların sayısı ne kadardır, diye sormuş. Hoca da:

– Eşeğimin vücudunda ne kadar kıl varsa, o kadardır, demiş. İkinci bilgin:

– O kadar olduğu ne ile belli, deyince Hoca:

– İnanmazsan say, demiş.

İkinci bilgin:

– Hocam, eşeğin kılları sayılır mı, deyince Hoca da:

– Ya gökteki yıldızlar sayılır mı, cevabını vermiş. Bu bilgin de söyleyecek bir söz bulamayarak çekilmiş.

Üçüncü bilgin ileri çıkarak:

– Ey Hoca, şu benim sakalımın kaç teli var, diye sormuş. Hoca hiç düşünmeden:

– Eşeğimin kuyruğunda ne kadar kıl varsa, o kadardır, demiş. Üçüncü bilgin:

– Ne ile ispat edersin, diye sormuş.

Hoca:

– O kolaydır, bir kıl senin sakalından, bir kıl benim eşeğimin kuyruğundan koparırız, eğer sayısı uymazsa galibiyet senindir, demiş.

Bilginler, Hoca'nın hazırcevaplığına ve zekâsına hayran kalarak Müslüman olurlar.

# İpe Un Sermek

Komşuları, Nasreddin Hoca'dan devamlı olarak öte beri istedikleri için, Nasreddin Hoca, komşularından bıkmış. İstenen şeyleri vermemek için, bir bahane öne sürüyormuş.

Yine bir gün komşularından biri, Nasreddin Hoca'nın kapısını çalmış.

- Hoca, demiş, karım çamaşır yıkadı. Çamaşırı asmak için, çamaşır ipi verir misin?.. Nasreddin Hoca, komşudan bir şey istemenin böylesine rastlamadığı için, kızgınlıkla:

- İp boş değil, üzerine un serdim, demiş.

Komşu, hayretle sormuş:

- Amma yaptın Hoca? İpe un serilir mi?

Nasreddin Hoca dayanamamış:

- İnsanın vermeye gönlü olmayınca, ipe un da serer, demiş.

Kaynak : http://www.kalem.biz

# İstediğin Kadar Vade Vereyim

Dostlarından biri Hoca'dan ileri bir tarihte ödemek üzere, vade ile bir miktar borç istemiş. Hoca şu cevabı vermiş:

– Vallahi birader, hiç birikmiş param yok, borç veremem. Fakat sen benim dostumsun, ne kadar istersen vade vereyim.

# İyi ki İçinde Değilmiş

Nasreddin Hoca, bir gece, ay ışığında, bahçede iri yarı bir kimsenin ellerini gerip durduğunu görür. Hırsız sanır. Hemen karısını uyandırır:

– Yahu, çabuk ol, şu benim okumu, yayımı getir! der.

Hemen oku yaya sağlamca yerleştirip hızla savurur. Adamın tam göbeğinden oku yediğini görür. O koca heykel, bir anda sarsılıp yere yuvarlanır. Hoca, kapıyı sağlamca kapatıp yatar. Gün doğmadan bahçeye çıkıp baktığında gece vurduğu şeyin kendi kaftanı olduğunu görür. Meğer gündüzün karısı yıkayıp sabaha kadar kurusun diye ipe sermiş. Göbeği hizasından kaftana büyük bir delik açıldığını gören Hoca, Allah'a şükretmeye başlar. Karısı bu şükrün sebebini sorunca Hoca cevap verir:

– Karıcığım, görmüyor musun, ok nereden delip nereden çıkmış? Ya ben içinde olsaydım; ne olurdu halim benim.
