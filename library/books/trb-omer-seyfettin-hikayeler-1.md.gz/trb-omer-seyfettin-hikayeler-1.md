# Aleko

Küçük Ali, yorgun uykusundan uyanınca kalktı. Gece yattığı tozlu fundalıklardan çıktı. Ilık, parlak bir güneş her tarafı ısıtıyordu. Bulutsuz hava bembeyazdı. Çalıların üstünde kuşlar cıvıldayarak uçuşuyordu. Kalktı. Bir av arıyormuş gibi tereddütlü adımlarla bodur böğürtlen dallarını hışırdatarak şoseye indi. Bir ileri, bir geri baktı. Her taraf tenha idi. Uzun, kıvırcık kirpikli iri siyah gözlerini yırtık çarıklarına dikti. Düşündü. Sırtındaki tozlu deri torbada yarım ekmekle bir soğandan başka bir şeysi yoktu. Altı aydır Gelibolu'da, bir Rum fırıncının yanında çalışıyordu. Birkaç gün evvel hükümet, "muharebe olacak" diye ustasını diğer Hristiyanlarla Anadolu'ya geçirmişti. Gelibolu'da akrabası filan yoktu. Barınacak bir yer bulamadı. Köyüne dönmüştü, ama köyünde de kimseyi bulamamıştı. Evler kapanmış, ahırlar boşalmış, küçük cami meydanı at, araba, asker, çadır dolmuştu. "Buralarda muharebe olacak, devlet ahaliyi geri çekti." diyorlardı. Küçük Ali, işte köyünün geri çekilen ahalisini, anasını, ihtiyar babasını bulmak için iki gündür yürüyordu. Gece açıkta yatmak, gündüz güneşin altında yürümek onu zayıflatmıştı. Zaten esmer olan yüzü şimdi daha siyahtı. Karnı öyle açtı ki! "Ne olur, ne olmaz" diye dün gece yemeyip sakladığı ekmek parçasını torbadan çıkardı. Şosenin kenarına çöktü. Kocaman bir altın parçasına bakıyormuş gibi bu kaba mısır ekmeğini evirdi, çevirdi, ucundan ısırdı. Ağzında lokmayı birdenbire yutmaya kıyamıyor, dilinin üstünde eziyordu. Anası, babası Malkara'ya gitmiş olacaktı. Orada bir akrabaları olduğunu hatırlıyordu. Acaba daha bu tenha şoseyi kaç gün yürüyecekti? Akşama ne yiyecekti? Bütün bütün aç kalmak korkusu ile uyurken rüyada kendini keçilerle beraber çalıları otlarken görmüştü. Tekrar köye dönmeyi, askerlerin arasına katılmayı düşündü. Halbuki köye kimseyi bırakmıyorlar, "Yasak! Dön, dön!" diye bağırıyorlardı. Su nereden içecekti? Mutlaka şosenin üstünde han, yahut karakol vardı. Oturduğu tümsekten kalktı, yola atladı. Yürümeye başlamadan döndü. Geldiği tarafa baktı. Dalgalı tepelerden geçen yol, parça parça gibi bazen görünüyor, bazen yeşillikler arasında kayboluyordu. Uzakta bir kalabalık gördü. Yoksa asker miydi? Dikkat etti. Bu kalabalık gayet yavaş yürüyordu. "Bekleyeyim de şunlardan su isteyeyim" dedi. Tekrar kalktı. Tümseğe oturdu. Dirseklerini dizlerine dayadı. Çenesini ellerinin arasına aldı. Gözlerini, vakit vakit kaybolup, yine şosenin görünen parçasında meydana çıkanlardan ayırmıyordu. Bunlar asker değildi. Çünkü karmakarışık geliyorlardı. Niçin olduğunu bilmediği bir ümitle sevindi. İki gündür kırlarda yapyalnız kalmış, sanki insanları göreceği gelmişti. Ayağa kalktı. Elini gözlerine siper yaptı. Siyah kuşağı, mavi aba saltası, gönden torbasıyla tıpkı koyunlarını arayan mini mini bir çobana benziyordu. Başında keçe filan yoktu. Sert kumral saçları güneşin aydınlığı ile yaldızlanıyor, parlıyordu. — Rumlar, be!.. diye haykırdı. En önde semerli bir beygirin üstünde beyaz sakallı, siyah kavuklu, siyah esvaplı papazı farketti. Kırmızı önlüklü, siyah başlıklı kadınlar, siyah aba esvaplı erkekler, çocuklar, eşya dolu arabaların yanında; ineklerle, koyunlarla, keçilerle karmakarışık yürüyorlardı.

Küçük Ali, hiç kımıldamadan onların yaklaşmalarına baktı. Bunlar şüphesiz geriye gönderilen bir köy halkı idi. Kendi köyünde komşu Rumlar'ın arasında büyüdüğü için çok iyi Rumca bilirdi. "Bunların arasına katılıp Malkara'ya kadar gidemez miyim?" diye düşündü. Fakat onlar, yanlarında Türk istemezler, Türk'e ekmek değil, bir damla su bile vermezlerdi.

Kafile yaklaşıyor, küçük Ali parlak gözleriyle dimdik bakıyordu. Hiç kımıldamadı. Papaz, onu daha uzaktan gördü. Tam hizasına gelince küçük Ali yine şoseye atladı. Papaza yaklaştı. Rumca:  
— Rica ederim, bana bir parça su verin.  
Dedi. Papaz beygirinin yularını çekti. O durunca, kafile de etrafa yavaş yavaş birikerek durdu. Çorap ören kadınlar tığlarını bıraktılar. Çocuklar babalarının bacakları arasından papazın konuştuğu çocuğu görmeye çalışıyorlardı.  
— Sen çoban mısın?  
— Hayır.  
— Burada ne arıyorsun?  
— Gelibolu'da çalışıyorum. Ustamı sürdüler, köye döndüm. Köyümü de sürmüşler, onları aramaya gidiyorum.  
Papaz parlak mavi gözleriyle Ali'yi baştan aşağı süzdü:  
— Adın ne?  
Diye sordu.

Bu mânâlı bakışı sanki "Türk müsün? Rum musun?" diyordu. Yarımadanın birçok köylerinde Türklerle Rumlar kıyafetlerinden ayırt edilemezdi. Lisanları, dinleri, âdetleri birleştiremeyen asırlar Boğazın bu tarafında esvapları birleştirmişti.

Rum çocuklarının Türk çocuklarından farkı yalnız başı kabak gezmeleri idi. Ali, Gelibolu'da ustasının fırınında fesini kaybetmiş, köyüne dönerken başına bir şey alamamıştı. Kekeledi:  
— Aleko.  
Dedi.  
— Anan baban var mı?  
—  Hayır, ben öksüzüm, kimsem yok.  
Papaz etrafındakilere döndü.  
— Su verin şu çocuğa!  
— Teşekkür ederim.  
Hemen eline bir testi uzanmıştı. Kana kana içti. Papaz beygirin üstünde doğruluyor, arkaya bakıyordu.  
— Jandarmalar çok geride.... dedi. Seni görmediler. Bize karış. Haydi yürüyelim.  
— ......  
Kalın çizmeli ayağıyla atının karnına vurdu. Ali, atın uzun kuyruklu, al sağrısı yanında yürümeye başladı. Semerin arkasındaki iki dolu heybenin üstünde örtülmüş kırmızı bir battaniyenin uçları sallanıyordu. Kadınlar sessiz sedasız çoraplarını örerek, erkeklerin arabaları, yük hayvanları etrafında daima dikkatli, konuşmadan yürüyorlardı. Ali, küçük bir planla açlıktan kurtulduğuna seviniyor, içinden: "Kandırdım şunları! Ne vakit olsa, köyün nereye göçtüğünü haber alınca, yanlarından kaçarım" diyordu. Atın al sağrısından kalkan gözleri papazın kanburca solmuş siyah cübbeye, hayvanın adımlarına göre bir öne bir arkaya sallanan kadın saçlı başına, siyah yüksek külahına bakıyordu. Yarım saatten ziyade gittiler. Uzaklarda koyun sürüleri duruyordu. Ali, papazın başını arkaya çevirdiğini gördü. Mavi gözleriyle sanki gözlerinin içine saplandı. Titredi.  
— Aleko.  
— Oriste...  
— Yanıma gel bakayım.  
Birkaç hızlı adım attı. Papazın dizi hizasına geldi. Gözlerini yerden kaldırmıyordu.  
— Sen benim atımla odama bakarsın.  
— Bakarım.  
— Seni kiliseye hizmetçi yaparım.  
— Teşekkür ederim.  
Öğle üstü bir hanın bahçesinde, asırlık çınar ağaçlarının altında mola verilirken, papaz, jandarmalara verdiği buğday ekmeğinden, haşlama etlerinden Ali'ye de verdi. Bardağının dibinde bıraktığı şarabı da ona içirmek istedi.  
— Teşekkür ederim papaz efendi, içmem.  
— Niçin?  
Cevap bulamıyordu.  
— .....  
— Haydi iç.  
— Alışmamışım.  
— Artık alışırsın. Kilisede şarapsız yemek yenmez.  
— ......  
Ali durakladı. Eline aldığı bardağın içindeki siyah suya baktı. Köydeki hocanın Ramazan vaazlarında: "Bir damlası haramdır. İçen îmansız gider." dediğini hatırladı. Ama... Hayır, o keyif için, günah için mi içecekti! Zorla... İçmese bunların arasında barınabilir miydi? Bardağı ağzına götürdü. Zehir gibi bir şey ağzını, boğazını yaktı. Sıcak sıcak karnına indi. Buruşan yüzü ile papaza gülmeye çalıştı.  
— Teşekkür ederim!

Kafile üç gün yürüdü. Geceleri, Ali, papazın verdiği bir çula bürünerek yatıyordu. Dördüncü gün, akşama doğru içerlerde bir Rum köyüne gelindi. Jandarmalar her eve bir aile dağıttı. Papaz kiliseye inmişti. Burası karanlık, gamlı, kapalı bir bina idi. Bahçenin kalın, yüksek duvarları koyu maviye boyanmıştı. Papazın odası kaygan taşı döşeli küçük avlunun tâ nihayetinde idi. Ali, kilise hizmetçisinin yanında yatıyor, sabahları erkenden kalkıyor, kiliseyi süpürüyor, sabah ibadetlerinde hazır bulunuyordu. Bir ay geçmeden her şeyi öğrendi. Papaz, jandarma kumandanına hep onu gönderiyordu. Gayet iyi Türkçe bildiğini görmüştü. "Gelibolu'daki ustam Türktü" diyordu. Her sabah kilisede Türkler'in perişan olması için duâ edilirdi. Bütün iki köy halkının ihtiyar, genç, her sabah bu duâları candan, gönülden tekrarlayışları, sanki Ali'yi derin bir uykudan uynadırıyordu. Köydeki hocanın "Hristiyanlar da Allah'ın kuludur, onlara fenalık etmek, Müslümanlar'a fenalık etmekten daha günahtır." diye vaaz ettiğini hatırlıyor, "Acaba yanlış mı aklımda kaldı?" şüphesine düşüyordu. Pazar günleri kilisenin avlusu ağzına kadar dolardı. Efendisiyle, eski papaz muharebeye dair köylüye havadisler verirler, Türkler'in kış geçmeden bozulacağını, bu sefer İstanbul'un mutlaka alınacağını, ne kadar Türk varsa bir tane kalmamak üzere kesileceğini yana yakıla söylerlerdi. Halbuki köyün altındaki şoseden Çanakkale'ye doğru hiç durmadan asker, araba, erzak, cephâne geçiriliyordu. Ali dinlerine girer gibi yaptığı Rumlar'ın bu garazlarından heyecana geliyor, kiliseden kaçarak köyün aşağısından geçen ırmağın başına gidiyor, söğütlerin altına oturarak saatlerce düşünüyordu. Demek kıştan sonra dünyada bir Türk bırakmayacaklar, hepsini keseceklerdi. Türkler'in bundan haberleri yoktu. Hatta geçen askerlerin zâbitleri yolda papaza rastgelirlerse muhabbetle selam veriyorlar: "nasılsın papaz efendi" diye hatırını soruyorlardı. Kilisede edilen duâları bilseler...

"Ben jandarma kumandanına gider; Türk olduğumu söylerim. Bunların konuştuklarını anlatırım!" niyetiyle kalkardı. Daha kendi köyünün ne tarafa gittiğini öğrenememişti. Köyde yabancı görünce evvela bunu sorardı. Bir gün yine kiliseden çıkarken ihtiyar papaza rastladı:  
— Nereye gidiyorsun Aleko?  
— Hiç, buradayım, dedi.  
— Öyleyse gel, seninle konuşalım.  
— ......  
Papazın arkasından yürüdü. Külahının altındaki örgülü beyaz saçlarını tutup koparmak, kafasına, suratına kamçı gibi indirmek ihtiyacını duydu. Dişlerini sıktı. Başını salladı. Papaz odasına yürüdü. Kapıyı itti:  
— Gir...  
Dedi. Bahçeye bakan bir pencere vardı. Kahverengi kalın bezden perdesi yarım açıktı. Papaz minderin üstüne, Meryem Ana kandili yanan köşeye oturdu. Ali kapının yanında ayakta duruyordu.  
— Otur bakalım, dedi. Kapıyı it.  
Ali minderin ucuna ilişti. Papazın gözünün içine bakıyordu. Sordu:  
— Senin anan, baban yok, değil mi?  
— Yok  
— Hayır... Senin anan, baban var, kimsesiz değilsin.  
Ali'nin yüreği oynadı. "Acaba Türk olduğum duyuldu mu?" şüphesiyle titredi. Bozuntu vermemeye çalıştı.  
— Hayır, papaz efendi, benim sizden başka kimsem yok!..  
— Var.  
— .....  
— Var ama, sen bilmiyorsun. Senin anan, baban milletindir.  
Ali içinden "oh!" dedi. Papazın uzun bir nutkunu cevap vermeden dinledi. Diyordu ki:  
— "Adam anası, babası için her türlü fedakarlığı etmeli. Hatta canını bile vermeli. Öksüzlerin anası, babası milletleridir. Her öksüz, milleti için en büyük hizmetlere hazır olmalı. Öksüze bakan, büyüten milletdir. Millet, evladından yardım ister." Bugünden sonra ihtiyar papaz her vakit Ali'yi odasına alıyor, ona bazı yerlerini anlamadığı bir lisanla eski Rumlar'ın dünyada neler yaptığını, bir Rum kızının yüzerek gidip düşman gemilerini deldiğini, bir Rum kahramanının üçyüz kişi ile bir milyonluk orduları bozduğunu hikaye ediyordu.

Ali, elifbeden başka bir şey okumamıştı. Ama bu korkak Rumlar bu kadar yaparsa, Türkler'in evvel zamanda İstanbul'u, Çanakkale'yi almak için neler yapmış olacaklarını düşünebiliyordu.

Kış geldi, geçti. Yine bir sabah, Ali, kiliseyi süpürmüş, elinde süpürge, yattığı odaya dönüyordu. Papazın, açık penceresinden eliyle kendini çağırdığını gördü. Koştu. Süpürgeyi kapıda bıraktı. Kapıdan girdi. Papaz saçlarını tarıyordu. Arkasında siyah bir gömlek vardı. Tarağı yatağın yanındaki masaya bıraktı. Eliyle saçlarını arkaya itti. Mindere ilişti. Kırpmadan bakan mavi derin gözlerini Ali'ye dikti: — Sana bir şey söyleyeceğim, dedi. Otur karşıma. — Buyurun. — Sen çok güzel Türkçe biliyorsun. — Biliyorum. — Ben Türküm, desen askerler şüphelenmezler, inanırlar. — Evet. — Sana bir mektup vereceğim. Bunu poturunun içine dikeceksin. Çanakkale'ye gideceksin. Askerlerin arasından bir yol bulacaksın. İngiliz kumandanına bu mektubu götüreceksin. — Peki. Papazın yüzü güldü. Mavi, derin gözleri parladı. Hala Çanakkale Türkler'den alınamadığı için bütün köy halkıyla beraber matemdeydi. Her gün sinirli sinirli düşünüyor, şoseden gelen geçen askerlerin yüzlerinden mânâlar çıkarmaya çalışıyordu. Ali, sokakta, evlerde, kilisede ibadetlerde bu umûmî yeisi görüyor, için için seviniyordu. Papaz gülümseyince o da gülümsedi. Yine uzun bir nutuk dinledi. Zayıf, uzun parmaklı, uzun tırnaklı sarı elleriyle beyaz sakalını okşayarak coşan bu ihtiyar, onda sarsıcı bir heyecan uyandırıyordu. Sekiz aydır kilisenin alacakaranlığı içinde acı gözyaşları gibi parlayan kandillerin titrediği gölgeler arasında insana canlı gibi bakan resimlerin karşısında ruhu da değişmişti. "Büyük Yunan, büyük Rumluk" emelini dinledikçe kalbi şişiyor, acı bir azap boğazına tıkanıyordu. İşittiği, duyduğu, anladığı her şey onda aksi bir tesir bırakıyordu. Ondört yaşındaki cahil bir çocuk hayaliyle gözünün önüne köyünün camiini getiriyor, daima ahiretten, Sırat köprüsünden, cennetten, cehennemden bahseden ihtiyar imamı mihrabın yanındaki yeşil boyalı kürsüye çıkartıyordu. "Büyük Türklük" için, Türk düşmanlarının perişan edilmesi için, tıpkı ihtiyar papaz gibi söyletiyor, ihtiyar papazın sözlerini Türkçe ona tekrarlatıyordu. Ertesi gün poturunun ağına mektubu diktiler. Türk sanılsın diye başına bir fes aldılar. Torbası dört günlük ekmekle, peynirle, haşlanmış yumurta ile dolduruldu. Veda ederken papaz alnından öptü. Eline bir kağıt uzattı: — Bu Atina İngiliz sefirinden evvelce alınmış bir itimatnâmedir, dedi. Bunu İngilizler'e gösterdin mi, bizim tarafımızdan geldiğini hemen anlarlar. Şayet üzerinde yakalanırsa "yerde buldum" dersin. Bizden aldığını inkar edersin. — Peki... — Karşına İngiliz askerleri çıkınca "Kıbrıs" diye bağır. Bu sene parola budur. Unutma ha: "Kıbrıs." — Peki. — Hiç korkma. Vatan, evladının hizmetini bekliyor. Milletin kalbi seninle beraber, İngiliz kumandanından bize haber getireceksin. Ne vakit bizi kurtaracaklarını öğreneceksin. Bize müjdeleyeceksin! — Peki. Papaz, Ali'nin tekrar alnından öptü. Yolda yemeği biterse almak için beş tane de mecidiye verdi. Kiliseden çıkınca Ali jandarma karakoluna gidip, İngiliz kumandanına verilecek bu kağıdı vermeyi düşündü. Ama vazgeçti. Her şey jandarmaların gözü önünde olurken onlar aldırmıyor, başlarını sallıyorlardı. "Ben bunu Çanakkale'ye paşaya götürürüm" dedi.

Şosede hızlı yürümeye başladı. Hava açıktı. Tekerlek izleri, hayvan izleriyle örtülü yol yine tenha idi. Bir gün gitti. İki gün gitti. Üç gün gitti. Geceleri yine fundalıklarda yatıyor, ama eskisi gibi korkmuyordu. Şimdi ruhu çok kuvvetliydi. Ne aç, ne açık kalacağını hiç düşünmüyor, milletine yapacağı hizmeti aklına getiriyordu. Yollarda rasgeldiği askerlerle tatlı tatlı konuşuyor, Rumlar arasında duyduğu havadislerin hep aksini işitiyordu. İngilizler'in bir adım ileri atmak ihtimalleri yoktu. Süngüden hepsinin ödleri kopuyordu. "Daha bir ay tutunamazlar, boyunlarını kırarlar" deniliyordu. Arıburnu, Cehennemdere hücumlarını, batan gemileri, tahtelbahirleri, tayyareleri, bombaları, havadan yağan çivi yağmurlarını dinledi. Dinledikçe damarlarındaki kanı kaynıyor, bir an evvel paşanın oturduğu yere erişmek hırsıyla adeta koşuyordu. Dördüncü gün top sesleri daha yakından işitiliyordu. Yolda daha kalabalık askerler rastladı. Karşıda siyah çalılıkların arasında birçok beyaz çadırlar görünüyordu. Yürüdü, yürüdü. Tepenin dibine geldi. Orada bir taşın üzerinde siyah bıyıklı, soluk kabalıklı, iri bir asker oturuyordu. Silahı yoktu. Ona:  
— Paşa burada mı oturur?  
Diye sordu.  
— Hayır.  
— Bu çadırlarda kimler var?  
— Yaralılar, burası hastane.  
— Paşa nerede oturur?  
— Ne yapacaksın?  
Ali ona geriden bir mektup getirdiğini, bu mektubun muharebeye dair olduğunu anlattı. Nefer "Hangi paşayı istiyorsun? Ben yaralıydım, iyi oldum. Alayıma gidiyorum. Bizim fırka siperlerdedir. İstersen seni bizim paşaya götüreyim." dedi. Ali buna razı oldu. Artık şose bitmişti. Yeni yollardan, topçu izlerinden yürüdüler. Mekkarî hayvanlarına, küçük cephane arabalarına, hasta sedyelerine tesadüf ediyorlardı. Top sesleri duyulmasa muharebe oluyor sanılmayacaktı. Denizin üstü süt gibiydi. Akşama doğru bir çam ormanının içine girdiler. Dik bir dereye indiler. Yükseklerden bir çağlayanın şırıltısı duyuluyordu. Derenin sağ tarafındaki sırtta onbeş yirmi kadar çadır vardı. Burası uzaktan beyaz çatılı, tenha bir köye benziyordu. İnce ahşap bir köprüyü geçtiler. Nefer, küçük Ali'ye:  
— Sen burada beni bekle.  
Dedi. Gitti. İlerledi. Nöbetçilerle konuştu. Çadırın birine yürüdü. Oradan çıkanlara bir şeyler söyledi. Sonra konuştuklarıyla beraber küçük Ali'ye döndü. Elini salladı.  
— Gel!  
Diye haykırdı. Ali, koşa koşa onların yanına gitti. Sırmalı iri bir adam onu baştan aşağı süzdü. Gülümseyerek sordu:  
— Hani mektup?  
— Poturumda dikili.  
— Ya! Kimden getirdin?  
— Papazdan!  
— Bizim paşaya mı?  
— Hayır, İngiliz paşasına.  
— İngiliz paşasına mı?  
Bu adam işi iyice anladıktan sonra "Gel, bunları yavere söyle" diye onu arkasına taktı. Tek, büyük bir çadırın yanındaki gölgeliğin altında yatar gibi uzanarak bir kitap okuyan genç bir zâbitin önüne götürdü. Ali, nasıl köyünü bulamadığını, nasıl Rumlar'a karıştığını, nasıl kendini Rum gösterdiğinden başladı. Kilisede olup bitenleri, papazın söylediklerini nihayetine kadar anlattı. Zâbit doğrulmuş, okumaktan yorulan gözleri birdenbire parlamıştı...

Kendi eliyle Ali'nin poturunu söktü. Mektubu çıkardı. Rumca tercümanı çağırttı. Ali ile onu arkasına takarak paşanın çadırına götürdü. Paşa, tıknaz, sakallı bir adamdı. Küçük bir masanın önünde zayıf bir zâbitle oturmuş, cigara içiyordu. Yaver selamladı. Ali'nin söylediklerini kısaca anlattı:  
— Mektup da bu...  
Dedi. Paşa ehemmiyetle tercümana:  
— Oku bakalım, ne?  
Diye uzattı.

Tercüman, tıpkı Girit muhacirleri gibi söylüyordu. Küçük Ali de çadırdakilerle beraber mektubun ne yazdığını işitti. Papaz, sekiz aydır köyün önünden geçen taburların, topların adedini söylüyor, "Daha bizi kurtarmaya gelmeyecek misiniz? Dört gözle sizi bekliyoruz. Her sabah sizin için duâ ediyoruz" diyordu. Ali okunan iftiraları duydukça "Yalan, yalan!" diye haykıracağı geliyordu. Jandarmaların, geçen askerlerin, zâbitlerin Rumlar'a ne kadar muhabbet gösterdiklerini hatırladı. Papaz mektubun nihayetinde kendini İngiliz Generaline takdim ediyor: "Bu öksüz Rum çocuğu bizim tarafımızdan yetiştirilmiştir. Her türlü fedakarlığı, hizmeti yapmak için hazırdır. Kendisine emniyet ediniz. Türkçe'yi de gayet iyi bilir. Her ne isterseniz yapar. Size Rum kahramanlığının nasıl nihayetsiz bir hamiyet olduğunu gösterir." tavsiyesinde bulunuyordu. Mektup bitince paşa, Ali'ye, köye, papaza dair birçok şeyler sordu. Sonra karşısında hiç ses çıkarmadan duran zâbite bakarak yavere emir verdi:  
— Hemen telgrafla bu casusun tutulmasını yazınız. Vakit geçmesin!  
— Başüstüne.  
Yaver çıkarken ilave etti:  
— Bu çocuğa da beş lira mükafat ver.  
Fakat Ali zeki bir çocuk serbestliği ile:  
— Ben para istemem.  
Dedi. Paşa ayağa kalktı. Tâ gözlerinin içine bakarak:  
— Ya ne istersin?..  
— Hizmet etmek isterim.  
— Nasıl hizmet?  
— ....  
— Küçüksün, muharebe edemezsin. Okuyup yazman var mı?  
— Azıcık okurum.  
— Seni telefoncuların yanına vereyim. Telefoncu ol.  
— ....  
Ali yutkundu. O, büyük bir iş yapmak, bir fedakarlık yapmak, başkalarının yapamayacağı bir şey yapmak istiyordu. Papazın ruhunda kopardığı fırtınaların gürültüleri hâlâ dinmemişti. Küçük bir Rum kızının yüzerek düşman gemilerinin altını deldiğini, bir genç Rum'un üçyüz kişiyle yüzbinlerce düşmanı bozup vatanı kurtardığını unutamıyordu. Bir Türk çocuğu da böyle bir şey yapamaz mıydı? Rumlar'la İngilizler'in parolasını bildiğini, kolaylıkla düşman tarafına gidip onlara da kendini Rum gösterebileceğini söyledi.  
— Belki bizim taraf için faydalı bir şey görürüm, anlarım. Size haber getiririm.  
Dedi. Paşa bu fikri çok muvafık buldu. "Bak, bunu düşünemedik." diye hâlâ hiç sesini çıkarmadan oturan zayıf zâbite döndü. Gülerek Ali'yi okşadı:  
— Aferin sana..  
— ....  
Yaver, Ali'yi çadırına götürdü. Çikolatalar, şekerler verdi. Hava kararıyor, yavaş yavaş her tarafı gölgeler kaplıyordu.

Sabahleyin erkenden yaverle beraber karargahtan çıktılar. O da al ata binmişti. Yaverinki beyazdı. Birkaç tepe aştılar. Tarlaların üzerinde insan büyüklüğünde gölgeler yatıyordu. Duvarları yıkılmış, çatıları yanmış, harap bir köyün hizasına gelince yaver atından atladı. — Artık yayan gideceğiz. Dedi. Belli ki buralarda muharebe olmuştu. Ali onun arkasına takıldı. Neferler atların yanında kalmıştı. Yaver önde, o arkada yarım saat kadar yürüdüler. Birtakım askerlere rasgeldiler. Hepsi selam veriyorlardı. Sonra kazılmış yola girdiler. Etraf görünmüyordu. Yürüdüler, yürüdüler. Bir tepenin arkasına çıktılar. Burada in gibi yerler vardı. Yaver bu inlerden birine onu soktu. İçeride üç dört zâbit oturuyordu. Ali'yi onlara gösterdi. Paşa'nın arzusunu anlattı. Kumandan Bey dediği uzun boylu, esmer adam: — Pekala, dedi. Ama gündüz gidemez. Vurulur. Onu ben şimdi ileri hatta gönderirim. Son dirseğin nihayetinde bir nöbetçi siperi vardır. Oradan fundalık yarı görsün. Gece yardan aşağı iner, İngiliz mevkiine doğru çıkar. Sabahleyin beyaz mendil gösterir. Belki vurmaz alırlar...

Telefonu eline aldı. Söylediklerini tekrarladı. Sonra yanına bir emir neferi kattı. — Haydi çocuğum, korkma... — Korkmam. Küçük Ali gülüyor, seviniyordu. Siperlerin içinden yürüdükçe kalbinin sevinçle çarptığını, tatlı bir hararetin yüzünden göğsüne indiğini duyar gibi oluyordu.

Bugün muharebe olmuyordu. Geri hatları geçti. En ileri hatta erişti. Siperin içinde birkaç nefer ayakta ileriye bakıyor, öbürleri aşağı oturmuş konuşuyorlar, gülüşüyorlar, türkü söylüyorlar, kabak çalıyorlardı. Sanki buraları bir düğün yeriydi... Her hatta birtakım genç zâbitlere rasgeliyorlardı. Zâbitler çok meraklıydı. Emir neferinden her şeyi anlıyorlar, Ali'ye de birçok şey soruyorlardı. Kumandan Bey'in "dirsek" dediği sipere gelince emir neferi onu kısa boylu, gözlüklü bir zâbite teslim etti. Döndü. Ali siperde yalnız kalınca bu zâbitin yanına oturdu. Neferin kısaca söylediklerini daha uzun anlattı. Zâbit: — Peki çocuğum, bize misafir olursun, gece salıveririm, dedi. Sonra onu kum dolu torbaların arasındaki küçük bir deliğe yaklaştırdı. Funda ormanını, derinyarı gösterdi. Eline bir dürbün verdi. İngiliz siperlerini buldurdu. Bu yarın etrafı boştu. İlerlemek mümkün olmadığı için iki tarafın da askerleri yoktu. Gece oluncaya kadar zâbitin yanında kaldı. Zâbitle beraber yemek yedi. Siyah bulutlar arasında yıldızlar parlamaya başlamıştı. Zâbit, kendi eliyle onu siperin üstüne çıkardı. Hava o kadar karanlıktı ki... Siperlerde sanki hiç insan yoktu. Yalnız mânâsı anlaşılmaz, uzak sesler duyuluyor, fakat hiçbir aydınlık görünmüyordu. Küçük Ali, gündüzden gördüğü yarın dibine doğru inmeye başladı. Düşmemek için çalılara tutunuyor, esvapları, yüzü, gözü çiziliyordu. Belki iki saat uğraştı. Ayağının altında toprak, taş parçaları kayıyor, tutunduğu dallar kopuyordu. Gözü karanlığa alıştı. Bulutlar geçtikçe yıldızlar çoğalıyor, etraf biraz görünüyordu. Yarın İngiliz tarafına tırmanacak bir yer buldu. Belki dört saatte burasını çıkmaya çalıştı. Biraz dinleniyor, bir parça ekmek yiyor, tekrar fundalara sarılıyordu. Bazen karşısına geçilmez bir kaya çıkıyor, tekrar inerek başka bir taraftan tırmanıyordu. Türk siperlerinin üstü morlaşırken, Ali, İngiliz siperlerine iyice yaklaştığını gördü. Sindi. Biraz durdu. Cebinden, karargahtan verdikleri beyaz bezi çıkardı. Kopardığı bir değneğe taktı. Yukarı kaldırdı. Ufkun üstündeki morluk pembeleşiyor, yıldızlar kayboluyordu. Yüz adım kadar yaklaştığı tepesindeki siperden birtakım sesler duydu. — Kıbrıs, Kıbrıs! Diye bağırdı.

Papazın parolası hemen anlaşılmıştı.

Görünmeyen insanlar cevap verdiler:  
— Ela, ela...  
Küçük Ali, sesin çıktığı tarafa doğru yürüdü. Daha güneş doğmamıştı. Beyaz torbaların arasında tüfek uçları görünüyordu. Torbaların üstüne çıktı. Bayırı atlayamadı. Çünkü pek derindi. Kocaman kırmızı yüzlü, kırmızı saçlı bir askerin açılmış kucağına düştü. Etrafına toplanan İngilizler anlamadığı bir lisanla ona sualler soruyordu. Ali, derin bir haç çıkarıp: "Ben Rumum!" dedi. Getirdiği mektubu gösterdi:  
— Puyne jeneral?  
— Allright.  
— Allright...  
Siperin içinde koşuşuyorlar, sanki birini arıyorlardı. Onu bir yeraltı yolunda geri götürdüler. Buraları tıpkı bizim tarafa benziyordu. Yalnız insanları ayrıydı. Hepsi sarı, uzun boylu, zayıftı. Hiçbirisi gülmüyor, herkes surat asmış, bir şeye dargın gibi duruyordu. Yeraltı yolunun nihayetindeki inde uzun bir sandalyeye yaslanmış İngiliz zâbite de, Ali, Rumca meramını anlatmaya çalıştı. O vakit biraz durdular. Karşısına orta yaşlı bir Rum getirdiler. Bu tercümandı.

Ali, papazın söylediklerini tekrarladı. Mektup koynunda idi. Çıkardı. Zâbite uzattı. Zâbit tercümanı dinledikten sonra sevinerek kalktı. Ali'nin elini sıktı. Yanındaki küçük masanın üstünde çabucak raporunu yazdı. İki askerle beraber Ali'yi kumandanın karargahına gönderdi.

Bu karargah gayet kalabalıktı. Tayyarelerin görmemesi için küçük sık bir koruluğun içine, yerin altına yapılmıştı. Hiç çadır yoktu. Ali, küçük pencereli birçok odaların tâ ortasındaki kapıdan girdi. İçerisi şehir evleri gibi muntazam boyalıydı. Odada oturan yavere neferler raporu verdiler.  Ali'yi gösterdiler. Yaver, yanda bir odaya girdi. Yarım saat kadar bekledi. Sonra kapıdan gözüktü. Ali'yi çağırdı. Ali içeriye girince büyük bir masada koltuğa yaslanmış, beyaz kesik bıyıklı, kırmızı yüzlü, ihtiyar bir adam gördü. Bu İngiliz paşası olacaktı. Yanında asker esvaplı bir adam duruyordu. Kendine Rumca hitap eden bu askerin bir tercüman olduğu anlaşıldı. Papazın söylediklerini, Rumlar'ın nasıl dört gözle İngiliz ordusunu beklediklerini ballandıra ballandıra anlattı. İhtiyar İngiliz gülümsüyordu. Sözlerini tercümana naklettikçe, kumandan İngilizce bir şeyler söylüyordu. Ali'nin sözü bitince, İngiliz askeri kıyafetindeki Rum sordu: — Papazınız mektubunda sizin her türlü fedakarlığa hazır olduğunuzu yazmış, hazır mısınız? — Hazırım. — Buraya geldiğiniz gibi gidebilir misiniz? — Giderim. Beni Türkler de Türk sanıyorlar. Çok güzel Türkçe bilirim. — Türkler'in karargahlarına da, siperlerine de girebiliyor musun? — Giriyorum. Onlara satmak için tütün, balık falan götürüyorum. — Pekala, jekala... İngiliz kumandanı tercümana uzun uzadıya bir şeyler söyledi. Ali, onun yorgun yorgun oynayan dudaklarına bakıyor, anlamadığı kelimelerden bir mânâ çıkarmaya çalışıyordu. Nihayet bu merak çok sürmedi. Tercüman lafa başladı: — Kumandan papazınıza selam ediyor. Biraz geç de olsa mutlaka gelip sizi kurtaracağız. Mutlaka İstanbul'u alacağız. Bundan şüpheniz olmasın. Sana küçük bir saatli bomba vereceğiz. Bunu kurup gizlice Türk paşasının çadırı yanına bırakacaksın. Kurulduktan yarım saat sonra patlar. Halbuki sen yarım saat içinde uzağa kaçıp kurtulursun. — Kurtulurum. Kumandanın yüzü güldü. Hemen zile bastı. İçeri gelen askere emirlerini verdi. Tercüman, Ali'ye, papazın mektubundaki şeyleri soruyor, Türkler'in korkup korkmadıklarını anlamak istiyordu. İki zâbit bir tahta kutu ile içeri girdiler. Kutudan bir şey çıkardılar. Masanın üzerine bıraktılar. Bu, bombaydı. Üç dört kerpiç büyüklüğündeydi. Üstünde dereceli bir şey vardı. Tercümana gösterdiler. Tercüman kendisine onların sözlerini tekrarladı: — İşte bu düğmeyi bu tarafa çevireceksin. Çevirdin mi yarım saat içerisinde işlemeye başlar . Sen hemen kaç. Yarım saat sonra ne karargah kalır, ne paşa... Hepsi uçar. Ali, masanın üstündeki siyah şeye daha dikkatli baktı. Düğme beyaz bir madendi. Zâbit İngilizce daha ziyade tafsilat veriyor, düğmeyi parmağıyla iter gibi yapıyordu. İngiliz kumandanı, hatta çadırın yirmi otuz adım uzağına bile konsa yine tesirinin müthiş olacağını tercümana söyletti. Küçük Ali, saatli bombayı tercümandan isteyerek torbasına soktu. Ağırdı. Belki beş okkadan ziyade idi. Tercüman, kumandanın iltifatlarını tekrar tekrar söylüyordu. Hemen bu gece geldiği yerden gitmesine karar verildi. Kumandan elli İngiliz lirası ihsan etti. Ali kabul etmek istemedi. "Kabul etmezsen, köydeki fakirlere ver." diyorlardı. Onu yandaki odaya geçirdiler. Bir masanın başına oturttular. Önüne et, ekmek, tatlılar, tanımadığı bir içki koydular. Uzun boylu yaver ayakta hizmet eden neferlere bakıyor, tercümanla konuşuyordu. Ali'nin torbası yanındaki sandalyede idi.

Ali yemekleri yerken bu adamların alçakça niyetlerini düşünmeye başladı. Halbuki Türk paşası böyle namertçe bir oyun düşünmemiş, teklif etmemişti. İçinden "Gece Türkler'in tarafına gidiyorum, diye atlarım. Bombayı kurar, siperin dibine bırakırım. Kendim kaçarım" dedi. Fakat böyle yaparsa, siper uçacak, içindeki askerler ölecek, bu hainliği düşünen İngiliz kumandanına bir şey olmayacaktı. Gece siperden dönüp buraya gelmenin ihtimali yoktu. Siper başları, büyük karargahın etrafı hep nöbetçi dolu idi. İngiliz yaverle tercüman konuşa konuşa açık kapının yanına gitmişlerdi. Ona dikkat etmiyorlardı. Ali bütün karargahı yerle bir edecek bu korkunç alete bakmak istedi. Yavaşça yanındaki torbayı kucağına çekti. Ağzını açtı. Dört köşe bomba kocaman kurşun bir tuğla gibiydi. Saatin düğmesi beyazdı. Gümüş gibi parlıyordu. Parmağını dokundurdu. Azıcık itti... Bir parmak kadar... Tekrar geri çekmek istedi... Hayır... Düğme geriye gelmiyordu. Düğmeyi nihayete kadar itip bombayı burada bırakmak aklına geldi. Ama nereye kaçacaktı? Hemen onu tutarlar, öldürürlerdi. Bombayı bizim paşaya götürüp teslim etse, ne fayda hâsıl olacaktı? Hiç... Yine İngiliz kumandanının kasti cezasız kalacaktı. Zihninden şimşek gibi bir fikir geçti. Dudaklarını ısırdı. İştahı kesildi. Kapıya baktı. Tercümanla yaver dalmışlar, ellerindeki bir haritaya bakarak konuşuyorlardı. Ne olabilirlerdi? Kendi Kendi de beraber... Papaz "Milleti için ölenler daima yaşarlar" demiyor muydu? Bu sözü yine hayaline getirdiği köyün imamına söyletiyor, içinden: "Bir insan ne kadar yaşasa yine ölecek değil mi?" diyordu. Büyük babasını, büyük anasını, dayılarını, amcalarını, halalarını düşündü. Hepsi ölmüşlerdi. Köyünün mezarları evlerinden çoktu! Nefret ettiği hain düşmanlara güzel bir darbe indirerek, kendi de beraber yüzlercesini öldürerek ölmek... Gülümsedi. Bu büyük fırsat her vakit ele geçer miydi? Parmağı ile düğmeyi yavaş yavaş tâ nihayete kadar itti. Şimdi bomba, tıpkı küçük bir saat gibi işliyordu. Kulağına yaklaştırdı. Tık... Tık... Tık... Hemen torbasının ağzını kapadı. Sırtına astı. Yemek yiyor gibi yaptı. Yarım saat! Fırında çalışırken evlerden gelen tepsiler fırında yarım saat dururdu. Bir tepsi müddeti! Yani... Artık yemiyor, düşünüyor, vakti hesabediyordu. Gözleri kumandanın kapısındaydı. Tam son dakikalara doğru oraya giriverecekti. Sırtında bombanın işlediğini duyuyordu.

Bir tepsi kızaracak vakit geçmişti. Masadan doğruldu. Ayağa kalkınca yaver döndü. Tercüman: — Karnın doydu mu oğlum? Diye sordu. — Teşekkür ederim. Kumandana bir şey daha söyleyeceğim. Demin unutmuştum. — Bana söyle yavrum, yavere söyleyeyim, o haber versin. — Hayır, çok mühim bir şey, ben kendim söylemeliyim... Tercüman, Ali'nin ısrarını yavere söyledi. Haritayı katlayan yaver gülerek Ali'ye baktı. "Allright" diye başını salladı. Bombayı götüreceği için onu çok takdir ediyordu. Yaklaştı. Omuzunu okşadı, Ali, bombanın işlediğini duyacak diye korktu. — Haydi gel... — ...... Tercümanla beraber yandaki kapıdan girdiler. Başıkabak kumandan masanın üstündeki gazeteleri karıştırıyordu. Niçin geldiklerini sordu. Tercüman cevap verdi. Sonra Ali'ye döndü: — Ne söyleyeceksin? Dedi. — Türkler tarafına gitmezden evvel bombanın patlayınca ne yapacağını soracağım. Ben kaçıp köye gidince papazımıza anlatayım. Tercüman kumandana soruyor, onun söylediğini Rumca tekrar ediyordu: — Bu en dehşetli cehennem makinasıdır. İki yüz metrelik yerde ne varsa hepsini havaya uçurur. — Demek karargahta ne kadar adam varsa hepsi ölecek? — Hepsi... Belki yangın da çıkacak. Cephaneleri bizimki gibi karargahlarına yakınsa, onlar da ateş alacaktır. — Ya bomba ateş almazsa? — Mutlaka alır. Emniyet düğmesini ittikten sonra yarım saat geçer geçmez hemen patlar. — Bunda hiç şüphe yoktur ya... — Asla... Ali durdu. Sırtında bombanın tiktaklarını daha hızlanmış gibi işitti. — Öyle ise kumandana söyle. Ben Rum değilim. Tercüman afalladı. Gözleri derinleşti: — Ya nesin? — Türküm! — Türk mü? — Evet Türk... Gülüyordu. Göğsü kabarıyordu. "Türk" lafını işiten kumandan ayağa kalkmıştı. Tercümandan Ali'nin ne söylediğini anlayınca yüzü kıpkırmızı oldu. Hiddetle bağırdı. Yaver, elindeki haritayı buruşturuyordu. Tercüman da sararmıştı: — Ne cesaretle buraya geldin? Şimdi kurşuna dizileceksin. — Beni kurşuna dizemeyeceksiniz. Ali'nin gözleri büyüdü. Bir adım daha ileri yürüdü. Kumandan hemen cebinden bir rovelver çıkardı. Bir kasitten korkuyordu. Ali daha ziyade gülüyordu. Tercümana: — Vakit dar, çabuk söyle. O beni öldüremeyecek, ben onu öldüreceğim, dedi. Tercümanın çeneleri kilitlendi. Şaşkınlığından bu cümleyi İngilizce tekrarlamaya vakit kalmadı.

Türk tarassut mahallerinden, düşman siperlerinin gerisinde her tarafı sarsan büyük bir infilak gürültüsüyle beraber bir dumanın havaya yükseldiği görüldü. Dumanların arkasından kalkan siyah alevler akşama kadar sönmedi. Tarassut zâbitleri telefonla kumandanlarına: "İngilizler'in karargahları tahmin olunan yerde emsalsiz bir infilak oldu. Fakat bizim mermilerimizin, tayyarelerimizin eseri değil bir kaza neticesi olması ihtimali vardır." diyorlardı.

Bu yangının asıl sebebi bir türlü anlaşılamadı. Yalnız paşa, çadırında her sabah garip bir elemle küçük Ali'yi hatırlıyor, erkan-ı harbine: "O gönderdiğimiz çocuktan hâlâ haber çıkmadı. Acaba büyük infilakta, yangında bir şey mi oldu?" diyordu.

# And

Ben Gönen'de doğdum. Yirmi yıldan beri görmediğim(-me,isim fiil) bu kasaba hayalimde artık seraplaştı. Birçok yerleri unutulan(-an.sıfat fiil) eski, uzak bir rüya gibi oldu. O zaman genç bir yüzbaşı olan(-an,sıfat fiil) babamla her vakit önünden geçtiğimiz Çarşı Camii'ni, karşısındaki küçük, harap şadırvanı, içinde binlerce kereste tomruğu yüzen(-en,sıfat fiil) nehirciği, bazı yıkanmaya(-ma,isim fiil) gittiğimiz(-tiğ,sıfat fiil) sıcak sulu hamamın derin havuzunu şimdi hatırlamaya(-ma,isim fiil) çalışıyorum. Fakat beyaz bir nisyan dumanı önüme yığılır. Renkleri siler, şekilleri kaybeder... Pek uzun gurbetlerden sonra vatanına dönen(-en,sıfat fiil) bir adam doğduğu(-duğ,sıfat fiil) yerin ufkunu koyu bir sis altında bulup(-up,zarf fiil) da, sevdiği(-diğ, sıfat fiil)şeyleri uzaktan bir an evvel göremediği(-diğ, sıfat fiil)için nasıl mahzun olursa, ben de tıpkı böyle meraka, sabırsızlığa benzer bir elem duyarım. O, her akşam sürülerle mandaların, ineklerin geçtiği(-tiğ, sıfat fiil)tozlu, taşsız yollar; yosunlu, siyah kiremitli çatılar; yıkılacakmış(-acak,sıfat fiil )gibi duran(-an, sıfat fiil)büyük duvarlar, küçük, ahşap köprüler, nihayetsiz tarlalar, alçak çitler hep bu duman içinde erir.

Yalnız evimizle mektebi gözümün önüne getirebilirim.

Büyük bir bahçe... Ortasında köşk tarzında yapılmış(-mış,sıfat fiil) bembeyaz bir ev... Sağ köşesinde her vakit oturduğumuz beyaz perdeli oda... Sabahları annem beni bir bebek gibi pencerenin kenarına oturtur, dersimi tekrar ettirir, sütümü içirirdi. Bu pencereden görünen(-en, sıfat fiil)avlunun öbür tarafındaki büyük toprak rengindeki binanın camsız, kapaksız tek bir penceresi vardı. Bu siyah delik beni çok korkuturdu. Yemeklerimizi pişiren(-en, sıfat fiil), çamaşırlarımızı yıkayan(-an, sıfat fiil), tahtalarımızı silen(-en, sıfat fiil), babamın atına yem veren(-en, sıfat fiil), av köpeklerine bakan(-an, sıfat fiil )hizmetçimiz Abil Ana'nın her gece anlattığı korkunç, bitmez(-mez, sıfat fiil)hikâyelerdeki ayıyı, bu karanlık pencerede görür gibi olurdum. Bu vehim ile, rüya dinlemek(-mek,isim fiil), tâbir etmek(-mek,isim fiil )merakında olan(-an,sıfat fiil )zavallı anneme, her sabah ayılı rüyalar uydurur; iri kızgın bir ayının beni kapıp(-ıp,zarf fiil )dağa götürdüğünü(-düğ, sıfat fiil), ormandaki inine kapadığını(-dığ, sıfat fiil), kollarımı bağladığını(-dığ, sıfat fiil), burnumu, dudaklarımı yediğini(-diğ, sıfat fiil), sonra Bayramiç yolundaki su değirmeninin çarkına attığını söyler(-er,sıfat fiil), ona birçok: "Hayırdır inşallah..." dedirtirdim. Tâbir ederken() benim büyük bir adam, büyük bir bey, büyük bir paşa olacağımı(-acağ,sıfat fiil), bana kimsenin fenalık yapamayacağını() temin ettikçe(-tikçe,zarf fiil), yalan söylediğimi(-diğ,sıfat fiil) unutur, ne kadar sevinirdim!

Nasıl sokaklardan, kiminle giderdim? Bilmiyorum... Mektep bir katlı, duvarları badanasız idi. Kapıdan girilince(-ince,zarf fiil )üstü kapalı bir avlu vardı. Daha ilerisinde küçük, ağaçsız bir bahçe... Bahçenin nihayetinde ayakyolu, gayet kocaman abdest fıçısı... Erkek çocuklarla kızlar karmakarışık otururlar, beraber okur(), beraber oynarlardı. "Büyük Hoca" dediğimiz, kınalı, az saçlı, kambur, uzun boylu, ihtiyar, bunak bir kadındı. Mavi gözleri pek sert parlar(-ar,sıfat fiil), gaga gibi iri, sarı burnu ile, tüyleri dökülmüş(-müş,sıfat fiil) hain, hasta bir çaylağa benzerdi. "Küçük Hoca" erkekti. Büyük Hoca'nın oğlu idi. Çocuklar ondan hiç korkmazlardı. Galiba biraz aptalca idi. Ben arkadaki rahlelerde, Büyük Hoca'nın en uzun sopasını uzatamadığı() bir yerde otururdum. Kızlar, belki saçlarımın açık sarı olmasından(), bana hep "Ak Bey" derlerdi. Erkek çocukların büyücekleri ya ismimi söylerler yahut "Yüzbaşıoğlu" diye çağırırlardı. Sınıf kapısının açılmayan() kanadında sallanan(-an, sıfat fiil)"geldi-gitti" levhası yassı, cansız bir yüz gibi bize bakar(-ar, sıfat fiil)kalın duvarların tavana yakın dar pencerelerinden giren(-en , sıfat fiil)donuk bir aydınlık durmadan(-madan,zarf fiil) bağıran(-an, sıfat fiil), haykırarak(-arak,zarf fiil) okuyan(-an, sıfat fiil)çocukların susmaz(-maz,sıfat fiil), keskin çığlıklarıyla sanki daha ziyâde ağırlaşır, bulanırdı...

Mektepte yalnız bir nevi ceza vardı: Dayak... Büyük kabahatliler, hatta kızlar bile falakaya yatarlardı. Falakadan korkmayan, titremeyen() yoktu. Küçük kabahatlilerin cezası ise nisbetsiz, mikyassız idi. Küçük Hoca'nın ağır tokadı... Büyük Hoca'nın uzun sopası... ki rastgeldiği kafayı mutlaka şişirirdi. Ben hiç dayak yememiştim. Belki iltimas ediyorlardı. Yalnız bir defa Büyük Hoca, kuru, kemikten elleriyle yalan söylediğim(-diğ, sıfat fiil)için sol kulağımı çekmişti. O kadar hızlı çekmişti ki, ertesi gün bile yanıyordu. Kıpkırmızı idi. Halbuki kabahatim yoktu. Doğru söylemiştim. Bahçedeki abdest fıçısının musluğu koparılmıştı. Büyük Hoca bu kabahati yapanı(-an, sıfat fiil)arıyordu. Bu, mavi cepkenli, kırmızı kuşaklı, hasta, zayıf bir çocuktu. Haber verdim. Falakaya konacaktı. İnkâr etti. Sonra diğer bir çocuk çıktı. Kendi kopardığını(-dığ, sıfat fiil), onun kabahati olmadığını() söyledi. Yere yattı. Bağıra bağıra sopaları yedi. O vakit Büyük Hoca, "Niçin yalan söylüyor, bu zavallıya iftira ediyorsun?" diye kulağıma yapıştı. Yüzünü buruşturarak(-arak,zarf fiil )darıldı...

Ağladım. Ağladım. Çünkü yalan söylemiyordum. Evet, musluğu koparırken(-ken, zarf fiil)gözümle görmüştüm. Akşam azâdında dayağı yiyen(-en, sıfat fiil)çocuğu tuttum: — Niçin beni yalancı çıkardın? dedim. Musluğu sen koparmamıştın... — Ben koparmıştım. — Hayır, sen koparmamıştın. Öbür çocuğun kopardığını() ben gözümle gördüm. Israr edemedi. Yüzüme baktı. Bir an öyle durdu. Eğer hocaya söylemeyeceğime() yemin edersem, saklamayacaktı. Anlatacaktı. Ben hemen yemin ettim. Merak ediyordum: — Musluğu Ali koparmıştı, dedi, ben de biliyordum. Ama o çok zayıf, hem hastadır. Görüyorsun, falakaya dayanamaz. Belki ölür(-ür, sıfat fiil), daha yataktan yeni kalktı. — Ama sen niçin onun yerine dayak yedin? — Niçin olacak. Biz onunla and içmişiz. O bugün hasta, ben iyi, kuvvetliyim. Onu kurtardım işte. Pek güzel anlamadım. Tekrar sordum: — And ne? — Bilmiyor musun? — Bilmiyorum! O vakit güldü, benden uzaklaşarak(-arak,zarf fiil) cevap verdi: — Biz birbirimizin kanlarını içeriz. Buna "and içmek" derler. And içenler(-en, sıfat fiil)kan kardeşi olurlar. Birbirlerine ölünceye kadar yardım ederler, imdada koşarlar.

Sonra dikkat ettim, mektepte birçok çocuk, birbirleriyle and içmişlerdi. Kan kardeşi idiler. Hatta bazı kızlar bile kendi aralarında and içmişlerdi. Bir gün, bu yeni öğrendiğim() âdetin nasıl yapıldığını() da gördüm. Yine arka rahlelerde idim. Küçük Hoca abdest almak(-mak, isim fiil)için dışarı çıkmıştı. Büyük Hoca, arkasını bize çevirmiş(-miş, sıfat fiil), yavaş yavaş, bir sümüklüböcek kadar ağır, namazını kılıyordu. İki çocuk tahta saplı bir çakıyla kollarını çizdiler. Çıkan(-an, sıfat fiil)büyük, kırmızı damlayı kolları üzerinde bu çizgiye sürdüler. Kanlarını karıştırdılar. Sonra birbirlerinin kollarını emdiler. And içerek(-erek,zarf fiil )kan kardeşi olmak... Bu beni düşündürmeye(-me,isim fiil) başladı. Şayet benim de kan kardeşim olsa idi, hocaya kulağımı çektirmeyecek(-ecek, sıfat fiil), ihtimal falakaya yatacağım() zaman beni kurtaracaktı. Koca mektebin içinde kendimi yapayalnız, arkadaşsız, hâmisiz zannediyordum, anneme fikrimi, her çocuk gibi birisiyle and içmek(-mek,isim fiil )istediğimi(-diğ, sıfat fiil)söyledim. Andı tarif ettim. Razı olmadı. "Öyle münasebetsizlikler istemem. Sakın yapma(-ma, isim fiil)ha..." diye tembih etti.

Lâkin ben dinlemedim. Aklıma and içmeyi(-me, isim fiil)koymuştum. Fakat kiminle? Bir tesadüf, beklenilmeyen() bir kaza bana kan kardeşimi kazandırdı. Cuma günleri bizim evin bahçesine ,bütün komşu çocukları toplanırlardı. Akşama kadar beraber oynardık. Arkamızdaki evlerin sahibi Hacı Budak'ların benim kadar bir çocukları vardı ki, en çok adı hoşuma giderdi: Mıstık... Bu kelimeyi söylerken sanki mütelezziz olur(-ür, sıfat fiil), hep tekrarlardım. O kadar ahenkli, tanînli idi. Kızlar, bu güzel isme uydurulmuş kafiyeleri, Mıstık'ı bahçede, sokakta görünce(-ünce,zarf fiil )bir ağızdan söylerler; hâlâ hatırımda:

Mustafa Mıstık,

Arabaya kıstık,

Üç mum yaktık,

Seyrine baktık!

Diye bağrışırlar, ellerini yumruk yaparak(-arak, zarf fiil)ona karşı dururlardı. Mıstık hiç kızmazdı. Gülerdi. Biz de, bazen bu beyitleri bağırarak(-arak, zarf fiil)tekrarlar, eğlenirdik.

Bu iki minimini beyit, benim hayalime bile tesir etmişti. Rüyamda, birçok arsız kızın onu büyük bir muhâcir arabasına sıkıştırarak(-arak, zarf fiil),etrafına üç mum yakarak(-arak , zarf fiil)seyrine baktıklarını görürdüm. Niçin Mıstık öyle uslu dururdu. Niçin birden fırlayıp(-ıp, zarf fiil)bu kızlara birkaç tokat atmaz(-maz, sıfat fiil), sıkıştığı() katran kokulu arabadan kurtulmazdı? Hepimizden kuvvetli o idi. Sanki adı gibi her tarafı yuvarlaktı; başı, kolları, bacakları, vücudu... Hatta elleri... Bütün çocukları güreşte yenerdi... Yazın, her Cuma sabahı, büyük bir deste söğüt dalı getirirdi. Bu dallardan kendimize atlar yapar, cirit oynar(-ar, sıfat fiil), yarışa çıkardık. Yarışta da hepimizi geçerdi. Onu hiçbirimiz tutamazdık. İşte yine böyle bir Cuma günü, Mıstık söğüt dallarıyla geldi. Ben en uzununu kendime ayırdım. Öbürlerini çocuklara dağıttım. Bir çakı ile bu dalların ucunu keser(-er, sıfat fiil), kabuklarından iki kulak, bir burun çıkartır, tıpkı bir at başına benzetirdik. Bunu en güzel ben yapardım.

Kendi atımı yapıyordum. Mıstık'la diğer çocuklar sıralarını bekliyorlardı. Nasıl oldu, farkına varmadım, söğüdün kabuğu birden yarıldı. Arasından kayan(-an, sıfat fiil)çakı sol elimin şehâdet parmağını kesti. Sulu, kırmızı bir kan akmaya(-ma,isim fiil) başladı. O saatte aklıma bir şey geldi: And içmek(-mek, isim fiil)... Parmağımın acısını unuttum, Mıstık'a: — Haydi, dedim, hazır elim kesildi. Kan kardeşi olalım. Sen de kes... Tereddüt etti. Siyah gözlerini yere dikerek(-erek, zarf fiil), büyük, yuvarlak başını salladı: — Olur mu ya... And için kol kesmek(-mek, isim fiil)lazım... — Canım ne zararı var? diye ısrar ettim, kan değil mi? Hepsi bir. Ha koldan, ha parmaktan... Haydi, haydi!...

Razı oldu. Elimden aldığı çakıyla kolunu, hatta biraz derince kesti. Kanı o kadar koyuydu ki, akmıyor, bir damla halinde kabarıyor, büyüyordu. Parmağımın kanıyla karıştırdık. Evvela ben emdim. Bu, tuzlu, sıcak bir şeydi. Sonra o da benim parmağımı emdi.

Bilmiyorum aradan ne kadar zaman geçti. Belki altı ay... Belki bir yıl... Mıstık'la kan kardeşi olduğumuzu() adeta unutmuştum. Yine beraber oynuyor, mektepten eve beraber dönüyorduk. Bir gün hava pek sıcaktı. Büyük Hoca, bizi yarım azad etti.. Tıpkı Perşembe günü gibi... Mıstık'la sokağın tozları içinde yavaş yavaş yürüyorduk. Ben fesimin altına mendilimi koymuştum... Terimi silemediğim() için yüzüm sırılsıklam idi. Büyük, geniş bir yoldan geçiyorduk. Kenarda yıkılmış(-mış, sıfat fiil)bir duvarın temelleri vardı. Birdenbire karşıdan iri, kara bir köpek çıktı. Koşarak(-arak, zarf fiil)geliyordu. Arkasından birkaç adam kalın sopalarla kovalıyorlardı. Bize, "Kaçınız, kaçınız, ısıracak!.." diye bağırdılar. Korktuk, şaşırdık. Öyle kaldık. Evvela ben biraz kendimi toplayarak(-arak, zarf fiil), "Aman, kaçalım..." dedim. Gözleri ateş gibi parlayan(-an, sıfat fiil)köpek bize yetişmişti. O vakit Mıstık, "Sen arkama saklan!..." diye haykırdı, önüme geçti. Köpek onun üzerine hücum etti. İlkin hızla birbirlerine çarptılar. Sonra tıpkı güreşir(-ir,sıfat fiil) gibi boğaz boğaza geldiler. Köpek de ayağa kalkmıştı.

Biraz böyle savaştıktan sonra ikisi de yere yuvarlandılar. Mıstık'ın küçük fesi, mavi yemenisi düştü. Bu muharebe bana pek uzun geldi. Titriyordum. Sopalı amcalar yetiştiler. Köpeğe odunlarının bütün kuvvetiyle birkaç tane indirdiler. Mıstık kurtuldu. Zavallının kollarından, burnundan kan akıyordu. Köpek, kuyruğunu bacaklarının arasına sıkıştırmış(-mış, sıfat fiil), ağzı yerde, dörtnala kaçtı. Mıstık, "Bir şey yok... Acımıyor... Biraz çizildi..." diyordu. Evine götürdüler. Ben de hemen evimize koştum. Anneme başımıza geleni(-en, sıfat fiil)anlattım. Abil Ana beni yere yatırdı. Uzun uzadıya kasıklarıma, korku damarlarıma bastı. Öyle bir duâ okuyarak(-arak, zarf fiil)yüzüme üfledi ki, sarmısak kokusundan aksırdım.

Ertesi günü Mıstık mektebe gelmemişti. Daha ertesi günü yine gelmedi... Anneme, Hacı Budak'lara gidip(-ıp, zarf fiil)Mıstık'ı görmemizi(-me, isim fiil)söyledim. "Hastaymış yavrum" dedi, "inşallah iyi olunca(-unca,zarf fiil) yine oynarsınız, şimdi rahatsız etmek(-mek, isim fiil)ayıptır." Ondan sonra ben her sabah Mıstık'ı iyileşmiş(-miş, sıfat fiil)bulacağım() ümidiyle mektebe gittim.

Fakat heyhat... O hiç gelmedi... Köpek kuduzmuş. Baktırmak(-mak, isim fiil)için Mıstık'ı Bandırma'ya götürdüler. Oradan İstanbul'a göndereceklerdi.

Nihayet bir gün işittik ki, Mıstık ölmüş...

Erken kalktığım() açık, bulutsuz sabahlar, herkes gibi bana da çocukluğumu hatırlatır. Yâdımda ezeli ve mor bir fecr memleketi gibi kalan(-an, sıfat fiil)doğduğum() yeri gözümün önüne getirmek(-mek, isim fiil)isterim. Daima, farkında olmayarak(-arak, zarf fiil)sol elimin şehâdet parmağına bakarım. Birinci boğumun üstünde hâlâ beyaz çizgi şeklinde duran(-an, sıfat fiil)bir küçük yara izi, bence çok mukaddestir. Andı için ölen(-en, sıfat fiil), hayatını mahveden kahraman kan kardeşimin, sıcak dudaklarını tekrar parmağımın ucunda duyar(-ar, sıfat fiil), beni kurtarmak(-mak, isim fiil)için o kendisinden büyük, kudurmuş(-muş, sıfat fiil), iri ve kara çoban köpeğiyle pençeleşen(-en sıfat fiil)aslan ve bahadır hayalini görürüm.

Ve kavmiyetimizden, hadsî Türklük'ten uzaklaştıkça(-tıkça,zarf fiil), daha müteâffin derinliklerine yuvarlandığımız() karanlık uçurumun, bu ahlaksızlık ve bozukluk, vefasızlık ve hodgâmlık, âdîlik ve miskinlik cehenneminin dibinde meyus ve şartlanmış kıvranırken(), saf ve nurdan mazi, kaybolmuş(-muş, sıfat fiil)bir cennetin hakikatten uzak bir serabı halinde karşımda açılır... Beni mütesellî ve mesut eder. Saatlerce Mıstık'ın hatırasıyla, bu muazzez ve necip matemin eskiyip(-ıp,zarf fiil) unutuldukça(-dukça,zarf fiil daha ziyâde kıymeti artan tatlı ve mahzun acısıyla mütelezziz olurum...

# Antiseptik

Minimini, güzel, şeytan Bedia'yı ailesi büyük bir adama vermek istiyordu. Halbuki o iki senedir, tıbbiye talebesinden olan kuzeni Namık'la işi pişirmişti. Kendini almayı arzu eden bu büyük adam tek gözlüklü, şık bir büyükelçiydi. "Kırkında var, yok..." diyorlardı. Bedia daha on yedisine girmemişti. Annesinin, babasının, hanımninesinin ısrarlarına biraz karşı geldi. Ağladı, sızladı, amma sonunda mağlup oldu. — Ben koca herifi ne yapayım? Elli sene Avrupa'da balolarda sürtmüş! dedikçe, — Haltetmişsin! Otuz sekiz yaşında! Koca dediğin böyle olur. Fenerbahçe kulübünde top oynayan oğlanlara mı varacaksın? Cevabını alıyordu.

Nişan günü köşke bütün aile efradı çağrılacaktı. Fakat bir gün evvel kuzen geldi. Bedia ile yalnız kaldılar. Evvela dargın dargın bakıştılar. Sonra Namık, — Yazık sana Bedia! Dedi. Büyükbaban yerinde bir adama varıyorsun. — Amma mübalağa ha... — Mübalağa değil! Bir asır yaşında, boyalı bir ihtiyar işte! — Ne yapayım! Annemin, babamın büyüklük merakı var. Damatları büyükelçi olacak! Hem annem, kırk yaşında bile olmadığına yemin ediyor. — Allah belasını versin! Bir asır yaşında diyorum. Senin miden nasıl alıyor. — Ben o kadar ihtiyar görmüyorum. Abanoz gibi siyah düzgün bıyıklar! Tepesi çıplak ama bu da zekaya delalet eder. Namık güldü, — Anlaşıldı, dedi, sen abanoz bıyıklara vurulmuşsun! Bu bıyıklar abanoz olmayıp fildişi gibi beyaz olsa yine varır mıydın? — Varmazdım. Hatta beyaz bıyıklı değil, kır bıyıklı olsa bile varmazdım. Namık biraz düşündü. Büyükelçi karısı olmak, yabancı başkentlerden saygı, medeniyet görmek hulyasıyla şimdiden kabına sığmayan Bedia fıkırdayıp duruyordu. Namık dedi ki: — Bende tılsımlı bir su var; onunla nişanlının bıyıklarını yıkatabilirsen, bir asır yaşında olduğunu sana söyleyecek. O vakit de varacak mısın? — Gevezeliği bırak. Nasıl su o? — Bir antiseptik... — Nasıl yıkatayım? — Gayet kolay! Yarın daha nişan merasimi yapılmazdan evvel onunla yalnız kal. Bedia bir kahkaha attı: — Ey? — Herifi azdır. Seni öpmeye kalkışsın. — Sonra? — De ki: "Ben meraklıyım. Evvela dudaklarınızı şu antiseptikle yıkayınız. Sonra istediğiniz kadar müstakbel eşinizi öpünüz." — Aman, şu antiseptiği getir, dedi, ona ilk defa tam bir Fransız kadını gibi çok eksantrik gözükmek isterim! Nişan olacağı gün köşke bütün davetliler gelmişti. Namık, Bedia'ya zarif bir şişe verdi. "İşte antiseptik! Haydi gayret!" dedi. Bedia, bu cesaretlendirmeden şuh bir heyecan duydu. Eksantrik görünmek en birinci düşüncesiydi. Ne yaptı yaptı, sefirle salonun yanındaki küçük odada yalnız kaldı. Zavallı diplomatın elini tuttu. Saçlarını okşadı. Dizine süründü. Aşktan, maşktan bahsetti. Zavallıyı iyice azdırdı. Diplomat, gül yağına kondurmak için abanoz bıyıklarını uzatırken, — Rica ederim, dedi, uslu durunuz. — Ah... — Ben meraklıyım. Dudaklarınızı yıkayınız. İstediğiniz kadar öpünüz. Ben artık sizin değil miyim? — ......... Cevap beklemeden koştu. Dışarı çıktı. Namık'ın verdiği şişeyi getirdi. — Şurada, pencerenin önünde, dedi. İştahı kabarmış olan diplomat, bu şuh emre hemen itaat etti. Bedia'nın eline döktüğü su ile güle güle ağzını, bıyıklarını yıkadı. Sonra cebinden çıkardığı ipek mendille kuruladı. Bedia birdenbire, — A!... diye haykırdı. — Ne var ruhum? — Hiç! Öpmek için yaklaştı. Bedia, sinir darbesine uğramış gibi katılırcasına gülüyordu. Kahkahalarının çirkinliği içinde, minimini parmağıyla, — Buradan, buradan, diye parlak alnını gösterdi. Diplomat, bu pembe alnı koklayarak öptü. Bedia, azıcık sükûnet bulunca, — Siz benim pederimsiniz, dedi. — Ne demek sevgilim! Şu aynaya bakınız. Hayaliniz size cevap verecek.... Avrupa'da kadınların eksantrikliğine çok alışkın olan diplomat hiç şaşırmadı. Döndü aynaya baktı. Kendini tanıyamadı. Abanoz bıyıkları fildişi gibi bembeyaz olmuştu. Sarardı, morardı, sonra hâlâ pencerenin yanında gülen Bedia'ya feci bir nazarla baktı: — Hain! Dedi. Burnu kanıyormuş gibi mendilini ağzına tutarak salonun ortasından hızla geçti. Portmantodan fesini kaptı. Tek gözlüğünü düşürdü. Bastonunu alamadı. Kendini bahçeye attı. Deli gibi köşkten uzaklaştı.

Müstakbel damatlarının böyle, nişandan evvel, birdenbire kaçışına hiçbir mana veremeyen aile halkı pencerenin dibinde gülen Bedia'nın başına toplandılar.  
— Ne yaptın, ne oldu?  
Diyorlardı. Bedia,  
— Hiçbir şey yapmadım. Şu şişedeki su kaçırdı. Benim kabahatim yok...  
Cevabını verdi. Annesi hiddetinden titriyordu.  
— O su ne? Çılgın!  
Bu sefer Namık cevap verdi:  
— Yengeciğim, hiç beyazı olmayan güzel, kumral saçlarınıza siz de biraz sürünüz. Ne olduğunu anlarsınız, dedi...

# Aşk Dalgası

Vapur dopdoluydu. Son düdük öttü. İki yandaki çarklar, dar kafeslerinde birden uyanan alışkın ve müthiş deniz aygırları gibi, hiddetli bir gürültü çıkararak, kımıldandı. Bütün vapur hafifçe sarsıldı. Hava gayet güzeldi. Kadıköy'e gidiyorduk. Nihayet leylâk renkli sisler içinde eriyen Marmara'nın kubbeli, ince minareli uzun, uyumuş ufuklarında, büyük ve beyaz kenarlı bulutlar, parçalanmış köpük dalgaları halinde yavaş yavaş büyüyor, dağılıyor, toplanıyor, derin çukurlarında, yüksek tepelerinde morluklar, koyu mavilikler birikiyordu. Haziranın yakıcı güneşi vapurun, dumanlardan ve yağmurdan esmerleşmiş tentelerine düşüyor, bazı duran ve yine birden esmeye başlayan kararsız rüzgârı sanki ılıklaştırıyor, sanki ona sarhoşluk verici, tahrik edici, şuh ve fettan bir şey katıyordu.

Uzak ve bilinmez masal adalarından gelmişe benzeyen süt gibi beyaz martılar etrafımızda uçuşuyorlar; çıkardıkları tatlı, derin sesleriyle şehirde kalmış, kalabalıktan, uğraşmalardan, hırslardan, kederlerden bunalmış zavallı insanları kendi vatanlarına, hakikatten pek uzak, tenha, sakin yerlere, biraz aşk ve şiir tatmak için çağırıyorlardı. Lacivert dalgalar içinde bir masal, bir efsane köşkünü andıran Kızkulesi hayalime dokunuyor, ruhumu, hissimi beyaz ve aydınlık dualarıyla uyutarak dimağımdan bütün etrafımın, muhitimin akislerini siliyordu. Artık vapurda olduğumu unutuyordum. Ömrümde her gün birkaç şiir okuyan, düşünen bir adamın o tuhaf, marazî iptilâsıyla etrafımı bozuyor; Üsküdar ve Selimiye yakalarındaki evleri, kubbeleri, minareleri, selvileri, hatta koca Tıbbiye Mektebini ve koca kışlaları silerek hiç görmüyor; onların yerine, alanlarında gümüş, elmas şelâleler akan, serin gölgelerinde çıplak ve pembe çiftler öpüşen, balta girmemiş çam ve kayın ormanları yapıyordum.

Hakikatte olmayan, yalnız kendi hayalimde vücut verdiğim bu levhaya, bu yüce ve büyük manzaraya bakarak, "Ah, aşk yeri... Ah, işte aşk yeri..." diyordum. Martıların, "Geliniz, uzaklara, şu leylâk renkli sislerin öbür tarafına... Orada sizi beyaz çiçekler, ezelî, yeşil baharlar içinde bekleyen kızlar var, geliniz, haydi oraya..." diyen ve çok derinlerden acele acele inleyerek gelen seslerini işittikçe hayalim bütün bütün dumanlanıyor, âdeta başım dönüyor. Artık pek aşağılarda kalan Kızkulesi'nin üstünde şeffaf kanatlı binlerce perilerin uçuştuklarını ve gidilse elle tutulabileceklerini açıkça görüyordum. Ansızın omuzuma bir el dokundu. Döndüm.  
— Yahu, nedir bu hal, bu dalgınlık ne?  
— Hiç...  
— Beni tanımadın mı?  
— Şey...  
— Uyan yahu, ver elini bakayım.  
Sıcak ve kuvvetli bir elin, benim haberim olmadan kendi kendine uzanmış olan soğuk elimi sıktığını duydum, uyanmaya başladım. Fakat hâlâ mahmurluktan kurtulamıyordum.  
— Sen ha!..  
— Ben ya!..  
Bu en sevdiğim mektep arkadaşlarımdan biriydi. On iki senedir görüşmemiştik. On iki sene... Aman yarabbim! Dün gibi... Hayat, hakikaten en uzun vakalarıyla çabuk biten bir sinema şeridinden başka bir şey değil. Mektepte herkesi güldüren, herkesle alay eden, herkese ad takan, şen ve sevimli arkadaşım çok değişmişti. Kırmızı dudaklarının üstünde sert, kumral bıyıklar çıkmış, şakaklarındaki saçlar tek tük ağarmış, biraz şişmanlamıştı. Fakat gözleri... Ne olduğunu bilmediğimiz, hakikati mahut "birinci sebep" in insan zekâsına ebedî bir surette kapalı kalacak karanlıkları içinde sönen ruhumuzun sanki en çok bulunduğu bu küçük parlak uzuvlar... Onlar hiç de değişmemişti. On iki sene evvel içlerinde gülen mavi neşe hâlâ yaşıyordu. Bilmem niçin, uzaklaştıkça muhabbetimiz artan, maziden bir simaya rasgeliş beni mesut etti. Seviniyordum. Bütün kuvvetimle ellerimdeki sıcak eli sıkıyordum. Vapurun üst katında idik. Kanapelerde boş yer yoktu. Vapur, önünden geçen mavnalara sık sık düdük çalıyordu. Herkes sebepsiz bir sıkıntı içinde gibiydi. Ortada hiç kadın görünmüyordu.

İhtiyarlar uyukluyarak gazetelerini okuyorlar, yanındakilere kısaca bir şey söylüyorlar. Şişmanlar sigaralarını içerek çarkların gürültüsünü dikkatle dinliyorlar, son moda esvaplı şık gençler, tek gözlüklerini düşürmemek için dimdik duruyorlar ve dizlerinin buruşturmaması için yukarı çektikleri ütülü pantolonlarından renkli acurlu çoraplarını gösteriyorlardı. Ama hepsi ihtiyarlamış, yorulmuş, bunamış sanılıyordu. Tüysüz ve tıraşlı yüzlerini, karınları ağrıyor gibi ekşitiyorlar, rüzgârdan kaşlarını ve dudaklarını buruşturuyorlardı.

Biz, beyaz boyalı parmaklıklara dayanıyorduk. Arkadaşım:  
— Bir derdin mi var? dedi, buraya çıkınca seni gördüm. O kadar dalgındın ki, yanına sokulduğumu duymadın. Ne var kuzum?  
— Hiç, hiç... Dalga geçiyordum.  
— Ne dalgası?  
Gülerek cevap verdim:  
— Aşk dalgası...  
— Daha bekâr mısın?  
— Bekârım!..  
Arkadaşımın mavi gözlerindeki eski neşe birden soldu. Üçüncü derecede veremden yatağa düşmüş bir zavallıya teselli ve cesaret vermek zahmetine girilmeden nasıl mahzun, mütevekkil bakılırsa bir an bana öyle, acır gibi baktı. Sonra parmaklığa dayadığı elini çekti. Cebine soktu. Biraz döndü. Ciddileşen gözlerini gözlerime dikti:  
— Hâlâ bekârsın ve aşk dalgası geçiyorsun ha? dedi, öyle ise azizim, sakın darılma, sen bir serserisin... Mektepten çıktık çıkalı görüşmedik. Sormadan, istersen başından geçenleri sana söyleyeyim. Hâlâ aşk dalgası geçmene bakılırsa hayatı anlamamış, açık ve bariz hakikatin farkına varmamışsın. Mademki hakikate bu kadar yabancı kalmışsın, mesut değilsin ve ölünceye kadar mesut olamayacaksın.  
— Hangi hakikat? diye gülümsedim.  
— Hangi hakikat mi dedin? İçtimaî hakikat... Eğer sen bu hakikati sezebilseydin asla aşkla uğraşmayacaktın.  
Anlamıyor, hep gülümseyerek:  
— Ama niçin? gibi yüzüne bakıyordum.  
O devam etti:  
— Her yerde başlı başına bir muhit, bir içtimaî vicdan vardır ki, bütün fenlerin, mantıkların, ilimlerin, felsefelerin, hilâfına olarak, en mutlak ve zalim bir tarzda, hükmünü sürer. İşte bizim muhitimizde, Türklerin muhitinde de aşk şiddetle yasaktır. Bir cehennem makinesi, bir bomba, bir kutu dinamit kadar yasak... Bir Türk on dört yaşına girdi mi annesinden, ablasından, kız kardeşinden, nihayet teyzesinden ve halasından başka bir kadının yüzünü göremez. O halde kimi sevecek? Hiç. Bu muhitin, bu içtimaî vicdanın kuvvetini, dehşetini, sana nasıl anlatayım? Adını unuttum, bilmem hangi feylesof; Allah'ın insanlar üzerindeki tesirinden, insanlarla münasebetinden, ahlâkından bahsederken: "O, içtimaî muhitten başka bir şey değildir..." diyor. Ben bu sözü biraz doğru buluyorum. Eski mukaddes kitaplarla bugünkü yeni dünyayı çeviren Allah her yerde, her devirde dinsizleri, kendine karşı gelenleri başka sebepler, başka tarzlarla eziyor. Evvel zamanda Galile'yi yakan kuvvet, bugün Galile'nin o büyük, korkunç kabahatini ders diye okuyan milyonlarca mektep çocuklarına aldırmıyor. İspanya'da Ferer'in kafasını delen kurşunlar, Fransa'da patlayabilse ihtimal orada ihtiyar ve bunak kadınlardan ve papazlardan başka kimse kalmaz. İşte bu feylesof da Allah'ımızın, ezelî kanununu işletmek için, hep muhiti, hep muhitin içtimaî vicdanını kullandığını görerek o hükmü veriyor. Bu ezelî mukavemet olunmaz kanun her yere, her kıtaya, her memlekete değil, hatta her şehre, her köye göre değişiyor.

Buradaki fazilet, orada cinayet; oradaki yararlık, burda fenalık sayılıyor; mukaddes kitapların bütün tabiat, uzviyet, tekâmül kanunlarına inat olarak hiç değişmez kalması lâzım gelen emirlerine bile her yerde başka türlü boyun eğiliyor; esasları bir olan Hıristiyanlık, Avrupa'da başka, Amerika'da başka, Afrika'da başka... İslâmlık da böyle! Hindistan'da başka, Liverpool'da başka. Buhara'da başka, Türkiye'de de başka... Arabistan'a ve Acemistan'a git, oralarda bütün bütün başka... İşte Allah'ımızın Türkiye'deki ezelî, karşı gelinmez kanunu, yeni içtimaî vicdan, aşkı bütün kuvvetiyle bize yasak ediyor. Türkiye'de kimse sevişemiyor. Ve kimse şimdiden sonra sevişemeyecek... Çünkü sevmek için evvelâ görmek lâzım. Halbuki genç bir kızla bir yuva yapmak, ölünceye kadar bahtiyar yaşamak için konuşmak, anlaşmak, sevişmek değil; hatta bir kerecik olsun yüzünü görmek imkânsız... Bu şiddetli yasağa karşı duranlar, iş devresine girmiş anarşistlerin, nihilistlerin, yahut eski zamandaki dinsizlerin akibetine uğrarlar. İçtimaî, acıklı bir ölümle sönüp giderler. Lâkin kurnazları, yasak olan aşkın usta kaçakçıları, hırsızlıklarından tıpkı, ihtiyar ve cesur bir tütün kaçakçısı, Yunanlı bir yankesici gibi, bıkmazlar. Hep yürek çarpıntısı içinde yaşarlar. Gece tenha yollarda, karanlık bahçelerin şüpheli köşelerinde rüzgâr, soğuk, rutubet altında saatlerce beklerler, ve nihayet korku ile karışık iki mânâsız kelime, tadı asla duyulmayan, acele, çabuk bir öpme... Hepsi bu! Eski edebiyata Acemistan'dan, yeni edebiyata Fransa'dan gelen aşk masalları, şiirler, hikâyeler şifa bulmaz bir frengi gibi bu kaçakçıların bütün varlığına geçmiştir. Onlar daima, bir macera ararlar. Kadınların görülmesi pek açık, pek bariz bir tarzda, dehşetle yasak olan bir muhite zıt, ecnebî muhitlerin âdetlerini, mesela sevişmek hülyasını sokmak isterler. Kendilerini yabancı, uzak memleketlerde geçen hayalî romanların kahramanları yerine koyarlar.

Edebî mecmualardaki birçok şiirleri tabiî okuyorsun? Mevzu: Gece ve kadın... Halbuki Türkiye'de ikisi de yoktur. Türk muhitinde, gece alaturka saat birden sonra bütün perdeler iner, sokaklar tenhalaşır. Evli evine, köylü köyüne, evi olmayan sıçan deliğine girer.

Gazinolar, balolar, tiyatrolar ve ilâh... Yani Beyoğlu tarafı asla Türk değildir. Orada yabancılar kendi muhitlerini, kendi âdetlerini yaşarlar. Kadınlarıyla kol kola umumî bahçelerde, lokantalarda gezerler, konuşurlar, eğlenirler, gülüşürler. Aralarına malûm mânâsıyla bir sıçan deliği bulamayan Türkler de karışırlar. Masaların başında pineklerler. Yabancıların kadınlarına, yabancı güzelliklere, yabancı göğüslere hasretle bakarlar. Uzatmayalım, Türkler'in gecesi yoktur.

Sonra yine bu yeni şiirlerde boyuna göller anlatılır; hangi göller!.. İstanbul'da Terkos'tan başka göl hatırlamıyorum. Oraya da eminim, şairlerin hiçbirisi gitmemiştir. Hususiyle Terkos'un civarında gece barınacak yer yoktur. Yüzlerce mısralarla, arşın manzumelerle anlatılan sevişmeler, sevgililer de yalan... Şairin bir sevgilisi vardır. Lâkin nerede! Şair sevgilisiyle konuşuyor, öpüşüyor. Lâkin nerede! Ah, ancak hayalinde... Hakikatte sevişmek, genç bir kızla üç dört dakika konuşabilmek, bugünkü Türk muhitinde, balıkların sudan çıkarak havada uçuşmaları, bostanlardaki ince kavakların dallarında tünemeleri kadar imkânsızdır. İstanbul ve civarında değil bir genç Türk kızıyla, geceleyin kol kola gezmek, bülbülleri dinleyerek aşk kelimeleri söyleşmek... Hatta gündüz biraz taze görünen annemizle bir arabaya binmek ne kadar tehlikelidir, düşün... Seyir yerlerinde, ah bu zavallı, feci, gülünç yerlerde de aşk mümkün değildir. Kadınlarla erkekler asla birbirlerine yaklaşamazlar. Aralarında mutlaka birkaç yüz adım bulunur, birkaç yüz adımdan başka da birkaç düzine polis, muhitin içtimaî vicdanına mahut yedi başlı mutaassıp, cehalet devinin arzusunu yerine getirmek için sanki bu polislerin, mebusansız, âyansız semavî bir kral kadar selâhiyetleri vardır. Kız kardeşinize sokakta bir laf söylediğinizi görmesinler, rezalet hazırdır. Hemen karakola... Kim olduğunuzu, konuştuğunuzun kardeşiniz, yahut anneniz olduğunu ispat edinceye kadar birkaç kilometre dayak yemezseniz yine talihiniz varmış demek. Muhitimizin dininden, ananelerinden, âdetlerinden, ulemalarından, ihtiyarlarından, mültecilerinden, hükümetin zabıtasından ziyade bu aşk yasağını isteyen kimlerdir, biliyor musun? Kadınlar! Türk kadınları. Bunlar aşkın, güzelliğin en korkunç düşmanlarıdır! Dışarıda kendi kavminden hiçbir kadın yüzü görmeyen erkeklerine, evlerinde de bir bakacak yüz göstermezler. Dışardaki zabıtanın en dehşetlisi evdedir. Mesela hizmetçi alacaklar, değil mi? En çirkinini bulurlar. Çiçek bozuğu, büyük ağızlı, kalın dudaklı, çarpık dişli, eğri burunlu berbat bir şey... Her gün karşınızda gezen, yemeklerinizi getiren bu kızı daha ziyade çirkinleştirmek için hususî bir maharetleri, hususî bir dehaları vardır. Kuvvetli, fırlak kalçaları görünmesin diye gayet bol esvap giydirirler. "Etrafa dökülüyor" bahanesiyle saçlarını sımsıkı bir yemeni ile bağlatırlar. Zavallıyı halis bir orangutana çevirirler. "Beyin hiç yüzüne bakmayacaksın, yanında laf etmeyeceksin, bir şey sorarsa cevap vermeyeceksin, kolların açık, çorapsız yanına girmeyeceksin..!", tembihlerini vermekte gecikmezler. Bir hizmetçinin aleyhinde bulunurken, "Çalışkan, temiz, atik kız ama, ağzı burnu yerinde" derler. Ağzı burnu yerinde olmak onlar için en affolunmaz bir cinayettir. Genç kızlarla görüşmek ve sevişmek asla mümkün olmadığından "evlenmek" meselesi de onların elinde bir madendir, istedikleri gibi işletirler. En birinci emelleri oğullarına yahut kardeşlerine çirkin bir kız almaktır. Tanımadıkları eve "görücü" giderler. Erkeklerin birçoğu daha hâlâ bilmezler ki bu görücü hanımlar güzelden ziyade bir çirkin ararlar... Mutlaka da bulurlar. Güzel bir kız alırlarsa kardeşlerinin yahut oğullarının onu seveceğini, onun lafını dinleyeceğini, sonra kendi pabuçlarının dama atılacağını düşünmek onları çıldırtır. Güzellikten dehşetle ürkerler. Bunun için İstanbul'da koca bulamayan, evde kalan kızların yüzde doksanı en güzeller, en cazibeliler, en sevimlilerdir.

Bu zavallı güzel Türk kızlarını görücü hanımlar beğenmez. "A, kardeş çok güzel ama, şeytan gibi çok bilmiş... Biz oğlumuza ecinni değil kız almak isteriz." derler. Kimine alafranga, kimine sıska, kimine şirret gibi kusurlar bulurlar. Gayeleri tombul, beyazca, sessiz, mıymıntı, budala, cahil, ıslanmış tavuğa benzeyen kızlardır. Böyle bir kıza rasgeldiler mi, "Ah işte bir melek!" diye haykırırlar; başlarlar oğullarına, kardeşlerine mübalâğalandırarak anlatmaya. Zavallı erkek talihin kendine bir peri gönderdiğine inanır, zifaf gecesi kalın duvağı kaldırınca karşısında "Adınız ne efendim?" sualine cevap veremeyen şaşkın, temiz, beyaz, biçimsiz bir et yığınından başka bir şey göremez. Erkeklerini hiçbir fırsat kaçırmayarak güzel görmekten, aşktan, sevişmekten mahrum bırakan bu kadınlar, aynı zulmü kendi cinslerine de yaparlar. Tanıdıkları bir kadının başından kazara bir macera geçer, mesela bir "nâme" si yakalanır, yahut da kocasından boşanıp diğer birine varırsa hepsi birden ona darılırlar, dehşetle afaroz ederler. Aradan uzun seneler geçer, o kadını sokakta gördüler mi yollarını değiştirirler, bazıları yüzüne tükürmeye kalkar, en insaflıları biraz acır, "Ah zavallı kötü oldu, alnının yazısı imiş" der.

Muhitimizde "Bir kadının en birinci vazifesi güzel olmaktır" sözünün nasıl tehlikeli bir yalan olduğunu pek iyi bilen anneler, kızlarını ellerinden geldiği kadar güzellikten, şuhluktan, süsten, serbestlikten menederler. Bu annelerin sokağa çıkarken kızlarının kulaklarına fısıldadıkları nasihatin değişmez modeli şudur: "Kızım! Peçeni indir. Ellerini çarşafın içine sok, başını yukarı kaldırma, aşifte diyecekler... Önüne bak, Frenk karıları gibi zıp zıp yürüme. Yavaş yavaş. Göğsünü ileri çıkarma, arkamıza takılacaklar. Sana azgın diyecekler. Adın çıkacak. Evde kalacaksın, vs. vs..!" Sonra tanışan, görüşen her aile sanki birbirlerinin tabiî müfettişleridir. Sakın bir aile içinde küçük bir aşk macerası geçmesin. Rezalet; dedikodu birden göklere çıkar, kahramanlarını tefe korlar. Oğullarının, kızlarının gizlice görüşmelerine, mektuplaşmalarına aldırmayan, göz yuman annelere bütün tanıdıkları, yine birden darılır: "Ah, ayol kadın bu yaştan sonra boynuz dikiyor..." diye ondan iğrenirler.

Bazı yeni romanlarda gösterilen Türkiye'deki mahut kibar âlemine gelince... Bu âlem, bütün bütün hülya mahsulüdür. Türkler'in arasında eskiden de, şimdi de imtiyazlı bir sınıf yoktur. Vâkıâ büyük memurların, eski devirden kalma paşaların, bir parça zengin olanların aileleri, sunî bir kibar âlemi yapmaya çalışırlar, esaslarını kaybederek sözde garplılaşırlar, Frenkleşirler. Fakat netice? Bütün muhit onlara düşman olur. Bir mahallede böyle, kadınları, nikâh düşen akrabalarına görünen bir aile oldu mu evvela, "Kötüler!..." lakabı takılır, sonra boykotaj başlar. Böyle bir vakada ailelerin etraflarında yükselen nefret, tecavüz sesleriyle bütün saadetleri söner. Yerlerini, yurtlarını terk etmeye, kırlara, uzak ve tenha köşklere, ücra yalılara çekilmeye mecbur kalırlar. Evet, yeni şiirlerdeki göller, geceler, aşklar gibi yeni romanlardaki o nikâh düşen akrabalarına, erkeklerinin arkadaşlarına çıkan kadınların vücudu yalandır. Uydurmadır. Bu romanlar Garp romanlarının gölgelerinden, tekrarlarından, tercümelerinden başka bir şey değildir.

İstanbul'da kadınları, yabancı, nikâh düşen erkeklere gözükür bir Türk ailesi bana gösterilsin, beş senelik kazancımı vermeye hazırım. Bu romanlarda anlatılan Avrupalılaşmış aileler, meşhur sanatkârlarımızdan Kel Hasan'ın ve Abdi'nin hususî, muharriri bilinmez piyesleri kadar hakikî Türklüğe mugayirdir. O tiyatrolarda uşağın hanımların yanına zırt pırt çıkması, "Oh, kaymak!" diye süt ninelerin göğüslerini sıkması hakikatte Türk aileleri arasında nasıl imkansızsa, bu rezaletler nasıl son derece uydurma şeylerse yeni romanlardaki yabancı erkeklerin ellerini sıkan, kocalarının yanında açık saçık, örtüsüz, çarşafsız, hatta bazen dekolte, yabancı erkeklerle konuşan kadınlar da öyle kaba, münasebetsiz, hakikate taban tabana zıt, soğuk, sahte hayallerdir.

Uzatmayalım, şimdi bana cevap ver. Böyle diniyle, ananeleriyle, âdetleriyle, kanunlarıyla, hükümetleriyle, zabıtasıyla, aile teşkilâtıyla, hatta kadınlarıyla aşkı yasak eden, nikâh düşen erkekle kadını asla birbirine göstermeyen bir muhitte aşk aramak, sevişmek inadı serserilik değil de nedir? Böyle bir muhitin içtimaî vicdanına karşı gelmek, en kuvvetli ve muazzam hükümetlere karşı anarşistlik etmekten daha delilik, daha çılgınlık değil midir? Çok akıllı sandığım senin de hâlâ bu imkânsız hülya ile uğraştığını gördüğüm için çok canım sıkıldı. Ah, zavallı dostum, sen şimdiye kadar piyangoyu çekmeli, kısmetine düşen et yığıntısına, et tarlasına razı olmalı, orduya askercikler yetiştirmeliydin. Ancak böyle mesut olabilirdin. Halbuki sen hâla aşk dalgası geçiyor, sonu bulunmaz bir yeis çölüne, içi lav dolu bir cehennem uçurumuna, arkasında ateş fışkıran yanardağlar saklı uzak, aldatıcı, sunî bir seraba koşuyorsun. Bilsen sana ne kadar acıdım.

Vapur Kadıköy'e gelmişti. Arkadaşımı dinlerken ökçelerimin üzerinde kalmış, hafifçe parmaklığa oturmuştum. Doğruldum. Sağ ayağım fena halde uyuşmuştu. Yere basamıyordum. — Biraz dur kuzum, dedim. Ayağım uyuşmuş. En sonra çıkarız. Gülüyor: — Ayağın değil, galiba beynin uyuştu, diyordu. Vapur iskele tarafına eğilmişti. Üstten, alttan adamlar çıkıyordu. Güneş kalın bulutlar altında kaybolmuş, hava esmer bir demir rengi bağlamış, ağlamaya hazırlanan, içi yaş dolu dargın, soluk bir göz gibi mahzunlaşmıştı. Çıkanlara bakıyordum. Yarım saat evvelki tatlı dalgamı korkunç bir fırtınaya çeviren arkadaşımın söylediklerini fertlerini ikiye ayıran, aşktan, sevişmekten mahrum bırakan, annelerini, karılarını, hapsederek asırlarca daldığı rüyasız ve granit uykusundan asla uyanmayan bir kavmin, bir cemiyetin sonu ne olabileceğini düşünüyor; dar tahtalar üzerinde korkak bir dikkatle hızlı hızlı geçenlerin sessiz sedasız çıkışlarını, ürkek bir hayvan sürüsünün acele kaçışına benzetiyordum. Bunların içinde hiç dişi yoktu. Çoluk çocuk, ihtiyar, genç, zengin, fakir, hepsi erkekti. Elimle dizimi oğuşturarak: — Vapurda hiç kadın yokmuş, dedim. Arkadaşım yine güldü ve cevap verdi: — Sabırlı ol... Onların erkeklerle karışmaları yasaktır. En son çıkarlar... Vapur tamamıyla boşalmıştı. Biz hâlâ davlumbazın üstünde, beyaz parmaklıkta idik. Bacağımın uyuşması geçmemişti. Arkadaşımın yanında topallayarak iskeleye doğru yürümeye başladım.

Artık şimdi kadınlar da, her tarafları örtülü, koyu siyah çarşaflarının altında sanki şangırtıları işitilmemek için pamuklara sarılmış gayet ağır, gizli esirlik ve zulüm zincirleri taşıyan lanetlenmiş, hayattan kovulmuş, hasta, dilsiz heyulalar gibi sendeleyerek, titreyerek yavaş yavaş çıkıyorlar, başlarını önlerine eğerek düşmemek, bir şeye dokunmamak, birbirlerine çarpmamak, yanlış bir adım atmamak için kalın, kara peçelerinin altından bastıkları yeri görmeye çalışıyorlardı.

# Aşk ve Ayak Parmakları

Âsıme Hanımefendi'den Hasan'a mektup

Evvela beni sen sevdin, yalvardın, yakardın, benim aşkım âdeta senin galeyanına sönük bir cevaptı. Sonunda beni aldın. Ben zengindim. Atım, arabam vardı. Bütün bugünün gençleri beni istiyorlardı. Herkesin isteğine sen nail oldun. Mesuttun. Ben sana sadıktım. Sonra nasıl oldu, birdenbire döndün. Benden soğudun. Beni görmekten kaçtın, yine sonunda beni boşadın... Bu mektubumu alınca sanma ki, sana yalvarıyorum. Fakat merak ediyorum! Niçin beni istemeyesin? Benim neyim var? Yahut neyim eksik? Daha bu sene Kadıköy kadınları arasındaki güzellik müsabakasında birinci geldim. Tahsilim birinci derecede... Zenginim de. O hâlde niçin beni istemeyesin? Benden güzelini bulsan bile, eminim ki benden zenginini bulamayacaksın. O hâlde niçin, niçin beni istemeyesin?

Hasan'dan Âsıme Hanımefendi'ye mektup

Evet güzel kadın, ben sevmiştim. Fakat sevmek nedir? Bunu biliyor musun?.. Sevmek herkes için başka bir şeydir. Tabiî mizaçların, tecessüslerin başka başka olması gibi... Kimi kaşa göze, kimi cilde, kimi ellere ayaklara, kimi şişmanlığa, kimi boya, kimi kalçaya bakar. Hâlbuki ben... Profile bakarım. Daha okuldan beri âdetimdir, birisiyle konuşurken onda ne profili olduğunu ararım. Mesela küçük profilli bir adamla konuşurken onun laflarını havlamaya benzetirim. Dünyada ne kadar adam varsa, hepsinde bir hayvan profili vardır. Köprü'den geçerken, önü kalabalık bir gazinoda otururken, herkesin yüzüne dikkat ederim. Daha bir profilsize rast gelmedim. Hep insan kıyafetine girmiş, insan maskesi takmış hayvanlar... Bir sürü köpek, öküz, keçi, leylek, at, eşek, baykuş, kartal, tavuk, papağan, arı, güvercin, karga, balık, ayı, kaz, kaplan, ilâh... Küçükken saf, masum bir merak ile okuduğum fizyonomi nazariyeleri, benim hayalime o kadar tesir etmiştir ki, kendimi Lafontein'in masallarını gösteren canlı bir albüm içinde sanırım. Mesela karşıdan bir dostum geliyor, bir kere bakarım, yüksek kırmızı fesi, alacalı kostümü, parlak boyunbağı... Burnunun ucu sivri... Kolları kalkık ve kabarık... İddiacı, cesur... Yandan bakınca ne olduğunu görür, içimden: — Ah, işte bir horoz.., derim. Gelir elimi tutar, kırmızı yüzüne, tıpkı bir gülibiğe benzeyen fesine bakarım. Sesi keskin ve notaları uzundur. Sanki bu mütemadiyen öter. Ondan ayrılır, diğerine rasgelirim. Çenesi, ağzı yayıktır. Bacakları paytaktır. Yavaş yavaş söyler ve yanaklarını gererek güler. — Ördek, ördek.., derim. O vakvakladıkça, ben keşfimden memnun, müsterih onun kanatlarını, kuyruğunu arar, hatta onları da üstünde bulurum. Meşhur adamların, büyük muharrirlerin, nazırların, mebusların, büyük memurların profilleri ezberimdedir. Profillerini bildiğim için, yeni nazırların iktidarda ne yapacaklarını ayniyle herkese söylerim. Hatta arkadaşlarım bana, — Sen eskiden geleydin, Peygamber olurdun, derler. Zannederler ki, benim kerametim var. Hayır, ben yalnız profilleri tanırım... Eşek profilli bir adam mutlaka eşekçe, arslan profilli bir adam mutlaka arslanca hareket eder. Bir adamda, hangi hayvanın profili varsa, mutlaka o hayvanın ahlakı da vardır. Öküz profilli bir adamda asla kurnazlık, hile, zeka olamaz. Eşek profilli olan inatçı, yani kibar mânâsıyla sebatkârdır. Arı profilli sokar, köpek profilli gürültü eder, dişlerini gösterir. Kaplan profilli sezer ve merhamet bilmez, papağan profilli durmaz taklit çıkarır, güvercin profilli durmaz aşk ve şefkat komedyası oynar. Tilki profilli herkesi aldatır. Domuz profilli yer, içer keyfine bakar.

Kadınların da hepsi erkekler gibi birer hayvandır. Onlarda da mutlaka bir hayvanın profili vardır. Şişman, kocaman memeli, dalgın ve ağır kadın, tamamıyla bir inektir. Zayıf, huysuz, esmer, çirkin fakat yalnız gözleri güzel bir kadın keçidir. En güzelleri çalıkuşu, kanarya, nemse tavuğu profilinde olanlardır. Bu üç profilin hiçbirisi sende yoktur.

Geçen yazdı. İlk defa Fener'de birbirimize rast gelmiştik. Ben hemen senin profilini aradım, fakat bulamadımdı. — Ah, acaba ne? diyor, yüzüne bakıp bakıp bulamayınca seni sevmeye başlıyordum. Mademki sende bir hayvan profili yoktu. O halde insanların, kadınların... Sende hiçbir profil olmadığı için, hiçbir hayvan ahlakı, hiçbir hayvan tabiatı da yoktu. Bazı yine şüpheye düşüyor, — Aldanıyorum, onda da bir profil var, ama ben göremiyorum, ben farkına varamıyorum, diyordum. İzdivacımızdan evvel, muhabbet günlerinde, senin yüzüne uzun uzun dalışlarımı, ihtimal aşk buhranları sanıyordun. Hayır. Ben hep senin profilini arıyor; seni hiçbir şeye benzetemiyordum. Profilini bulamayınca seni severdim. Galiba sen de beni... Altı ay ne kadar hoş bir hayat geçirdik. Tabiî hatırlarsın. Fakat bir sabah... Ah keşke senden önce kalkmasaydım... Erken kalkmış, pencerenin yanına oturmuştum. Sen hâlâ yatıyordun. — Bu ne tembellik, dedim. Doğruldun, giyindin, karyolanın içine oturdun. Hava biraz serindi. Yanan soba daha odayı ısıtmamıştı. Birden yüreğim çarpmaya başladı. Boğuluyor gibi oluyordum. Sen terliklerinin üzerine düşmüş olan mor çoraplarından birisini sağ ayağının parmaklarıyla tuttun. Yukarı kaldırdın, yatağın içinde, oturarak giydin. Çorabın öbür eşini yerden almak için, sol ayağını uzatıyordun. Görmemek için yüzümü çevirdim. Evet, güzel kadın, sen ayağının parmaklarını tıpkı bir el gibi kullanıyordun. — Yirminci asrın orta yerinde, diyordum. Hilkatten yahut tekâmülden şu kadar yüz bin sene sonra... ....Titriyordum. Hastalandım. Sen, beni yere seren darbenin ne olduğunu anlayamıyordun. Yattığımız zaman buruşan gömleğini ayağının parmaklarıyla tutup çekiyordun. Ben bunu duyunca dişlerimi sıkıyor, tekrar titremeye başlıyordum. Yine anlamıyor: — Galiba hava soğuk, üşüyorsun işte, diyordun. Yine bir sabah sobanın önündeki koltuğa oturmuştun. Ayaklarında çorap yoktu. Yine kalbim atmaya başladı. Ayağının parmakları ile sobanın henüz ısınmayan kapağını açıyor, kımıldamayarak bakıyor, tekrar kapıyordun. Sonra yine bir gün sevgili kedin ayaklarından oynuyordu. Daha çoraplarını giymemiştin. Yüreğim hopladı. Fakat dişimi sıktım. Baktım, senin ayaklarının parmakları uzundu. Hem biraz fazla uzundu. Bu uzun parmaklarınla kediyi kollarından tutuyor, küçük bir çocuk gibi havaya kaldırıyordun. Âdeta ayaklarını ellerin gibi, hatta ellerinden daha iyi kullanıyordun.

Gözlerimi yüzüne kaldırdım. O an, o kadar arayıp da bulamadığım profilini gördüm. Sen maymundun. Alnın dar, ağzın biraz ileriye çıkıktı. Güzel, parlak cildin bu maymun iskeletini tamamıyla örtemiyordu. Hele ayakların... Aman Yarabbi... Tıpkı bir maymunun üçüncü, dördüncü elleri idi. Sen biraz daha gayret etsen, yerden çoraplarını almak, sobanın kapağını açmak, yorganı, gömleğini düzeltmek, kediyi tutup havaya kaldırmak değil, hatta ayaklarının bu uzun tekâmül etmiş parmaklarıyla yemek yiyebilecek, hatta piyano çalabilecektin. O vakit senden ürktüm. Bir daha seninle bir yatağa girmedim. Kendimi balta girmemiş bir ormanda zannediyor, kendimi o kablettarih mahlûklarından bir nesne ile evlenmişim sanıyordum.

Yirminci asırda, vücudunda kablettarihî adaleleri olan, tıpkı bugünün maymunları gibi ayaklarını el diye kullanan, tekâmül etmemiş bir mahlûktan, yani senden kaçtım. Uzaklaştım.

El gibi kullandığın bu ayaklarından bir tanesini şimdi kalbinin üzerine koy, öyle hükmet. Artık seni sevmemekte haklı değil miyim?

Âsıme Hanımefendi'den Hasan'a telgraf  
-Gayet Müstacel-  
Mektubunu okumadan yırttım, senden nefret ederim. Sakın bir daha mektup göndermeye kalkma. Sonra fena olursun...

# Bahar ve Kelebekler

Küçük salonun fes renginde kalın ve ağır perdeli penceresinden dışarısı muhteşem, parlak bir suluboya levhası gibi görünüyordu. Saf mavi bir sema. Çiçekli ağaçlar... Cıvıldayan kuşlar... Uyur gibi sessiz duran deniz... Karşı sahilde mor, fark olunmaz sisler altındaki dağlar, korular, beyaz yalılar... Ve bütün bunların üzerinde bir esâtir rüyasının havâi hakikati gibi uçan martı sürüleri! Pencerenin önündeki şişman koltuğa gayet zayıf, gayet sarı, gayet ihtiyar bir kadın oturmuştu. Bahar ve hayata dargınmış gibi arkasını dışarıya çevirmişti. Sönmüş gözleri köşelerdeki gölgelere karışıyordu. Karşısında, bir şezlonga uzanmış esmer, güzel bir kız, siyah maroken kaplı bir kitap okuyor; pencereden, çiçek, kır kokuları; deniz, dalga fısıltıları getiren tatlı bir nisan rüzgârı giriyordu. Bir saatten beri ikisi de susuyor, öyle duruyorlardı. Bu ihtiyar büyük nine tam doksan yedi yaşında idi. Köşelerin hafif karanlıklarından bazen uyanır gibi ayrılan gözlerini ara sıra, karşısında kitap okuyan genç kıza, bu torununun torununa atfediyordu... Birden, üç dişi kalan buruşuk ağzını açtı. Esnedi. Bir mumya uzvu kadar sararmış, katılaşmış elini başına götürdü. Kahve rengindeki yemenisinin altında daha beyaz görünen saçlarına dokundu. Bir an düşündü. Yine esnedi. Galiba uyanacaktı. Arkasındaki açık pencereden giren muharrik rüzgâr onu tehyic ediyor, kuşların güneşli cıvıltıları, çiçek ve çimen kokuları hayalinde uzak, ezeli bir fecir, nihayetsiz, mülevven bir sabah uyandırıyordu. Yavaş yavaş kamburunu arkasına dayadı. Ellerini dizlerine koydu, başını kaldırdı. Biraz doğruldu. Torununun torununa: — Yavrum, niçin susuyorsun? dedi. Biraz konuşalım. Genç, esmer kız, yeni neslin son Türk kadınlarının o asla tatmin edilemeyecek olan ebedi hicran elemiyle bulutlanan siyah gözlerini kitabından ayırmayarak: — Okuyorum büyükanneciğim. Dedi. Ancak on sekiz yaşında vardı. Şezlongdaki mühmel uzanışı ona müstesna bir letafet veriyor, ince jüponun altında bediî bir vuzuh ile irtisam eden kalçaları daha dolgun, daha geniş, dizleri daha narin, daha mütenasip, eteklerinin pembe ve beyaz gölgeleri içinde pek şuh, pek uyanık duran bacakları daha tombul, daha nefis, ayakları daha küçük görünüyordu. Tuttuğu siyah maroken cildin üzerinde beyaz bir tenevvür le parlayan parlak, zarif ve ince elleri asi bir istical ile göğsünden fırlamak ister gibi kabaran memelerine dayanıyor, sanki onları zaptediyordu. Gür, siyah saçları mağmum ve hüzünlü çehresi etrafında mesut edici, düşündürücü bir zevk veriyor gibiydi. Büyük nine sordu: — Okuduğun ne, kızım? — Bir roman. — Neden bahsediyor? — Hiç. Büyük nine tekrar daldı. Karşısındaki, senelerce evvel ihtiyarlayıp ölen torununun bu güzel, bu taze torununa bakıyordu. Bu vücut işte hayatın baharı idi. Arkasındaki, görmek istemediği şu pencerenin dışarısındaki gürültülü, kokulu bahara niçin bu kadar yabancı duruyordu. Kendisini tehyiç eden, mukavemet olunmaz bir gençlik arzusu veren, on yedi yaşında bir âşığın busesi kadar leziz ve muharrik olan bu nisan rüzgârı, niçin onun meçhul matemlerini örtmüyor, onun dudaklarında biraz tebessüm, gözlerinde biraz şule uyandırmıyordu. Tekrar sordu: — Söyle yavrum. O roman ne diyor? Genç kız büyük gözlerini kaldırdı. Kitabı dizlerine indirdi. Nazik bir şive ile: — Büyükanneciğim, Fransızca bir roman işte... Dedi. Lakin büyük nine merak ediyordu, mutlaka anlamak istiyordu: — İsmi ne? — Désenchanter... — Ne demek? — "Sevinçten ve saadetten mahrum kadınlar" demek. — Onlar kimmiş? — Biz... Türk kadınları... Büyük nine düşündü. Sol eliyle siyah, parlak saçlarını düzelten torununun torununa şimdi pek elemli bakıyordu; bu kız tıpkı büyük matemler geçirmiş, felaketler görmüş bir zavallı gibiydi. Hiç gülmüyor, hep mahzun duruyordu. Ah, işte hep bu kitaplar onları zehirliyor, onları solduruyordu. Onları bahara, saadete yabancı bırakıyordu. Ansızın kalbinde bir acı duydu. Bu genç, bu güzel kıza acıyordu. Titreyen kadît ellerini koltuğunun yanlarına dayadı. Hiddetlenmiş gibi biraz yükseldi: — Sevinçten, saadetten mahrum kadınlar, Türk kadınları mı? dedi. Hayır hayır! Türk kadınları asla sevinçten, saadetten mahrum değildiler. Sevinçten ve saadetten mahrum olanlar sizsiniz. Şimdiki kadınlar... Siz bozuldunuz. Siz büyükannelerinize benzemediniz. Ah biz!... Gençken ne kadar mesuttuk. Bahar, şu arkamdaki bahar bizi sevinçten deli ederdi. Şimdi siz bunları görmüyorsunuz, siz bu zehirleyici kitaplar üzerine düşüyor, kararıyor, soluyor, soluyor, hırçın, berbat, tahammül olunmaz bir mahluk oluyorsunuz. Genç kız gülümsedi. Büyük ninesinin böyle hiddetli serzenişlerini her vakit dinler, bazen onunla münakaşa ederdi. — Hiç siz okumaz mıydınız, büyük nineciğim? diye sordu. — Okurduk. Kibar ve zengin efendiler kızlarına Farisî öğretir, Cami dersleri gösterirlerdi. "Tuhfe-i Vehbî" 'yi okuturlardı. Fuzûlî'nin, Bâkî'nin gazellerini ezberlerdik. Mesnevî'yi anlardık. Mükemmel seci'ler, kafiyeler yapar, kocalarımızla müşâare eder, hafızamıza, zekamıza, nüktelerimize onları hayran ederdik. O vakit bir kadın için en büyük medih: "Fâzıla, edîbe, şaire, âkıle...." idi. Şimdi siz Frenk mürebbiyeler elinde büyüyor, kendi lisanınızın güzelliklerini tanımıyor, başka memleketlerin, başka şeylerini öğreniyorsunuz. Onlara benzemek istedikçe, kendi benliğinizden uzaklaşıyor, etrafınızdan nefret ediyor, hakikaten sevinçten ve saadetten mahrum kalıyorsunuz. Ah... At elinden o kitabı! Esmer, güzel kız yine gülümsedi: — Peki, büyük nineciğim, dedi, bu kitabı atayım. Okumayayım. Sonra bize müebbet ve yıkılmaz bir hapishane olan bu sıkıcı evin içinde, bu mevkufiyet in yalnızlığı içinde çıldırayım mı? Okuyor, eğleniyor, biraz teselli buluyorum. &mdas; Hayır kızım, okuyor, fakat eğlenemiyorsun. Gözlerini görsen... Bir bulut, bir sis içinde gibi! Bütün bütün fenalaşıyorsun. Bu kitaplar hep zehir, hep keder... — Peki söyleyiniz, okumayayım da ne yapayım?" Büyük nine düşünmeye başladı; evet, ne yapsın? Şimdi hakikaten her taraf hapishaneye dönmüştü. Seksen sene evvelki hayatı birden hatırladı; o vakit erkeklerden ayrı bir kadınlar âlemi vardı ki, şimdi tamamıyla dağılmıştı. Bu âlem pek genişti. Binlerce kadın birbiriyle konuşur, görüşür, eğlenirlerdi. Kendilerine mahsus eğlenceleri, zevkleri vardı. Moda yoktu. Annelerinin esvaplarını kızlar giyer, büyük ninelerinin mücevherlerini torunlar takardı. Sırmalı çedik pabuçlar, kırmızı ferâceler... ah hele kırmızı ferâceler... Baharın yeşil çimenleri üzerinde, seyir yerlerinde kadınlar tıpkı bir gelincik çiçeği gibi parlarlardı. Hiç aralarında çirkin, yani zayıf, hastalıklı yoktu. Erkekler yalnız kadınlarını tanırlar, işlerinden sonra erkence evlerine gelirler. Zevcelerine doyulmaz aşk ve muhabbet sahneleri ibda ederlerdi. Kıraathaneler, gazinolar, birahaneler, kulüpler, tiyatrolar, kafeşantanlar, bekarhaneler, bütün bu Türk erkeklerini eşlerinden ayıran, zavallı Türk kadınlarını tenha evlerde unutulmuş bir bekçi gibi bırakan felaket mahalleri yoktu. Kadınlar erkekleriyle üzülmeden yaşıyor, sonra o vakitki aşı boyalı büyük evlerin büyük sofalarında, havuzlu, kameriyeli bahçelerinde, bostanlarda, deniz kenarlarında, cesim, nadir yalılarda toplanıyor, eğleniyor, mesut oluyorlardı. Ne oyunlar, ne âdetler, ne zevkler vardı ki, bugün hepsi tamamıyla unutulmuştu.

Bugün Frenkçe okumak, mütemadiyen esvap değiştirmek, moda yapmak çılgınlıklarından, soğukluklarından, boş bir tekebbür den, mânâsız ve münasebetsiz bir tefevvuk iddiasından başka bir şey yoktu. Alafrangalık bir veba gibi içimize girmiş, yanaklarımızın allığını, dudaklarımızın tebessümünü silmiş, ferâcelerimizi parçalamış, pabuçlarımızı atmış, parmaklarımızı narin bir mercan gibi parlatarak güzelleştiren kınalarımızı bile ortadan kaldırmıştı. Eşyamızı, esvaplarımızı değiştirirken ruhlarımızı da değiştirmişti; her şey yalan, her şey sahte, her şey taklit oldu. Ananelerimiz öldü. Saadet uzak bir hayale, yetişilmez bir hulyaya inkılâp etti. Âdetlerimizle beraber sevinçlerimiz de söndü. Şimdi şaşkın ve mustarip bir nesil!... Her şeyden nefret eden, her şeyi fena gören, karanlık gören, berbat, hasta, tedavisi imkan haricinde bir nesil... Ah şimdiki mariz ve müteverrim muhit...

Büyük ninenin gözleri kapanıyordu. Seksen sene evvelki saadetlerin bugünkü ıstıraplarıyla seri ve ani mukayesesi, zihninde şedîd bir yorgunluk husûle getiriyor, onu hala yaşadığına müteessif ediyordu. Genç ve esmer kız yüz yaşına girmeye birkaç adımı kalmış olan bu annesinin annesinin annesinin annesine, bu mükerrer büyük ninesine dalgın dalgın bakarak onun zamanındaki kadınların saadetinin ne olabileceğini tahayyül ediyordu. Fakat bunu bulamıyordu: — Sustunuz, büyük nineciğim... dedi. İhtiyar kadın, buruşuk gözlerini açtı: — Ah!... Eski günleri, eski saadetleri düşünüyorum. — Eski zamanda, sizin zamanınızda bugünden fazla ne vardı, nineciğim? — Çok... birçok şeyler... Büyük nine tamamıyla doğruldu. Söyleyeceklerini zihninde toplar gibi bir an düşündü. Sonra yine başladı. Genç kız onun kırık dişli ağzının içindeki derin sivri karanlığa bakıyor, oradan çıkan kelimeleri sanki ziyade temaâşâ ediyordu. — Evet yavrum, birçok şeyler vardı. Her şey bizim için zevk, eğlence idi. Her şey! Çocukluk, mektebe başlayış, ferâceye giriş, kocaya varış, doğuruş, hatta ihtiyarlayış bile... Bunların hep ayinleri vardı. Her kadının bu devirleri diğer birçok kadınlar için bir zevk, bir eğlence vesilesi olurdu. Bütün hayatımız eğlence içinde geçerdi. Bir hafta olmazdı ki bir mektebe başlama, bir sünnet, bir düğün, bir lohusa cemiyeti görmeyelim. Esvaplarımız, kınalarımız bile eğlenceye vesile olurdu. Mânilerimiz, şarkılarımız vardı. Toplanır, aramızda müşâere eder, kış geceleri dîvanlardan tefeül ederdik, mevsimler bile bir eğlence idi. Her mevsimin kendine mahsus âdeti, eğlencesi, ananesi vardı. Daha hiç açmamış, bir senelik gül ağaçlarının dibine akşamdan beyaz kavanozlar kor içine yüzüklerimizi, yüksüklerimizi atar, ertesi sabah güneş doğarken mani söyleyerek tekrar çıkarırdık. Birbirine benzemeyen bin mani bilen, bütün kış herkesin lafına, bir söylediğini bir daha tekrar etmeden binlerce kafiye bulan kadınlar vardı.

Büyük nine ateh getirmiş ihtiyarların yalnız çenelerine mahsus olan o yorulmaz faaliyetle devam ediyor, sözünü uzatıyordu. O esnada bir kuş kümesi pencerenin yakınındaki bir ağacın dallarına konmuştu. Şiddetle cıvıldaşıyorlar, keskin çığlıklarını ihtiyarın hafif ve titrek sedasına karıştırıyorlardı: — Evet, yavrum biz sizin gibi: 'Ne yapalım?' diye düşünmezdik. Buna lüzum yoktu. Can sıkıntısının ne olduğunu bilmezdik. Hâsılı her şey gülmeye, eğlenmeye vesile idi. Mesela bahar... Ah, siz odalarda kapalı oturuyorsunuz. Bahar geldi mi, biz hepimiz bahçelere dökülürdük. Baharın kendine mahsus eğlenceleri, ananeleri vardı. — Ne gibi büyük ninecigim? — Ne gibi olacak, bahar da her mevsim gibi eğlence vesilesiydi. Biz bir senelik hayatımızı baharda tefeül eder, güler, eğlenir, oynardık. Ah bu tefeül... Pek şairane, pek latif, pek hassastı. Daima doğru çıkardı. Hepimiz îtikat ederdik. — Nasıl? — Bahar geldi, ağaçlar çiçek açmaya, yapraklar yeşillenmeye, çimenler baş göstermeye başladı mı, bizim gözlerimiz artık odalarda duramazdı. Bahçeye koşar, baharın ortasında gezinirdik. İlk göreceğimiz kelebek bir senelik talihimizdi. Onu tecessüs eder, onu beklerdik. İlk kelebeğin beyaz, yahut pembe olması için mâniler söyler, dalların üzerine beyaz ve pembe kumaş parçaları atardık. Sarı veyahut siyah bir kelebek göreceğiz diye korkar, ne kadar heyecanlar geçirirdik. — Niçin? — Çünkü kelebeklerin birer mânâları vardı. Ah, siz bunları bilmez, bunlara îtikat etmezsiniz. Beyaz kelebek: Saadete, talihe... Pembe kelebek: Sıhhat ve afiyete... Sarı kelebek: Kedere, hastalığa... Siyah kelebek: Felakete, matem ve ölüme delalet ederdi. Beyaz kelebek görünce talihimizin o sene açık olduğuna, mesut olacağımıza kâil olurduk... Bahar çiçekleri altında beyaz kelebeğin şerefine semâîler okurduk... Büyük nine devam ediyor, ilk defa küme halinde görülen kelebeklerin de umumî mânâlarını anlatıyor, beyaz kelebek kümelerinin zenginliğe, pembe kelebek kümelerinin bolluğa, sarı kelebek kümelerinin kıtlığa; kırmızı kelebeklerden müteşekkil ve pek nadir görülen meşum kümelerin mutlaka kanlı bir muharebeye, siyah kelebek kümelerinin fetrete padişahın öleceğine işaret olduğunu söylüyor, uzatıyor, büyük vakalardan evvel hep bu kümeleri o vakitki kadınların müşahede ederek erkeklerine haber verdiklerini hikâye ediyordu. Genç ve esmer kız artık dinlemiyor; büyük, siyah gözlerini büyük ninesinin arkasındaki pencereden görülen nisan semasının mavi ve beyaz aydınlığına dikmiş, tahayyül ediyordu. Hakikaten seksen sene evvel kadınların mesut olmaları lazım geliyordu. Kendileri, yeni nesil okudukça, anladıkça, erkeklere yaklaştıkça iptidâi kadınlıklarından, dişilikten uzaklaşıyorlar, ruhlarda bir isyan, bir ihtilal tutuşuyor, eski kadınlığın zevke, saadete vesile addettiği dişilik kayıtları kendilerine ateşten, demirden bir zincir gibi geliyordu. Hususî bir mâbet kadar sessiz, meçhul duran evlerine hapishane nazarıyla bakıyorlar, siyah çarşaflı kalın peçeleri ezici, soldurucu, vahşi, merhametsiz esaret örtüleri telâkkî ediyorlardı. Fakat haksız mıydılar? Mademki "terakkî" den ictinap kabil değildi; terakkî ise mutlaka değiştirmek, mutlaka eskiye benzememek idi, o halde asırlarca evvelki Türk kadınlığı da iptidâi, mebnâî halinde kalamazdı. Kuklalıktan, bebeklikten, masumiyetten, hâsılı dişilikten çıkacak, hakiki kadın haline gelecek, erkeklere tefevvuk etmese bile müsâvî bulunacak, bütün mânâsıyla insan, insan olacaktı... Büyük ninesinin "tarih-i mukaddes" hikâyeleri gibi garip vehimler içinde uzayan sözlerini artık işitmiyordu. Hayalinden bir sene evvelki gürültüleri, sevinçleri, nutukları, tiyatroları, konferanslarıyla Meşrutiyetin ilanı geçiyor, hâlâ tükenmez el şakırtılarını, alkış kabuslarını işitiyor gibi oluyordu. O günler kendileri için ne mesuttu. Bir an, bu siyah, sıkı esaretten azat edileceklerini, insanlık hakkına nâil olacaklarını ümit etmişlerdi. Ah bu ümit, nasıl çabucak sönmüş, söndürülmüş; bu hayal nasıl, ne feci bir surette kırılmıştı... Düşünüyor, ağlamak istiyor, titriyordu. Lakin... Lakin istikbâlden bir şey ümit edemezler miydi? Türk kadınlığı bir gün yüksek idrakiyle, altı asırlık tesadüfî, tabii bir istifa sayesinde harika haline gelen hüsnüyle, zekasıyla, bir Avrupalı kadın gibi insanlık sahnesine çıkarak ihtiramlar, perestişler önünde yükselemeyecek miydi?... Bugünkü tevekkül daha ne kadar devam edebilirdi? Büyük nine nihayetsiz hikâyesine devam ediyor; genç, esmer kız tahayyül ediyor, zihninde müphem hayallere karışan abus suallere cevap veremiyordu. Birden gülümsedi. Kelebeklerle tefeül etmek... Bu pek hoş olacaktı. Eski Türk kadınlığının îtikatları yeni Türk kadınlığının talihine nasıl bir hüküm verecekti? Merak ediyordu. Uzandığı şezlongdan doğruldu. Ayağa kalktı. Büyük nine susmuştu. Torununun bu ani kalkışına taaccüple bakıyordu. Sordu: — Ne var kızım, neye kalktın? Güzel, esmer kız gülerek: — Ben de bu bahar hiç kelebek görmedim. Kendim için değil, benim gibi olanlar için Türk kızları için, bütün Türk kızlarının talihi için bakacağım. Dedi, pencereye yaklaştı. Büyük nine titreyerek koltuğundan kalktı. — Gözlerim o kadar görmez ama diyordu, ben de bakayım sizin için... İkisi de pencerenin kenarında idiler. Sağda genç kız muhteşem ve levent endamıyla yükseliyor, solda minimini ve kambur büyük nine çürümüş bir balmumu külçesi gibi, sessiz ve donuk duruyordu. Dışarıya bakıyorlardı. Bütün tabiat gözleri kamaştıran tatlı, sıcak bir aydınlıkla parlıyordu. Denize güneş aksetmiş, onu başka âlemlere akıp giden ebedî, nihayetsiz bir gümüş nehrine benzetmişti. Ağaçların ufak, koyu yeşil yaprakları hazdan, hayattan titriyor, yollara beyaz çiçekler düşüyordu. Karşı sahil tirşe dağları, mor koruları, beyaz yalılarıyla bir serap memleketini, bir peri payitahtını andırıyordu. Susuyor, bakıyorlardı. Henüz bir kelebek görmemişlerdi. Çiçek tarhları üzerinde küçük sinek kümeleri görünüyor ve birden kayboluyorlardı. Tek bir martı yakın bir tehlikeden, meçhul bir şeâmetten kaçar gibi hızla geçiyor, haykırıyordu. Nerede oldukları görülmeyen kuşlar mütemadiyen ötüyorlar, cıvıltıları canlı ve tannan bir ziya yağmuru gibi semadan yağıyor zannolunuyordu. Genç kız birden, elini kalbine götürdü, yavaş bir sesle: — Ah işte... Dedi.Pencerenin yakınında, ağacın çiçekli dalları altında siyah bir kelebek uçuşuyordu. Gösterdi. Büyük nine korkunç ve iskelet parmağıyla: — Fakat ben senden evvel şu beyazı gördüm. Diye mermer havuzun üstünde dolaşan bir kelebeği gösterdi. Genç kız son bir cebirle ona da baktı: — Ah büyük nineciğim, iyi göremiyorsunuz, dedi, o beyaz değil, sarı bir kelebek... ...Ansızın ruhuna meçhul bir elem hücum etti, gözleri karardı. Bu parlak ve taze tabiat şimdi ona meyus görünüyor, mermer havuz genç, esir bir melikenin türbesine, bahçenin tarhları müteverrim ve mahbus kızların metruk çiçekli kabirlerine benziyordu. Geri çekildi. Yine şezlonga uzandı. Büyük nine de kendisine ölümü ihtar eden bu sarı, siyah kelebekli bahardan ürkmüş, yine arkasını dönmüştü. Koltuğunda yusyuvarlak oturuyor, kamburunu iyice çıkarıyordu. Genç kız elinden bırakmadığı siyah maroken kaplı kitabını açtı, bu kitap şimdi siyah, cesim, ölü bir kelebek gibi onun yüzünü tamamıyla örtüyordu. Okumuyor, irsi, intisalî bir vehim ile kelebeklerin yalan söylemediğine; zavallı yeni neslin, şimdiki Türk kadınlığının talihi ancak felaket, keder, ölüm olduğuna, ebediyyen siyah kefenini yırtamayacağına, tesettürden kurtulamayacağına, evlerin boş ve tenha duvarları arasında, meçhul çiçekler gibi açmadan solacağına, doğmadan öleceğine kanaat getirir gibi oluyordu... Mazi, batıl îtikatlar o kadar kuvvetli, müthiş idi ki, bütün idrake, bütün ilme, bütün fenne, bütün hakikate galebe çalıyor, tahavvül kanununun o muhayyel nazari kuvvetini esasından kırıyordu. Düşünüyordu; fakat bu batıl îtikatlar, bu haşin, anûd, katil mazinin anif tahakkümü yalnız Türklere, yalnız Türkiye'ye mahsus değildi. Birkaç hafta evvel Paris'te tahsilde bulunan kardeşi, oturduğu evin tabldotunda perhiz münasebetiyle et ve yağ bulunmadığını, Paris'te aileler arasındaki Katolik deliliğinin, dini taassubun bir mislini Sudan'da, çöllerde, kumlu, hudutsuz yamyamlar memleketinde bile bulmak mümkün olmayacağını yazıyordu... Birden kendisi gibi başka ufuklar, başka saadetler, başka hayatlar tahayyül eden mahrum kadınların romancısı, büyük bir garp muharririnin şâkirdine her şeyin bir hududu olduğundan bahsettikten sonra: "...Lakin insanların behimiyetine nihayet yoktur!" dediğini hatırladı.

Pencereden, sevdiğine kavuşmadan ölen genç ve müteverrim bir âşıkın son veda busesi kadar mahzun ve nazik bir rüzgar giriyor, taze mezarlar üzerine bırakılmış, taze çelenk kokuları getiriyor, odanın gölgelerinde görünmez, matemli hayaller dalgalanıyordu...

Büyük ninenin gözleri kapanıyordu. Bu meşum tefeülün ihtiyar dimağında husûle getirdiği yorgunluk ona bir uyku ilacı gibi tesir etmişti. Genç kız... Genç, esmer kız gözlerini kitaba dikmiş, okumuyor, kitabı tutan zambak ellerini asi, anarşist göğsüne bastırarak, içinden dudaklarına yükselen kalbî ihtilali, bu şedîd, sebepsiz hıçkırığı tutmaya çalışıyordu. Odanın uyutucu gölgeli sükununda sanki bu iki vücut eski, yeni Türk kadınlığının meyus, teselli kabul etmez iki timsali idi. Biri, bir asır evvelki neslin son numunesi, hayattan ziyade ölüme, nisyana ait bir hatırası... Diğeri, bugünün bir asırlık mecburi ve meşum terakkinin tagayyürün narin ve tatmin olunmaz bir çiçeği idi. Netice itibariyle ikisinin de talihi bu kapalı tenha oda, bu muhteşem, süslü mezar idi. Pencerenin yakınlarına gelen kuş kümesi, bazen şedid bir cıvıltı, aydınlık bir gürültü koparıyor, sonra susuyordu. Büyük nine uyudu. Artık hafif, kuvvetsiz bir ihtizar hırıltısı ile horluyordu. Torununun torunu, genç kız, güzel kız, esmer kız hâlâ hıçkırığını zaptediyor, donmuş gibi, şezlonguna uzanmış duruyordu. Geniş pencereden intizamsız fasılalarla giren kokulu ve çiçekli bahar rüzgarının cereyanı ansızın deminden gördükleri siyah kelebeği getirdi! Bu siyah kelebek parlak, muhteşem tabiatın, çiçekli, müşfik baharın cennetinde, cehennemin, zulmet, cehalet müvekkilinin siyah ruhunu andırıyordu. Şimdi bu siyah ruh çimen, çiçek kokularıyla gelmiş, şu geniş pencerenin önünde çırpınıyordu. İçerdeki, müstebit muhitin, hain mazinin, zalim îtikatların doğmadan katlettiği bu canlı ölüleri, onların müebbet sükununu seyrederek mahzuz ve mütelezziz oluyor, nerede oldukları belli olmayan kuşlar insafsız ve yakıcı bir hücuma uğramışlar gibi ansızın bütün kuvvetleriyle cıvıldamaya başlıyor, bütün tabiatı istila eden şedid, feci cıvıltılarla acı acı feryat ediyorlardı.

# Balkon

Muhsin Bey sofradan kalkınca, büyük ceviz büfeye dayanmış, kendilerini gülümseyerek dinleyen hizmetçiye:  
— Eleni, nargilemi kameriyeye getir, kahveden evvel... Haydi çabuk, dedi.  
Sonra sofradakilere döndü:  
— Çocuklar! Siz de oraya gelin!  
Hamdune Hanım; —narin, süzgün, yaşlı bir kadın— elmasını soyuyordu. Gözlerini kaldırmadan itiraz etti:  
— Daha mehtaba bir saat var. Karanlıkta ne yapacağız?  
— Burası cehennem be!  
— Orası cennet mi?  
— İsterseniz gelin. Ben burada yanamam.  
— Uğurlar olsun.  
Bu, şişman bir adamdı; ihtiyar bir şişman! Sallana sallana kapıdan çıktı. Tekâüt olduktan sonra doktorlara inat, oburluğa, nargileye bir nihayet vermemişti. Kır sakalının, daha dökülmemiş kır saçlarının altında kıpkırmızı, şiş yanakları onda yalancı bir sıhhatin daimi sevincini alevlendirirdi. Halbuki on senedir iyi olmaz bir kalp hastalığından mustaripti. Maddî ıstırabı, manevî neşesini bozmamıştı. Hamdune Hanım, kocasının aksi, çok küskün bir kadındı. Her an sebepsiz bir elem, bir sıkıntı içinde yaşardı. Meçhul bir matem sanki ruhunu ebediyyen karartmıştı. Daima sinirli, az güler, hep heyecan içinde... Köşkün kapısından kazara postacı geçse sapsarı kesilirdi. Gece gündüz bir felaket haberi bekler gibiydi. Sağındaki oğluna:  
— Maşallah, hepimizden genç, dedi.  
— Genç değil, içi ferah!  
— Ya yemek yemesine ne dersin?  
— Fena. Ama ne yapalım?.. "Allah sekizde verdiğini dokuzda almazmış!" Böyle rahat felsefeye dayandıktan sonra...  
Delikanlının karşısında havlusunu katlayan genç kız:  
— Aman, siz de hep beybabamla uğraşırsınız!  
Dedi. Sofranın üzerindeki lambanın kırmızı abajurundan süzülen ziyâ içinde iri, mavi gözleriyle, kumral saçlarıyla harikûlâde güzel görünüyordu. İnce, keten bluzun altından, iri, gürbüz, muntazam bir vücudun, geniş bir göğsün şekli sanki taşıyordu. Bu, Hamdune Hanım'ın daha memede iken alıp kendine evlat ettiği bir kızdı. Tam on sekiz sene Muhsin Bey onu oğlu Suat'tan ayırdetmemiş, belki daha ziyâde sevmişti. Bu muhabbet karşılıklıydı. Aile içinde Muhsin Bey'in taraftarı, hatta fedakarı Resan'dı.

Hamdune Hanım:  
— Sahi sıcak. Ben de burada duramayacağım! dedi.  
Suat sordu:  
— Nereye anne?  
— Babanın yanına.. Siz de gelin!  
— Geliriz.  
O çıkınca, iki genç yalnız kaldılar.

Resan arkasına dayanmış, gözleri pencerenin dışarısındaki simsiyah bir duman gibi görünen geceye dalmıştı. Suat sandalyesinden doğruldu. Onun önüne geldi. Yemek masasına dayandı. Resan'ın gözleri hâlâ daldığı yerden kurtulamıyordu. Elini tuttu.  
— Bu dalgınlık ne, Resan?  
— Hiç.  
— Söyle, söyle.  
Genç kızın gözleri sanki yorulmuştu. Suat'ın ellerinden çektiği eliyle gözlerini oğuşturdu.  
— Bu karanlıkları hiç sevmiyorum. Bana öyle geliyor ki, bütün felaketler hep bu yıldızsız, aysız gecelerin içinde saklı!  
— Gayet şairâne, yani gayet yanlış bir fikir.  
— Ne ise, ben burada oturacağım, istersen sen bahçeye çık.  
— Ben de burada otururum, cicim.  
Şık genç, demin annesinin kalktığı sandalyeyi Resan'ın yanına çekti. Beyaz fanile pantolonun üzerinde ince, lacivert bir ceket vardı. Cebinden narin bir tabaka çıkardı. İçinden bir sigara aldı, genç kıza verdi.  
— İstemem, canım istemiyor...  
— Al, al, karanlık düşmanı. İçmeye başlayınca ister!  
Sigarayı kendi eliyle Resan'ın güzel dudaklarına dokundurdu. Bir kibrit çaktı. Evvela onunkini, sonra kendisininkini yaktı. Çıkan dumanlar içinden derin derin birbirlerine baktılar. Küçükten, pek küçükten beri sevişiyorlardı! Suat:  
— Yalnız karanlık değil, dedi, sende başka bir şey var.  
— Ne gibi?  
— Halinde bir durgunluk.  
— Hiçbir şey yok!  
— Var, var, söyle.  
— Ne olabilir?  
— Bilir miyim?  
Resan aralık kapıya baktı.  
—Tabii, zaten sana söyleyecektim, dedi.  
Suat duraksadı:  
— Söyle Resan'cığım.  
İçeri giren hizmetçi kız tabakları toplamaya başladı. Büfenin önüne istif etti. Örtüyü kaldırdı. Dışarı çıkınca, Suat tekrar:  
— Ne söyleyeceksin bakalım?  
Diye genç kıza şefkatle baktı. Resan öyle ince, yapmacıklı, aktris tavırlı, sahte bir kız değildi. Son derece hassas, doğru, samimi, serbestti. Ağır bir seda ile:  
— Artık evlenmeliyiz. Suat... dedi.  
— Elbet, Resan'cığım. Bu zaten bizim yegane emelimiz değil mi?  
— Evet, fakat hemen evlenmeliyiz, hemen. Bu ay, hatta bu hafta içinde.  
— İki üç aya kalmaz diplomamı alacağım. Daha mektepte iken evlenivermek bana biraz mahalle çocukluğu gibi geliyor.  
— Mecburuz.  
— Niçin?  
— Çünkü...  
Genç kız gözlerini önüne indirdi. Uzun, kumral kirpikleri gözlerini göstermiyordu.  
— Çocuğumuz doğacak! dedi.  
— Gebe misin, cicim?  
— Evet.  
— Pekala, öyle ise, hemen evlenelim. Sakın üzülme. Bu ay, bu hafta değil. Hemen yarın!  
— Yarın mı?  
— Yarın vallahi...  
Birbirlerine sarıldılar. Suat dikkat etti. O daha ziyade güzelleşmiş, büyümüş, kadınlaşmış, bir harika olmuştu.  
— Resan'cığım, sen biraz yukarı, yahut bahçeye çık, ben annemi çağırayım. Hemen meseleyi açayım.  
— Fakat...  
— Fakatı makatı yok. Biliyorsun, ben sabırsızım. Sabaha bir şeyi bırakamam.  
Hakikaten Suat son derece aceleciydi. Aklına geleni yapar, anî, asabî hareketlerle herkesi şaşırtırdı. Erenköyü'nün en namdâr sporcusu sayılırdı. Cesurdu. Ufak bir şeyden heyecana gelir, ehemmiyetsiz bir laftan büyük bir kavga çıkarır, en tehlikeli tecrübelere gözünü kırpmadan atılırdı. Resan'ın kalkmasını beklemedi.  
— Eleni!...  
Diye seslendi. Hizmetçi kız gelince, "Git annemi çağır, hemen gelsin!" dedi. Resan'la tekrar kucaklaştılar.

Hamdune Hanım odaya girer girmez:  
— Ne var Allah aşkına, Suat?  
Diye sordu. Yüzü sapsarı kesilmişti. Meçhulden ürken bu kadın için "Çabuk, hemen, şimdi" gibi kelimelerin içinde mutlaka bir felaket gizliydi. Suat:  
— Otur, anneciğim, sana sevinçli bir şey söyleyeceğim... dedi.  
— Söyle bakayım...  
— Ben Resan'ı alacağım.  
Solgun kadının yüzü gülümsedi:  
— Hayırdır inşallah, rüya mı gördün? Böyle birdenbire...  
— Yok, hakikat. Hem de hemen yarın alacağım...  
— Aman, Suat, deliliği bırak. Bu acele ne?  
— Anneciğim, sen benim tabiatımı bilirsin. Aklıma bir şey koydum mu, hemen yapmalıyım.  
— Resan'a bir şey söyledin mi?..  
— O da beni seviyor!  
— Pekala ama, hazırlıksız, nişansız, filan... Herkes bize deli diyecek...  
— Ne derlerse desinler, herkes benim umurumda değil!  
— Yok, yok, bu olamaz.  
— Olacak anne!... Söyle, sen bu izdivaca razı değil misin?  
— Tabii razıyım...  
— O halde yarının, öbür günün ne ehemmiyeti var?  
— Vâkıâ hiç...  
— Öyle ise niçin beni kırıyorsun?  
Hamdune Hanım oğluna gülümseyerek baktı. Bu şımarık çocuk onun gönlüne hâkimdi. Doğduğundan beri ne isterse yaptırırdı. Yavaş yavaş içinde bir sevinç duydu. Resan'ı da kendi kızıymış gibi severdi. Hakikaten bu, mesut bir izdivaç olacaktı. Yuvanın kuşları başka yerlere gitmeyecek, eski ahenk bozulmayacaktı, damat gibi gelin gibi yabancı ruhlar bu küçük ailenin harîmine girmeyecekti.  
— Memnunsun ya, anneciğim?  
— Çok.  
— Şimdi Resan'ı da çağıralım.  
— Çağır.  
Suat, dışarı fırladı. Resan'ı aldı, getirdi. Ciddi kız, kıpkırmızıydı. Hamdune Hanım onlara birçok güzel sözler söyledi. Kendi hissiyatını anlattı. Artık sinirleri geçmişti. Gülüyordu. "İşte ben sizi bu akşamdan birbirinize veriyorum!" dedi ve Resan'la Suat'ın ellerini birleştirdi.  
— Fakat bir halka olsun takamıyorsunuz. Suat bu senin deliliğin... diyordu.  
— Güç olsun da, geç olmasın, anneciğim.  
— Haydi deli!..  
Konuşurlarken dışarıda, kameriyedeki Muhsin Bey'i unutmuşlardı.

Suat: — Babam bu kararımızı duyarsa kimbilir ne kadar sevinecek! dedi. Hamdune Hanım: — Çıldıracak! Diye güldü. O vakit Suat'a bir fikir geldi. Annesi ona bu kararı söyleyecekti. Sonra kendileri onun karşısına çıkıvereceklerdi. Muhsin Bey gayet şen, gayet neşeli, adeta çocuk gibi bir adamdı. Ailenin asıl reisi Hamdune Hanımdı. Hatta bu izdivaç için Muhsin Beyin reyine bile lüzum görmüyorlardı. Yalnız nasıl sevineceğini görmek için haber vereceklerdi. — Anne dedi. Sen şimdi babamın nargilesini yukarıya göndertirsin. Biz de Resan'la beraber balkona çıkarız. Perdeleri indiririz. Sen işi açarsın. O çocukça sıçramaya, ellerini çırpmaya başladığı zaman biz arkasından çıkıveririz.

Resan bunu istemiyordu: — Tiyatro oynar gibi. Ne olacak sanki bu! — Hiç, Resan'cığım. Babam seni de, beni de kucaklayacak, öpecek, işte bu! Hamdune Hanım: — Babana birdenbire sevinçli bir haber vermek yasak olduğunu unutma! dedi. — Yavaş yavaş açarsın. — Peki... Bari siz önden çıkın. Ben de onu yukarıya alayım. — Haydi anneciğim, benim cici anneciğim. Suat kocaman bir bebek beceriksizliğiyle annesine sarıldı. Kırlaşmış saçlarından, soluk alnından öptü. Annesi dışarıya çıkınca aynı şefkatle Resan'ı kucakladı. — Fakat, Suat, ben bu balkona saklanmayalım, diyorum. — Niçin, cicim? — İçim istemiyor. Daha mehtap çıkmadı, orada karanlıkta nasıl duracağız? — Yapma Resan'cığım. Mesut mesut güleceğiz. Babamın sevincini seyredeceğiz. Sana artık nasıl sataşmayacak, neler söylemeyecek. "Gelin hanım, gelin hanım" diye. — Suat balkona çıkmayalım. — Yapma cicim. — Çıkmayalım. — Haydi, haydi. Babamdan evvel davranalım. Bizi görmesin. Delikanlı, Resan'ı kollarından tuttu. Adeta onu zorla sürükledi. "Seni karanlığa alıştıracağım" diyordu. Yüksek bir merdivenden çıktılar, yüksek tavanlı bir salondan geçtiler. Suat ortadaki lambayı açtı. İki pencere arasındaki balkonun ağır perdelerini indirdi. Köşedeki bir koltuğu açık pencereye doğru çevirdi. Tam bu sırada Eleni de büyük beyin nargilesini getirmişti. Suat onu da yerine koydu. — Haydi şimdi aktörleri bekleyelim, diye Resan'ı balkona çekti. Hava son derece karanlıktı. Civar köşklerin aydınlıkları, can çekişen ateş böcekleri gibi hasta, donuk bir ziyâ ile parlıyordu. Suat yarınki karısını kucakladı. Genç kız gözlerini yummuştu. Açsa sanki yaşlar dökülecekti. O kadar mesuttu...

— Rutubet var. — Siz zaten hep beni rahatsız etmeye çalışırsınız. Yemeğime karışırsınız. İçirtmezsiniz. Uyutmazsınız. Sanki dünyaya kazık kakacakmışım gibi! — Burada otursak ne olur? Muhsin Bey pencereye dönen koltuğa çöktü. Hamdune Hanım nargilenin marpucunu çözerek kocasına uzattı: — Al memeni! — Haydi bakalım, bunu da çok görün. Konuşmaya başladılar. Hamdune Hanım, daima meyus yaşayan sinirli insanların neşeli zamanlarındaki heyecanlı tavırlarıyla yavaş yavaş işi açıyordu. Suat'ın büyüdüğünden bahsetti. Çabuk evlenirse çok iyi olacaktı. Fakat Resan'a hiç kıyamıyordu. Dışarı veremeyecekti. Muhsin Bey: "İç güvey alırız" dedi. Fakat Hamdune Hanım, Suat'a da kıyamıyordu. Muhsin Bey:                                                 "Gelini de yanımıza alırız" dedi.

Hamdune Hanım:  
— Bu kadar uzun külfetlere ne lüzum var? diye güldü, Ben bu meseleyi halletmenin kolayını buldum.  
— Nasıl?  
— Yanımıza ayrı bir iç güvey, ayrı gelin alacağımıza...  
— Ey?  
— Suat'a Resan'ı alıveririz, vesselam.  
Muhsin Beyin marpucu elinden düştü. Ağır hareketlerle onu yerden alırken:  
— Ne münasebetsiz şeyler düşünüyorsun, hanım! dedi.  
— Neden münasebetsiz olsun?  
— Münasebetsiz ya!  
Balkondaki âşıklar da, tıpkı Hamdune Hanım gibi, bu beklenilmez tavırdan şaşırmışlardı. Muhsin Bey'in sevineceğini, ellerini birbirine çarparak çocuk gibi kalkıp hepsinin boynuna sarılacağını bekliyorlardı. Hamdune Hanım, konuştuklarını işiten balkondakileri çok üzmemek istedi:  
— Sen uyuyorsun, Bey! dedi.  
— Ne demek?  
— Ben Suat'la Resan'ı birbirlerine verdim bile!  
Muhsin Bey, bu sefer marpucu elinden attı. Doğruldu. Yüzü kıpkırmızı oldu.  
— Bu izdivaç katiyyen olamaz! Hamdune Hanım yine sinirlendi:  
— Oldu bile... dedi.  
— Olamaz, diyorum.  
İhtiyarın çehresi fena halde bozulmuştu. Balkondakilerin kalpleri çarpıyordu. Bu hiç beklemedikleri mümânet onları şaşırtmıştı. Resan hıçkırmaya başladı. Suat onu öpüyor: "Korkma, cicim. Ne ehemmiyeti var? Yarın seninle burayı terkeder, başka yere gideriz" diyordu. Hamdune Hanım da içeride kocasıyla münakaşayı azıttılar. Muhsin Bey bir türlü niçin bu izdivaca razı olmadığını söylemiyordu.

Karısı onu zorladıkça, yalnız: "Olamaz, olamaz, ben sağken buna imkan yoktur!" diye bağırıyordu.  
Hamdune Hanım, nihayet iki gencin birbirlerini sevdiklerini, izdivaç etmezlerse bedbaht olacaklarını söyledi:  
— Sebepsiz bir mümâneatle iki genci meyus etmekte ne fayda?  
— Sebep var, diyorum, ısrar etme!  
— Söyle o sebebi!  
— Söyletme, diyorum!  
— Söyleyeceksin!  
O vakit Muhsin Bey boğuk bir sesle karısına:  
— Madem ki istiyorsun, söyleyeyim işte, dedi. Hani yirmi sene evvel, henüz seninle yeni karı koca iken ben İzmir'de malmüdürü tayin olunmuştum. Hatırlıyorsun ya?  
— Hatırlıyorum.  
— İstanbul'dan yalnız gittim, sen gelmedin.  
— Evet.  
— Sana her hafta mektup yazdım, çağırdım, yalvardım, yakardım, gelmedin.  
— Gelemezdim. Annemi ölüm döşeğinde nasıl bırakırdım?  
— İşte o bir sene içinde ben sana kızdığımdan İzmir'de başka bir kadınla evlenmiştim!  
— !!!..  
— Bu sırrı tam yirmi sene sakladım. Yine senin zorunla söylüyorum. Bu kadın doğururken öldü. Resan işte onun kızıdır. Suat'ın kardeşidir. Anladın mı?  
Hamdune Hanım bembeyaz kesildi. Balkonda boğuk bir gürültü, acı bir feryat koptu. Karı koca, ikisi de yerlerinden sıçradılar. Perdeyi açtılar. Resan'la Suat birbirlerini parçalayacaklarmış gibi boğuşuyorlardı.  
— Olmaz, dur!  
— Bırak, beni bırak!  
Resan, inanılmaz bir hamle ile sporcu genci balkonun eşiğine çarptı, sonra adeta beyaz bir alev gibi balkonun kenarından karanlığın içine fırladı. Bahçenin çakıllarına düşen bir vücudun derin, ağır sesini dehşetle duydular. Suat, daha doğrulmamıştı. Muhsin Bey ellerini boğazına götürdü. Birdenbire arkası üstü yuvarlandı. Hamdune Hanım, onu oturtmaya çalışırken gayr-i ihtiyari gözlerini balkona çevirdi. Oğlu, sevgili Suat'ı da korkunç karanlıkların içinde kaybolmuştu.

Biraz sonra... Siyah  ağaçların  arkasından doğan kan renginde bir ay, balkonun kenarında, kendini tutmak isteyenlerin arasında, saçları dağılmış, gözleri yerlerinden fırlamış, sarı, perişan bir hayalin aşağıya bakıp kahkahalar attığını gördü...

# Başını Vermeyen Şehit

"...Hak budur ki, ol guzzâtın içinde  
böyle gaziler olmasa. Zigetvar'a  
bu kadar kurbi civarda, cevânib-i  
erbaa kafir hisarı iken, meks ve  
ârâm, bâhusus böyle cenge ikdâm  
ne mümkün idi..."

Peçevî, s.355

Yarın arifeydi. Öbür günkü bayram için hazırlanan beyaz kurbanlar, küçük Grijgal palangasının etrafında otluyorlardı. Karşıda... Yarım mil ötede Toygun Paşa'nın son muhasarasından çılgın kışın hiddeti sayesinde kurtulan Zigetvar Kalesi, sönmüş bir yanardağ gibi, simsiyah duruyordu. Hava bozuktu. Ufku, küflü demir renginde, ağır bulut yığınları eziyor... Sürü sürü geçen kargalar tam hisarın üstünden uçarken sanki gizli bir kara haber götürüyorlarmış gibi, acı acı bağırıyorlardı. Palanga kapısının sağındaki beden siperinde sahipsiz bir gölge kadar sakin duran Kuru Kadı yavaşça kımıldadı; ikindiden  beri rutubetli rüzgarın altında düşünüyor, uzakta, belirsiz sisler içinde süzülen kurşuni kulelere bakıyordu. Bunların hepsi Türklerin elindeydi. Yalnız şu Zigetvar...

Yıkılmaz bir ölüm seddi halinde "Kızılelma" yolunu kapatıyordu. Sanki bu uğursuz kargalar hep onun mazgallarından taşıyor, anlaşılmaz bir lisanın çirkin küfürlerine benzeyen sesleriyle her tarafı gürültüye boğuyorlardı. Kuru Kadı içini çekti. Sonra "Ah..." dedi. İncecik, sinirli boynunun üstünde bir taş topuz gibi duran çıkık alınlı, iri kafasını salladı. Yeşil sarığını arkaya itti. Islak gözlerini ovuşturdu. Şimdiye kadar, asker olmadığı halde, her muharebeye girmişti. Birkaç bin yeniçeriyle dört beş topu olsa... Bir gece içinde şu kaleyi alıvermek işten bile değildi! Şimdi vâkıa müstakildi. Ne isterse yapabilirdi. Palanganın kumandanı Ahmed Bey, öteki boy beyleriyle beraber Toygun Paşa ordusuna katılıp Kapuşvar fethine gitmişti. Kapuşvar'dan sonra Zigetvar'ı saran ordu, kışın aman vermez zoruyla, zaptı yaza bırakarak Budin'e dönünce, o da askerleriyle tekrar palangasına gelmemiş, Toygun Paşa'nın yanında kalmıştı. Bugün Grijgal'den altı mil uzaktaydı. Palangaya yalnız Kuru Kadı karışıyordu; esmer, zayıf yüzünü buruşturdu: "Palanga, palanga...Amma topu tüfeği kaç kişi?" dedi. Bütün genç muharipleri, Ahmed Bey, beraberinde götürmüştü. Hisardakiler zayıflardan, bekçilerden, hastalardan, ihtiyar sipahilerden ibaretti. Hepsi yüz on üç kişiydi!!! Düşman, galiba öteki palangalardan çekiniyordu. Yoksa burasını bırakmaz, mutlaka almaya kalkardı. Biraz eğildi. İnce yosunlu, soğuk sipere dirseklerini dayadı. Aşağıya baktı. İki üç asker beyaz koyunların arasında dolaşıyordu. Bir tanesi karşısına geçtiği iri bir koçu, başına dokunarak kızdırıyor tos vurduruyordu. Öbürleri elleri silahlarında bu oyunu seyrediyordu. Bağırdı: — Oynamayın şu hayvanla... ....... Askerler, başlarını tepelerinden gelen sese doğru kaldırdılar. Kuru Kadı'dan hepsi çekinirlerdi. Gayet sert, gayet titiz, gayet sinirli bir adamdı. Âdeta deli gibi bir şeydi. Sabahtan akşama kadar namaz kılar, zikreder, geceleri hiç uyumazdı. Daha yatıp uyuduğunu kalede gören yoktu. Vali Ahmed Bey ona "bizim yarasa" derdi. Zavallının "dâûsseher" denilen hastalığını kerametine de yoranlar vardı. Tekrar bağırdı: — Haydi, artık akşam oluyor, içeri alın onları. ....... Askerler koyunları toplamaya başladılar. Kuru Kadı'nın dirsekleri acıdı. Doğruldu. Tekrar Zigetvar'a baktı. Üst tarafındaki göl, kirli bakır bir levha gibi yeri kaplıyordu. Kargalar, havaya boşaltılmış bir çuval canlı kömür ellemeleri gibi karmakarışık geçiyorlar, sükûtu parçalayan keskin, sivri sesleriyle gaklıyorlardı. Kalbinde ağır bir elem duydu. "Hayırdır inşallah..." dedi. Canı o kadar sıkılıyordu ki... Elleri arkasında, başı önüne eğik, bastığı siyah kaplama taşlarına görmez bir dikkatle bakarak yavaş yavaş yürüdü. Derin bir karanlık kuyusunu andıran merdivenin dar basamaklarında kayboldu.

... Arife sabahı, herkes uyurken, o, her vakitki gibi yine uyanıktı! Mescit odasının önündeki taş yalakta, iki büklüm, abdestini tazeliyordu. Giden gece, daha gölgeden eteklerini toplayamamıştı. Bahçeye çıkan kapı kemerinde asılı kandil, sönük ziyasıyla, duvarları titretiyordu.  
— Hey, çavuşbaşı... Hey!...  
......  
Elinden ibriği bıraktı. Kulak kabarttı. Bu, kuledeki nöbetçinin sesi idi. Kolları sıvalı, ayakları çıplak, başında takke, hemen yukarı koştu. Merdivende çavuşa rastgeldi. Onu itti. Yürüdü. Nöbetçinin yanına atıldı:  
— Ne var?  
— Kaleden düşman çıkıyor.  
......  
Erguvanî bir esmerlik içinde siyah bir kaya gibi duran Zigetvar'a baktı. Bu kayadan yine koyu, uzun bir karartı süzülüyor, palangaya doğru akıyordu.  
— Bize geliyorlar!..  
Dedi. Çavuşa döndü:  
— Haydi, gazileri uyandır. Kurban bayramını bugünden yapacağız. Koş. Bana da çabuk topçuyu gönder.  
.....  
Çavuş, bir eliyle bakır tolgasını tutarak, koştu. Merdivene daldı. Kuru Kadı, uzakta, kara yerin üstünde daha kara bir leke gibi yavaş yavaş ilerleyen düşman alayına dikkatle baktı. Gözlerini küçülttü, büyülttü. Önlerinde birkaç top da sürüklüyorlardı. Binden ziyadeydiler. Halbuki hisardaki gaziler? Kendisiyle beraber yüz on dört kişi... "Ama, yine haklarından geliriz!" dedi. Uyanan, yukarı koşuyordu. Hisar kapısının iyice bağlanmasını emretti. Sarığını, cübbesini, kılıcını, tüfeğini getirtti. İhtiyar topçu gelince, ona da, hemen "haber topları"nı atmasını söyledi. Bu bir âdetti. Taarruza uğrayan bir palanga hemen "işaret topu" atarak etraftaki kuleleri imdadına çağırırdı.

Biraz sonra düşman hisarın önünde, harp nizamına girmiş bulunuyordu. Toplar başsız, gür ejderha yavruları gibi siyah ağızlarını bedenlere çevirmişti. Türkçe bağırdılar: — Size teklifimiz var. Elçimizi içeri alır mısınız? Kuru Kadı: — Alırız. Gönderin, gelsin! Cevabını verdi. Bedenler, kalkanlı, tüfekli, oklu gazilerle dolmuştu. Palanganın ruhu, neşesi, keyfi olan iki arkadaş, bu esnada tuhaf tuhaf laflar söyleyip yine herkesi güldürüyordu. Bunların ikisine de "deli" derlerdi:

Deli Mehmed, Deli Hüsrev... Serhat muharebelerinde, hayale sığmayacak yararlıklarıyla masal kahramanları gibi inanılmaz bir şöhret kazanan bu iki deli, hiçbir nizama, hiçbir kayda, hiçbir zapt ü rapta girmeyen, dünya şerefinde gözleri olmayan Anadolu dervişlerindendi. Her zaferden sonra kumandanları onlara rütbe, hilat, murassâ kılıç gibi şeyler vermeye kalkınca, gülerler: "İstemeyiz fâni vücuda kefen gerektir. Hilat nâdan ları sevindirir..." derler, hak uğrundaki gayretlerine ücret, mükafat, şâbâş kabul etmezlerdi. Harp onların bayramıydı. Tüfekler, oklar atılmaya, toplar gürlemeye, kılıçlar, kalkanlar şakırdamaya başladı mı, hemen coşarlar, kendilerinden geçerler; naralar savurarak düşman saflarına saldırırlar, alevli gözlerle takip edilemeyen birer canlı yıldırım olup tutuşurlardı.

Kuru Kadı, onların herkesi güldüren münakaşalarını, saçma sapan sözlerini gülümseyerek dinlerken, elçiyi yanına getirdiler, iki deli de sustu. Herkes kulak kesildi. Bir elçi Türkçe biliyordu. Küstahça tekliflerini söyledi.

Palangayı saran Zigetvar kumandanı Kıraçin'di. Yanında iki bine yakın muharibi vardı. Grijgal'in "Vire" ile verilmesini istiyordu. Ateşe, nura, haça, İncil'e, Zebur'a yemin ediyor; çıkıp giderken muhafızlara hiçbir ziyanı dokunmayacağına dair söz veriyordu.  
Kuru Kadı:  
— Pekâlâ!... Haydi git. Biz aramızda anlaşalım, kararımızı size öğleden sonra bildiririz!  
Diye elçiyi aşağı gönderip kapıdan attırdı. Sonra etrafındakilere döndü. Şöyle bir göz gezdirdi. Sırtının hafif kamburu içeri çekildi:  
— İşittiniz ya, gaziler! dedi, Kıraçin haini bizim yüz on dört kişiden ibaret olduğumuzu anlamış... Üzerimize iki bin kişi ile geldi. Teklif ettiği "Vire"yi kabul etmek isteyenler varsa ellerini kaldırsın!  
— .......  
Kimsenin eli kalkmadı.  
— Öyleyse hazır olalım. Haydi...  
Bir gürültüdür koptu:  
— Hazırız....  
— Hepimiz, hepimiz...  
— Hepimiz, hepimiz hazırız.  
— Kılıçlarımız, kalkanlarımız yağlı.  
— Oklarımız bağlı.  
— Yatağanlarımız keskin...  
— Bugün nusret bizim.  
— Âmin, âmin...  
......  
Kuru Kadı:  
— Yarabbelâlemîn...  
Diye ellerini kaldırdı. Bir duaya başlayacaktı. Deli Mehmed yalın kılıç karşısına dikildi. Palabıyıklı, gök gözlü, geniş beyaz çehresi, yeni doğmuş bir ay gibi parlıyordu:  
— Duayı bırak efendi, dedi, gaza duadan efdal dir. Gel... Lütfet. Bize şu kapıyı aç. Kalbindeki korkuyu at. İşte hepimiz hazırız. Şu ayağımıza gelen gaza fırsatını kaçırmayalım.  
Kuru Kadı'nın elleri aşağı düştü. Deli Hüsrev de arkadaşının yanına sokulmuştu. Bütün gaziler bu iki delinin arkasına üşüştü. Sanki hepsi bir anda deli oldular... Hepsi bir ağızdan:  
— Aç bize kapıyı, aç...  
Diye bağırmaya başladılar. Kuru Kadı'nın iri patlak gözleri yaşardı. Yüzü sapsarı oldu. Uzun siyah sakalı kımıldadı. İki deliyi bile titreten, bütün gazilerin saçlarını ürperten ilahî bir mersiye ahengi kadar müessir sesiyle haykırdı:  
— Meydan erleri! Ey mertler! Padişahımız Süleyman Gazi aşkına şu sözümü dinleyiniz. Benim muradım sizi gazadan menetmek değildir. Bugün can, baş feda olsun... Bâhusus yarın kurban bayramı... Fakat bakınız maksadım ne? Bugün Cuma, hem de arife... Bugün hacılarımız Arafat'ta, diğer müminler camilerde bizim gibi gazilerin nusreti için dua etmekteler... Bunda şüphesi olan var mı?  
— Hayır.  
— Hayır, asla...  
— Hayır.  
— O halde münasip olan budur ki, biz de namazlarımızı eda edelim. Gözlerimizin yaşını dökelim. Dua edelim. Birbirimizle helalleşelim. Sonra gazaya girişelim. Kalanlarımız gazi, ölenlerimiz şehit olsun! Dünyada iyi nam ile anılalım. Ahirette Peygamberimizin alemi dibinde toplanalım... Ne dersiniz?  
— Hay, hay.  
— Muvâfık...  
— Pekâlâ!  
....  
Gazilerin hepsi buna razı oldu. Öğleye kadar durdular. Abdest aldılar, namaz kıldılar, tekbir çektiler, helalleştiler. Kıraçin'in askerleri sardıkları palangadan yükselen derin uğultuyu hep teklif ettikleri "Vire" münakaşasının gürültüsü sanıyorlardı.

Ansızın, uzaktaki Türk kulelerinden atılan "işaret topları" işitildi. Bu, "Biz, dörtnala geliyoruz!" demekti. Kuru Kadı, eliyle hisarın kapısını açtı. Grijgal gazileri "Allah, Allah" naralarıyla müthiş bir çöl fırtınası gibi fışkırdılar. İki koldan hücum olunuyordu. Kollardan birisine Deli Hüsrev, birisine Deli Mehmed baş olmuştu.

Ovada, Grijgal'e gelen yollardan bir toz dumandır kalkıyordu. Nice bin atlı imdada koşuyor sanılırdı. Düşman, bu hâli görünce şaşırdı. İki ateş arasında kaldığını anladı. Halbuki toz duman içinde yaklaşanlar ancak beş on gaziydi.

... Bozgun başladı.

Deli Mehmed'le Deli Hüsrev'in takımları düşmanı kaçırmamak için iyice sarıyordu. Kuru Kadı cübbesini atmıştı. Elinde kılıç, teşcî ettiği gazilerin arkasından yürüyordu. Deli Hüsrev, bir sarhoş gibi Karaçin'in alayına dalmış, kesiyor, kesiyor... İnanılmaz bir çabuklukla kaçanlara yetişiyor, ikiye biçiyordu.

Kuru Kadı'nın gözleri Deli Mehmed'i aradı.

Bakındı, bakındı.

Göremedi.

Acaba o muydu? Yüreği ağzına geldi. Düşman safına karışıp kaynaşan kolun arkasında iri bir vücut yere uzanmıştı. Elli altmış adam kadar kendisinden uzaktı. Siyah, yüksek atlı bir şövalye, uzun bir kargıyı bu uzanmış vücuda saplıyordu. Durmadı. İlerledi. Koşarken ayağı bir taşa takıldı. Yuvarlanıyordu. Kılıcı ileri fırladı. Hemen toplandı. Kalktı. Düşen kılıcını aldı. Doğruldu. Koşacağı tarafa baktı. Şövalye atından inmiş, kargıladığı şehidin başını teninden ayırmıştı. Bir anda, bu kestiği baş elinde, yine siyah bir ifrit gibi şahlanan atına sıçradı. Kaçacaktı... Kuru Kadı, bütün kuvvetiyle ona yetişmek için koşarken, baktı ki, solu ilerisinde Deli Hüsrev kalkanını sallayarak, avazı çıktığı kadar bağırıyor: — Mehmed, Mehmed!.. Canını verdin!.. Başını verme Mehmed!.. Bu nara o kadar müthiş, o kadar müessir, o kadar yanıktı ki... Kuru Kadı: "Vah, Deli Mehmedmiş!" diye olduğu yerde dikildi kaldı. Durur durmaz, o an, kırk adım kadar yaklaştığı kesik başlı şehidin yerden fırladığını gördü. Nefesi tutuldu. Şaşırdı. Bu başsız vücut uçar gibi koşuyordu. Kendi kellesini götüren zırhlı şövalyeye yetişti. Eliyle öyle bir vuruş vurdu ki...Lâin hemen yüksek atından tepesi üstü yuvarlandı. Götürmek istediği baş elinden yere düştü. Deli Mehmed'in başsız vücudu canlıymış gibi eğildi. Yerden kendi kesik başını aldı. Hemen oracığa, yorgun bir kahraman gibi, uzanıverdi. Bunu Kuru Kadı'dan başka kimse görmemişti! Herkes kaçan düşmanı kovalıyordu. Yalnız Deli Hüsrev: — Yüzün ak olsun, ey celâsın! diye bağırdı. Sonra Kuru Kadı'ya doğru koşarak sordu: — Nasıl, gördün mü bu civanı? — ..... — Görmedin mi? — ..... Kuru Kadı sesini çıkaramadı. Gördüğü harika onu dondurdu. Olduğu yerde öyle dimdik kaldı. Sanki ölmüştü. Deli Hüsrev onu hızla sarstı. — Ne durursun be, can! Ne oldun, haydi gazaya... Düşman kaçıyor. Deli Hüsrev'in kalkması Kuru Kadı'ya baştan can verdi. "Allah, Allah" diyerek ileriye atıldı. Mücahitlere karıştı.

Cenk akşama kadar sürdü.

Er meydanının kanlı yüzüne "gece siyah saçlarını" dağıtırken münadi nin: — Gaziler hisara!... Sadâsı duyuldu. Dönen gaziler içinde kılıcından kanlar damlayan Kuru Kadı, birkaç sipahi ile dışarıda kaldı. Yaralıları taşıttı. Şehit olanları saydırdı. Bunlar tam on dokuz kahramandı... Düşman altmış dört ceset bırakmış, diğer ölülerinin hepsini kaçırmıştı. Kuru Kadı, sabahtan beri yemek yememiş, su içmemiş, durup dinlenmemişti... Toplattığı şehitleri hisarın önündeki meydana yığdırdı. Şehit Deli Mehmed'in naaşını kendi buldu. Kesik başı koltuğunda, uyur gibi, sakin yatıyordu. Olduğu yerde gömdürdü. Sonra yanındakileri savdı. Bu taze mezarın başına çöktü. Ezberden "Yâsin" okumaya başladı. Dışarlarda kimse yoktu, yalnız uzakta palanga kapısındaki nöbetçi dolaşıyordu. Kuru Kadı okurken, önündeki mezarın birden yeşil nurlarla tutuştuğunu gördü. Sesi kısıldı. Dudaklarını oynatamadı. Çeneleri kitlendi. Bu yeşil nurun içinde Deli Mehmed'in kanlı boynuna sarılmış beyaz kanatlı bir melâike, hem onu nurdan elleriyle okşuyor, hem açık alnını öpüyordu. Bu sıcak, bu yeşil nur büyüdü. Taştı. Bütün âlem bu nurun içinde kaldı. Kuru Kadı'nın gözleri kamaştı. Ruhu yandı. Kendinden geçti.

Onu, daha ilk defa böyle derin bir uykuya dalmış gören yoldaşları zorla kaldırdılar. Koltuklarına girdiler:  
— Haydi, kapı kapanacak, dediler; içeri gir.  
Kuru Kadı'nın dili tutulmuştu. Cevap veremedi. Sarhoş gibi sallana sallana hisara girdi. Hâlâ titriyordu. Palanganın içinde Deli Hüsrev'in menzilinden geçerken durdu. Kulak verdi; ağlıyor mu, inliyor mu diye... Hayır, Deli, şıkır şıkır, atını kaşağılıyor, keyifli bir türkü söylüyordu. Seslendi:  
— Hüsrev!..  
— Efendim?  
.....  
Kapı açıldı. Kaşağı elinde, kolları paçaları sıvalı, başı kabak Deli Hüsrev... Daha Kuru Kadı bir şey sormadan:  
— Gördün mü Deli Mehmed'in zevkini? dedi.  
— Siz de benim gibi buradan gördünüz mü?  
— "Gözlüye hod gizli yoktur!"  
Küttedek kapıyı kapadı. Yine türküsüne başladı.

Kuru Kadı palangada sabahı dar etti. Güneş doğmadan Deli Mehmed'in mezarına koştu. Artık bütün günlerini bu mezarın başında geçiriyordu. Bu mezarın daimi ziyaretçisi oldu. Büyük bir taş yontturdu. Yazdırdı. Başına diktirdi. Beş vakit namazlarını bile cemaatine bu kabrin başında kıldırmak isterdi. Artık ne hâcet dilese, ne muradetse, ona nâil oluyordu.

Grijgal'de, komşu palangalarda Kuru Kadı için "deli oldu" diyorlardı. Her an "bekâ" bâdesi ni içmiş ezeli bir sarhoş gibi nihayetsiz bir gaşy, pâyansız bir şevk, sükûn bulmaz bir heyecan içinde yaşıyordu. Fakat nasıl "deniz çanağa sığmaz"sa, onun büyük sırrı da ruhuna sığmadı. Taştı. Huruç günü gördüğü harikayı herkese anlatmaya başladı. Hatta daha ileri gitti, çok iyi okuduğu "Mevlid-i Şerîf" lisanıyla o gün gördüğünü yazdı. Yüzlerce beyitlik bir destan düzdü.

Ama o zaman eski şevki kayboluverdi. Ruhuna koyu bir karanlık doldu. Kalbine acı bir ağırlık çöktü. Artık Deli Mehmed'in yeşil nurdan mezarı içinde sürdüğü ilahî zevki göremez oldu. Bu mahrumiyet onu delirtti. Yemekten, içmekten kesildi. Bir gün yine perişan, kırlarda dolaşırken Deli Hüsrev'e rastgeldi. Meğer o da geziniyormuş. Elindeki yayıyla yavaşça Kuru Kadı'nın arkasına dokundu.  
— Ahmak, dedi, neye gördüğünü halka söyledin? Adam gördüğünü kâle geçirirse kazandığı hâli kaybeder. Eğer susaydın, gördüğün keramete ölünceye kadar şahit olacaktın...  
Kuru Kadı yere diz çöktü, ağlamaya başladı:  
— Çok perişanım, diye inledi, lütfet. Gel, beni gaflet uykusundan uyandır. Benim o görmüş olduğum ahvâl ne hikmettir? İçinde aklımı kaçırdığım bu mehâbet, bu heybet nedir? Benimle senden başka onu gören oldu mu?  
— Bir gören daha var. O "can" herkese görünmez.  
— Kimdir?  
— Bilemezsin...  
— Başkaları görmedi de, biz ikimiz niçin gördük?  
— Şehitlik müjdesidir! İkimiz de mutlaka şehit düşeceğiz!..  
.....  
.....  
Kuru Kadı, gittikçe öyle serseri, öyle perişan, öyle berbat oldu ki... Kendisini o kadar seven Vali Ahmed Bey bile, Budin'den gelince, onun hallerine dayanamadı. Nihayet "Bu meczup bir kişidir. Palangada hizmetinden istifade olunamaz." diye geriye göndermeye mecbur oldu. Aradan epey zaman geçti. Serhadde değil, hatta Grijgal hisarında bile herkes Kuru Kadı'yı unuttu. Yalnız yazdığı destan okunuyor, hiç unutulmuyordu.

On iki sene sonra...

Zigetvar'ın zaptı akşamı yaralılar toplanırken meşhur kahraman Deli Hüsrev'in —bir gülleyle parçalanmış— naaşı yanında, uzun boylu, ak saçlı, ak sakallı, yeşil cübbeli bir şehit buldular. Kıbleye karşı yüzükoyun uzanmış yatan bu şehidin büyük, yeşil sarığı henüz bozulmamıştı. Üzerinde hiçbir silah yoktu. Yarası, neresinden olduğu belli değildi. Günlerce süren muhâsara esnasında hiç kimse böyle bir adam görmemişti. İnceden inceye tahkîkat yapıldı. Kim olduğu bir türlü anlaşılamadı. O vakit birçok gazilerin "gayp ordusundan imdada gelmiş bir velî" sandıkları bu şehit, acaba, Grijgal hisarının o eski meczup kadısı mıydı?

==Dipnotlar== Kaynakça: Başını vermeyen şehit

# Binecek Şey

Derviş Hasan birdenbire durdu. Kirli, yırtık yenleriyle alnının terlerini sildi. Sıcak bir haziran güneşi dünyayı sebepsiz bir belâ gibi kasıp kavuruyordu. Sabahtan beri işte dört saattir hiç durmadan yürümüştü. Etrafına bakındı: Seyrek, sıska ağaçlı bir ormanın kenarında idi. Uzakta, tirşe rengi hafif bir sisle boyanmış kat kat dağlar görünüyordu. Köye, kasabaya benzer bir şey gözüne çarpmadı, yolun üst tarafındaki ağaçlara döndü:

«Biraz dinlensem...»

Diye düşündü. Vakıa şu alacalı gölgelerde uzanıp rahat bir uyku çekmek... Hiç de fena değildi. Fakat karnı zil çalıyordu:

«Öğleden evvel bir köye rast gelirim...»

Ümidi ile geceyi geçirdiği çoban kulübesinden aç çıkmıştı. Her halde yürümeli, bir an evvel bir köye yetişmeliydi! Amma hangi köye?.. Derviş Hasan bunu asla bilmez, düşünmez, aklına getirmezdi. Otuz senedir, omuzunda keşkülü, sırtında abası, gönlünde tevekkülü, nereye gittiğini bilmediği yollardan geçmiş, ismini öğrenmediği köylerde misafir kalmıştı. Her yerde ona yiyecek, içecek verirlerdi. Anadolu tekkelerinin kapıları ağzına kadar açıktı:

«Huuu...»

Diye girer, isterse haftalarca, aylarca... Tâ canı sıkılıncaya kadar kalırdı. Dağın, taşın, nehrin, gölün, ormanın hususî isimleri olur muydu? Onun fikrince köylerin, kasabaların, şehirlerin isimlerine de lüzum yoktu. Hepsi «dünya» demekti. Balık, denizinde nasıl hiçbir mevzu hiçbir kanuna tabi olmadan, rahat rahat yüzerse, o da, dünyasında öyle serbest serbest gezerdi. İlkbaharlar, sonbaharlar, yazlar, kışlar tabiatın birer efsanesiydi. Hükümet, kanun, aile, din, ahlâk, hâsılı her şey nazarında, manası olmayan birtakım uydurma latifelerdi. Vücut bir rüya idi. Hayat bir seraptı. Ancak nâdanlar bu rüya ile seraba aldanırlar, beyhude yere üzülürlerdi. Hakikat «bir»di. O da «aşk» idi. Aşk idrak eden büyük hakikate ermiş, harici, batınî kâinatın, hakkın manasını anlamıştı.

Derviş Hasan, işte bu erenlerden biriydi. Geniş, kuru omuzlarının üstündeki koca külâhlı, çok saçlı başı, beyaz sakallı yanık yüzü, derin, iri siyah gözleri, ona garip bir heybet verirdi. Ne olduğuna dikkat etmediği «dünya»nın üstünde, bir duman içindeymiş gibi, hiç görmeyerek yaşardı. Aşkı, Allah'ı, hakikati, saadeti, gayesi ruhunda idi. Aşkın haricindeki şeyler onun etrafına toplanmış bir küme masiva bulutuydu. «Vücut» yoktu. Fakat, gayri ihtiyarı:

- Of, dizlerim... Dedi.

Açlık, sıcak, ihtiyarlık üç bin okkalık bir yük gibi sırtına çökmüştü. Şimdi, bir an için, aşkını unutuyor, bu ağır yükün altında ezilen vücudunun varlığını sezer gibi oluyordu. Başı çatlayacak derecede ağrıyor, ayakları titriyor, nefes aldıkça, daralmış göğsü acıyordu. Tekrar, durduğu yolun ilerisine, gerisine baktı. Ne gelen vardı, ne giden... Gözlerini yere indirince, birtakım hayvan, kağnı izleri gördü. Mutlaka yakında bu izlerin gittiği bir köy, bir kasaba bulunacaktı. Bu tahmin ona teselli verdi. Onu sevindirdi. Derin bir «hu» çekti. Ellerini arkasına bağladı. Yine aşkının hakikatine dalarak, yine etrafını dumanlaştırarak, hiçbir şey görmeden, yürümeğe başladı. Gitti, gitti... Fakat bu ümit verici izlerle örtülmüş, cehennem gibi; sıcak, çöl gibi tozlu yol bitmiyordu. Nefesi, kollan, dizleri kesiliyor, hakikatte «olmayan» vücudunun elemleri, «mevcut olan» ruhunu sıkıyordu. Ömründe ilk defa olmak üzere bir araba düşündü. Bu arabanın yumuşak ipek yastıklı içi kim bilir ne kadar rahattı. Yavaşça:

- Ah bir araba olsa... Dedi.

Sonra, sırma eğerli bir atı gözünün önüne getirdi. Böyle bir ata binse ufukta göreceği en uzak bir köye yarım saat içinde gidebilirdi. Hayalinden deve katarları, kervan katırları geçti. Açlıktan, sıcaktan, ihtiyarlıktan artık o kadar bitkin bir haldeydi ki... Gülümsedi:

- Bir topal eşek olsa da razıyım ya... Dedi.

Sıcak gittikçe kızıyor, yol daha ziyade biçimsizleşiyor, tozlar çoğalıyor, taşların arasında baygın kertenkeleler görünüyordu. Kendine baktı. Tozla örtülmüş çarıklarının eskiliği belli olmuyor, kıllı göğsünden çamurlu terler damlıyordu. Gayret lâzımdır:

«Yolcu yolunda gerek...»

Nasihatini hatırladı. Yürüdü, yürüdü, yürüdü, yürüdü... Saatlerce yürüdü. Güneş tam tepeden tekrar ufka doğru inmeğe başlamıştı. Derviş Hasan, şimdi şehirlerdeki zengin, tenperver zahitlerin içmeğe kıyılamayacak soğuk, berrak sularla serin gölgeli, rahat şadırvanlarda ikindi namazı için abtestlerini tazelemekle meşgul olduklarını düşündü. Onların cehennem azabıyle, cennet hırsıyle daima rahatsız olan ruhlarına mukabil, vücutları, ne kadar mes'ut, ne kadar rahattı. Yürüdü, yürüdü... Yürüdüğü yolda izler gittikçe karışıyordu. Gözlerini kaldırdı, ileriye baktı. Yolun dönemecinde küçük bir tepenin önüne gelmişti. Dönemecin karşısında iki üç çınar ağacı ile kurumuş çeşme vardı. Durmadı. Yürüdü. Bu tepenin eteğini dönünce yolun tırmanıp aştığı öyle dik, öyle sarp bir yokuş gördü ki...

- Vallahi bunu çıkamam!

Diye haykırdı. Hemen çömeldi. Açlık, sıcak, ihtiyarlık, sabahtan beri durmadan yürüyen Derviş Hasan'ı azıcık daha isyan ettirecekti. Bu dik yokuş karşısında duyduğu feci ümitsizlik onun arif ruhunu kararttı. Şimdiye kadar eğilmeyen boynunu menfaatperver, tekâpucu, hesapçı bir zahit gibi büktü. Gözlerinden, harici âlemin hayalini kaplayan aşk dumanı, dudaklarından ariflik tebessümü silindi. Ömründe ilk defa olarak zahitlerin mabuduna yalvarmağa başladı:

- Allah'ım, bana merhamet et, dedi, açım, ihtiyarım! Karşıma çıkardığın bu yokuşu çıkamayacağım. Bana bir «binecek şey» gönder. Yalnız şu yokuşu aşayım. Öbür taraf için seni taciz etmem.

Sonra, sürüklenerek, kurumuş çeşmenin başında çınarların gölgesine gitti:

- At istemem, araba istemem. Binecek kötü bir şey... Bir topal eşek olsun Allah'ım, merhamet, merhamet...

Diye inledi. Böyle inlerken, ansızın aczinden, Allah'a karşı yaptığı arsızlıktan utandı. İsyan etti:

- Allah'ım, benim vücudumu yarattın. Onu ıstıraplarından da sen kurtar! Sana yalvarıyorum, mutlaka bana «bir binecek şey» göndereceksin, üzerine eserini yükleteceğim. Göndermezsen... Senin ağır, senin sefil eserini taşımayacağım. Burada yıkılıp yatacağım. Sana inat, açlıktan, susuzluktan, sıcaktan öleceğim. Sen görücü, bilici, işiticisin. Gökler gözün, kâinat aklın, âlem kulağındır. İşit, hem bil ki, bana bir «binecek» göndermezsen, buradan bir yere kımıldamayacağım, gebereceğim. Leşimi kargaların yediğini göreceksin. «Binecek» göndermezsen, Allah'ım, bu yokuşu kat'iyyen çıkmayacağım. Geriye de gitmeyeceğim...

Hakkını haykırmış bir asi sükûnuyle mağrurlanarak, sustu. Yavaş yavaş gözlerini kapadı. Evet, Allah mutlaka bir «binecek» gönderecekti. Bu, eserini seven merhametli Allah'ın en birinci vazifesiydi.

Zavallı Derviş Hasan, açlıktan, sıcaktan, ihtiyarlıktan o kadar yorgundu ki... Hemen uyuyuverdi. Yüz yıl kadar uzun süren bir rüya görmeğe başladı; bir şehre vali oluyordu. Saraylar, cariyeler, köleler... Mermer havuzlara neftî gölgeleri düşen büyük ağaçlı bahçeler, altın işlemeli köşkler, sümbüller, güller... Sazlar, bülbüller, şaraplar, sakiler; mahbuplar... Bütün bunların ortasında esirden yaradılmış gibi nazik, zarif, altın haşalı, beyaz, şeffaf bir at kişniyor, tepiniyor, şaha kalkıyordu. Derviş Hasan, bir kolunda mahbuplar, öteki kolunda cariyeler, arkasında genç köleler, menekşe, yasemin kokuları, saz, ney sedaları içinde bu küheylâna doğru yürüyor, binmeğe çalışıyordu. Mahbuplar üzengileri tutuyor, cariyeler gemi kasıyor, köleler koltuklarından kaldırıyorlardı. Tam bineceği zaman küheylân birdenbire döndü; kafasına öyle bir çifte attı ki... Mahbuplar, cariyeler, köleler birbirine karıştı. Etrafında ne varsa tuzla buz oldu. Gözünü açınca, iri bir Yürüğün, başında zebani gibi dikilmiş durduğunu gördü:

- Kalk bakalım, derviş baba, bu kadar uyku yetmez mi?

- Eyvallah oğlum, iyi ki uyandırdın.

Gülümsedi. Gördüğü rüyanın henüz sönmeyen tadıyle gerindi, doğruldu. Çeşmenin biraz ilerisinde, yüklü, yüksüz birçok atlar, katırlar duruyordu. İşte her şeyi gören, işiten, bilen Allah, istediğini göndermişti. Hem bir tane değil, sürü ile...

Yörüğe sordu:

- Nereye gidiyorsunuz, evlât?

- Kazdağı'na.

- Ben de oraya...

Hiç şüphesiz, bu Yürükler, kendine bir at verirlerdi. Başında sırıtarak, dikilen Yürüğe baktı. Döndü, tekrar çeşmenin başına baktı. Birçok boş semerli hayvan vardı. Tam ağzını açacağı vakit Yürük dedi ki:

- Derviş baba, bize bir yardım edeceksin.

- Ne gibi?..

- Şuracıkta, kısraklarımızın biri doğurdu. Doğan tay yokuşu çıkamayacak. Biz de pek yorgunuz. Sen uyumuş, dinlenmişsin. Gel, sevabına, şu tayı kucağına al da, yokuşun başına kadar çıkarıver.

Derviş Hasan, gözlerini fal taşı gibi açtı:

- Ne?..

Diye haykırdı. Yürük:

- Ağır değil, yeni doğdu, beş, altı okka ya gelir, ya gelmez, dedi; hem yokuşun başına kadar... Haydi, sevabına...

- Ben sevap filân istemem.

- Hıyanetlik etme derviş baba, hepimiz Müslümanız, yapma, din kardeşlerine acı...

Hiddetinden boğulacak gibi olan Derviş Hasan, geldiği ciheti göstererek:

- Ben Kazdağı'na gitmiyorum. Yolum bu taraf, Dedi. Ama Yürük laf anlayacağa benzemiyordu:

- Zarar yok derviş baba. Sen tayı yokuşun başına kadar çıkar, sonra yine iner, o tarafa gidersin.

Derviş Hasan, hiddetinden sanki deli oldu. Sevaba, Müslümana, din kardeşlerine sövmeğe başladı. Yürük, arkadaşlarını çağırdı. Bunlar öyle ağız patırtısına pabuç bırakır takımından değildiler. Derviş Hasan'in başına üşüştüler, tekme, tokat, döve döve kaldırdılar. Yeni doğan tayı zorla kucağına vererek önlerine kattılar. Derviş Hasan, sırtına, beline, uyluklarına yediği tekmelerin altında büsbütün sersem, hatta «eyvallah» bile diyemeyerek, nefes nefese yokuşu tırmandı. Yalnız yeni doğma, ıslak «binecek şey»in ekşi, keskin kokusunu duyarak yüzünü buruşturuyordu. Tepeye çıkınca açlıktan, sıcaktan, ihtiyarlıktan ziyade tayın ağırlığından yorgun, yere yıkıldı. Gözlerini göğe, Allah'ın her şeyi gören büyük gözüne dikti. Bu mavi gözün nihayetsiz bakışında:

«Gönderdiğim bineceği beğendin mi?»

Diyen bir istihza vardı. Derviş Hasan, sesini çıkarmadı. Tekrar gözlerini kapadı. Dünya zahitleri tarafından binlerce seneden beri o kadar ibadet, o kadar taleple taciz edilen Allah'ın, şüphesiz artık «istenildiği gibi» değil, «istediği gibi» vermek en haklı bir hikmetiydi. Kabahatin kendisinde olduğunu anladı! Deminki isyanına pişman oldu. Şimdi uzaklaşan Yürük hayvanlarının gittikçe derinleşen çıngırak seslerini işitiyor, çıkmayan sesini bu yeknesak çıngıraklara uydurarak, «istediği gibi veren»den bir daha «bir şey istemeğe»:

«Tövbe, tövbe, tövbe!»

Diyordu.

# Bir Hatıra

"Le grade dégrade.."

Ah gençlik!.. Tıpkı ezeli bir baharın ilk çiçekli günlerine benzer. Yeşil kırlar, kelebek dolu bahçeler, güzel kokular içinde serçelerin şen efsanelerini doymadan dinleyerek dolaşırız. İdealimizin rüyası bize hayat kışının fırtınalarını, karlarını, tipilerini hatırlatmaz. Ben işte bu hiç bitmez sanılan baharı İzmir'de geçirdim. On dokuz yaşındaydım. Galiba on beş sene evvel... Evet, seneler nasıl bir ok gölgesi gibi uçuyor! Meşrutiyetin bu hür, bu serbest günlerinden çok uzaktık. Lâkin o eski, zalim idarenin ezici kahrını, gafletim sayesinde hiç duymuyordum. Mersinli'deki minimini evimde, kocaman çınar ağaçlarının hiç durmadan öten ninnileri içinde, kitapların dipsiz girdabına dalmış gitmiştim. Haricî kainat umrumda değildi. Sözde, felsefe feneriyle büyük bir hakikat bulacaktım. Heyhat! Şimdi bu masum hülyamı aklıma getirince, nasıl acı acı gülüyorum... Bir kelimeyi, bir satırı, bir sözü haftalarca, aylarca düşünür, bir cümlenin altındaki —var tevehhüm ettiğim— gizli mânâyı bulmak için birçok geceler uyuyamazdım. Filozofların pek o kadar mânâ murad etmeden yumurtladığı fikirler, bence bir "ilahi nass" gibiydi. Hatta romanlarda rasgeldiğim "ukalalık"lar bile gözümden kaçmazdı. Onları da fişlere yazar, notlarımın arasına kordum.

Bu "ukalalık"lardan birisi, beni tam üç ay düşündürdü. Tam yüz beş gece gözüme uyku girmedi. Flaubert'in miydi, yoksa bir başkasının mı, iyice hatırlayamıyorum. "Le grade dégrade...", yani: "Rütbe, haysiyeti düşürtür." cümlesi! Bundan bir türlü mânâ çıkaramadım. Bilakis, fikrimce rütbe insanı herkesin seviyesinden yukarı kaldırır, yükseltir, hatta sahibine hususi bir haysiyet verirdi. Artık başka kitap, gazete falan okuyamaz oldum... Her satırın altında, mânâsını anlamadığım bu "Le grade dégrade.." cümlesi kararıyor, bir avuç istifham işaretinden yuğrulmuş sabit bir fikir gibi dimağımda düğümleniyordu. Sakin evimde oturamıyor, bulamadığım mânâyı arayarak tenha sahillerde, kalabalık caddelerde, dar sokaklarda serseri serseri dolaşıyordum. Bir "meçhul", bir "sır" insana ne kadar ıztırap verir; bâhusus masum bir iman da olursa... Bir gün yine deli gibi, içimden: "Le grade dégrade..." diye söylenerek Hükümet Konağı'nın önünden geçiyordum. İsmimi işittim. Döndüm. Bir de baktım ki, riyâziye muallimim, Logaritmacı Hasan! Askerî Kıraathanesinin ta köşesinde bir sandalyeye kurulmuş nargilesini çekiyor...  
— Nereye böyle?  
— Le gr.. şey! Hiç..  
Diye kendimi topladım.  
— Çok dalgınsın.  
— Evet.  
— Gel otur da, kahve iç bakalım. Dalgınlığın geçer.  
Dedi. Gösterdiği sandalyeye iliştim. Kalıpsız fesini taş masanın üstüne koymuştu. Açık, yüksek alnında çok sık, çok kır saçları bir arslan yelesi gibi muntazam bir dağınıklıkla kabarıyordu. Parlak gözleriyle beni bir süzdü:  
— Sana ne olmuş, dedi, betin benzin solmuş!  
— Hiç...  
— Söyle, söyle.  
— Üç aydır küçük bir cümlenin mânâsını arıyorum da...  
— Bulamıyorsun ha? diye güldü.  
— Evet.  
Dedim. Başını salladı:  
— İşte riyâziyeye çalışmamanın cezası! Dünyada ancak bir ilim vardır o da riyâziyedir. Onu bilen, her şeyi bilir. Başka ilimler hep safsatadır.  
— Ben felsefeyle uğraşıyorum.  
Diye lafını kestim.  
— Daha iyi ya... Bütün bütün atmasyon! İspata muhtaç olmayan bir şey.  
O vakit ben de gençliğin boş gururuyla canlanmış, mutaassıp bir felsefe hamiyeti vardı. Bu küfür canımı sıktı. Vâkıâ logaritmacının paradoksal bir adam olduğunu biliyordum. Ama yine kendimi tutamadım:  
— Sen riyâziyecisin! dedim, ama her cümlenin, her kelimenin mânâsını anlar mısın?  
— Anlarım. Bence meçhul yoktur.  
— Mânâsını ihâta edemediğin bir söz olmaz mı?  
— Olmaz! Pascal, Newton, Leibnitz, Goos, Auguste Comte... Daha sayayım mı! Hasılı dünyada ne kadar hakikate benzer müsbet bir şey meydana koymuş âlim, filozof varsa niçin hepsi riyâziyecidir? Çünkü fikirler mücerrettir. Dünyada hiçbir fikir yoktur ki, riyâziyenin tecrit çerçevesinden hariç kalsın.  
Logaritmacı, hislerimizin işaretleri olan isimlerin, tâbirlerin, hatta vasıfların şuurumuzda nasıl başlı başına bir "mücerredât" âlemi teşkil ettiğini, bu âlemin nâzımı ancak riyâzî mantık olduğunu uzun uzadıya anlatmaya başladı. Garson kahvemi getirdi. Yudum yudum içiyor, şuna "benim cümlenin mânâsını bir sorayım" diyordum. Nutkunu en coşkun yerinden kestim:  
— "Le grade dégrade!" ne demektir, hocam?  
Diye sordum.  
— "Le grade dégrade!" evet, "Rütbe tenzil-i, kadr ü haysiyeti mûcip olur!" değil mi?  
— Fakat bundan ne anlıyorsun?  
— Bayağı mânâsını anlıyorum işte...  
— Rütbe, haysiyeti bozar mı?  
— Bozmaz mı?  
— Bozar mı?  
. . . . . . . . .

Münakaşaya başladık. Logaritmacı evvela "tâbir"leri tarif ettirmek istiyordu. Önce "haysiyet" kelimesini, tarif edemeyen, hududunu çizemeyen kullanmamalıydı. Bana sorduğu suallere kendi cevap veriyordu: "Mesela haysiyet, yani dignité" diyordu, büyük, küçük, âlim, cahil, zengin, fakir, âli, adi, şah, gedâ, hırsız, uğursuz... hasılı herkesin kendi nefsine mahsus hususi bir haysiyeti vardır. Bu haysiyetle yaşarsa gülünç olmaz. Bu şahsî haysiyet herkesin tabiatine o kadar girifttir ki... Nasıl anlatayım? Mesela her hayvanın kendisine mahsus şekli, tüyü, sesi gibi... Sarı gagalı beyaz bir kaz ne kadar tabiî, ne kadar mantıkîdir. Ama şimdi bu kazın rengini yeşile boyasalar, gagasını ördek gagası gibi yassıltsalar, ne tuhaf olur. Yahut fino köpeğinin kafasına bir çift eşek kulağı, gergedan boynuzu takılsa... Kedi kişnetilse... At havlatılsa... Düşün, mahluklar ne maskara olurlar! İşte insanlar da böyledir. Kendi içtimaî seviyelerine, tabiî mevkilerine uymayan bir vaziyet onlara ibrâm edildi mi, hemen düşer, rezil, rüsva olurlar.." Lafını, kıyaslarını, misallerini uzatıyor, eldiven gibi vücuda tıpatıp oturan elbiseler insanı nasıl güzelleştirirse, bol yahut küçük gelenler de palyaçoya çevirdiğini söylüyordu. Ben dinliyordum. Mevki ile sahibinin arasında samimi bir münasebet bulunmazsa, vaziyetin çok gülünç olacağına pek akıl erdiremiyordu. Önümüzden atlı tramvaylar, arabalar, insanlar geçiyordu. Logaritmacı, benim anlayışsızlığımı görünce, yine mektepteki tavsiyelerini tekrarlamaya başladı. Ben, artık yalnız dinler gibi davranıyor, yine cümlenin mânâsını dalga geçiyordum. Birden haykırdı:  
— Bak işte!  
— Ne?  
Diye gösterdiği tarafa döndüm.  
— Sorduğun sözün canlı mânâsı...  
— ......  
Baktım. Salepçioğlu Hanı tarafından kır sakallı, şişmanca bir adam, arkasında iki üç zeybek, sallana sallana geliyordu.  
— Kim bu?  
— Dikkatli bak.  
Pantalon azmanı koyu mavi dar bir çakşır, üstüne şık bir smokin giymişti. Başında ince, âbânî bir sarık vardı. Temiz bir işkence aletine benzeyen, gayet yüksek yakalı, beyaz gömleğinde boyunbağı yoktu. Gözlerinde altın gözlükler, göbeğinin üstünde kalın bir altın zincir... Sanki bir tarafa dokunmasın diye dikkatle vücudundan ayrı tuttuğu ağır tesbihi elinde, kırıta kırıta yürüyordu. Kolları, koltuklarının altında birer zaviye-i kaaime hâsıl edecek derecede kabarmıştı. Arkasındaki maiyeti paltosunu, şemsiyesini, bastonunu taşıyordu. Kendimi tutamadım. Pufkurdum:  
— Ayol, bu ne?  
— Dikkatli bak.  
Bu küçük alay, sallana, süzüle önümüzden geçti. Âbânî sarıklının arkasındakiler taşıdıkları şeyleri mukaddes emanetlermiş gibi göğüsleri hizasında tutuyorlardı. Gülüyordum. Acaba bir Apokurya şakası mıydı? Logaritmacı:  
— Gördün ya.... Dedi.  
— Ne bu Allah aşkına?  
— İzzet Holo'nun bir cinayeti!  
Anlamadım, tekrar sordum:  
— Ne cinayeti?  
— Söyleyeyim, dedi. Bu adamcağız tarlalarının içinde kendi haberi olmadan, büyük bir maden damarı çıkan cahil bir köylüdür. Yedi sekiz sene evvel köyünde gayet tabiî bir hayat geçiriyordu, okuyup yazması yoktu. Fakat gayet ciddi bir haysiyet sahibiydi. Beş vakit namazını kılar, sözü dinlenir, herkesten hürmet görürdü. Fakat kendi taksiratı haricinde parası çoğalınca çiftini çubuğunu bıraktı. Sık sık İzmir'e gelmeye alıştı. Sonra...  
— Ey, sonra?  
Diye sabırsızlandım. Güldü.  
— Sonra nasıl olmuş bilmiyorum, bir kolayını bulmuş, başkâtip İzzet'e her sene turfanda üzüm falan filan göndermeye başlamış. İzzet'in işi yok! Tutmuş bu zavallı adama, bol keseden, bir "mîrimiranlık" rütbesi vermiş! Memiş Ağa birdenbire Memiş Paşa oluverince... İşte bu gördüğün vaziyete girdi. Şimdi İzmir'e geldi mi, en açık havalarda bile, arkasında ayrı ayrı paltosunu, bastonunu, şemsiyesini taşıyan uşaklarıyla: "Ben paşayım, bana bakınız!" der gibi, kabara kabara dolaşır. Etrafından selam, temennâ, hürmet, takdir dilenir. Ama görüyorsun, ne acıklı, ne gülünç bir hal!  
— ......  
Logaritmacıya deminden sorduğum cümlenin mânâsını artık kendim yazmış gibi anlamıştım. Kafamdan —velev ehemmiyetsiz olsun— bir "meçhul"un ağırlığı kalkınca, o kadar ferahlamıştım ki... Başka düşünecek bir şey bulmak için Mersinli'deki minimini evime döndüm. Büyük ağaçların ahenkli fısıltıları içinde yine kitaplarımın dipsiz girdabına daldım.

Hamiş: Şimdi yeni zenginciklerimizin bazı komik muvâzenesizliklerini duydukça, yine bu cümleyi hatırlıyorum, gayr-i ihtiyâri  "Le grade dégrade..." diyorum. Gözümün önüne dar smokinli, mavi çuha çakşırlı, âbânî sarıklı Memiş Paşa'nın kabaran hayali geliyor...

# Bir Kayışın Tesiri

Bir zabit arkadaşımla oturuyorduk. Yanımızdaki masada iri, palabıyıklı, kocaman kalpaklı bir babayiğit, çetin bir Çerkes şivesiyle karşısında sıralanmış irili ufaklı kalpaklılara birşeyler anlatıyordu. Daha Kafkasya'dan yeni gelmiş sanılacaktı.

- Demek yollar açıldı, dedim.

Arkadaşım,

- Hangi yollar? diye yüzüme baktı.

- Hangi yollar olacak, Karadeniz yolu.

- Nereden bildin?

- Baksana şu hemşeriye... İşte mutlaka yeni gelmiş olacak.

- Hangi hemşeriye?

Sağımızdaki, yanağından kan damlayan iri Çerkesi gösterdim. Arkadaşım bir kahkaha attı. Azıcık daha katılacaktı.

- Çerkes taklidi yapar!

- Güldürmek için mi?

- Hayır.

- Ya niçin?

- Kendini Çerkes zannettirmek için.

Tekrar koca kalpaklı babayiğide baktım. Hiç Türkçe bilmez bir Çerkes fesahatiyle başını ağır ağır sallayarak elindeki gümüş savatlı kamçıyı çizmelerinin uzun konçlarına vurarak, takır tukur konuşuyordu. Sandalyeye ata biner gibi binmişti.

- Şaka etme, dedim, bu halis muhlis Çerkes...

Arkadaşım yemin etti:

- Vallahi değil...

- Ne biliyorsun?

- Nasıl bilmem, benim sınıf arkadaşım.

- Ne gülüyorsun?, dedim.

- Ayol o Çerkes değildir! dedi.

- Ey, lisanına ne diyeceksin?

- Zabit mi?

- Evet, fakat cuma günleri böyle Çerkes gibi giyinir.

Merak ettim:

- Çerkes değil diyorsun, Gürcü mü?

- Hayır.

- Çeçen mi?

- Hayır.

- Lezgi mi?

- Hayır.

- Ya ne?

- Türkoğlu Türk!

- Nereli?

- İstanbullu... Anası Germiyanzadelerden. Babası... Mirliva olduğu halde daha dilini düzeltememiş bir Kastamonulu idi...

O halde bu Türk, niçin herkese kendini Çerkes zannettirmek istiyor? diye sordum. Arkadaşım tekrar bir kahkaha attı.

- Bak sana anlatayım niçin, dedi. Bu sahte Çerkesin adi Mahmut Beydir. İdadi ikinci sınıfa kadar hiçbir milliyet iddiası yoktu. O sene ramazan tatilinde bir arkadaşı kendisine Karamürsel'den gayet zarif bir Çerkes kayışı getirdi. Bu kayışı hepimiz gördük. Hakikaten nefisti. Gümüş savatlı tokaları ağır, kayışı siyaha yakın koyu lacivertti. Gümüşten üç büyük sarkıntısı vardı. Mahmut bey bu kayışı beline taktı. O günden itibaren Türklerle konuşmamağa, hep Çerkeslerle düşüp kalkmağa başladı. Ertesi sene hiç tanıdığı olmadığı halde tezkere getirerek Karamürsel'e sılaya gitti. Harbiyeye geçtiğimiz zaman Mahmut Bey, Türk şivesini kaybetti. Büyük fedakârlıklar yaparak piyadeden süvariliğe becayiş etti. Zabit çıktığımız zaman Türkçe’yi unutmuştu. Ama, Çerkesceyi de öğrenemedi. Öğrendiği mükemmel bir Çerkes şivesiydi. Adını alay için "Çerkes Mahmut" takmıştık. O buna kızmaz, hatta iftihar ederdi. Zabitken meşhur bir Çerkes paşaya intisap etti. Onunla İstanbul'a sürüldü. Kafkasya'ya kaçtı. Milleti ile hiç münasebeti olmayan yerleri öz vatanıymış gibi gezdi, dolaştı. Bir Çerkes kızıyla evlendi. Hürriyetten sonra İstanbul'a geldi. Artık işi gücü Çerkeslik için çalışmak oldu. Her yerde şu işittiğin garip şive ile "Adige" propagandası yapmağa başladı. Kastamonulu paşa babasından kalan serveti Çerkes Tarihi'ni yazacak muharrire adadı.

Kafkasya'dan yeni gelmiş sandığım sahte Çerkes Türke tekrar baktım.

- Acaba akrabaları içinde Çerkes filan yok mu?

Arkadaşım,

- Yok be yahu! diye elini taş masaya vurdu, halis muhlis Türk diyorum! Hâlâ bir kelime Çerkesce bilmez. Sınıf arkadaşımın Karamürsel'den getirdiği Çerkes kayışında sanki bir tılsım vardı. O andan itibaren Çerkeslik sevdasına düştü.

Arkadaşım yarım saat kadar Çerkes Mahmut beyin gülünç menkıbelerini anlattı. Hâli tavrı son derece babayiğitvari olan bu kahraman, meğer ömründe hiçbir muharebeye girmemiş. Son derece korkakmış. Daima tanıdıklarının iltimasıyla seferberlik zamanını geri hizmetlerde geçirmiş.

Biz konuşurken Çerkes Mahmut bey gülerek, yanındakilere Çerkesce şakalar ederek kalktı. Büfenin önünde durdu. Para veriyordu. Çantasını pantolonunun cebinden çıkarırken gördüm. Belindeki yirmi sene evvel Karamürsel'den hediye gelen kayışın savatlı gümüş sarkıntıları pırıl pırıl parlıyordu. Türklerin hariçten kendi içlerine gönüllü bir tek "Millettas" celbedecek böyle ehemmiyetsiz kayışçıkları bile olmadığını düşündüm.

# Bir Refikin Defter-i İhtisasatından

Şirket-i Hayriye vapuru açılan bir sine-i seyyal-i mâ içinde süzülerek ilerliyordu. Çarkların aheng-i muttaridi içinde titreyen ruh-ı samtın sine-i tesliyetine bazen küçük bir nağme yayılıyor, ve sonra o ıttırâd-ı sükûn devam ediyordu. Gâh ü bî-gâh riyâh-ı mesânın daha uzaklardan getirdiği bir ses, bir nağme-i hırâş ile başlayarak kesiliyor yine başlıyor, ve cevr-i garibin gâze-i samtından inleyerek bir enin-i sükûn gibi akşamın afak-ı dûrâdûru içinde titreyip sönüyor, nihayet kendine bir melâz-ı sükûnet buluyordu. Aksi bir cezbe-i rüzgâr vapurun siyah dumanlarını Mirgûn’un bir tutuk-ı hülya perver içinde uyuyan bayırcıklarına doğru sevk ederken ruhumda sakin ve masum bir hayalin mevâlîd-i firakını dinliyordum.

Vedîa-i ulviyet-i hayalim olarak gecenin, bu Mirgûn’un leyle-i ruhanîsinin, ünsiyet-i samimanesine ihdâ edilecek elhân-ı münâcâtı düşünürken yeşil bir türbeciğin küçük ormanına gelmiştim.

Gecenin bütün ruhaniyet-i şiiri pîş-i nevîn-i fikretimde bir şehper-i ilham suretinde titredi: Bazen sana bir kürsi-i sünûhat olan bu müstesna tepecikte şimdi sensiz olarak bir gaşy-ı münbasitle bulunuyordum. Boğaz’ın bir silsile-i medîd-i mehasin içinde uzanan tepeleri hâbide şiir ve hayal olmuş, ve bir kerime-i visal gibi râkid ve sakin bunların âguş-ı harîm-i sevdasında deniz huzur-ı ruhumda uyuyan derin bir şiir-i güzîn-i ebed ulviyetiyle öyle mest-i garam kalmıştı. Sonra kamerin, bu enîs-i şiir-âlûd-ı leyâlin, mirvaha-i iltimâı a‘mâk-ı târ-ı ebhâra kadar süzülüp gidiyor ve sahillerden dökülen mülevven birer hayt-ı mînâ bu lema-i amud-ı nûranî içinde bir lü’lü’-i perran oluyordu.

Şimdi belki senin de zîr-i sürûd-ı nigâhında açılan bu semâyı bedâyide şemîm-i füsûnundan bir nükhet-i sevda duyarak öyle bir gaşy-ı manzum içinde idim. Nâgehân senin ekseriya pancurlarını açarak dalgaları seyr ettiğin odana baktım. “Ah... belki” dedim.

Sonra yine denize ibzâl-i nigâh eylerken bir seyr-i seri‘-i ihtizazkâr ile uçar gibi süzülen bir sandal mihr-i leyâlin lemaâtını parçalayarak ilerledi. O zaman her lema bir perîde-i emel, her dalga bir ümid-i visal, her ümit bir emel-i nevîn-i vefa oldu. Bu bir sandal idi, sevgilim geçti. Her şey halecân-ı vuslatla titreyerek bir penâh-ı rüya oldu. Fakat niçin, ey yâr-ı füsunkâr, bu ruh-ı melûl ü sevdakâra rûh-ı güzîn-i şiirinle bir lâne-i serap bulunmuyor.

# Bir Temiz Havlu Uğruna

BİR TEMİZ HAVLU UĞRUNA

"Balık istifi” denilen o kımıldanmaz, o nefes almaz kalabalıkla taşacakmış gibi dolu olan Şirket vapurunun kenarında, kaptan kulesinin altındaki dört ince, beyaz demir direğin içine, üç arkadaş çömelmiş, savaştan, parasızlıktan, bulgurdan bahsetmemek için eski zamanları hatırlıyor, dertleşiyorduk! Hava sıcaktı. Boğaz'ın tepelerindeki tek tük korular parlıyor, deniz düz mavi bir kadife gibi uzanıyordu. Başka milletlerin elinde olsa, bizim içinde yalnız sıkıntı duyduğumuz bu eğlencesiz, bu zevksiz, bu neşesiz İstanbul, kim bilir nasıl bir dünya cenneti olurdu? Babalarımız bu güzelliklerden istifade etmişler, yemişler, içmişler, sevmişler, sevilmişler, zevk içinde, heyecan içinde hayatlarını geçirmişlerdi. Biz şimdi babalarımıza benzemedikten başka, onların zevklerini ayıplamaya bile kalkıyorduk. O kadar kabalaşmış, alıklaşmış, aptallaşmıştık.

İsmini hatırlayamadığım eski okul arkadaşım:

"Ah keşke biz o vakitler dünyaya gelseydik...” dedi.

Bu kumral saçlı, kesik, kumral bıyıklı şişman bir kalem beyi idi. Yirmi beş sene evvel Sarıyer okulunda beraber okumuştuk. O ne olmuştu? Bilmiyorum. O da tabii benim ne olduğumu bilmiyordu. Yalnız rast geldikçe selamlaşıyorduk. İşte o kadar...

Öbürü?... Onun da ismini bilmiyordum. Galiba Gülhane Rüştiyesi'nden arkadaşımdı. Kıyafetinden onun da bir kalem beyi olduğu anlaşılıyordu.

"Âmin denemeyecek boş bir dua...” diye başını salladı.

Pek zayıf, pek asabiydi. Merhum babasından dinlediği eski Boğaziçi âlemlerini, mehtap eğlencelerini anlatmaya başladı. Bebek Koyu hep kayıkla dolamış. Bahaî körfezinden, Kör Tahsin Bey yalılarının önünden geçilemezmiş. Gazeller, sazlar, ahlar şafağa kadar devam eder, bu genel ahenkten asabileşen bülbüller, sabahleyin güneş doğduktan sonra bile ötmekten vazgeçmezlermiş.

Şimdi, şimdi, şimdi...

Acı acı gülümseyen kumral, çocukluk arkadaşım canlı tahtelbahirler1 gibi bata çıka vapurla yarış yapmaya çalışan yunus balıklarını göstererek,

"Bütün Boğaz'ın keyfi, eğlencesi, mehtabı bunlara kaldı” dedi.

Öbürü dalgın gözlerle karşı sahile bakmaya başladı. Bir sessizlik... Artık çarkın patpatlarını duyuyorduk!

Ben bu sıkıcı sessizliği bozdum:

"Aslında dışarıda mesut değiliz” dedim, "fakat evimizde? Çoluğumuzun çocuğumuzun arasında? Hayatımızın her türlü yokluklarını unutmaz mıyız?'

İkisi de manalı manalı gülümsedi. Kumral şişmancası, azarlanmış bir çocuk küskünlüğü ile denize baktı. Öbürü yüzünü ekşitti:

"Yarama dokundun.” dedi.

Anlamadım, sordum:

"Ne demek?”

"Bütün hayatımca sürecek bir kanserin ta üzerine bastın...”

Yine anlamadım:

"Yani, aile hayatında da mesut değil misiniz?”

"Mesutluk şöyle dursun, bilakis çok bedbahtım."

"Sebebi görünür bir şey değil ki, söyleyeyim.”

Kumral şişman da gözlerini dalgalardan kaldırdı.

Benim gibi sordu:

"Söyle, niçin mesut değilsin bakalım?”

Zavallı, yüzünü daha beter ekşiterek uzamış tıraşlarını kaşıdı. Tepesi dökülmüş başı kocaman bir bilar- do yuvarlağı gibi muntazam, gayet parlak, gayet beyazdı.

"Niçin mi?” dedi. "Haydi derdimi anlatayım size...

Malum ya, gönül kimi severse güzel odur! On beş, yirmi sene evvel şimdiki gibi görme görüşme, sevme sevişme yoktu. Evlenmek tamamıyla ezberden kötü bir şeydi. Ben evleneceğim zaman, görücü gezmeye çıkacak anneme gönlümün sevdiği tipi tarif etmedim. Mesela,

Uzun boylu, ela gözlü, ablak çehreli, kâfuri beyaz olsun... filan gibi bir şey söylemedim. Yalnız sevmediğim şeyleri söyledim. Nefret ettiğim üç hal vardı. İhtimal bu üç hal ayrı ayrı birer güzellikti. Ama ben nefret ediyorum işte. Mavi göz, kısa boy, muhacirlik...

Anneciğim dedim, gözü mavi, boyu kısa, kendi muhacir olmasın... Ne olursa olsun, makbulüm! Aman bu üçüne dikkat et. Beni yakma.

Rahmetli annem dikkat edeceğine tekrar tekrar yemin etti. Kız aramaya başladı. Dünyada en hoşlanmadığım şey kadın boşamaktır. Evlenişim hem ilk, hem son olacaktı. Uzatmayayım, annem kızı buldu. Bana bir övgü, bir övgü... Tabii inandım. Nikâh oldu. Koltuğa girdim. Bir de duvağı kaldırınca ne göreyim: Çiğ mavi iki göz...

Ayakta duruyordu. Baktım, başı benim belimin hizasına bile gelmiyordu. İsmini sordum. Konuşmaya başladık. Ah o siygalar, o muhacir siygaları... Geliri, gideri, yaperi, ideri! Gözlerim karardı. Sanki dünya kafama yıkıldı. Vurulmuş gibi koltuktan çıkarken annem beni tuttu:

— Nasıl yavrum, memnun oldun ya?

— Allahtan bul, anne, beni yaktın dedim.

— Niçin, diye şaşaladı.

Merdivenin başında duruyorduk. Biraz ilerdeki kadınların işitmeyeceği kadar yavaş bir sesle konuştuk: Ben sana, mavi gözlü olmasın, demedim miydi?

— Çok güzeldi! Onun için maviliğine dikkat etmedim.

— Boyuna ne diyeceksin?

— Yaşı küçük. Daha büyür oğlum.

— Ey, muhacirliğine?...

— Muhacir ama, çok asilzade! Soyu sopu belli. Ona tamah ettim.

Ayrılmak, bilhassa 'ezberden evlenme' usulünü kabul ettikten sonra ayrılmak, büyük bir cinayetti; zavallı kızın ne kabahati vardı? Hiç bozuntuya vermedim. Talihine razı olmuş bir esir gibi ocağıma sadık kaldım. Beş çocuğum oldu. Gelinlik bir kızım yetişiyor. Düşünün, insanın nefret ettiği, sinirlerine dokunan hallerle ölünceye kadar girift kalmasın! Mavi göz, kısa boy, muhacirlik... Karımın boyu bir santimetre bile büyümedi. Asilzadeliğinden de bir şey anlamadım. Gözleri çok güzelmiş derler. Hâlbuki ben mavi duvarlı cennet bile olsa içine girmek istemem. Şimdi böyle zevkimin taban tabanına zıddına kurulmuş bir yuva bana ne kadar saadet verebilir? Dışarıdaki mahrumiyetlerimi evimde unutabilir miyim, söyleyin...” Sesimi çıkaramadım.

Kumral şişman acı acı güldü. Dedi ki:

"Ailem hakkında şimdiye kadar kimseye bir şey söylemedim. Hem böyle gevezelikleri âdeta namussuzluk sayarım. Ama şimdi icap etti. Dertliler gibi hasbıhal2 ediyoruz. Birbirimizi ayıplayacak halimiz yok.

Ben de senin gibi ezberden evlendim, ama kendim istemedim. Gençken meramım ölünceye kadar bekâr kalmaktı. Bir akşam annem damdan düşer gibi,

— Eğer evlenmezsen sana hakkımı helal etmem, dedi.

Gayet uygun bir kız bulduğunu söyledi. Şart mart koymaya meydan vermedi. Beni sıkboğaz etti. Ne mizacıma, ne zevkime, ne arzuma önem verdi. Mesela ben okur yazar şeytanca, şuh bir kadın isterdim. Esasen sükûndan, sessizlikten nefret ederim. Annemin pek uygun bulduğu kız son derece sessiz, iki lafı bir araya getiremez, durgun, okuyup yazması yok, anlayışsız bir zavallıydı. Annem asilzadelik filan düşünmemişti. Bir gün nasılsa Kocamustafapaşa'ya, Sümbülefendi'yi ziyarete gitmiş. Sokakta aptesti sıkışmış. Rast gele bir kapıyı çalmış. Kapıyı mahcup bir kız açmış. Annem abdest almak istediğini söylemiş. Kızcağız,

— Buyrun, hanım nine, diye hiç tereddüt göstermeden annemi içeri almış. Yerlerin, merdivenlerin, musluğun temizliğine annem bayılmış. Abdest aldıktan sonra, bu kızcağız hemen karşısına koşmuş, gayet temiz, gayet beyaz, ütülü, mükemmel bir havlu tutmuş. Annem bu ikrama, bu terbiyeye bütün bütün bayılmış:

— Kızım senin annen, baban var mı', diye sormuş.

— Var, efendim cevabını almış.

Kızcağızın ezilip büzülmesi daha ziyade hoşuna gitmiş. Lütuf damarları kabarmış:

— Benim bir oğlum var, ister misin, seni ona alayım, demiş.

Kız utancından kıpkırmızı kesilmiş. Hiç cevap verememiş. Annem bu sükûtu ikrar saymış3. Sümbülefendi dönüşünde tekrar eve uğramış. Ama bu sefer abdest almaya değil.. Görücü gibi! Adresimi vermiş. Kendine temiz havlu tutan kızı annesinden, Allahın emriyle, peygamberin kavliyle istemiş! Benim hiçbir şeyden haberim yokken iş olup bitmiş! Evvela karşı koymak istedim. Annem,

— Vallahi kendimi öldürürüm. Ben söz verdim.

Hakkımı sana helal etmem, diye ayağa kalktı.

Nihayet bu temiz evin, temiz kızıyla evlendim. Kadınlık adına düşündüğüm şeylerin hiçbirini karımda bulamadım. Doğrusu şimdi yalımızın her yeri bir hamam kadar temiz... Tavanlar bile sabunla ovulmaktan parıl parıl parlıyor.

Havlularımız hep ketenden... hep ütülü! Keskin keskin lavanta çiçeği kokuyor... Ama bunlar benim için bir saadet değil... Benim de çocuklarım oldu. Temiz temiz büyüdüler. Fakat düşünün, hayatımın en mühim emeline annemin bir abdesti hâkim oldu. Talihimi bir temiz havlu temin etti. Evet, ben bir temiz havlu uğruna yandım. Bir temiz havlu uğruna...”

Vapur, Sarıyer'e yanaşıyordu. Kalktık. Ufki parmaklıkların arasından birer birer güverteye geçtik.

Çömelmekten bacaklarımız öyle uyuşmuştu ki... Tıpkı oğullarına kız aramaya giden romatizmalı anneler gibi, badikleye badikleye yürümeye çalışıyorduk.

# Bomba

Ali Süha Bey'e

Duvarları ve tavanı uzun bir kışın isleriyle kararmış bu yer odasında mahpus gibi duran bodur ve çirkin ocak, içindeki odunları sanki hiddetle yakıyor, bir an evvel yutmaya çalışıyordu. Hızla tutuşarak uzayan ve sönen alevler, mandolinle heyecanlı sosyalist marşını çalan genç Boris'i, karşısında ezelî ve nihayet bulmaz millî çorabını ören güzel karısı Magda'yı hafif ve akıcı bir kırmızıya boyuyor, bütün odayı kaplayan büyük ve kötürüm gölgelerini titretiyordu. Dışarıda vahşi ve soğuk bir şubat gecesi vardı. Kudurmuş bir rüzgar küçük pencerenin örtülmüş kapaklarına çarpıyordu. Ortadaki kalın ayaklı kaba ve iri masanın etrafında, yine kaba ve biçimsiz sandalyeler duruyor, çalınan mandolinin keskin sesini dinler gibi uyukluyorlardı. Ocağın üstündeki harap ve ihtiyar saat gece yarısının geçmiş olduğunu gösteriyordu. Boris mandolinini duvara dayadı. Ayağa kalktı. Birden tavanı kaplayan gölgesiyle gerindi. Magda seri tığlarının ucundan güzel gözlerini kaldırdı:  
— Uykun mu geldi?  
Genç ve iri Boris gerinmesine devam ederek cevap verdi:  
— Hayır, hiç uykum yok...  
Ve tekrar oturarak ilave etti:  
— Bilmem niçin, içimde bu gece bir sıkıntı var.  
Magda birden durdu. Çorabını dizlerinin üzerine indirdi. Mütereddid ve şüpheli Slav gözleriyle kocasına baktı. Kaşlarını çatarak:  
— Benim de içimde bir sıkıntı var!..  
Diye söylendi. Boris ancak yirmi beş yaşında vardı. Baba İstoyan'ın bir tanecik oğluydu. Köyünde, Sofya'dan gelen muallimde okuduktan sonra, genç papazın delâletiyle kendisi de Sofya'ya gitmiş, orada tahsilini bitirmişti. Beş sene nihayetinde potursuz ve kuşaksız dönen dinç ve güzel Boris, babasının evinde, ihtiyar anasının yanında çok oturmamış, bir gün dağa çekilip gitmişti. Senede ancak birkaç defa, geceleyin gelir, anasıyla babasıyla görüşür, yine kaybolurdu. Genç Türkler hiç beklenilmeyen Meşrutiyeti ilan edince, o da bütün arkadaşları gibi şehre inmiş, silahını hükümete teslim etmiş ve köyüne gelmişti. Fakat anası yoktu. O, üç ay evvel, "Ah Boris! Ah Boris!" diye diye ölmüştü. Gözlerinin açık kaldığını ve papaz eliyle kapamaya çalıştığı halde muvaffak olamadığını komşular söylüyorlardı. Issız ormanlarda, korkunç kayalıklarda, hep kamersiz gecelerin karanlıkları içinde geçen beş seneden sonra hür ve serbest, parlak ve yeşil köyü pek hoşuna gitmişti. Artık babası pek ihtiyardı. Tarlaları ve çifti idare edemiyor, adamları onu aldatıyorlardı. İşleri eline aldı. Zaten sa'y e karşı derin bir muhabbeti vardı. Bir gün köydeki mektebin daskaliçe sine rastgeldi. Tanıdı. Bu kızcağız da kendisi gibi Sofya'da okumuştu. Konuştular ve çok sürmedi, seviştiler. İzdivaç ettiler. Magda, Boris'e vardıktan sonra mektebi terketmiş, hayatını evine, zevcine hasretmişti. Aşkları gittikçe ziyâdeleşiyor, fikirlerinin tevafuk u onları daha şedid bir iştiyak ile birbirlerine rapteyliyordu. İşte aylardan beri böyle gece yarılarını bulurlar, konuşurlar, sevişirler, uyumak istemezlerdi.

Boris, tekrar mandolinini aldı. Çalmaya başladı. Magda çorabını örüyor ve düşünüyordu. Üç ay sonra çocukları olunca kimbilir ne kadar mesut olacaklardı. Tığlardan ayırdığı gözleriyle kabarmış karnına bakıyordu. Eteğinin altında, karnında, kendi içinde Boris'in yavrusu duruyordu. Dirseklerini bu şişliğe temas ettirerek saadetten titriyor ve ayıp bir şey yapıyormuş gibi gizlice Boris'e bakarak kızarıyordu. Ocaktaki odunlar çatırdayarak yıkılıyor, birden alevler çoğalıyor, sanki bütün oda kırmızı gölgelerle doluyordu. Boris yine sosyalist marşını çalıyordu. Bitirdi. Mavi gözleriyle karısına baktı ve marşın nakaratını tekrar etti:  
— Da jivee truda!..  
Magda çok saçlı güzel başını kaldırdı. İnce kaşları, muntazam bir burnu, pembe ve taze bir rengi vardı. Geniş omuzları, kabarık göğüsleri esvabının altından taşmak istiyor gibiydi. Alevlerle aydınlanan eteklerinin altındaki kalın bacaklarından sonra ayakları pek küçük ve nazik kalıyordu. Gebelik onu daha güzelleştirmiş, daha nefis ve mükemmel bir kadın yapmıştı. Genç ve iri Boris müştak gözlerle zevcesini süzüyor, ruhundaki sıkıntıyı atmaya, bu meçhul kederi unutmaya çalışıyordu. Konuşmak istedi:  
— Yaşasın sa'y ü teab! dedi, değil mi  
  
  
  
Magdacığım? Çalışan mesut olur. Acaba  
  
  
  
sosyalistlerin hayali ne vakit hakikat  
  
  
  
olacak!

Magda başını salladı, gülümsedi:

— Hiç, hiç, hiçbir vakit... Onların hayali hep  
  
  
hayal kalacak! Yine insanlar fenalar elinde  
  
  
  
esir olacak, çalışmanın faziletini birçok  
  
  
  
adamlar inkar edecek.

Boris mandolinini kucağından bıraktı. Ellerini

pantolonunun cebine soktu. Ayaklarını uzattı:

— Evet, ben de bu hayalin hakikat olacağına  
  
  
  
kail değilim, dedi. Lâkin bu hayaldeki  
  
  
  
  
insanlık fikrine meftûnum! Düşün.  
  
  
  
Muharebeler kalkacak. Cinayetler  
  
  
  
  
olmayacak. Hain politika unutulacak,  
  
  
herkes kardeş gibi... Çalışacaklar ve mesut  
olacaklar...  
  
  
— Heyhat...  
  
Boris de tekrar etti:

— Benden de heyhat! Hele burada, bu pis ve  
  
vahşi yerde, bu zalim Makedonya'da rahatla  
  
  
  
çalışmak mümkün değil. Ah bu kanlı  
  
Makedonya...  
Magda, boynunun altında ansızın bir acı duydu. Çorabını bıraktı. Boris'in yüzüne baktı. Kalbi hızla çarpmaya başlamıştı. Rüzgarın bir küfürü andıran şiddetli gürültüsünü işitti. Ocağın üzerindeki saatin kırık bir kalp gibi vuran kuvvetsiz ve mahzun tik-taklarını duydu. Ayağa kalktı. Boris'in boynuna atıldı:  
— Ah, yatalım, dedi. Böyle acı şeylerden bahsetme...  
Boris, kolunu Magda'nın beline, kalçasının üzerine koydu. Onu kucağına çekti, oturttu. Dudaklarından öptü. Bir an, bir dakika, uzun bir dakika böyle kaldılar. Boris diğer eliyle karısının kabarık memesini tuttu. Bütün avucunu dolduran bu yumuşak ve nefis kabarıklığı yavaş yavaş, dalgalandırarak sıktı. İkisinin de gözleri küçülüyor ve titriyorlardı. Magda'nın başı Boris'in kuvvetli göğsüne düştü. Boris dudaklarını bu çok ve kumral saçların arasına koydu:  
— Müsterih ol, Magdacığım, artık hiç korkmayacak, mesut olacaksın!..  
Genç kadın iri ve çıplak bacaklarını kocasının kavî bacaklarına dolaştırdı. Sıktı. Bütün vücudu takallûs etti ve sordu:  
— Ah, mesut olacak mıyız? Nasıl? Söyle, nasıl?  
Boris mesut ve mahzuz:  
— Anlatayım, inan, dedi. Artık buradan gideceğiz.  
— Kaçacak mıyız?  
— Hayır, hicret edeceğiz.  
— Nereye?  
— Amerika'ya...  
— Amerika'ya mı?  
— Evet, Amerika'ya, Magdacığım. İşte iki aydır hazırlanıyorum. Sana haber vermedim. Tam buradan çıkacağımız gün söyleyecektim. Babama nemiz varsa sattırdım. Şimdi sekizyüz liramız var. Sekizyüz lira ile Amerika'da bir insan çalışırsa çok mesut olur.  
Magda kocasının bacaklarını daha ziyâde sıktı, dönerek boynuna sarıldı.  
— Niçin benden sakladın, dedi. Oh, ne kadar mesut olacağız.  
Boris karısının dudaklarını öperek cevap verdi:  
— Sebep vardı. Korkacaktın. Senden saklamaya mecburdum.  
— Söyle, ne vardı? Neye korkacaktım?  
— Şimdi söylesem yine korkacaksın.  
— Söyle, korkmam.  
Boris tereddütle anlattı:  
— İki ay evvel, bir pazar gecesi eve geliyordum. Kapıda bir mektup buldum. Açtım. Bu, ihtilal komitesi tarafından yazılmıştı.  
— Ah...  
— Evet, ihtilal komitesi tarafından... "Ey dinsiz Boris!" diye başlıyordu. Ve "Vaktiyle dağlarda neşretmek istediğin sosyalistliği burada öğretmeye başladın. Hainsin! Vatanımızın düşmanısın! Bil ki, o hain kafanı balta ile vücudundan koparacak, sana uyanların, seni sevenlerin eline vereceğiz."  
— Ah...  
— "Yahut bize delâlet et. Bizimle beraber Balkan'a çık... Büyük vatan için çalış." deniyordu. O vakit anladım ki, burada seninle, senin aşkınla yaşamak benim için mümkün değil. Hemen babamı kandırdım. Her şeyi sattırdım.  
Magda tekrar Boris'i öperek sordu:  
— Ah, ne vakit gideceğiz? Söyle, buradan ne vakit gideceğiz?  
— O kadar yakın bir zamanda ki... Söylesem inanmazsın...  
— Söyle..  
— Yarın!  
— Yarın mı? Aman yarabbi...  
Hızla kocasının kucağından kalktı. Sevincinden çırpındı. Tekrar kocasının dizlerine oturarak onu öpmeye başladı:  
— Yarın, yarın... Demek bu son kederli gecemiz...  
Boris karısının sevincinden memnun ve mahzuz, onu okşayarak, buseler içinde devam etti:  
— Evet Magdacığım. Yarın Amerika'ya gideceğiz, orada çalışacağız. Küçük, rahat, âsûde bir evimiz olacak. Ne komite, ne eşkiya, ne vahşet, ne cinayet! Yalnız çalışacağız. Gider gitmez çocuğumuz orada doğacak. Zavallı babam geçirdiği yetmiş senelik azabın mükafatını orada görecek. Kalbi rahat, yatağında ölecek. Geceleri hücum ve boğazlanmak korkusundan uzak, tatlı tatlı konuşacağız. Aşkı, hayatı, güzelliği, iyiliği, fazileti hissedeceğiz.  
Magda titriyordu:  
— Oh, ne saadet!  
Boris yine buseler içinde devam etti:  
— Göreceksin ki o zaman, insanlık ne tatlıymış! Güzel ve asayişli şehirler... Tiyatrolar! Geniş ve aydınlık sokaklar, cennet gibi köyler. Birbirine ihtiram etmesini bilen adamlar... Hiçbir sefalete müsaade etmeyen büyük şefkat müesseseleri... Hastaneler, sanatoryumlar... Mektepler, dârülfünunlar... Hâsılı cennet! Mümkün değil bunları tahayyül edemezsin.  
Magda daha ziyâde titreyerek dirsekleriyle şişmiş karnını, bacaklarıyla kocasının bacaklarını sıkarak:  
— Oh, tahayyül ediyorum!  
Dedi. Boris devam etti:  
—O vakit bazı geceler, minimini evimizde, doğacak çocuğumuz yanımızda oynarken, sa'y ve namusumuzdan emin, ansızın Makedonya'yı, bu yamyamlar memleketini hatırlayacağız. Gözümüzün önüne pis ve dar sokaklar, sefil ve uryan adamlar... Kanlarla lekelenmiş nihayetsiz karlar, kara, müstekreh ve keskin baltalar sonra siyah, müthiş Balkanlar, Pirin gelecek! Tüylerimiz ürperecek, sen yine böyle benim kucağıma kaçacaksın. Bu pis ve müthiş Makedonya'nın kabuslarını buselerimle senin gözlerinden sileceğim...  
Magda memnuniyet ve saadetten tatlı bir baygınlık hissediyordu. Kocasının bacaklarını sıkan dolgun bacakları gevşedi. Kolları yanına düştü. Gözleri uzak hayallere bakıyordu. Boris yine onu kucağında sıktı. Dudaklarından öpmeye başladı:  
— Görüyorsun ki, burada her dakikamız elem, matem, ıstırap içinde geçiyor. Bir dakika kalbimiz rahat değil. Ufak bir gürültü bizi korkutuyor. Mesela işte seni o kadar severken, sana o kadar perestiş ederken dehşetle memlû dimağımda aşkım için müsterih bir yer kalmıyor. Dudaklarının lezzetini tamamıyla duymuyorum. Hayalimde o kadar çirkin ve kanlı levhalar var ki... Hâsılı burada, daima meçhul bir tehlike karşısında tedehhüş etmiş biçare, idraksiz, şuursuz vahşi hayvanlar gibiyiz.  
Ocağın odunları yıkılmış, alevler sönmüştü. Yalnız ocağın üstünde küçük lamba sarı bir ziya neşrediyordu. Boris'le Magda yine birbirlerine bütün kuvvetleriyle sarıldılar. Öpüştüler.

Boris:  
— Artık aşkı duyacağım, diyordu, hatta şimdiden duyuyorum. Kendimi Amerika'da farzediyor, seninle yalnız, emin ve mutmain odamızdayız addediyorum.  
Magda'nın dudaklarındaki buseler söndü. Birden:  
— Oh, ben korkuyorum!  
Dedi. Boris hayretle sordu:  
— Neden?  
— Bilmem. Fakat o kadar korkuyorum ki....  
Genç kadın asabi bir teheyyüc e uğramıştı. Hakikaten korkudan titriyor ve ağlıyordu. Boris bu meçhul ve bu nâgehânî kederi teselli etmek istedi:  
— Korkma, haydi kalk, dedi, yatalım; müstakbelin pek yakın saadetini şimdiden yaşayalım. Bu pis odayı, bu pis ocağı, bu zulmet ve dehşet yuvasını görme, gözlerini kapa, Amerika'yı tahayyül et. Haydi kalk, korkma, gözlerini sil!  
— Korkuyorum Boris, korkuyorum.  
— Neden sevgilim? Sakin ol. Saadetimiz seni müteessir ediyor, haydi yatalım. Benim yanımda, kucağımda... Korkacak bir şey yok...  
İkisi de kalktılar. Boris kolunu Magda'nın boynuna attı. Magda asabi bir iştiyak ile kocasının beline sarıldı. Yürüyorlardı. Karşı karşıya duran iki kapıdan birisine girecekler ve yatacaklardı. Magda tekrar durdu:  
— Korkuyorum Boris, bak köpekler havlıyorlar...  
Boris cevap verdi:  
— Her vakit havlarlar.  
— Hayır, koşarak havlıyorlar. Birisi geliyor!  
Boris mütereddid ve müteaccip, durdu. Dudaklarını büktü:  
— Kim gelecek, gece yarısı çoktan geçti, dedi.  
Rüzgara karışan köpek havlamaları daha ziyâde şiddetleniyor ve daha ziyâde yaklaşıyordu. İkisi de ayakta dimdik kaldılar. Boris'in kolu Magda'nın omuzundan düştü. Magda elini Boris'in belinden çekti. Köpekler koşuyorlar ve bir yabancıya saldırarak havlıyorlardı. Boris:  
— Kimdir, pencereden bakalım!  
Dedi. Pencereye doğru yürüdü. Magda koştu, içerisi görünmesin diye lambayı söndürdü. Odaya kesif ve zenci bir karanlık doldu. Ocağın içindeki ateşler bir zebaninin dili ve kanlı dişleri gibi parlamaya başladı. Açılan pencereden şiddetli bir rüzgar giriyor, bu ateş dişleri tutuşturuyor, bu siyah ağıza görünmez tehditler söyletiyordu.

Boris bağırdı:  
— Kimdir o?  
Uzak ve ince bir ses cevap verdi:  
— Ben!..  
— Sen kimsin?  
— Ben, Melina...  
Bu, komşunun kızıydı. Acaba şimdi niçin gelmişti? Ne arıyordu? Boris yüzünü içeri çevirdi, Magda'yı aradı, göremiyordu. Yalnız ocağın içindeki ateşler gözüne çarptı. O kadar karanlıktı ki...

Tekrar dışarıya, karanlıklara baktı:  
— Ne istiyorsun?  
— Baba İstoyan'ı?  
Kız bu esnada yaklaşmış ve pencerenin dibine gelmişti.

Boris, Magda'ya:  
— Lambayı yak! dedi.  
Oda aydınlandıktan sonra birbirlerinin yüzlerine baktılar. Boris sordu:  
— Acaba babamı ne yapacak?  
— Bilmem, şimdi anlarız.  
Ve Magda birden kapıya yürüdü. Açtı. Karanlık rüzgarla beraber genç bir kız içeri girdi. Üşümüş ve yanakları kıpkırmızı olmuştu. Ellerini futasının altına sokmuştu. Göğsü içeri çekik, bacakları içeri dönük, biraz kamburdu. Magda, bir sene ders okuttuğu bu budala kızı isticvâb a başladı:  
— Baba İstoyan'ı ne yapacaksın?  
Melina bir cevap vermedi. Evvela:  
— Dobra veçer!  
Dedi. Sonra alık alık etrafına bakındı:  
— Ben bir şey yapmayacağım!  
— Ey öyleyse ne arıyorsun?  
— Ben aramıyorum.  
— Kim arıyor?  
— Komitalar...  
Magda birden sapsarı kesildi. Düşmemek için duvara dayandı. Elini kalbinin üstüne koydu:  
— Komitalar mı?  
Melina gitmek isteyerek:  
— Bilmem, işte silahlı adamlar...  
Dedi. Magda duyulmaz ve ümitsiz bir sesle yine sordu:  
— Bizim köyden mi?  
Budala kız izah etti:  
— Hayır. Sarı esvaplı, tüfekli adamlar! Mutlaka Baba İstoyan'ı istiyorlar. "Eğer gelmezse oraya gelir, hem hepsini keseriz, hem evlerini yakarız." diyorlar.  
Magda'nın dizleri çözüldü. Elleriyle duvarı tuttu, çenesi kilitlendi. Ölü ve boş bir nazarla Boris'e baktı. O da sararmış ve mütefekkir duruyordu. Pantolonunun cebinden sağ elini çıkardı. Ve uzun saçlarını kaşımaya başladı. Gözleri ayaklarında idi. Kıza bakmayarak sordu:  
— Bu adamlar nerde?  
— Bizim evde... Şarap içiyorlar.  
— Kaç kişi?  
— Daskal la beraber dört kişi..  
Birden gözlerini kıza kaldırdı ve:  
— Haydi git söyle, ben geleceğim... dedi. "Baba İstoyan hasta imiş", de.  
Kız "Sıs zdrave" dedikten sonra çıktı. Kapıyı açık bırakmıştı. Şiddetli bir rüzgar giriyor, lambanın ziyasını dalgalandırıyor, Magda'nın eteklerini kımıldatıyordu. Boris karısına baktı. Bitmişti. Sanki o bu dakika ölecekti. Sapsarıydı. Yürüdü, kuvvetli kollarıyla dayandığı duvardan onu çekti.  
— Korkma, dedi, ben yarım saat sonra gelirim.  
Magda ağlamaya başladı. Ta içinden gelen hıçkırıklarla sarsılıyor:  
— Ah, gitme, gitme Borisciğim...  
Diye yalvarıyordu. Boris onu öperek teselli ve teskin etmeye çalıştı. Eğer gitmezse gelip mutlaka bir edepsizlik edeceklerini, Baba İstoyan gitse zavallı ihtiyardan hakaret ve işkencelerle para isteyeceklerini anlattı ve ilave etti:  
— Hainler, babamın her şeyi sattığını haber aldılar. Hicret edeceğimizi tahmin ettiler. Şimdi bütün servetimiz olan sekizyüz lirayı isteyecekler. Babam giderse işkence ve tahkir edecekler. Şimdi ben giderim. Onlarla konuşur, kendileriyle beraber dağa çıkmaya razı olduğumu söylerim. Ve paraların da henüz alınmadığını, bir hafta sonra elimize geçeceğini anlatır ve kandırırım. Yarın akşam bizi burada bulamazlar...  
Magda meyus ve perişan:  
— Ah, inanmazlar, sana bir fenalık yaparlar, dedi.  
Boris tekrar temin etti. Mutlaka kandıracağını, böyle hareketten başka çare olmadığını, Baba İstoyan giderse işte asıl fenalık o vakit olacağını uzun uzadıya anlattı. Magda asabi ve derin hıçkırıklarla ağlıyor, kıvranıyor, ince parmaklarıyla kumral saçlarını sıkıyordu. Boris kalpağını başına koydu. Karısını tekrar öperek ve elini sıkarak:  
— Haydi sevgilim, cesur ol, dedi. Yarım saat sonra gelirim, yatarız. Bu son gecenin heyecanları bize bir hatıra olur.  
Kapıya yürüdü. Magda da beraber yürüdü. Titrek bir sesle:  
— Ben de geleyim, Boris!  
Dedi. Lâkin kocası razı olmadı:  
— Sen orada, sarhoşların arasında ne yapacaksın? Burada otur, bekle, yarım saat sevgilim, cesur ol...  
— Ah, bari yanına rovelverini alsan..  
— Muharebeye gitmiyorum ki... Konuşmaya gidiyorum, lüzumu yok!  
Dedi ve asabi bir istical ile dışarıya çıktı. Magda kapıda kalmıştı. Karanlık elle tutulacak ve hissolunacak kadar siyah ve kesif idi. Kocası bu karanlıkta kaybolmuştu. Sevgili Boris'ini yutan bu siyah rüzgarlı gecenin ademi andıran, ölümü ihtar eden korkutucu karanlığı gözlerinden vücuduna, damarlarına giriyor, kanına karışıyor, ruhuna nüfuz ediyordu. Başı döndü. Hıçkırıklar ve gözyaşları içinde tıkandı. Olduğu yere yıkıldı. Gözlerini vahşi ve siyah geceye dikmiş, siyah ve soğuk rüzgarın altında ağlıyor, fasılasız hışkırıklarla kıvranıyordu.

Baba İstoyan daima, güneş battıktan bir saat sonra yatar, hemen uyur ve sabah olmazdan iki saat evvel uyanırdı. Kuşağını sararak kapısını açtı. Gelinini bahçe kapısının eşiğinde uzanmış görünce şaşaladı: — Ne yapıyorsun orada? Dedi. Magda kayınbabasının sesini işitir işitmez kalktı. Toplandı: — Hiç! diye cevap verdi, dışarı çıkacaktım, uzanmıştım. İhtiyar ocağa doğru yürüdü. Magda kapıyı itti. Ve ocağa koştu. Odun attı, tutuşturmaya başladı. İhtiyar çubuğunu dolduruyordu. Magda ateşi yaktıktan sonra ortada, kaba ve kalın ayaklı masanın yanındaki bir sandalyeye oturdu. Dirseklerini dayadı. Başını ellerinin içine aldı. İşte yarım saat oluyordu. Boris henüz gelmemişti. Niçin bu kadar gecikmişti? Kalbi burkuluyor ve avazı çıktığı kadar haykırarak ağlamak, kendisini yerlere atmak, koşarak Melina'nın evine gitmek, Boris'i bulmak, onun kolları içine atılmak istiyordu. Baba İstoyan, kamburunu çıkarmış, sakin ve abûs çubuğunu çekiyor ve sol elinin orta parmağı ile burnunu karıştırıyordu. Harap ve eski saat, durmuş da sanki yeniden kendi kendine işlemeye başlamış gibi, hazin tik-taklarını tekrar işittiriyor, tutuşan odunlar yine odanın içine kırmızı gölgeler, kırmızı hayaller dolduruyor, soğuk rüzgar daha vahşi, daha hain haykırıyor, pencerenin kapağını daha ziyâde sarsıyordu. Magda, Boris'i düşünüyor ve gizli gizli hıçkırıyordu. Kalbi şişiyor, göğsünü acıtıyordu. Dışarıdan uzak köpek sesleri işitildi. Bunlar mutlaka komşunun köpekleriydi. Birden başını kaldırdı. İşte Boris çıkmış olacaktı. Köpekler havlıyordu. Dinledi. Oh, Boris geliyordu. Birkaç dakika kımıldamadı, öyle kaldı.

Şimdi köpek sesleri yaklaşıyordu. Kendi köpekleri de havlıyordu. Fakat niçin? Boris'e niçin havlıyorlardı? Acaba yanında bir yabancı mı vardı? Köpek sesleri daha ziyâde yaklaştı. Magda ayağa kalktı. Pencerenin yanına gitti. Kapağı açmaya cesaret edemiyor, meçhul bir korku onu hareketsiz bırakıyordu... Köpekler pek yaklaşmışlardı. Ayak sesleri işitiliyordu. Magda'nın kalbi durdu. Nefesi kesildi. Kendinden geçti.

Kapı birdenbire vurulmuştu. Baba İstoyan sıçradı ve çubuğunu düşürdü. Magda elini kalbinin üstüne koydu. Omuzlarını kaldırdı. Boynunu içeri çekti. Kapı tekrar ve daha şiddetle vuruldu. Baba İstoyan kalktı. Pencereye doğru yürüdü. Kuvvetsiz bir sesle: — Kim o? Dedi. Dışarıdan ahenksiz bir ses cevap verdi: — Aç Baba İstoyan, biziz. Konuşmaya geldik. Korkma! İhtiyar mütereddid ve korkak, tekrar sordu: — Siz kimsiniz? — Kaptan Raçof, Pançe, Sandre... İhtiyar, yıldırımla vurulmuş gibi dondu kaldı. Bunlar en müthiş, en kanlı, en merhametsiz, en gaddar komitalardı. Namları bütün ova köylerini titretiyordu. İhtiyar bir hayal gibi kapıya yürüdü. Açtı. Uzun boylu, kahverengi esvaplı, omuzunda manliher, bir adam göründü. Gözleri küçük ve kanlıydı. Zayıf ve gayet çirkin bir boynu vardı. Baba İstoyan, yalnız Bulgar köylülerine has olan o esir ve mazlum tavır ile eğildi, yine bu köylülere has olan o çolak ve sahte selamla voyvodayı selamladı. — Buyurunuz Gospodin! Dedi. Raçof'un arkasında iki kişi daha vardı. Bunlar da manliher tüfekleriyle müsellâh idiler. Bellerinde ve göğüslerinde çaprazvari fişeklikler bulunuyordu. Biri kısa boylu, esmerdi. Diğeri Raçof gibi sarı, fakat daha genç ve daha az çirkindi. Magda'nın gözleri açılmış ve yüzü bembeyaz olmuştu. Koştu. Raçof'un ayaklarına sarıldı. Öpmeye başladı, ağlayarak istirham ediyordu: — Gospodin! Boris nerede? Ah, Boris nerede? Raçof, ayaklarına kapanmış güzel kadının güzel saçlarını müteverrim ve çamurlaşmış yılanlara benzeyen parmaklarıyla okşayarak: — Kalk sosyalist daskaliçe, dedi, şimdi Boris'in gelir. Biz şimdi işimizi konuşalım... Ve yürüdü. Magda yerde kalmıştı. Masanın yanındaki sandalyeye teklifsizce oturdu. Masanın üzerine tüfeğini koydu. Öbürleri de karşısına oturdular. Esmer ve kısa boylunun elinde siyah bir beze sarılmış yuvarlak bir şey vardı. Onlar da tüfeklerini masanın üzerine koydular ve siyah beze sarılı yuvarlak şey de tüfeklerin yanına kondu. Raçof, Baba İstoyan'a döndü: — Gel bakalım çorbacı, dedi, karşıma otur. Seninle konuşacağım. Magda, sen de şöyle yanıma gel. Baban aksilik ederse bize muâvenet et ki, fenalık yapmayalım. İkisi de tereddüt etmedi. Baba İstoyan, Raçof'un karşısına oturdu. Magda da yanına... Baba İstoyan bütün bütün aptallaşmıştı. Gelininin niçin komitalardan oğlunun nerede olduğunu sormasına akıl erdirememişti. Boris evde değil miydi?

Raçof cebinden bir tabaka çıkardı. Ortaya koydu. Bir cigara yaptı. Magda seri bir hareketle kalkarak ocaktan ateş aldı. Haydudun cigarasını yaktı. Sonra ateşi ocağa attı. Yine kalktığı yere oturdu. Raçof birkaç nefes cigarasından çekti. Ve dumanlarını seyrederek: — Ey, Baba İstoyan, dedi, şimdi evvela bize vaat et ki, çok zahmet etmeyeceksin! Uzun lafın kısası: Vakit geçirmeyelim... Sekizyüz lirayı getir. İhtiyar titredi. Altmış senedir o kadar iktisat ve eziyet ile kazanılmış bir malın semeresi... mecmû u...yekûnu... Şimdi böyle bir anda isteniyordu. Deli olacaktı. İnkar etti: — Nasıl sekizyüz lira? Voyvoda gülümsedi. Kirli ve kırık dişleri göründü. Tekrar cigarasını çekti. Başını salladı: — Anlaşıldı. Demek zahmet edeceksin. Mutlaka dayak yemeden, ayakların yanmadan, tırnakların çıkarılmadan söylemeyeceksin! Eğer yine söylemezsen oğlun Boris bizim elimizde mahpustur. Onu keseceğiz. Evini de yakacağız. Yine seni rahat bırakmayacağız. Baba İstoyan önüne bakıyordu. Hatta oturdukları evi bile satmışlardı. Bu sekizyüz lirayı verirse muhakkak açlıktan ölecekti. Bir eşeği bile kalmamıştı. Magda, Boris'in kesileceğinden bahsedildiğini duyunca ağlamaya başladı. Tekrar Kaptan Raçof'un ayaklarına kapandı: — Affet gospodin, Boris'i affet... Dedi. Raçof gülerek cevap verdi: — Güzel daskaliçe! Sen de maksada vefasız kaldın. Burada ikiniz de bizim için çalışacağınız yerde, babanıza mallarını sattırıp kaçmak istediniz. Sizin için milletin verdiği parayı çalmak arzu ettiniz. İşte biz buna müsaade etmiyoruz. Elinizden paraları alacağız. Buradan bir yere gidemeyeceksiniz. Bizim için çalışacaksınız. Ve ilave etti: — Haydi, Boris'ini seversen paraları getir. Baba İstoyan inat ederse sevgilinin kafası kesilecek. Bir daha onu ömründe göremeyeceksin. Magda Boris'in öldürülmek ihtimalini düşününce deli olacaktı. Kalktı, ağlayarak Baba İstoyan'a sarıldı: — Ver babacığım, ver, biz genciz. Boris'le çalışır, yine kazanırız. Söyle nerede, gideyim, getireyim. Raçof ve arkadaşları Magda'nın yalvarmasını seyrediyor ve gülüşüyorlardı. Baba İstoyan tamamıyla aptallaşmıştı. Sanki hiç lafları işitmiyor, mânâlarını anlamıyordu. Hasis köylü için ölmek, bu parayı vermekten daha çok ehvendi. Magda yalvarıyordu. Birden Baba İstoyan başını kaldırdı. Raçof'a dedi ki: — Kaptan, bari yüz lirasını bir ev almak için bana bırak. Âhir vaktimda açıkta kalmayayım. Raçof reddetti: — Hayır, yüz lirasını bırakmam. Oğlun genç, çalışır. Seni besler. Haydi getir diyorum. Vakit geçiyor. İhtiyar tereddüt ediyor, Magda yalvarıyordu. Raçof bir işaret etti. Kısa boylu esmer, tüfeği aldı. Dipçikle ihtiyarın sırtına dehşetli bir darbe indirdi. Raçof ayağa kalktı. Şiddetle sordu: — Haydi, Baba İstoyan, dayağa başlayacağız. Ayaklarını ateşe sokacağız. Vakit geçiyor. Paraları getirecek misin? Magda gözyaşları içinde çırpınıyor ve ihtiyara sarılıyordu. İhtiyar hiçbir şey söylemedi. Başını salladı. Yattığı odanın kapısına gitti. İçeri girdi. Bir dakika sonra kırmızı ve ağır bir çıkın ile geldi. Masanın üzerine bıraktı. Haydutlar parayı bu kadar çabuk elde ettikleri için sevindiler. Raçof hemen çıkını açtı. Saymaya başladı. — Aferin, Baba İstoyan, diyordu. Zahmet vermedin. Şimdi bize şarap çıkar, eğlenelim... Paraların sayılması bitti. Raçof liraları üçe taksim etti. Arkadaşlarıyla çantalarına koydular. — Hani şarap, hani şarap? Diye haykırdılar. Magda ayağa kalktı. Ambarın küçük kapısına koştu. Açtı ve içeri girdi. Üç bardak ile bir testi şarap getirdi. Haydutların önüne koydu. Sonra tekrar ambara girdi. Mezelik biber ve turşu çıkardı. Komitalar birbiri üzerine aceleyle içiyorlardı. Raçof: — Böyle mezeye lüzum yok, dedi. Biz cansız meze istemeyiz... Bu laftan bir şey anlamayan Magda'yı belinden tuttu ve öpmek istedi. Magda mukavemet etti ve ağlamaya başladı. Raçof, genç kadını bırakmayarak diyordu ki: — Yanaklarından meze alacağım. Sen sosyalist değil misin? Sosyalistler her şeyde iştirak isterler. Ben de senin yanaklarına Boris'le müşterekim!... Magda çırpınıyordu. Raçof çirkin ve akur sesiyle dedi ki: — Eğer böyle münasebetsizlik edersen Boris'ini göremezsin. Onu keseriz. Magda bu lafı işitince tekrar hıçkırmaya ve Raçof'a yalvarmaya başladı. Artık Raçof onun taze yanaklarından bol bol öpüyordu. Kadeh kadeh içiyor ve tekrar tekrar öpüyordu. Arkadaşlarına: — Siz de meze alınız, be!.. Dedi. Cansız bir yumak gibi Magda'yı onların kucağına attı. Bu iki kuvvetli herif bu nefis kadına yapıştılar. Bir tanesi eteklerini kaldırmak istiyordu. Diğeri daha fena sarhoştu. Dişleriyle, avucunun içinde tuttuğu bu güzel başın yanağını ısırmıştı. Magda birden haykırdı. Ve kucaklarından kurtuldu. Sağ yanağının iki yerinden kan akıyordu. Baba İstoyan bu manzarayı görmemek için ocağın kenarına çömeldi ve başını avuçlarının içine aldı. Gözlerini ateşe dikti. Magda elini yanağına koymuştu. Parmaklarının arasından mebzûliyetle kan sızıyor ve ağlıyordu. Haydutlar bu güzel kadının bu kan içinde ağlamasına bakarak sanki mahzuz oluyorlardı. Hepsi susuyorlardı. İhtiyar saat bu tecavüzden ve i'tisaf tan müteessir olmuş gibi yine tik-taklarını işittiriyor, rüzgarın gürültüsüne horoz sedâları karışıyordu. Raçof sözde acıdı: — Ağlama Magda, dedi. Şimdi Boris'in gelir. Orasını öper. Acısı kalmaz. Haydi ben mandolin çalayım, bize biraz rakset... Ve ocağın yanından mandolini alarak bir polka çalmaya başladı. Magda ağlıyor: — Ben oynamak bilmem kaptan! Diyordu. Raçof kalktı. Magda'nın yanına gitti. Kulağına müessir ve vahşi bir sesle: — Eğer oynamaz, neşemizi kırarsan, Boris'i göremezsin, gider keseriz... Magda'nın bütün vücudu sarsıldı. Gözlerinin yaşı dindi. Ve mütevekkil bir sesle: — Oynayayım, ah Boris... Dedi. Raçof oturdu. Mandolini çalmaya başladı. Diğer iki haydut, durmadan içiyorlar ve gülerek Magda'nın oynayışını seyrediyorlardı. Yanağından akan kan beyaz boynuna gidiyor, ona tekrar hayata gelmiş bir şehit manzarası veriyordu. Isıran haydut, başka bir arzu ızhar etti: — Kaptan, dedi, eteklerini kaldırsın, öyle oynasın. Bacaklarını görelim... Raçof, Magda'ya döndü: — Haydi Magda, bunu da yap! Bacaklarını görsünler! Artık gidelim, Boris'ini gönderelim.. Genç kadın bir an durdu. Baba İstoyan'a baktı. Yüzünü ateşe dikmiş, hiç onları görmüyordu. İşte bu herifler artık namusunu da tahkir ediyorlardı. Lâkin Boris'i tehlike içindeydi. Eğer arzularını yapmasa, o kadar sevdiği Boris'i kesilecekti. Bir daha onun kumral ve çok saçlarını, mavi gözlerini, küçük ve kırmızı dudaklarını, tatlı tebessümünü göremeyecekti. Gözlerini kapadı ve eteklerini kaldırdı. Çalınan polkaya ayaklarını uydurarak sıçramaya başladı. Haydutlar coştular. Kaptan daha şiddetle ve iştiyak ile çalmaya başladı. Diğerleri yerlerinde oturamıyorlar, bu beyaz ve dolgun bacaklara, onların atılışlarındaki şehveti cazip, muharrik hareketlere bakarak birbirinin boynuna sarılıyor, itişiyor, kakışıyorlardı. Kalktılar, Raçof'un yanına gittiler. Kulağına bir şey fısıldadılar. Raçof: — Olur ama, vakit geçti! Sabah oluyor! Geç kaldık! Dedi ve derin, behîmî, muharrik bir hırsla güzel kadına baktı ve: — Ah, vakit olsaydı!... Diye müteessif oldu. Kalktılar. Tüfeklerini omuzlarına geçirdiler. Sarhoştular. Adımları birbirine karışıyordu. Raçof: — Allahaısmarladık, Baba İstoyan! Dedi. İhtiyar köylü sanki ölmüştü. Hiç cevap vermedi. Magda tekrar haydudun ayaklarına kapandı: — Aman kaptan, Boris'i gönder. İşte her şeyimizi aldınız. Eğer o gelmezse açlıktan ve ümitsizlikten ölürüz. Bize acı. Bize merhamet et... Raçof güldü: — Mutlaka gelecek, mutlaka... Daha çabuk gelmesini istiyorsan, şu kanlı yanağından bir buse ver... Magda hırsla geri çekildi. Haydut tekrar kadını tuttu. Zorla kanlı yanağını öptü. Yaladı. Dışarı çıkıyorlardı. Kısa boylu esmer, beraber getirdikleri siyah beze sarılı şeyi hatırladı. — Kaptan, dedi, bombayı ne yapacağız? Raçof bir an düşündü. Geri döndü: — Magda, bana bak! Dedi. Magda yine bir i'tisâfa uğrayacak zannıyla titredi. Fakat bu haydut nazik ve mürüvvetli idi. — Şunu görüyor musun, Magda? Bu işte bir bombadır. Eğer siz eziyet edip parayı vermeyeydiniz, sizden yine zorla alacak ve mücâzat olmak üzere ikinizi biraraya bağlayacak, bu bomba ile atacaktık. Lâkin siz akıllılık ettiniz. Bize zahmet vermediniz. Mücâzata hacet kalmadı. Şimdi senden bir ricam var, bu bombayı bana saklayacaksın. Sakın jandarmalara filan verme. Nasıl vaat ediyor musun? Ben de gidip hemen Boris'i bırakayım... Magda ümit ve tehalükle cevap verdi: — Vaat ediyorum gospodin! Allah aşkınıza hemen Boris'i gönderiniz. Raçof tekrar sordu: — Göndereceğim, lâkin bu bombayı sadıkâne hıfzedecek misin? — Hıfzedeceğim. — Nerede? — Kendi çeyiz sandığımda. En gizli, en muazzez yerde! — Bravo! Memnun oldum. Öyleyse Allahısmarladık! Hepsi güzel kadının elini şiddetle sıktılar ve kapıdan çıktılar. Dışarısı hafifçe ağarıyor, esmerleşiyordu. Köpekler havlamaya başladılar. Kesif gölge halinde duran uzak binaların arasında gidiyorlar ve bir şarkı söylüyorlardı. Ah, şimdi Boris gelecekti. Genç kadın, açılmaya başlayan geceye bakıyor, köydeki bütün horozların birbirlerine cevap verir gibi öttüklerini duyuyordu. Kalbi şiddetle atıyor, Boris'ini bekliyordu. Uzaklaşan haydutlardan biri haykırdı. Bu, meşum ve mevhum bir kabus tehdidi gibiydi: — Hey, Magda, dikkat et, bomban patlayacak. Genç kadın kulak kabarttı. Bu tehdit, sanki meçhul ve vahşi uçurumlardan, adem boşluklarından aksediyormuş gibi tekerrür etti: — Hey, Magda, dikkat et, bomban patlayacak. Horozların umumi ötüşleri rüzgarı söndürmüş zannolunacaktı. Uzakta samanlıkların üstünde yalancı bir fecir, mor gözlerini açıyordu. Genç kadın şuursuz bir tefekkürle düşündü. Bu haydutlar her şeyi, akla gelmeyen vahşetleri yapabilirlerdi. İhtimal bu bombayı ateş alması için, saniyeli tıpasını tanzim etmiş, öyle bırakmışlardı. Şimdi birden patlayacak ve zavallı Borisciği gelince yıkılmış bir evle tanınmaz kanlı et ve kemik parçalarından başka bir şey bulamayacaktı. Mihânikî bir istical ile bu felaket oyuncağını kaldırmaya koştu. Ta masanın orta yerinde duruyordu. Elini uzattı. Kaldırdı. Öbür eliyle altından tutmuştu. Ilık bir ıslaklık hissetti. Eline baktı: Kanlanmıştı. Kan?.. Sonra bu tehlikeli ve tahmin ettiği kadar ağır olmayan bombayı önüne koydu. Kadranını, fitilini görmek istiyordu. Yavaşça siyah bezi çözdü. İkinci bir bez daha vardı. Bu bez kandan kıpkırmızı idi. O bezi de çözdü. Kumral saçlar meydana çıktı. Baktı, baktı, dikkatle baktı...

Ve birden öyle müthiş, öyle keskin, öyle feci, öyle korkunç bir nâra attı ki, ocağın başındaki Baba İstoyan sıçradı ve gelinine koştu. Zavallının gözleri çerçevesinden çıkmış, karışık saçları dimdik olmuş, omuzları gerilmiş, iki eliyle tuttuğu bir şeye haşyet ve dehşetle bakıyordu. Dikkat etti. O tuttuğu şey, oğlunun, güzel ve kumral Boris'in vücudundan koparılmış kesik ve kanlı kafası idi....

# Büyücü

Büyük Selahaddin, kendisinden aman dileyen Kudüs'ü aldıktan sonra hiç durmamıştı. Şam'da "Biraz dinlenelim!" istirhamında bulunan askerine,  
— Ömür kısadır. Ecelden emin değiliz! cevabını verdi.  
Yayından çıkmış bir alev ok şiddetiyle yabancı Avrupalıların haksız yere sahiplendikleri kasabalar üzerine atılıyor, müthiş nekkaplarıyla deldiği kaleleri hemen zaptediyordu. Kurtularak Sur kalesine kapağı atan halk düşmanı mutaassıpların adedi Avrupa'dan gelen imdatlarla çoğalıyor, milyonlara varıyordu. Ama artık İslamın yüzü gülmüştü. Yıllarca süren zulümlerin intikamı alınacaktı. Şam, her gün yeni bir fetih haberiyle seviniyor, camiler şenleniyor, Allah'a şükretmeye koşan halkı mâbedler almıyordu. O vakit bu şehir, fasılalı fakat mütarekesiz din muharebeleri yüzünden âdeta bir Türk ordugâhına dönmüştü. Sıkışan halifelerin, ürkmüş emîrlerin seyrek saflarını doldurmak için Turan'dan taşan "bahadırlar tufanı" sanki burada birikmiş, karar kılmıştı. Doğu tarafında kocaman bir Türk mahallesi vardı. Kılıçla, kalkanla, tolgayla, eyersiz atlar üzerinde gelenlerin çocukları Arapça öğrenip medreselerde âlim oluyorlar, medeni bir zevk içinde, şiir, edebiyat, ticaret sahasında yaşıyorlardı. Doğan Bey de bunlardan biriydi. Babası, Alp Arslan'ın en eski kumandanlarındandı. Üç küçük kardeşini yirmi senedir görmemişti. Biri Kızıl Arslan'ın, biri Pehlivanoğlu Özbek'in, biri de Harzemşah Döğüş'ün ordusunda idi. Kendisi hiçbir orduya girmemiş, gençliğini medresede geçirmiş, Dımışk'tan hiç ayrılmamıştı. Etrafı yüksek duvarlarla çevrili büyük bir bahçenin ortasındaki harap evinde yalnız oturuyordu. Çoluk çocuğa karışmamış, kitaplarının üstünde ihtiyarlamıştı. İhtiyar bir hizmetçisi vardı. Yiyeceğini, içeceğini çarşıdan o taşırdı. Kendi dışarıya hiç çıkmaz, kimseyle görüşmez, kimseyle tanışmazdı. Ama, bütün mahalle, hatta bütün şehir halkı yine onunla meşguldü:  
— Ne yapıyor?  
— Herhalde ibadet değil!  
— Camilerde görünmez.  
— Niçin dışarı çıkmaz?  
— Evine kimseyi sokmuyor. Niçin?  
— Yapayalnız ne yapıyor?  
— .. Ne yapacak acaba? diyorlardı.  
Meraklarında biraz haklıydılar. Çok defa sakin, beyaz duvarların arkasından yerleri sarsan patlamalar duyulurdu. Çocuklar, kadınlar, gençler sokakta küme küme dururlar, sık fıstık ağaçlarının tepelerinden havaya tüten kırmızı, sincabî, mor, yeşil dumanları korka korka seyrederlerdi. Halkın telkininden kurtulamayan ulemalar da hiç yüzünü görmedikleri bu münzeviye fahri bir garez bağlamışlardı. "Katlinin vacip olduğundan" dem vuruyorlardı. Şehirde her felaketi onun uğursuzluğuna yormak âdetti. Kuraklığı, fırtınaları, yangınları, kavgaları, cinayetleri hep o... "Büyücü Doğan" yapıyordu. Ahalisiyle ülfet etmediği Dımışk'ın ruhunda, yıllar geçtikçe, Doğan, dayanılmaz bir elem olmuştu. Büyük küçük herkes ona levmediyor, lanetler yağdırıyordu. Yanılıp da bir gün dışarı çıksa, ihtimal üzerine atılıp parçalayacaklardı. En umulmaz zafer haberinin verdiği neşe bile, halka Büyücü Doğan'ı unutturamadı. Selahaddin geldiği zaman, Emeviye Camiinin önünde bütün Dımışk toplandı. o namazdan çıkarken,  
— Ey Sultan! Bizi bu Büyücü Doğan'dan kurtar! diye bağrıştılar.  
Selahaddin, hayatını cihatta geçirirdi. Yolu düştükçe uğradığı Şam'ın ahvalini iyice bilmezdi. Sarayına gelir gelmez yeğeni olan kaymakam Ferruhşah'ı huzuruna çağırdı:  
— Halkın istemediği bu Doğan kim? diye sordu.  
Baalbek Emîri Ferruhşah, vâkıa amcası kadar müthiş bir kahraman değildi. Ama, amcasından daha adildi. Şairlere birçok kasideler yazdıracak derecede şeci, cömert, kerim bir zattı. Mefkuresi hakla adaletti.  
— Halka hiç ziyanı dokunmayan bir mûtekif! cevabını verdi.  
— Sana şimdiye kadar şikâyet ettiler mi?  
— Çok defa...  
— Niçin adaleti yerine getirmedin?  
— Getirdim.  
— Ne ceza verdin?  
— Ceza vermedim. Tahkikat yaptım. Anladım ki, bu Doğan'ın hiçbir zararı dokunmamış... Aradım, halk içinde "Bana şunu yaptı" diyen bir davacı çıkmadı.  
— Öyleyse niçin yolumda "Bizi ondan kurtar!" diye bağırırlar?  
Ferruhşah gülümsedi. Kaleler almasını, krallar esir etmesini, ordular dağıtmasını pek iyi bilen kahraman amcası halkın ruhuna yabancıydı.  
— Sultanım, dedi, "Bizi ondan kurtar" diye bağırmaları, gördükleri bir zulümden, bir şerden değildir.  
— Ya nedendir?  
— Meraktandır.  
— ..?  
— Maksatları "Bizi meraktan kurtar!" demektir.  
— Neyi merak ederler?  
— ...  
Ferruhşah, Doğan'ın yıllarca süren sessiz itikâfını, asaletini, gençken medresede kimya ilmiyle hendese ilmine çalıştığını, gayet derin bir âlim olduğunu, şimdi madde ile yanar cisimlerle uğraşıp bilinmeyen şeyler keşfine savaştığını amcasına uzun uzadıya anlattı. Halkın mahiyetini bilmediği şeye kin bağlaması tabii idi. Bu zavallı adam, kırk senedir, merak ettiği bir noktaya ömrünü hasretmişti. İşte onu anlamaya çabalıyordu. Başka bir kabahati yoktu. Fakat Selahaddin,  
— Canına dokunmayalım. Buradan çekilip gitsin... kararını verdi.  
Vâkıa o da büyüye, sihire inanmazdı. Ama, halkın istemediği bir adamı şehirde bırakmayı, siyasete muhalif görüyordu. En vâhi bir şayia dan kan, kavga, nizâ çıkabilirdi. Ferruhşah, o gün adamlarını ihtiyar Doğan'a gönderdi. Sultanın emrini tebliğ etti. Ertesi sabah, evinin önüne toplanan halk, büyük kapının açıldığını, yedeklerinde birer deve çeken iki ihtiyarın çıktığını gördü. Öndeki beyaz sakallı, kısa boylu, mavi gözlü adam Büyücü Doğan'dı. Birçok kişi ilk defa olarak görüyordu. Arkadaki, kambur hizmetçisi... Onu zaten tanıyorlardı. Savrulan küfürleri, lanetleri duymuyor gibi ikisi de yere bakarak yürüyorlardı. Çöle çıkan caddeden gittiler. Açık kapıdan halk bahçeye üşüştü. Bağırarak evin her tarafını aradılar. Fıçı fıçı neftlerden, şişe şişe renkli sulardan, türlü türlü tozlardan, ne olduğunu anlayamadıkları birtakım cetvellerden, pergellerden, hendese aletlerinden başka bir şey bulamadılar. Hepsini kırdılar, kopardılar, döktüler, dağıttılar, yıktılar. Bir hafta geçmeden Büyücü Doğan unutuldu. Yıllarca onunla korkunç bir kabus, meşum bir birsâm gibi uğraşan Dımışk'ın mustarip ruhu sanki birdenbire rahatladı!

Ramazanda, ordusu ile Şam'dan çıkan Selahaddin, birkaç hafta sonra Safad'la Kevkeb'i de aman vererek aldı. Oranın ahalisini de Sur'a gönderdi. Beş altı sene içinde Irak'ta, Suriye'de hükmü altına girmeyen bir kale yoktu. Ötede beride kalan mutaassıp güruhu aman istiyor, teslim oluyorlardı. İslamın bu parlak galebelerinden kederlenen Papa'nın yüreğine inmişti. Mukaddes Roma-Cermen İmparatoru ile, Fransız kralı Filip, İngiliz Kralı Rişar... sonra Avrupa'nın bütün namdâr şövalyeleri haç alametleri taktılar. Filip'le Rişar, deniz yolu ile geleceklerdi. Sur, Avrupa'dan hıncahınç gelen imdatlarla o kadar doldu ki... kale bu kalabalığı almadı. Siyah bayraklı hadsiz hesapsız bir ordu Akkâ'ya doğru taştı, fışkırdı. Selahaddin, bu kara tufanın önüne yıkılmaz bir çelik kaya gibi çıktı. Bu kudurmuş canlı dalgaları kırdı. Sahrayı kırmızı, sakin bir denize çevirdi. Evet, birkaç saat içinde düşmanın on bin tanesini öldürdü. Geri kalanları esir etti. Ölüleri nehre attılar. Zira gömmek imkanı yoktu. Her taraf ceset dolmuştu. Nihayetsiz leş yığınlarının kötü kokusu havayı bozdu. Şanlı galip hastalandı. Kulunç illeti onu kımıldanamaz bir ıstırap yumağı haline soktu. Hekimler ölüm nehriyle kaplanmış bu er meydanının hemen terkine lüzum gösterdiler. Selahaddin, Akkâ'daki askerine: "Ben hastalandım, iyi olmak için buradan uzaklaşmaya mecburum. Siz sebat ediniz. Korkmayınız. Yine geleceğim." haberini gönderdi. Dünyayı titreten bu kahraman, sedye içinde kıvrana kıvrana Harube'ye gitti. Meydanı boş bulan mutaassıp Haçlılar, Akkâ'yı bütün kuvvetleriyle karadan, denizden sardılar.

Bütün kış muharebe ile geçti...

Mukaddes Roma-Cermen İmparatorunun, ordusu ile Suriye'ye yaklaştığı söyleniyordu. Yaz gelince kulunçları geçen Selahaddin, yatağından kalktı. Atına bindi. Bir dakika durmadı. Cihada koştu. Yine eskisi gibi ordusunu "Tel Kisan" da kurdu. Akk'acirc;'yı saran hesapsız kuvvete her gün hücuma başladı. Haçlılar fütur getirmiyorlardı. Her tarafa istihkâmlar kazmışlar, muhasara ordusundan başka, arkalarını vuran Selahaddin'e karşı da iki büyük ordu kurmuşlardı.

Artık Akkâ'yı kurtarabilmek ümidi sönüyor gibiydi.

Frenkler, deniz  yolu ile birçok kavi keresteler getirmişler; kalenin üç köşesine altmış arşın yüksekliğinde, beşer tabakalı üç büyük burç kurmuşlardı. Burçların her tabakasında asker vardı. Gece gündüz kalenin siperlerine ok, ateş yağdırıyorlar, büyük hendekleri dolduruyorlardı. Selahaddin, atıyla muharip saflarının arkasındaki küçük tepeciklerde geziniyor, kalenin etrafında yükselen bu büyük burçlara bakarak dişlerini gıcırdatıyor, — Ah gitti, ah gitti... diyordu. Vaâkıa içeriden bu burçların üstüne neft, paçavra filan atıyorlardı. Fakat, hiçbirisi tutuşmuyordu. Selahaddin, şahin gözleriyle kalenin müdafaadaki hareketini görüyor. "Acaba bu tahtalar niçin yanmıyor?" diye düşünüyordu. Bu merakını, o gün tutulan bir esir halletti: "Frenk mühendisleri kulelerin ahşap kısımlarını derilerle kaplamışlar, üstüne sirke, çamur, sonra birtakım yanmaz eczalar sıvamışlardı." Küçük, büyük, harple, amanla şimdiye kadar elli kale alan bu kahraman, sevgili Akkâ'sının can çekişmesine dayanamıyor, geceli gündüzlü, az kuvvetleriyle bu çok düşmana saldırıyordu. Artık iki taraf da fütur getirmek üzereydi. Hırsından kıvranan Selahaddin, bir sabah burçların birisinin tutuştuğunu gördü. Gözlerine inanamadı. Atının üstünde doğruldu. Sağ elini gözlerine siper yaptı. Dikkatle baktı. Arkasındaki muhariplere sordu: — Tutuşuyor, değil mi? — Evet... — Birdenbire? Alev içinde kalan burçtan müthiş bir vâveyla yükseliyordu. Her tarafı birden ateş sarmıştı. Dördüncü, beşinci tabakadan siyah noktalar yerlere atlıyordu. Diğer iki burçtaki askerler de bağırarak kaçışıyorlardı. Yarım saat geçmedi, bunlar da ateş aldı. Selahaddin hemen kat'î hücum emrini verdi. Ansızın iki ateş arasında ürken düşmanlar, mücahitlerin keskin kılıçları altında kırıla kırıla kaçtılar.

Selahaddin, kıymetli kalesine girmedi. Altındaki kemikleri görünen naaşlarla hâlâ cızırdayarak, fena bir koku çıkararak yanan yıkık burçların kömürleşmiş direkleri önünde atının dizginini kastı. Ordunun bir kısmı kaçıp kurtulanların arkasından gitmişti. Yaralılar toplanıyor, esirler bağlanıyordu. Huzurunda bugünkü muzafferiyetten sevinen yorgun kale kumandanına,  
— Bu kuleleri biz yanmaz biliyorduk. Nasıl yaktınız? Diye sordu.  
— Evvela yakamadık sultanım! Melunlar sirkeyle, çamurla her tarafını sıvamışlardı. Kale içinde bir ihtiyar garip çıktı: "Bana istediğimi veriniz, bu burçları yakayım" dedi. Ne istedi ise verdim; neft, kireç, pamuk, kil... Bir ay içinde üç bin tane humbara döktü. On beş gün de çalıştı, yedi oluklu, hiç görülmemiş bir mancınık yaptı. Bu sabah "Artık işim bitti. İsterseniz yakayım" dedi. "Haydi yak" dedim. Yaktı.  
Selahaddin merakla,  
— Nasıl yaktı? diye tekrar sordu.  
— Burcun en dolusuna, bir anda, yaptığı tuhaf mancınıkla humbaralar yağdırmaya başladı. Her tarafı evvela mor bir alev kapladı. İçindekiler de tutuştu. Öbür burçlardaki düşman, korkusundan kaçmaya başladı. Biz de kapıları açtık. Arkalarına düştük.  
— Şimdi bu ihtiyar nerede?  
— İçerde.  
— Ne yapıyor?  
— Kendine minnettar kalan ahalinin elleri üzerinde geziyor.  
— Sen ne mükafat verdin?  
— Mükafat kabul etmiyor. Ne verdimse reddetti.  
— Çabuk buraya getirt. Ben onu memnun etmek isterim.  
— Baş üstüne sultanım...  
. . . . . .

Al maşlah lı genç kumandan hızla uzaklaştı. Adamlarını kaleye koşturdu. Selahaddin evvelki kanlı boğuşmalara saha olan meydana bakıyor, direklerin arasında yanan cesetlerin keskin kokularından tiksiniyor, vücudunun her tarafında yine müthiş kulunç ağrıları duyar gibi oluyordu. Yarın, şüphesiz hava yine bozulacak, orduda hastalık başlayacaktı. Askerlerine, bütün ölüleri arabalarla denize taşıyıp atmalarını emretti. Liman da mutaassıpların elinden alınmış, Mısır'dan donanma tam vaktinde yetişmişti. Kalenin kapısından zafer, sevinç, şevk naraları savuran bir kalabalık çıktı. Selahaddin başını çevirdi. Elleri üstünde beyaz sakallı, küçük bir ihtiyar gördü. Akkâ'nın minnettar ahalisi, kendilerini ölümden, esirlikten kurtaran muhterem vücudu başlarında taşıyorlardı. — Ya Sultan! İşte bizi kurtaran! diye bağrışarak yaklaştılar. Üstü başı perişan, siyah başlıklı, beli bükük bir ihtiyar... Yere ayaklarını basınca biraz doğruldu. Çok sıkılmış olduğu yüzünden belliydi. Sultanın arkasından, atlılar arasındaki Şamlılar bir ağızdan, — Büyücü! — Büyücü Doğan! — Büyücü Doğan bu! diye haykırıştılar. Sonra, ansızın çöken derin bir sessizlik, bu hayreti daha beter ağırlaştırdı. Selahaddin, atından atladı, ihtiyara doğru birkaç adım attı. — Doğan! Sana bir deve, yüzbin dinar, hem de bütün Kerk malikânelerini ihsan ettim. Daha ne istersen söyle... Emirlik, hâkimlik, ne istersen...dedi. — Ben bir şey istemem. . . . . . . .

Sultan kalın kaşlarını çattı, başını salladı: — Hizmetin büyüktür! Sen burçları yakmasaydın Akkâ mutaassıpların eline düşecekti. Akkâ düşünce, biz İslamlar Suriye'de tutunamayacaktık. Kudüs'ü bile bırakıp çöle çekilmeye mecbur olacaktık. Sen hepimizi bu felaketten kurtardın. Yalnız bizi değil belki bütün İslamı kurtardın. Bu mükafata layıksın. Kabul et. İhtiyar kafasını yukarı kaldırdı: — Ben bu hizmeti Allah rızası için yaptım. Ödülümü ancak Allah'tan isterim! dedi. Sonra sultanın cevabına meydan vermeden döndü. Yüksek sesle hükümdarlarından, kaleye hemen kendisinin emir nasbolunmasını yalvarmaya başlayan Akkâlıları göstererek ilave etti: — Yalnız beni bunların elinden kurtar! . . . . . . .

# Cimnastiğe Dair - 2

3 Teşrin-i evvel, Kuşadası

Cimnastikle hayatım arasında o kadar eski ve samimî bir irtibat vardır ki tâlâb-ı hatıratıma müntehidir. Küçükken, ben daha dokuz yaşında bir çocukken Kuşdili’nde oturuyorduk. Bu musikişinas, gayet meşhur bir hanede komşumuzun benden biraz büyücek çocukları vardı. Bunlar koca çayırın her tarafında perende atarlar ve bir ramazan gecesi, Şehzadebaşı’nda, beni fevkalâde teshir eden küçük cambaz çocuğu gibi elleriyle yerde yürürlerdi.

Ben dört yaşından beri vefakâr kaldığım mâi boyal-ı sevgili çemberimi düdüklü değneğimle bahçenin bir köşesine atarak ellerim boş ve meshur her akşam çayıra çıkar, o çocukları seyrederdim. Nihayet bir gün çocukluğun tabiî olan hicap ve lâubalîliği ile mahcup ve metecasir, bu perende atmayı, bu ellerle yürümeyi bana öğretmelerini onlardan istirham ettim.

En büyükleri evvela “Valideniz darılır, belki...” nezaketiyle reddetti, sonra ısrar ve hararetli temennilerime dayanamayarak muvafakat etti. Ve ilk ders olmak üzere en lâzım olan belimin kabiliyet-i inhinasını temin etmeğe kalkıştılar, bana sordular ki: “Beliniz kırık mıdır?..”

Hiç böyle bir sual işitmemiştim. Mütehayyir ve mahfuf “Hayır” dedim.

“Öyle ise kıralım...”

Zavallı ben korku ve hayretimden mebhut, incimat etmiş gibi, onların ellerinde, beş on dakika kıvrıldım, düzeltildim. Daha sonra muallime benzeyen en büyükleri küçük dizini benim nazik belciğime dayanarak “haydi” kumandasını verdi, diğer ikisi kalçalarımla omuzlanma şiddetle bastılar; belimde bir intırak... O zamana kadar duymadığım ve tasavvur edemediğim bir kütleme... Başladım ağlamağa, onlar galiba bu ameliyeyi benden evvel birçok çocuk üzerinde tekrar etmişlerdi. Hiç gözyaşlarıma ehemmiyet vermeyerek “Sus, sus küçük bey, şimdi geçer, ağlama...” tesellisiyle beni terk ediverdiler. Ben de eve geldim ve belimin acısını, tekdir işitmemek için, yavru bir kedi tahammülüyle sakladım. Bu ağrı hakikaten geçti; fakat minimini insafsız hocalarımın dediği gibi bir “şimdi” zarfında değil, birkaç haftada...

Yine her akşam çayırda onları seyre dalıyordum. Onlar perende attıkça ben sanki manyetizma oluyor, cezb oluyor, gayr-i ihtiyarî yanlarına gidiyordum. Onlar da benim meyl-i mütehalikâneme rağmen en gösterişli hünerlerini icra ediyorlar, yekdiğerinin bellerine sarılarak, çifte perende atıp, müstehzi bir kütle-i sanat halinde uzaklaşıyorlardı.

Benden büyük olan bu küçük sanatkârların buluttan bakan müstağni gözleri benim küçücük masum izzet-i nefsimi cerihadar etti; ben niçin onlar gibi yapamıyor ve... oh hem de öğretirlerken ağlıyordum. Küçük müfekkirem ile düşündüm ki ilk defada perende atmak olmayacak. İlk defada bu nazik belin çekemediği bu nazik macakları havada tutmak lâzım... Bunun için de çalışmak lâzımdı, evde bu mümkün değildi, herkes “Aman boynun kırılacak yapma...” ihtarıyla menediyorlardı.

Bahçemizin bir köşesinde çiçeklikten bozma bir oda vardı ki orada aşçı ile ihtiyar uşağımız yatardı. Gündüzleri onların bulunmaması tam fırsat... Uşağın nim toplanmış yatağını hemen açar, ellerimle başımı o yumuşak yere dayayarak bacaklarımı havada tutmağa çalışır, düşer, yine kalkar; bıkmaz, usanmazdım. Ne kadar gün geçti, bilmiyorum, artık ellerim ve başım yerde, ayaklarımı yukarıda tutabiliyordum. Hemen çayıra koştum, onların, o çocukların önünde kendilerinin tenezzül etmeyecelerini bildiğim ehemmiyetsiz maharetimi ibraz ettim. Geçen gün ağlayan çocuğun bugün kavak duruşu taaccüplerini celp etti, mahaza takdir ettiler. Sonra başlayan mütereddit ve bîgâne bir arkadaşlık –çünkü birbirlerimizin isimlerini bilmiyorduk– içinde ve az bir zaman zarfında ben de ellerimle yürümesini ve birbiri arkasına dört beş perende atmasını öğrendim. Hatta yan perendelerde onlara bile takaddüm etmiştim.

Sonra beni hususî bir mektebe verdiler. Mekteple beraber inşa olunan cimnastikhane dün yapılmış gibi yeniliğini muhafaza ediyordu, yalnız fahrî olan cimnastik muallimi çocuklara tabur olmasını, ikişer ikişer yürümesini öğretirken onların celb-i hevesleri için yeni ve parlak halkalarda birkaç kere sallanırdı; sonra da küçük bir nutuk:

“Efendiler, kuvvetli olmak istiyorsanız, (ceketinin üzerinden pazularını göstererek) işte benim kollarım gibi kalın, kuvvetli bir kola malik olmak istiyorsanız cimnastik yapacaksınız. Düşmemek için kollarınızın kuvvetlenmesi lâzımdır, onun için de çok idman yapacaksınız...”

Eski kafa pederlerin evlâtlarını mektebe kaydettirirken dermiyan ettikleri “Müdür Bey mektebin bahçesinde gördüğüm cimnastik aletleri... Rica ederim çocuğu böyle kazalı şeyleren sevk etmeyiniz, çünkü cambaz olmayacaktır” şartı hilâfına her akşam bir saat kadar kazasız cimnastik yapılır; kollar ileri, aşağı, yukarı uzatılır, terlenilir, bitâp kalınırdı.

Bir gün cüretkâr ben muallimin önüne gittim ve “Müsaade ediyorsanız sallanmak istiyorum efendim” dedim. O lenfatik ve nazik talebesine taaccüp etti: “Fakat, düşersin.”

“Hayır, bendeniz düşmem.”

“Şimdiye kadar hiç cimnastik yaptın mı?”

Tehalükle cevap verdim: “Pek çok, emrederseniz önünüzde birkaç maharetimi tekrar edeyim?..”

Muallimin, istihfafkâr tebessümünden çıkan: “Haydi yap bakalım...”

Mulallim, bilhassa pek hoşlandı. Çünkü tevzi-i mükafatlarda, bazen maariften gelen müfettişler huzurunda, mektepte hakikaten cimnastik dersi verildiğini ispat ve irae edecek küçük bir artiste büyük bir ihtiyaç vardı.

Muallim de bu nokta-i nazarı muhakeme ederek benden istifade etti, gösterdiği hareketleri pek suhuletle yapıyordum. İki senede o kadar terakki ettim ki muallimin muavini olmuştum. Onun gelmediği günler, son dersten sonra hemen cimnastik elbisemi giyer, dar ve kalın kemerimi belime takar, bütün talebelere, hatta kendimden yukarı sınıflara bir amir mestî-i gururuyla kumanda ederdim.

“İkişer olunuz, eş tutunuz, ayaklarınız hep bir hizada olacak ve gülmeyeceksiniz.”

Sol elimin başparmağı kemerimin iri, kalın halkasına takılmış, sağ kolum bir zaviye-i mağrur-ı mücessem hâlinde arkamda, göğsüm kabarmış, o çocuk tabiiyetinin önünde gezinirdim.

“‘17’ haydi barfikse, ‘126’ siz halkalara, ‘49’ siz de merdivene...”

Sonra hepsinin hatalarını tashih, kendisini kaldıramayanlara muavenet ve pek kuvvetsiz olanlara da, ceza olarak yarım saat iki hafif halteri kaldırtır, indirtirdim...

Tahsilim büyüdükçe çemberimin metrukiyetiyle başlayan idmanım da büyüyor, maharetlerim tezayüt ve taaddüt ediyordu. Ailemin en eski kafa eşhası bile benim bir sür’at-i fevkalâde ile neşv ü nema bulan bünyeme bakarak cimnastiğin fevaidine itikat ediyorlardı; bir küçük ve tüysüz çocuk çehresinin altında katı pazulu, adalî bir delikanlı vücudu yaşıyor, vücudum koşuyor, yaşım geride kalıyordu. Seneler geçti, büyük mekteplere geçtim, artık müthiş bir cimnastik taraftarı, devamlı bir idmancı idim.

O vakit bir riyaziye muallimimiz vardı. Ders esnasında münasebet getirdikçe cimnastiğe girişir, o kadar tecavüz ederdi ki bütün sınıftakilerin nazarları bilâ-ihtiyar bana dönerdi.

“Efendiler; sakın cimnastik yapmayınız, zekânızı kaybedersiniz. Pehlivanları görüyorsunuz ya... hepsi aptal ve ahmaktır. Sınıfınızın birincisine, ikincisine, üçüncüsüne ve en zekilerine nazar-ı dikkatinizi celp ederim, bakınız bunların bünyeleri ne kadar kuvvetsiz, fakat fikirce, zekâca hepinize galiptirler.”

Ve bütün dünyadaki dershanelerde –pek az istisna ile– hâlin bu merkezde olduğunu iddia eder, fikrini teyit için bahsettiklerine cimnastik yapıp yapmadıklarını sorar, “Kat’iyen hayır...” cevabını alırdı. Teneffüs zamanı münakaşacıların hepsi başımda... Ben bu hatt-ı muhasaraya, bu hücum-ı sual ve iddiaya mukabele etmek için muhakemesiz bir mektepli nezaketsizliğiyle muallimi gıyaben tahkire başlar, “O ne çakar?..” derdim. Harikulade şöhretler, pehlivanlar, o dünyanın eski kahramanları, onların insafsız musaraaları, kanlı müsabakaları hep boş muydu?.. Şimdiye kadar onun gibi bir akıllı çıkıp niçin “bu fenadır” dememiş?

Ve ilh.

Bu zeminde önü ve arkası olmayan boş bir farfara ile muterizleri iskât eder, susturamadığım ve benim müdafaalarımı ciddî ve tamam itirazlarla cerh eden gayet zeki bir refikimin nazik bileklerini kuvvetli pençelerimle sıkarak “Artık sus” derdim, “bak bir şey söyleyebilir misin?..”

Zavallı susardı, idmancı arkadaşlar bu refike cimnastik mikrobu lâkabını vermişlerdi.

Ben, bu cimnastik mikrobunu ihtida ettirmek –cimnastik yapmayanları kandırıp kabul ettirmek için tabir-i mahsusumdu– ümniyesiyle boş zamanlarda, tenha bir yerde yakalar, evvelâ mağlûbane bir hasbıhâl ile mübahaseye girişerek onu mağlûp etmeğe çalışırdım.

“Azizim, rica ederim, ciddî görüşelim bu sefer. Şimdi ben daima seni cimnastiğe, terbiye-i bedeniyeye teşvik ediyorum, bir cambazhane müdürü değilim ki sende bir emel-i istifade tahayyül edeyim, benim saikim samimiyet ve senin gibi zeki bir vücudun sıhhat-i müstakbelini temin etmektir.”

“Teşekkür ederim, ama ben de aynı senin hissinle mütemessih, yani sen, senin sıhhatini kurtarmak hissiyle... yazık, yazık ki vücudunu mahvediyorsun, fazla adalât ile, fuzulî harekât ile sarf-ı sıhhat ü hayal ediyorsun. Bir gün gelecek kafanı da kullanamayacaksın. Tedricî bir batâet-i gayr-i mahsusa ile ilerleyen gabavet, bir pehlivan behîmiyeti senin maneviyatını öldürecek.”

Münakaşamız saatlerce uzardı, en nihayet ben derim ki: “Sağlam bir vücuda salim bir fikir.”

O gülümserdi: “Tasdik ederim; ‘Sağlam bir vücutta salim bir fikir... fakat tabiata itisaf ve taaddi eden sun’î bir vücutta değil, ilel ve emrazdan salim tabiî bir vücutta.’”

Ve ilâve ederdi: “Eğer idman yapanların vücutlarını sağlam zannediyorsan pek, ama pek yanılıyorsun, bir pazunun şişmesiyle, diğer bir adalenin küçülmesiyle büyüyen bir adalenin gayr-i muntazam tahaccümüne kuvvet diyorsun. Bravo sana, kuvvet mukavemettir, yapılan idman mukavemeti tezyit değil, bilâkis tenkis eder, işte sana avamî, kat’î bir misal: Vücutlarına gıpta ettiğimiz pehlivanların eyyam-ı mahdûde-i hayatı, o zavallıların facia-i şeyhûhetleri...”

Ben mağlûbiyetini mümkün değil tasdik etmeyen bir inatçı... Seneler idmanla, bir müphemiyet-i rüya içinde geçti. Cimnastiğin aleyhinde bulunan Beyoğlu’na, cimnastik kulübüne yahut cimnastikhaneli büyük bahçelere götürüyor, karşılarında bir cevab-ı amelî gibi, en küçüğü kırk beş kilo olan ağır halterleri kaldırıyorum. Son sınıfların müteaddit dersleri, tahammülsüz vazifeleri beni idmandan mahrum bırakmadı. Ben her akşam muntazaman yemekten evvel idmanımı yapıyorum, L’Education Critique’in vürudunu her ay başı müziç bir intiraz ve tahassürle bekliyordum...

Mektep hayatından uzaklaştıktan bir müddet sonra idmanla kalp ve dimağın mesele-i teessürü beni epeyce işgal etti. Müntesib-i fen olmayan bir adam fenne ait ne kadar kitap okuyabilir ve cem-i malûmat edebilirse ben maazziyadetin yaptım; tasdik ettim ki idmanla ahen-i kalp bozuluyor, çünkü kalp tabiî adalât için çalışır. Şimdi bir kalbin idare ettiği iki pazu ki fevkalâde büyüyor, kalbin onlar için daha ziyade çalışması icap ediyor, diğer azanın hakkı ihmal olmuyor, bir kısmında zafiyet, diğer kısmında kifayetsizlik... İşte ahengi muhtel, şaşırmış bir kalp. Yalnız bu kadar olsa ne ise... Bu zavallı kalp de ağır ve çok hareketle şekl-i tabiî ve tabiat-ı hulkiyesini kaybediyor, büyüyor, tıpkı bir pazunun harekât-ı sakil ile büyüdüğü gibi... Tembelleşiyor, vücud-ı umumî için vaazifelerini unutuyor, sefil kalıyor.

Dimağın tesirine gelince: Faaliyet-i zihniye ve iştigalât-ı fikriye tezayüt ettikçe nasıl ibtida vücut ve bünye tenakus ediyor, iştigalât-ı fevkalâde-i bedeniye ve harekât-ı gayr-ı tabiiye-i sakile ile vücut zenginleştirildikçe bir inhitat-ı batî-i dimağî, bir donukluk, bir adem-i intizam zuhur ediyor.

Benim fikrim işte bunların itidalinden, vasatîsinden bahis ve onu ihsas etmektir, yani vücudun inhitatına mukabil olan iştigalât-ı fevkalâde-i fikriyeyi tahfif ve tanzim etmek, bir de fikir ve dimağın inhitat-ı batîsine muadil kazanılan yalancı, sahte o pek çabuk fâni bünyeye tamah etmeyerek harekât-ı tabiiye-i kâfiyeye terk-i vücut etmek.

Arzu ediyorum ki arazkâr, zayıf, cılız, muteriz bir efendi zannolunmayayım. Daha bana cimnastik hıyanet etmedi, çünkü gencim. En masum ve tamahkâr bir idmancıyı iftihar ettirebilecek pazulara, uyluklara, göğüse malikim. Bu malikiyetle beraber beyan-ı hakikat için husule gelen fenalıkları saklamayacağım.

Yazacaklarım tecrübelerime ve tetkikatıma müstenit olacak. Tecrübe –velev yanlış olsun– tahkir olunmaz. Tecrübeyi hiçbir felsefe tahkir etmez, nasıl ki riyaziyede doğru faraziyeler yanında aynı kıymeti haiz yanlış faraziyeler de vardır ki meselenin halline birinciler kadar hizmet eder. İşte hakikatin tezahürü için dermiyan olunan tecrübeler de böyledir. Doğrular kadar yanlışlar da kıymettardır, çünkü tecrübedir. Doğrunun kıymeti yanlışa kaimdir, miyarı odur.

Yanlış olması muhtemel tecrübelere, doğru olmaları muhtemel olanlara nispet ve yekdiğerleriyle mukayese olunur, hakikat tezahür eder!

Hâlbuki cimnastiğin, harekât-ı sakile-i gayr-i tabiiyenin fenalıkları, cimnastiğin fevaid-i maznûnesi kadar malûmdur. Bunu yalnız fevkalâde olarak, mafevkattabia olarak münhasıran ben iddia etmiyorum. Terbiye ve harekât-ı bedeniyeye en ziyade riayet eden akvamdan İngilizlerin en büyük, en meşhur hekimi, en muktedir ve namdar âlimi bütün memlekettaşlarını tenkit ediyor, cimnastiğin fenalığı ve tehlikesi için idare-i kelâm ve efkâr ediyor. Bununla beraber, fevaid-i mevhume-i zahiriyesi evvelâ umum tarafından tadik olunduğu hâlde fenalıkları, zararları, tehlikeleri sonradan meydana çıkan şeyler az mıdır?..

# Diyet

Dar kapısından başka aydınlık girecek hiçbir yeri olmayan dükkânında, tek başına, gece gündüz kıvılcımlar saçarak çalışan Koca Ali, tıpkı kafese konmuş terbiyeli bir arslanı andırıyordu. Uzun boylu, iri pençeli, kalın bazulu, geniş omuzlu bir pehlivandı. On senedir bu karanlık in içinde ham demirden dövdüğü kılıç namluları bütün Anadolu'da, bütün Rumeli'de, serhat boylarında büyük bir nâm kazanmıştı. Hatta İstanbul'da bile yeniçeriler, satın alacakları kamaların, saldırmaların, yatağanların üstünde "Amel-i Ali Usta" damgasını arıyorlardı. O, çeliğe "çifte su" vermesini biliyordu. Uzun kılıçlar değil, yaptığı kısacık bıçaklar bile iki kat olur, yine kırılmazdı. "Çifte su vermek", sanatının, yalnız ona özgü bir sırrı idi. Yanına çırak almaz, kimseyle çok konuşmaz, dükkânından dışarı çıkmaz, habire uğraşırdı. Bekardı. Hısımı, akrabası yoktu. Memleketin yabancısıydı. Kılıçtan, demirden, çelikten, ateşten başka laf bilmez, pazarlığa girişmez, müşterileri ne verirse alırdı. Yalnız muharebe zamanları ocağını söndürür, dükkânının kapısını kilitler, kaybolur; muharebeden  sonra meydana çıkardı. Şehirde ona dair birçok hikâyeler söylenirdi. Kimi "cellat elinden kaçmış bir çelebi", kimi "sevgilisi öldüğü için vakitsiz dünyayı terketmiş bir garip" derdi. Siyah şahane gözlerinin yüksek bakışından, kibar tavrından, mağrur sükunundan, düzgün sözlerinden onun öyle sıradan bir adam olmadığı belliydi... Ama kimdi? Nereliydi? Nereden gelmişti? Bunları bilen yoktu. Halk kendisini seviyordu. Şehirde böyle meşhur bir ustanın bulunması herkes için ayrı bir iftihardı.  
— Bizim Ali...  
— Bizim koca usta...  
— Dünyada eşi yoktur...  
— Zülfikâr'in sırrı ondadır!.. derlerdi.  
Koca Ali en kalın, en katı demirleri mısır yaprağı gibi incelten, kağıt gibi yumuşatan sanatını kimseden öğrenmemiş, kendi kendine bulmuştu. Daha oniki yaşındayken, sert bir beylerbeyi olan babasının başı vurulmuş, öksüz kalmıştı. Amcası çok zengindi. Debdebeli bir vezirdi. Onu yanına aldı. Okutmak istedi. Belki devlet katında yetiştirecek, büyük mevkilere çıkaracaktı. Fakat Ali'nin mizacında "başkasına minnettar kalmak" ihtimali derin bir elem sızlatıyordu. "Ben kimseye eyvallah etmeyeceğim," dedi. Bir gece amcasının konağından kaçtı. Serseri bir adsız gibi dağlar, tepeler, dereler aştı. İsmini bilmediği memleketler dolaştı. Nihayet Erzurum'da ihtiyar bir demircinin yanına girdi. Otuz yaşına kadar Anadolu'da uğramadığı şehir kalmadı. Kimseye boyun eğmedi. Minnettar kalmadı. Ekmeğini taştan çıkardı. Alnının teriyle kazandı. Çok çalıştı. Emsalsiz işler meydana getirdi. Pek az kazanca kanaat etti. İçinde "mukaddes ateş"ten bir şûle bulunan her mucit gibi, para için değil, sanatı, sanatının zevki için çalışıyordu. "Çeliğe çifte su vermek" onun aşkıydı. Gönüllü gibi muharebelere gittiği zamanlar yeniçerilerin, sipâhîlerin, sekbanların içinde "Ali Usta" işinin methini işittikçe tadı dille anlatılmaz manevi bir zevk duyardı. Ölünceye kadar böyle hiç durmadan çalışırsa daha birkaç bin gazîye kırılmaz kılıçlar, kalkanları parçalayan çelik yatağanlar, zırhları kesen ağır saldırmalar yapacaktı. Bunu düşündükçe gülümser, tatlı tatlı yüreği çarpar, ruhundan kopan bir hamleyle örsünün üzerinde milyonlarca kıvılcımlar tutuştururdu.  
— Tak!  
— Tak, tak!...  
— Tak, tak!

İşte bugün de sabah namazından beri durmadan on saat uğraşmıştı. Dövdüğü eğri namluyu örsünün yanındaki su fıçısına daldırdı. Ocağının sönmeye başlayan ateşine baktı. Çekici bırakan eliyle terini sildi. Kapıya döndü. Karşıki mescitte hazin hazin akşam ezanı okunuyor; bacasının tepesindeki yuvada leylekler nihayetsiz bir takırtı koparıyorlardı. İkindi abdesti daha duruyordu. Yalnız ellerini yıkadı. Kuruladı. Yenlerini indirdi. Saltasını omzuna attı. Dışarıya çıktı. Kapısını iyice çekti. Kilitlemeye lüzum görmezdi. Uzun meydandan mescite doğru yürüdü... Şehrin kenarındaki bu mütevazi mabede hep fakirler gelirdi. Minaresi sokağa bakan küçük bir pencereydi. Müezzin buradan başını çıkarır, ezanını okurdu.

Koca Ali mescide girince her vakitkinden fazla bir kalabalık gördü. Daima üç kandil yakılırken bu akşam Ramazan gibi bütün kandiller yanmıştı. Daha namaz safları dizilmemişti. Kapının yanına çöktü. Yanında alçak sesle konuşanların sözlerine istemeye istemeye kulak kabarttı. Konya'dan iki garip derviş geldiğini, yatsı namazına kadar Mesnevî okuyacaklarını duydu.

Akşam namazı kılınıp bittikten sonra cemaatin bir kısmı çıktı.

Koca Ali yerinden oynamadı. Zaten biraz başı ağrıyordu. "Mesnevî dinler, açılırım!" dedi. Büyük bir gönül rahatlığı içinde, iki garip dervişin ruhu ürperten nağmeleriyle gaşyoldu. Her âşık gibi onun kalbinde de nihayetsiz bir vecd, bir heyecan, bir galeyan istidâdı vardı. En küçük bir vesileyle coşardı. Mânâsını anlamadığı bu lisanın uhrevî ahengi onun sakin kanını sular altında saklı derin bir girdap gibi kaynattı. Her tarafı sebepsiz bir sarsıntıyla titriyor, sökülmez bir hıçkırık boğazına tıkılır gibi oluyordu. Yatsı namazını kıldıktan sonra mescitten çıkınca, doğru dükkânına giremedi. Yürüdü. Uykusu yoktu. Ilık, yıldızlı bir yaz gecesiydi. Saman uğrusu, sarı altın tozundan nihayetsiz bir bulut gibi göğün bir tarafından öbür tarafına uzanıyordu. Yürüdü, yürüdü. Şehirden mandıralara giden yolun geçtiği tahta köprüde durdu. Kenara dayandı. Geniş derenin dibine akseden yıldızlar, nurdan çakıltaşları gibi parlıyor, şırıldıyordu. Kenarlardaki karanlık top söğütlerde bülbüller ötüyordu. Daldı, gitti. Saatlerce kımıldamadı. Dinlediği nağmelerin, ruhunda kalan ahenklerini işitiyor, tıpkı mescidde gibi gaşyoluyordu. Ansızın arkasından bir ses:  
— Kimdir o?...  
Diye bağırdı.  
— ....  
Daldığı tatlı âlemden uyandı. Döndü. Köprünün öbür tarafından iki üç karaltı ilerliyordu. Gayr-i ihtiyarî cevap verdi:  
— Yabancı yok!  
— Kimsin?  
— Ali...  
— Hangi Ali?  
— .....  
Gölgeler yaklaştılar. Bir adım kalınca onu kıyafetinden tanıdılar:  
— Koca Ali... Koca Ali, be!  
— ....  
— Sen misin, Ali Usta?  
— Benim!  
— Ne arıyorsun bu vakit buralarda?  
— Hiç...  
— Nasıl hiç? Suya çekicini mi düşürdün yoksa!...  
— !....  
Bunlar şehir subaşısının adamları, dizdarlardı. Kol geziyorlardı. Ne cevap vereceğini şaşırdı. Geceleri afyon yutan bu serseriler, ehl-i ırzlar nazarında hırsızlardan, uğursuzlardan daha korkunçtu. Kendilerinden başka dışarıda bir gezeni yakaladılar mı, dayaktan canını çıkarırlardı. Ama, ona fena muamele etmediler. Dizdarbaşı:  
— Ali Usta, sen deli mı oldun? dedi.  
— Yok...  
— Böyle gece yarısına yakın değil, hatta yatsıdan sonra sokakta, bâhusus böyle şehir kenarında kimsenin dolaşmasına ağamızın razı olmadığını bilmiyor musun?  
— Biliyorum.  
— Ey, ne arıyorsun buralarda?  
— Hiç...  
— Nasıl hiç?..  
— .....  
Koca Ali yine cevap vermedi. Dizdarlar onun namuslu bir adam olduğunu biliyorlardı. Hırpalamadılar. Yalnız:  
— Haydi yerine git, dolaşma... dediler.  
Geldiği yollardan hızlı hızlı dönen Koca Ali, ruhunda demin dinlediği ahengi tekrarlıyordu.  
Bülbüller keskin keskin ötüyor, uzaktan mandıraların köpekleri havlıyorlardı. Sokakta hiç kimseye rastgelmedi. Dükkânının önüne gelince durdu. Bacasının üstündeki leylek uyumamış, kefenli bir hayal gibi ayakta duruyordu. Kapısı aralıktı. Çıkarken sıkı sıkıya kapadığını hatırladı:  
— Tuhaf, rüzgâr açmış olacak!...  
Dedi. Dükkanında örsü ile çekicinden başka kıymetli bir şeyi yoktu. Bunlar da çalınmaya değmezdi. Kimsenin işine yaramazdı ki, hırsız aşırmak sıkıntısına girsin...

İçeriden kapıyı sürmeledi. Dizdarların müdahalesi canını sıkmıştı. İşte şehirde yaşamak da bir türlü esirlikti. Halbuki dağ başında, köyde sanatı geçmezdi. Birden ağır bir yorgunluk duydu. Kandilini yakmaya üşendi. Ocağın soluna gelen alçak musandıraya el yordamıyla çıktı. Büyük bir ayı pöstekisinden ibaret olan yatakçığına uzandı.

Sıçrayarak uyandı. Kapısı vuruluyordu. Uyku sersemliğiyle:  
— Kim o? diye haykırdı.  
— Aç çabuk.  
. . . . .

Sabah olmuştu. Kapının aralıklarında bembeyaz ziya çizgileri parlıyordu. O hiç böyle dalıp kalmaz, güneş doğmadan uyanırdı. Doğruldu. Musandıradan atladı. Ayakkabılarını bulmadan yürüdü. Hızla sürmeyi çekti. Birdenbire açılan kapının, dükkânı dolduran aydınlığı içinde, palabıyıklı, yüksek kavuklu dizdarbaşıyı gördü. Arkasında keçe külâhlı, çifte hançerli genç yamakları da duruyorlardı. "Ne var?"  gibi yüzlerine baktı. Dizdarbaşı:  
— Ali Usta, dükkânı arayacağız! dedi.  
Koca Ali şaşkınlıkla sordu:  
— Niçin?...  
— Bu gece Budak Bey'in mandırasında hırsızlık olmuş.  
— Ee, bana ne?...  
— Onun için işte dükkânı arayacağız.  
— O hırsızlıktan bana ne?  
— Hırsızlar, çaldıkları bir kuzuyu köprünün altında kesmişler. Meşin keselerin içindeki paraları alarak bir tanesini oraya bırakmışlar.  
— Bana ne?...  
— O keselerden bir tanesini de bu sabah senin dükkânın önünde bulduk. Sonra... Şu eşiğe bak. Kan lekeleri var!  
Koca Ali, kamaşan gözleriyle kapısının temiz eşiğine baktı. Hakikaten el kadar bir kan lekesi sürülmüştü. O, bu kırmızı lekeye dalgın dalgın bakarken, palabıyıklı dizdar:  
— Hem bu gece, geç vakit, ben seni köprünün üstünde gördüm. Orada ne arıyordun? dedi.  
— ...  
Koca Ali yine verecek bir cevap bulamadı. Önüne baktı:  
— Arayın...  
Diye geri çekildi. Dizdarla yamakları dükkâna girdiler. Örsün yanından geçen yamaklardan biri haykırdı:  
— Ay! İşte, işte...  
— !..  
Koca Ali gayr-i ihtiyarî, dizdarın baktığı tarafa gözlerini çevirdi. Yeni yüzülmüş bir deri gördü. Şaşırdı. Yamaklar hemen deriyi yerden kaldırdılar. Açtılar. Daha ıslaktı. Bir ağalarının, bir de mücrimin yüzüne bakıyorlardı. Dizdarbaşı hiddetlenerek sordu:  
— Çaldığın paraları nereye sakladın?  
— Ben para çalmadım.  
— İnkâr etme, işte kuzunun derisi dükkânında çıktı.  
— Bu deriyi ben buraya koymadım.  
— Ya kim koydu?  
— Bilmiyorum.  
. . . . . .

Koca Ali zaten çok lakırdı söyleyemezdi. Subaşının karşısına çıkartıldığı zaman da, gece geç vakit köprünün üstünde ne aradığını anlatamadı. Dizdarların bulduğu bütün deliller aleyhine çıkıyordu. Budak Bey'in yeni sattığı beşyüz koyun ücreti de  mandıradan çalınmıştı. İki kuvvetli hırsız, bekçi çobanı sımsıkı bağlamışlardı. Sonra canını çıkarıncaya kadar dövmüşler, hatta işkence için bir kolunu da kırmışlardı. Ertesi gün hâkimin  huzurunda bu çoban, hırsızın birini Koca Ali'ye benzettiğini söyledi. Gece geç vakte kadar dükkânına gelmemesi, derinin dükkânda, para keselerinden birinin kapısı önünde bulunması, Koca Ali'nin ithamına kâfi geldi. Ne kadar inkâr etse hırsızlığı te'vil götürmüyordu. Zaten hükümetçe nereden geldiği, nereli olduğu da belli değildi.

Sol kolunun kesilmesine karar verildi.

Koca Ali, bu kararı duyunca ömründe ilk defa olarak sarardı. Dudaklarını ısırdı. Karara rızadan başka çare yoktu... Sendeleyerek ayağa kalktı. Hâkime dik bir sesle: — Kolumu bırakın, kafamı kesin! Diye rica etti. bu ömründe ilk ricasıydı. Fakat ihtiyar hâkim çok adildi: — Hayır oğlum, dedi, sen adam öldürmedin. Eğer çobanı öldürseydin, o vakit kafan giderdi. Ceza kabahate göredir. Sen yalnız hırsızlık ettin. Kolun kopacak. Hak böyle istiyor. Şeriatin kestiği yer acımaz.. — ... . . . . . .

Koca Ali'nin kolu kafasından çok kıymetliydi. Çeliğe "çifte su"yu bu iki kol sayesinde veriyor, bu iki el sayesinde serhadlerde dövüşen binlerce gaazîlere çelik kalkanları kıran, ağır zırhları yırtan, demir tolgaları ikiye biçen tüy gibi hafif kılıçlar yetiştiriyor, yok pahasına, pîr aşkına çalışıyordu.

Onu, Ağa kapısında dizdarların odası altına kapattılar. Kısas gününü burada bekliyor, hıç sesini çıkarmıyor, çolak kalınca örsünün başında çekiç vuramayacağını düşünerek, mâbudu ölen  bir mümin matemini duyuyordu. Kolunun diyetini verecek on parası yoktu... Şimdiye kadar para için çalışmamıştı.

...Bütün şehir halkı, Koca Ali gibi mahir bir ustanın kolu kesileceğine acıdı. Bu kadar yakışıklı, mert, çalışkan, kuvvetli, güzel bir adamın ölünceye kadar sakat sürünmesine en duygusuz vicdanlar bile dayanamıyordu.

İşte herkes onu seviyordu.

Sipâhîler kendilerine pek ucuz kılıç döven bu adamı kurtarmaya sözleştiler. Şehrin en büyük zengini Hacı Mehmed'e müracaat ettiler; bu adam Karun kadar mal sahibi olduğu halde son derece hasisti. Hâlâ şehrin pazar yerinde küçük bir dükkânda kasaplık yapıyordu. Düşündü, taşındı; nazlandı. Suratını ekşitti. Başını salladı. Ama sipâhîlerle hoş geçinmek lazımdı. — Madem ki siz istiyorsunuz, dedi, ben de önün kolu için diyet veririm. Ama bir şartla... — Ne gibi? diye sordular. — Varın kendisine söyleyin. Eğer ben ölünceye kadar bana bedava hizmetçilik, çıraklık etmeye razı olursa... — Pekâlâ, pekâlâ... ...Sipâhîler, Ağa kapısına koştular. Hacı Kasap'ın teklifini Koca Ali'ye söylediler. O, evvela "kasaplık bilmediğini" ortaya sürdü. Kabul etmek istemiyordu. Sipâhîler "Adam sen de! Kasaplık iş mi? O kadar harp gördün. Kılıç salladın. Bağlı koyunu yer yatırıp kesemez misin?" diye ısrar ettiler. "Kula kul olmak", fâni dünyada "birisine minnettar kalmak" azapların en ağırı idi.

O daha pek gençken, vezir amcasının lütfunu bile çekememiş, minnettar kalmamak için aile ocağından kaçmış, gurbet ellerine atılmıştı. Şimdi kör talihi, onu bak kime köle edecekti?

Sipâhîler: "Hacı'nın yaşı yetmişi aşmış... Zaten daha ne kadar yaşar ki... O ölünce yine sen hür kalır, bize kılıç yaparsın. Haydi, düşünme usta, düşünme!" diyorlardı.

Hacı Kasap, kesilecek kolun diyetini hâkime saydığı gün, Koca Ali'yi arkasına taktı. Dükkâna getirdi. Bu adam gayet titiz, gayet huysuz, gayet berbat bir ihtiyardı. Hiç durmadan dırdır söylenirdi. Hasisliğinden şimdiye kadar bir hizmetçi, bir çırak tutamamıştı. Koca Ali'yi eline geçirince hemen dükkânının köşesinde bir set yerleştirdi. Üstüne bir şilte koydu. Geçti, oraya oturdu. Her şeyi ona yaptırmaya başladı. Ama her şeyi... Sabah namazından beş saat evvel şehirden iki saat ötedeki mandırasından o gün satılacak koyunları ona getirtiyor, ona kestiriyor, ona yüzdürüyor, ona parçalatıyor, ona sattırıyor... Tâ akşam namazına kadar durmadan emirler veriyordu. Zavallıya verdiği yalnız bulgur çorbasıydı. Bazen kendi artıklarını köpeğe verir gibi önüne atardı. Geceleri dükkanı baştan aşağı yıkatıyor, uykuya yatırmadan ertesi sabah için koyun getirmek üzre mandırasına yolluyordu. Odununu bile ormandan ona kestiriyor, suyunu ona taşıtıyor, her işi, her işini ona gördürüyordu. Hatta evinin bahçesindeki lağım kuyusunu bile ona ayıklattı.

Koca Ali sade suya bulgur çorbasıyla bu kadar zahmetlere yıllarca göğüs gerebilecekti. Fakat Hacı Kasap'ın ikide bir: — Ulan Ali!... Kolunun diyetini ben verdim. Yoksa çolak kalacaktın!... Diye yaptığı iyiliği tekrarlamasını çekemiyordu. Bir gün, iki gün, üç gün dişini sıktı. Durmadan çalıştı. Gece uyumadı. Gündüz koştu. Efendisinin karşısında elpençe dîvan durdu. Yine: — Kolunun diyetini ben verdim. — ... — Şimdi çolak kalacaktın, ha... — ... — Benim sayemde kolun var. — ... Hacı Kasap, âdeta bu sözleri "aferin" tarzında diline pelesenk etmişti. Her emrinin icrasından sonra kır sakallı, çirkin, sıska suratını ekşiterek, mavi çukur gözleriyle onu tepeden tırnağa kadar süzer, "Aklında tut, benim esirimsin!" der gibi verdiği diyeti hatırlatırdı. Koca Ali susar, kalbinin yırtıldığını, göğsüne sıcak sıcak bir şeyler yayıldığını, kilitlenen çenelerinin çatırdadığını, şakaklarının attığını duyardı. Geceleri uyuyamıyor, gündüzleri uğraşırken, mandıraya gidip gelirken, salhânede koyunları yüzerken, müşterilere et keserken, "Ne yapacağım, ne yapacağım?" diye düşünüyor, hiçbir şeye karar veremiyordu. Dünyada kimseye eyvallah etmeyerek kanaatle, gururunun saadeti için yaşamak isterken başına gelen bu bela neydi?

Kaçmayı namusuna yediremiyordu.

İşte o vakit gerçekten hırsızlık etmiş olacaktı.

Fakat bu herifin ikide bir de bu yaptığını başa kakmasına tahammül... Ölümden pek güç, ölümden pek acı, ölümden pek ağırdı...

Hacı Kasap'a köle olduğunun tam haftasıydı. Günlerden Cuma idi. Yine erkenden mandıraya gitmiş, koyunları getirmiş, salhânede yüzmüş, dükkandaki çengellere asmıştı. Tezgahın solundaki büyük, yağlı siyah taşta satırları biliyor, yine "Ne yapacağım, ne yapacağım?" diye düşünüyor, dudaklarını ısırıyordu. Daha efendisi gelmemişti. Satırları bitirince, büyük bıçakları bilemeye başladı. "Ne yapacağım, ne yapacağım?" hülyasına öyle dalmıştı ki... Kasabın geldiğini duymadı. Ansızın uğursuzun boğuk sesi yüreğini ağzına getirdi:  
— Ne yapıyorsun be?...  
Döndü. Efendi köşesinde oturmuş, çubuğunu tüttürüyordu:  
— Bıçakları biliyorum, dedi.  
— Hay tembel miskin hay!... Sabahtan beri ne yaptın?  
Cevap vermedi. Kapakları çürümüş bu küçük, bu hain, bu yılan gözlere kırpmadan baktı, baktı. İhtiyar beklemediği bu acı bakıştan kızdı. Sordu:  
— Ne bakıyorsun?  
— ...

Koca Ali, sesini çıkaramıyor, bir hafta içinde belki beş senelik hizmetini durup dinlenmeden gördüğü halde, kendini yine "tembel, miskin" diye tahkir etmeye sıkılmayan bu kötü insanı ezici bir bakışla süzüyordu. Yine kalbi yırtılır gibi oluyor, göğsüne sıcak bir şeyler yayılıyor, çeneleri kilitleniyor, şakakları zonkluyordu. Bir anda bu titreme durdu. Koca Ali gözlerini açtı. Bir hafta buna nasıl tahammül etmişti? Şaşırdı. Hacı Kasap çubuğu yanına bıraktı. Hizmetçisinin bu ağır bakışından kurtuluvermiş gibi dırlandı: — Kolunun diyetini benim verdiğimi unutuyorsun galiba, dedi, ben olmasam şimdi çolak kalacaktın...

Koca Ali yine cevap vermedi. Acı acı gülümsedi. Kızardı. Sonra birden sarardı. Hızla döndü. Bilediği satırların en büyüğünü kaptı. Sıvalı kolunu, yüksek kıyma kütüğünün üstüne koydu. Kaldırdığı, ağır satırı öyle bir indirdi ki... O anda kopan kolunu tuttu. Gördüğü şeyin dehşetinden gözleri dışarı fırlayan Hacı Kasap'ın önüne: — Al bakalım, şu diyetini verdiğin şeyi! diye hızla fırlattı. Sonra esvabının kolsuz kalan yenini sıkı bir düğüm yaptı. Dükkândan çıktı.

Onun, vaktiyle geldiği yer gibi, şimdi gittiği yeri de, şehirde kimse öğrenemedi.

# Dünyanın Düzeni

(Bir genç kızın hatıra defterinden kopya edilmiştir.)

Bir ay geçmeden fikrim değişti. Amma öyle yavaş yavaş değil... Birdenbire! Bugün anneme hak veriyorum. Dünyanın düzeni bozulmayacak! Ben de her kız gibi mutlaka bir kocaya varmalıyım. Hani kesin kararım? Gülmekten katılıyorum:  
— İstemem, istemem, kocaya varmayacağım!  
— Niçin?  
— Niçinse niçin... İstemem, istemiyorum!  
— ?..  
— !..  
Acaba bu densizliklerime gerçekten inanıyorlar mıydı? Deli gibi kalk, zavallı horozu öldür, sonra erkeklerin doğası, temel olarak bu hayvana benziyor diye, ölünceye kadar kocaya varmaktan vazgeç... Olur iş değil... Ben gerçekten biraz şey... Haydi neyse, söylemeyeyim!

Fikrimin birdenbire değişmesine yine bu öldürdüğüm horozun hayali neden oldu... Önceki gece müthiş bir kabus gördüm. Kabus ile rüya arasındaki farkı bilirim. Rüyada insan serbesttir. İstediği gibi hareket edebilir. Bir dereceye kadar iradesine sahiptir. Fakat kabus! İnsan kımıldayamaz. Ağzını açamaz. Sesini çıkaramaz. Benim geçirdiğim kabus, rüyayla karışıktı. Horozu karyolamın ayak ucuna konmuş gördüm. Ağzında peynir topacı gibi bir şey tutuyordu. Dikkat ettim. Sırtına vurup öldürdüğüm taş... Bunu kaldırdı, üzerime fırlattı. Korkunç bir gürültü... Sanki bir dağ yıkıldı. Haykırmak istedim. O da mümkün değil. Horozun gözleri ateşten bir mercan gibi kıpkırmızı parlıyordu. Keskin keskin, uzun uzun öttü. Her ötüşünde titriyordum. Sonra tıpkı bir insan gibi kalın sesli, gürbüz bir savaşçı gibi, eski bir şövalye gibi bana sordu: — Neden beni öldürdün? "Ben öldürmedim!" diyecektim, dilimi oynatamadım, korkudan donmuş, taş olmuştum. Fakat o benim aklımda geçen cevabı işitti. — İnkar etme!, dedi. İşte haberim olmadan sırtıma attığın taş! Fakat neden beni öldürdün? Cevap veremiyordum. Karşımdaki büyüyor, büyüyor, adeta bir dev halini alıyordu. Hiddetle söylenirken oynattığı kanatları o kadar muhteşem, o kadar iriydi ki... Hemen hemen tavanı kaplıyordu. Kabarık göğsündeki parlak kıvılcımlı tüyleri, altından bir zırh gibiydi. Sivri gagasından kelimeler çıkarken sanki birer ok oluyordu. Üzerime atılacakmış gibi çırpınarak, kanatlarını çırparak laflar söylemeye başladı. Demir pençelerinin altında karyolam zangırdıyor, sanki bir zelzele her tarafı sarsıyordu. — Neden beni öldürdün? — . . . . . . — Susuyorsun işte, hain kız! Sen benim güzelliğimi çekemedin. Gördün ki, ben miskin tavukların hepsinden güzelim! Altın mantom var! Güneşten parlak gözlerim var! Aslandan kuvvetliyim! Kümesin beyi, efendisi, kralıyım... Söylerken sanki insanlaşıyor, çizmeli, tuğlu, sorguçlu, miğferli bir savaşçı oluyor; bu sorguçlar, miğferler, silahlar, kalkanlar, kılıçlar eriyerek tüy, kanat, gaga, ibik, mahmuz haline giriyordu. Fakat bu gaga, bu kanatlar, bu ibik, bu mahmuzlar; kılıçlardan, kalkanlardan pek çok korkunçtu. Evet, bu güzel, gayet güzel bir ejderhaydı. Ben, hârelene hârelene karşımda değişmesine bakarken susmuyor, yine söyleniyordu: — ... Büyükleri küçükler, zenginleri fakirler, kuvvetlileri zayıflar, güzelleri çirkinler çekemezler. Sen de benim güzelliğimi çekemedin. Sen çirkindin, ben güzeldim. — Hayır, hayır, senin güzelliğinin önemi yok! Ben zavallı tavuklara ettiğin zulümlere kızdım, diye haykıracaktım. Sesim çıkmadı. Ama zihnimden geçen cevabı o yine işitti: — Tavuklara zulüm mü? Hay aptal kız hay!... diye tıpkı bir insan kahkahasıyla odayı çınlattı. Tavuklara zulüm ha... Bu zulüm, tavuklara lütuftur. Nimettir. Lezzettir. Onlar dövüldükçe sevinirler. Gagalandıkça neşeleri artar, benim gözlerimin önünde birbirleriyle ne kavga, ne gevezelik edebilirler. Ben olmadım mı yumurtlamayı filan bırakırlar. Hepsi iğrenç birer obur kesilirler. Bir solucan, bir böcek için onu, yirmisi boğuşmaya başlar. Ne vuran, ne döven, ne dayak yiyen, ne bulunmuş şeyi kapan bellidir. Yani bir curcuna... Ama boğazları doydu mu, yine hepsi umutsuz olur. Birer köşeye çekilir, pineklerler. — Fakat rahat ederler, demek istedim. — Rahat ne demek. Tembellik, miskinlik! Uyanık uyumak! Diriyken ölmek değil mi? Rahat, rahat! Yorgunluksuz rahat, dünyanın en ağır azabıdır. Tavuklar ben yokken değil, asıl ben varken rahat ederler. — Hayır, hayır... Hayır işte!, demek istedim. Güzel ejderhanın gözleri hiddetten tekrar tutuştu, ibiğinden kırmızı alevler çıktı. Mahmuzları çatırdadı; kanatları bir şimşek gibi aydınlıklar saçarak gürledi. Sanki binlerce metreden üzerime atladı. Haykırdım. O zaman kabus bozuldu. Rüya başladı. Bu kocaman horoz saçlarımı yoluyor, üstümü başımı didik didik ediyordu. Kafamı gagasının çift uçlu bir hançer gibi deldiğini, pençelerindeki tırnakların, omuzlarıma, kaburgalarıma saplandığını duyuyordum. Kendimi karyoladan aşağı attım. Kapıya doğru kaçarken beni yine tuttu. Gagasıyla havaya kaldırdı. Tıpkı Pamuk'a yaptığı gibi yere çarptı. Boynumu halıya sürtüyordu. Haykırıyordum. Gece kandili birdenbire sönmüş, oda zifiri karanlık kesilmişti. Ateşten bir canavar gibi yalnız horoz parlıyor, altın kırmızısı alevler duvarlarda uçuşuyordu. Bağırıyordum. Beni öldürüyordu.

Uyandığım zaman ter içindeydim. Kimbilir ne kadar çırpınmıştım... Yorgan aşağı düşmüştü. Baş yastığımın bir tanesi göğsümdeydi. Saçlarım dağılmıştı. Hele vücudum... Adeta kımıldayamıyordum. Sanki bütün kemiklerim kırılmış... Fakat ne tatlı, ne hoş, ne ruhsal bir ıstırap, Yarabbi! Bu korkunç rüyaya tekrar dönmek olasılığı olduğunu bilseydim, hemen gözlerimi kapayacaktım. Gerçekten, acının, korkunun, zulüm görmenin, dayak yemenin, gagalanmanın, didiklenmenin pek başka bir lezzeti var! Mazlumun duyduğu bir lezzet ki, zalim bunu hayalinde bile canlandıramaz... İstemeye istemeye, altüst olmuş yataktan kalktım. Aşağı inerken balkona saptım. Dirseğimi kenara dayadım, dalgın dalgın bahçenin perişan haline bakmaya başladım. Burası tamamıyla bir harabeydi. Ne zamandan beri tavuklar yumurtayı kesmişlerdi. Duvar diplerinde kötürüm gibi yatıyorlar, daha henüz sabah olduğu halde sanki uyukluyorlardı. Sebepsiz bir üzüntü, bir keder... Bir soğukluk! Bir ölüm soğukluğu! İçimden, — Demek eski şen hayat, eski gürültü, eski hareket hep horozdanmış, dedim. Zihnimle beraber anılarım da açıldı. Kümesin bir aylık tarihini aklımdan geçirdim. Tavukların düzeni gerçekten bozulmuştu. Zamanla kümese girmiyorlardı. Horoz sağken dövüşmezlerdi. Şimdi birbirlerinin gözlerini oyuyorlardı. Bunlara bir baş, bir efendi, bir kral lazımdı. İşte kümes horozsuz kaldı mı, perişan oluyordu. Ben, sözde tavukları semirtmek için zavallı efendilerini öldürmüştüm. Halbuki onun zulmü, aynı lütufmuş!

Biraz semirdiler... Ama hepsi son derece arsız, yüzsüz, hırsız, tembel oldu. Yumurtlamak kalktı. Gıt gıdak sesleri kesildi, "Yarın mutlaka bir horoz bulmalıyım" diyordum. Yine dayak, gürültü, hareket başlayınca, bu sersem, bu dağınık hayvancıklar bir yere toplanacaklar; uykuyu, uyuklamayı, pineklemeyi bırakıp güzel güzel yumurtlamaya, civciv çıkarmaya koyulacaklardı. Hayat da yani mutluluk da bundan başka bir şey miydi?  
— Ne yapıyorsun orda?  
. . . . . . . . . . . .

Başımı çevirdim, annem....  
— Üşüyeceksin, böyle çırçıplak! Sabah rüzgarına karşı.. dedi.  
— Şey...  
— Ne?  
— Düşünüyordum ki?  
— Ne düşünüyordun?  
— Kümesin düzenini bozmak olmayacak!  
— Ne demek bu, diye hayretle yüzüme baktı.  
Açıkladım:  
— Bir horoz lazım anne! Tavuklar, işte bir aydır yumurtayı kestiler. Şu rezalete bakın, yatalak gibi uzanmışlar. Hepsinin gözleri bahçe kapısında... Yemden başka bir şey bilmiyorlar.  
Annem,  
— Pekala! Babana söyler aldırırız bir tane, dedi. Ama üşüyeceksin. Çabuk haydi içeri gir, arkana bir şey al.  
. . . . . . . . . . . . . . .

Arkama bir şey almak mı? Asla! Hararetten yanıyor, tutuşuyordum. Sabahki kabus beni ateş içinde bırakmıştı. Hâlâ, evet hâlâ saçlarımın dibi, alnım ter taneleriyle sırılsıklamdı. Balkondan içeri girdim. Yukarı giderken kendimi tutamadım. Anneme döndüm: — Yalnız kümesin düzenini değil, başka düzenleri de bozmamalı!, dedim. Annem anlamadı. Yüzüme dikkatli dikkatli baktı. — . . . . . . . . — Dünyanın düzenini de bozmaya gelmez, diye bir kahkaha attım. Yukarı kaçtım. Şüphesiz ne demek istediğimi anladı. Şüphesiz, arkamdan, "Deli kız! Deli kız!" diye gülümsedi. Şüphesiz, ince uzun kaşlarını yukarıya kaldırarak , ukalalık edeceği zamanlar yaptığı gibi yavaş yavaş başını salladı! Evet, dünyanın düzenini bozmaya gelmeyecek. Yani... Yani işte, işte... Horozsuz kümes, mezarlığa benziyor vesselam!

# Elma

–Ali Canip Beye–

Âteşin, hummalı, şedit muhabbetler iftirak sız bir vefa bağının yakarak yelpazeleyen hararetli kanatları altında söndükten sonra, aşkın o nûşin ve muhrib heyecanları, fasılasız nöbetleri ebedî ve mutlak, saf bir sahiplenmeyle tatmin ve tedavi olunduktan sonra duyulan nekahat dinginliği... Ah, bu, hayal yorgunluğu ne kadar mahzun ve tatlıdır, bilir misiniz? Biz de Süzun'la, bu sahih ve genç aktrisle günlerce, haftalarca, aylarca, hatta yıllarca seviştikten sonra yorulmuş, hastalanmış, bitap kalmıştık. Evvelâ yataklarımız, sonra odalarımız ayrılmıştı. Artık geceleri geç vakte kadar benim odamda beraber oturuyor, ben yarın dershanede talebelerime yazdıracağım notlarla, meselelerimi tertip ile uğraşıyor, o daima müteheyyiç ve mütelezziz olmak için sevinçli sevda ve seks romanlarını mütalâa ya dalıyordu. Mâhazâ ayrılamıyorduk... Tedfin ettiğimiz mukaddes aşk hatıralarının matemi bizim için o kadar muazzezdi ki, bir gecelik iftirak kurtuluşu mümkün olmayan bir vicdan azabı bırakacak bir günah olabilirdi. Yemeklerimizi karşı karşıya yerdik. Ve bizi samimî ve sade soframızda bir yabancı görseydi, mutlaka bunamış iki kardeş zannedecekti. Evet, aşkla ihtiyarlamıştık. Ruhumuz sanki mefluç idi. İşte yine bir sonbahar akşamı ufacık yemek odamızda sade yemeklerimizi batî bir sükûn içinde yiyorduk. Küçük, billur yemişlikten iri ve kırmızı bir elma almış, bıçağımla soyuyordum. Nasıl oldu bilmem, gözüm Süzun'a kaçtı. Gittikçe bana uzun görünmeye başlamış olan narin burnu sanki daha ziyade uzamış, kaşları daha ziyade incelmiş, boynu daha ziyade zayıflamıştı. Ve gözlerini garip ve şedit bir dalgınlıkla soyduğum elmaya dikmiş, kırpmadan bakıyordu. Gayri ihtiyarî sordum: — Ne daldın, azizem öyle?... — Hiç... Dedi. Fakat ikazımdan mustarip olduğunu yüzünden anladım. Önündeki bardakla oynamaya başladı. Ben yine elmamı soyuyordum. Boş ve mütereddit bir sükût dakikası geçti. Sonra tuhaf ve garip bir sesle dedi ki: — Bu elma sana bir şey ihsas etmiyor mu, sevgilim? Sana kıymettar bir hatırayı yad ettirmiyor mu? Tekrar yüzüne baktım, kızarmıştı. Mavi ve yorgun gözleriyle gayri müdrik gözlerimde, gamlı ve ricakâr, sanki bir cevap arıyordu. Elma... Bu bana ne ihsas edebilirdi? Hatıratımı yoklamak için geriye, çocukluğuma doğru hayalen dönerek şimdi muzlim ve ehemmiyetsiz bir mazi olan yirmi altı seneyi bir anda yaşadım. Düşündüm. Hiçbir şey yoktu... Hatta ömrümde bir elma ağacı bile görmemiştim. Süzun hâlâ yüzüme bakıyordu. Müphem bir sıkıntı hissettim ve soyduğum elmayı yemeye başlayarak gayrı ihtiyarî: — Evet, dedim, on yedinci asrın nihayetine doğru İngiltere'de, tenha bir bahçenin sessiz bir köşesinde münferit bir elma ağacı vardı. Bir gün bu ağacın altında dalgın ve mütefekkir bir adam yatıyordu. Ağacın üstünden bu adamın ayaklarına bir elma düştü. Ve bir "deha" uyandırdı. O adam, Kepler'in yeni tedvin ettiği "muvazene-i ecram" konularını düşünen meşhur âlim Nevton idi. Elmanın sukut unu gördü, düşündü, çalıştı ve "cazibe-i umumiye" kanununu keşfetti. İşte bana bu elmanın yad ettirdiği fennî ve kıymettar ha... Lafımı kesti: — Ne muacciz sin! Rica ederim sus... Ve ağlamaya başlayacakmış gibi mavi gözlerini küçülterek ince kaşlarını çattı. Darıldığını, canını sıktığımı anladım. Fakat niçin darılıyordu. Bunu soracaktım. Bana vakit bırakmadı. Mavi ve yorgun gözlerini, asla unutamayacağım müellim hüzünlü bir vaaz ile, tabağımın içindeki elma kabuklarına dikerek: — Zavallı aşk, dedi, ben, Madam Amede'nin sofrasında ilk defa birbirimizi gördüğümüz akşam verdiğin elmayı, o elmayı verirken eğilerek o kadar heyecan ve tahassüs le bana fısıldadığın Musset'in şiirini hatırlayacaksın sanıyordum. Fakat heyhat...

# Ferman

Sanki bir tûfandı. Gök delinmiş gibi fasılasız yağmurlar yağıyor ve bütün ordu Semlin'e doğru sel, çamur, sis ve bora içinde ilerliyordu. Belgrad - Şabaç yolu çökmüştü. Karanlık ormanlara, sarp yokuşlara, uçurumlu dağlara alışkın olmayan nakliye develeri, yedekçileriyle beraber kaybolmuşlardı. Zâbitler bağırıyor, boru sesleri işitiliyor, atlar kişniyordu. Hatta padişahın otağı bile meydanda yoktu. Bu kısa yol, üç gündür bitip tükenemiyordu.

Konak yerine, yalnız sadrâzamın çadırı kurulabilmişti. Padişah gerdûnesinin penceresinden kendi otağını göremeyince, etrafındaki ıslanmış, allı yeşilli, sırmalı esvablarıyla gözleri kamaştıran iri ve çevik muhafızlarına: — Daha durmayacak mıyız? Dedi. — ..... Hiç kimse cevap vermedi. Herkes önüne bakıyor ve şakır şakır yağmur yağıyordu. İhtiyar padişah hastaydı. Fakat ayaklarındaki nikris sızılarını duymuyor, Kurban Bayramı namazını Semlin'de kılmayı düşünüyordu. Artık eskisi gibi ata binemiyor, hatta vezirleriyle istişâre için bile gerdûnesinden çıkamıyordu.

Konak yerinde otağ-ı hümâyunu görmeyen bütün ordu, âsumânî bir gazap karşısında donakalmış; günahkâr bir cemaat gibi birdenbire sustu. Sesler, borular, uğultular, hatta atların kişnemesi bile kesildi. Yalnız yerlere ve çalılara düşen yağmur damlalarının şıkırtışı duyuluyordu. Sadrazam ne yapmıştı? Tâ İstanbul'dan beri padişahtan bir konak ileri gidiyor, yolları düzeltiyor, otağ-ı hümâyunu kurduruyordu. Bu onun vazifesiydi.

Fakat hangi otağ-ı hümâyun?..

Yağmurun loş gölgeleri içinde, koca kavuğu ve uzun boyuyla Sokullu'nun, elleri önünde bağlı, gözleri yerde, yavaş yavaş gerdûneye yaklaştığı görüldü. Ulaklar açılarak yol veriyordu. Arkasından üç tuğlu vezirler de geliyordu. Kavuğundan sızan sular solgun yüzüne, sarı sakalına akıyordu. Som sırma perdenin yanına gelince: — Padişahım, merhamet ediniz, kulunuzun çadırına teşrif buyurunuz, dedi. — Bizim otağımız niçin yapılmadı? — Otağcılar fırtınadan yolu kaybetmişler. Konak yerine gelemediler, padişahım... — .... — .... Padişah bir şey söylemedi, perdenin gerisine çekildi. Yağmur durmuyor, daha ziyâde şiddetleniyordu. Sokullu'nun işaretiyle, altın yaldızlı muhafız mızraklarının arasındaki murassâ gerdûne hareket etti. Sakin ve ıslak vezirler, büyük kavuklarındaki parlak tuğları sallayarak, gözleri yerlerde, altın tekerleklerin yanı sıra yürüyorlardı. Çadırın önüne gelince, gerdûneden inen padişahın kollarına girdiler. Sırma perdeli kapıdan içeri soktular.

Hiç durmadan yağmur yağıyordu.

... İstanbul'dan kırk dokuz günde Belgrad'a gelen yorgun ordu, yollarda birtakım haydutların taarruzuna uğramıştı. Yeniçeri ağası bunların takibine çıktı. Malkara Beyi, Evren Bey'le birleşti. Hepsini saklandıkları kovuklarda tuttu. Konak boylarında astırdı. Bu takiplerde Dergah-ı âlî mensuplarından ve padişahın gözdelerinden pek genç bir kahraman olan Tosun Bey yine kendini gösterdi. Tek başına dağları, ormanları, mağaraları dolaştı. Beşer, onar rastgeldiği eşkiyalarla tek başına vuruşarak hepsini yere serdi. Bütün ordu yolunu temizledi. Hiçbir yasakçı onun arkasından at süremiyor, kimse ona yetişemiyordu. İleri, geri, üç konağı birden gidiyor; uykusuzluk, yorgunluk nedir bilmiyordu. Dört sene evvel padişah, onu sipâhîler arasında görmüş, güzelliğine, şeci tavırlarına meftun olarak maiyetine almış, kendisine birçok hizmetler vermiş, hatta bir sene içinde çavuşbaşlığa kadar çıkarmıştı. Henüz yirmi beş yaşındaydı. Gür siyah bıyıkları, şahin bakışlı iri ela gözleri, geniş ve kalın omuzları, levendâne yürüyüşü, her göreni hayran ederdi. Muharebelerde, ayrı ayrı yerlerinden şimdiye kadar otuz yara almış ve ne kadar general kafalarını mızrağına takarak paşalara hediye etmişti... O, bütün ordu içinde rakipsiz bir cesaret, kahramanlık ve çabukluk enmuzeci idi. İhtiyar Zal Mahmud'dan daha kuvvetli olduğunu herkes biliyordu. Kuş gibi uçar, yıldırım gibi seğirtir, arslan gibi atılır, kaplan gibi parçalardı. Sadrazam en tehlikeli işlere onu saldırır, büyük ve harikulâde muvaffakiyetlerden sonra padişahın huzuruna sokar, ona iltifat ettirirdi. Kendilerinden başka yiğit olduğuna asla ihtimal vermeyen mağrur yeniçeriler bile önlerinden o geçerken kendilerini tutamazlar, galeyana gelirler: — Yaşa Tosun Bey! Seni hangi ana doğurdu! Diye nara atarlardı. Tek başına yaptığı şeyler dillere destandı. Muhâsaradaki kalelere gece gizlice kurulan ince merdivenlerden çıkmış, yalınkılıç, tek başına, düşman arasına atılmış... Düşman ordugâhlarının görünmeden arkasından dolaşarak, cephânelerine ateşe vermiş... Esir olduğu vakit yüzlerce muhafızın arasından kurtularak, kendini beklerken öldürdüğü nöbetçilerin silahları ve atlarıyla dönmüştü. Herkes onu sever, herkes ona hürmet ederdi. Hatta vezirler bile... Çünkü Tosun Bey, bu cesaretiyle yakında beylerbeyi olacak, vezirlik içın çok beklemeyecek, ihtimal... Evet ihtimal daha sakalına kır düşmeden padişahın mührüne nail olacaktı. Hem cesur, hem fâzıldı! Seferlerde sedefli curayla kahramanlık destanları söyler; sulh zamanında gayet çelebice hikmetlerle dolu gazeller, kasideler yazardı. Kılıç kabzasının nasırlattığı elinde, kalem yabancı durmuyordu. Halkın ağzında kendisine dair birçok efsaneler dolaşırdı. Babasının bir emektarı onu büyütmüştü; haksız yere kafası kesilmiş bir beyin oğlu idi.

Yağmur durmadan yağıyordu.

Konak, çamurlu ve bozuk bir yolun sağında kurulmuştu. Her taraftan seller akıyor, askerler sırayla yerlerine geliyorlar, çadırlar kuruluyor, kazanlar indiriliyor, ötede beride ateşler parlıyordu. Bu kalabalığın arasında Tosun Bey'in al atıyla süzüldügü görüldü. İki konak geriden orduya yetişmişti. Yol kenarında semeri devrilmiş bir katırı kaldıran yeniçerilere sordu:  
— Otağ-ı hümâyun nerede, ağalar?  
Yeniçeriler onu görünce doğruldular, hürmetle selamladılar. En yaşlıları cevap verdi:  
— Kurulmadı.  
— Efendimiz geri mi gitti?  
— Hayır.  
— Ya nerede?  
— Sadrazam Paşa'nın çadırında.  
Tosun Bey durdu. Yeniçerinin yüzüne dikkatle baktı. Yeniden sordu:  
— Otağ-ı hümâyun nerede kurulmuş?  
— Kurulmamış.  
— Niçin?  
— Kaybolmuş...  
— Ne?..  
— ...  
Yeniçeri sustu. Önüne baktı.  
— Otağ-ı hümâyun mu kaybolmuş?  
— Evet...  
Tosun Bey fena halde hiddetlendi. Dişlerini sıktı. Otağ-ı hümâyun nasıl kaybolurdu? Bunu havsalası almıyordu. Padişah, onca mukaddesti. Otağ, onun nazarında müteharrik bir Kâbe'ydi. Kâbe'si yıkılan bir mümin tehâlükü ile ağır ve keskin mahmuzlarını atının karnına vurdu. Islak tuğlarıyla bayrak direkleri görünen sadrazam çadırına doğru saldırdı. Ama pek ileri gitmedi. Seğirdim ustaları yağmur içinde dolaşıyordu. Kendisini pek seven Kazasker Perviz Efendi'nin çadırını gördü. Yere atladı. Atını, koşan bir hizmetkâra verdi. Kahramanlık şiirlerini okuduğu Perviz Efendi, çadırın içinde ayaktaydı. Nişancı Eğri Abdizâde Mahmut Çelebi'yle Şabaç Köprüsü'nün, Semendire Beylerbeyi Bayram tarafından nasıl yapıldığını konuşuyordu. Onun girdiğini görünce:  
— Hayrola, Tosun Bey!  
Diye lafını kesti, Tosun Bey titriyordu. Kendine mâlik değildi:  
— Otağ-ı hümâyun kaybolmuş.  
— Evet oğlum.  
— Bu nasıl olur, efendi hazretleri?  
— Yolu şaşırmışlar belki...  
— Sadrazam paşa bir konak önden gidiyor. Nasıl Kaybetmiş?  
— ....  
Perviz Efendi cevap vermedi. Mahmut Çelebi yağmurun, fırtınanın şiddetinden bahsetmek istedi. Tosun Bey coşuyordu. Açtı ağzını kapadı gözünü... Artık bu kadar kayıtsızlık olur muydu? Bu kulluğa yakışır mıydı? Hasta velinimet hiç düşünülmüyordu. Ya otağı suya kaptırdılarsa... Ya taht bulunmazsa... Daha İstanbul'dan çıkmazdan evvel bir çavuş gönderilerek Semlin'e mülakat için çağrılan Zigismond'u, padişah nerde huzuruna kabul edecekti? Bir parça yağmurdan yollarını şaşıran, dağılan orduya, padişah nasıl emniyet edecekti? Tosun Bey cesur adamlara mahsus o mütecaviz pervasızlıkla ağzına geleni söylüyordu:  
— İki konak arasında bir otağa sahip olamayan adam, koca bir devleti nasıl idare eder? dedi.  
Bu çok ağır bir sualdi. Perviz Efendi, kalın halının üzerine serilmiş erguvânî şiltesine çöktü. Mahmud Çelebi bu sözü hıç işitmemiş gibi davrandı. Durmadan yağan yağmurun sayısız ve asabi damlaları tıpır tıpır çadırın üstüne düşüyor, orduğâhın müphem uğultusu içinde, sanki hayali bir akının uzak ve muntazam ayak seslerini duyuruyordu.

Tosun Bey dışarı çıkınca, aceleyle adamlarını buldurdu. Atını değiştirdi. Kimseyle konuşmadan, tek başına, otağ-ı hümâyunu aramaya çıktı. Hava gittikçe kararıyordu. Derin yarlardan, sel yarıklarından aştı. Taşan, köpüren derelerden geçti. Ormanlara dalan yollara girdi. Tepelere çıktı. Dört tarafa naralar savurdu. Sesinin boğuk akislerinden başka bir cevap alamadı. Gelen gece pek karanlıktı. Yağmur durmuyordu. "Sabah erkenden çıkar, bulurum" diyerek geri döndü. O kadar karanlıktı ki... Dizgini boş bırakıyor, geldiği yollardan atının sevk-i tabiisiyle dönebiliyordu.

Meşaleleriyle, ordugâh uzaklardan görünmeye başladı. Karanlığın, yağmurun, rüzgârın içinde at, âdi adımlarla yürüyordu. — Kimdir o? On adım ötede koyu bir karaltı belirdi... — Yabancı değil... — Sen misin, Tosun Bey! — Benim! — Sadrazam Paşa Efendimiz sizi arattırıyor. Biz on sipâhî, etrafa dağıldık. — Pekâlâ, gidelim. Ve karanlığın içinde Tosun Bey önde, sipâhî arkada, ordugâha koştular. Meşaleleri, nöbetçileri, mehterleri geçtiler. Zaten hizmetkârlar, solaklar, çavuşlar yağmurun altında bekleşiyorlardı. Tosun Bey'i, sadrazamın yanına götürdüler. Paşa büyük şiltesine yaslanmış, uzun ve murassâ çubuğunu çekiyordu. Karşısında Silahtar Cafer Ağa ile Nişancı Feridun Bey dîvan duruyordu. — Oğlum Tosun, dedi, sana bir iş çıktı. Senin gibi at sürecek er yok. Bu ferman-ı hümâyunu şimdi al. Koş, Niş'e götür... Oradaki Bey'e ver... Karşısında sırılsıklam dîvan duran Tosun Bey'e, öpüp başına koyduğu kırmızı bir keseyi uzattı. Tosun Bey, elleri bağlı, ilerledi. Eğildi. Keseyi aldı. Öptü. Basına koydu. Dışarı çıkarken Sadrâzam: — Haydi arslanım, çabuk, yolun uğurlu olsun! Diyerek gülümsedi. Çadırın önünde mükemmel bir kır atın onu beklediğini gördü. Yağmur hâlâ eski şiddetiyle yağıyordu. Bindi. Karnı açtı. Üzengisini tutan hizmetkârlardan su istedi. Verdikleri çotrayı nihayetine kadar içti; ağır, keskin mahmuzlarını atın karnına vurdu. Ordugâhın kalabalığı, ışıkları, uğultusu arasından beş dakikada çıktı. Karanlığın, yağmurun, rüzgârın içinde dörtnala uzaklaştı. Kayboldu...

Ormanlardan, derelerden, köprülerden, tepelerden, uçurumlardan şimşek gibi geçti. Belgrad'da durmadı. Hemen atını değiştirdi. Azığını aldı. Yine yola atıldı. Hiç uyumuyor, yalnız düz yerlerde atı tırıs giderken, rüyasız ve uyanık bir uykuya dalıyordu. Gecelerden gündüze, yağmurlardan güneşe girdi. Haziran sıcaklarıyla esvabları kurudu. Kendi ve atı terledi. Akşamları serin rüzgârlara karışan bülbül sesleri işitti. Sabahları cıvıldayan tarlakuşlarının saklandığı ekin deryaları içinde yürüdü. Nihayet bir gece, pek uzaktan Niş'in aydınlıklarını gördü. Büyük bir çiftliğin önünden geçiyordu. İri ve azgın köpekler arkasından koşuyor ve havlıyorlardı. "Gün doğuncaya kadar şurada kalayım. Erken şehre girerim," dedi ve çiftliğe saptı. Herkes gibi çiftliğin adamları da onu tanıyorlardı. Atını aldılar. Hürmetlerle yukarıya, kuleye çıkardılar.  
— Ben biraz dinleneceğim. Gün doğmadan beni uyandırın!  
Emrini verdi.

Ne vakit olursa olsun, her gelen yolcuya yemek çıkarmak âdetti. Tosun Bey: — Hiçbir şey istemem. Bana biraz ayran getirin, dedi. Getirip bıraktıkları testiyi dikti. Susuzluğu geçince sedire uzandı. Gözlerini kapadı. Fakat uyuyamadı. At üzerinde gelen uykusu, böyle hareketsiz kalınca kaçıyordu. İki tarafına döndü. Tolgasını çıkardı. Kılıç kemerini gevşetti.

... Tam dalacağı sırada birdenbire sıçradı. Göğsünün üzerine koyduğu ferman ateş almış yanıyordu. Elini götürdü. Hayır... Tuhaf bir rüya. Ferman yerinde duruyordu.

Biraz daldı.

Rüyasında, götürdüğü, fermanın eriyerek kan olduğunu, sonra tûfan dalgasının kırmızı alevler halinde bütün vücudunu sardığını görüyordu. Siçradı, uyandı. Hiçbir tehlike karşısında intizamını bozmayan kalbi şimdi hızlı hızlı çarpıyordu. Doğruldu: "Hayırdır, inşallah..." dedi. Oturdu. Bir şeyler okudu. Döndü. Üç defa sol tarafına tükürdü. Elini titreyerek fermana götürdü. Yerinde idi. Yavaşça tuttu ve gayr-i ihtiyâri bir hareketle çekti. Ocağın üzerindeki kandilin titrek ve sönük aydınlığı içinde baktı. Üstüne sardığı çevreyi çıkardı. Bu kırmızı bir kese idi. Yanından balmumu ile mühürlenmişti. Dikkat etti. terden, yağmurdan ve hareketten bu mum mühür yerinden oynamıştı. Acaba içinde ne vardı? Dehşetle rüyasına giren bu ferman ne idi? Mutlaka inzibata dair bir emr-i şerif... Çünkü harp yukarıda idi. Haydutlar, cephâne, yahut yollar ve mekkâreler için bir şey olmak ihtimali vardı. Ama, hayır... Bu mühim, pek mühim bir emirdi. Çünkü bilhassa kendisiyle gönderiliyordu. Acaba ne idi?

Fermanı tekrar çevreye sardı. Koynuna koyacaktı. Fakat göğsünün görünmez bir cendere ile sıkıldığını duydu. Boğazı tıkandı. Sanki ferman sahiden ateş almış, vücudunu yakıyordu. Sönmez bir merak ateşi ruhunda tutuştu. Zaten işte mühür bozulmuştu. Açsa... Belli bile olmayacaktı. Başını salladı. Kendi kendine: — Sakın, sakın! Dedi. İçinde tutuşan merak ateşi öldürücü bir sıtma gibi her yerini sarsıyordu. Hararetten yanan elleri, sanki kendi iradesiyle inat eden başka bir vücudun âza imiş gibi torbayı açtı. Üçe katlanmış kâğıdı çıkardı. Tosun Bey, iradesine isyan eden ellerinin cinayetinden titredi. Bir ferman açılabilir miydi? Fakat kımıldayamıyor, ellerine hükmedemiyordu. Zincire vurulmuş, hareketsiz yatarken, başkasının işlediği cinayeti karışmadan seyreder gibi, ellerinin hiyanetine bakakaldı. Kendisini dinlemeyen bu eller, fermanı da açtı. Tosun Bey az ışık veren kandilin ziyâsıyla ancak gördüğü satırları okudu. Taş odanın beyaz duvarları, nakışlı tavan, halı örtülmüş döşeme etrafında dönmeye başladı. Deli oluyordu.

Cinayetten sonra kaçan katiller gibi elleri iki tarafına düştü. Açık ferman dizlerinin üstünde kaldı. "... İşbu emr-i şerifimizin hâmili devletimize vücudu muzır olan Tosun Bey kulumun da hemen, vücudundan başın kesesin ve şöyle bilesin ki..." Gözünü bu cümleden ayıramıyordu. Aşağısını okuyamadı. Demek, gece gündüz, hıç durmadan koşarak getirdiği, rüyasında vücudunu yakan bu kırmızı kese, kendi idam fermanıydı. Şaşkınlığı çok sürmedi. Belki elli defa ölümün pek yakından geçerek korkunç kanatlarını sürttügü geniş ve parlak alnını tuttu. Arkasına dayandı. Sağındaki pencereden siyah ve dağınık bulutların geçişine baktı. Bir an öyle durdu. Derin bir nefesle göğsünü kabarttı: :— Ama niçin? Ama niçin? Dedi. Sadakatten, cesaretten, fedakarlıktan, harpten, hücumdan başka ne yapmıştı? Tâ on beş yaşından beri... On senedir at sırtından inmiyordu. Bütün dünyayı dolaşıyor, en nâmdar kahramanların çekindikleri yere gözünü kırpmadan atılıyordu. Muhâsaradaki burçların içine, yüzlerce zırhlı düşmanın arasına, tek başına yalın kılıç atıldığı zamanlar ölmediği halde, şimdi bir celladın, âdî,köpek bir çingenenin satırı altında mı can verecekti? Maziyi hep birden düşünüyor ve kırılır gibi olan cesareti yavaş yavaş yerine geliyordu. Doğruldu. Ayağa kalktı. Ferman ve kese yere düştü: — Ben kafamı kolay kolay vermem. Dedi. Pencereye yaklaştı. Siyah bulutlar daha hızlı geçiyor, tan yeri morlaşıyor, çiftliğin yanından akan küçük bir derenin hüzünlü ve hafif şırıltısı işitiliyordu. Bütün Rumeli, bütün Anadolu kendisini tanırdı. Anadolu'ya atlayınca hangi şehzadenin yanına gitse, muhabbetle kabul olunacağına emindi. On kişiye, yüz kişiye değil, icabında bin kişiye karşı koyabilecek bir cesareti vardı. Sonra kuvveti, mahareti, çevikliği... Bütün memlekette daha bir eşi yoktu. Bir kere Anadolu'ya kapağı atınca, ele geçmek imkansızdı. İran'a, Turan'a kadar vura kıra gider, nâmına birçok şanlar, şerefler ilave ederdi... Tekrar kalbi: — Ama niçin? Niçin?.. Diye burkuldu. Hiçbir şey beklemiyordu. Aklına ancak mükafat ve iltifat gelirdi. Böyle bir kelime... Asla... Acaba ne kabahat yapmıştı? Düşünüyor, düşünüyor, bir türlü kabahate benzer bir şey yaptığını hatırlamıyordu. — Ah müzevirler! Allah'tan korkmaz bühtancılar... Kimbilir aleyhinde ne yalan uydurmuşlardı. Fakat... O, babası gibi celladın pis kılıcına bir koyun itaatiyle başını uzatmayacak, canını almaya gelenlerin canlarını alacak; kendi canı alınıncaya kadar, başkalarından can alacaktı.. — Vakit geçirmeyeyim. Diye mırıldandı. Tolgasını başına geçirdi. Kılıcının kayışını, kuburluklarını sıkıştırdı. Yerdeki fermanla keseyi aldı. Yine gözüne "...devletimize vücudu muzır olan..." kelimeleri ilişti. Niçin onun vücudu devlete muzırdı? Böyle bir itham, canını devlet uğruna nezretmiş bir insan için ne acı bir tahkir, ne acı bir küfürdü... Yazıya dikkat etti. Acaba padişahın hattı mıydı? Silahtar Cafer Ağa'nın da olmak ihtimali vardı. Padişahla onun hattı, farksız derecede birbirine benzerdi. Fermanı katladı. Yine keseye soktu. Balmumunu hohladı. Mührü eski yerinden hafifçe yapıştırdı. Azrailin kanadından kopma kanlı bir tüy kadar hafif olan bu müthiş bez içinde, işte hayatı duruyordu. Evirdi, çevirdi. Böyle... Bu müthiş şeye bakarken, yâdından hep eremediği muradları, mübhem emelleri geçti. Bu dakikaya kadar ne mesuttu. Şan, şeref, şöhret, servet, debdebe içinde yaşıyordu. Padişahın en sevgili gözdesiydi. Gördügü lütufları düşündü. Sipâhîlik zamanlarını hatırladı. Daha on beş yaşındayken bile kuvveti, şecaati görenleri şaşırtıyordu. Cirit oyunlarında, güreşlerde, mübârezelerde hep birinci geliyordu. Sonra... Kendini evinde büyüten, babasının eski emektarı ihtiyar Salih Ağa gözünün önüne geldi. İstanbul'dan çıkarken veda için elini öpmeye gittiği zaman, bu ihtiyarın verdiği nasihatı işitir gibi oldu: "Padişah'ın emrinden dışarı çıkma. Canını istese ver. Düşünme. Dünyada olmasa bile ahirette mükafatını görürsün..." Maziyi hatırlamaya devam edemedi. Ansızın bozulan bir saat gibi sanki dimağı durdu. Yalnız kulağından Salih Ağa'nın sesi çıkmıyordu: — Padişahın emrinden dışarı çıkma... Halbuki... Halbuki... O, işte padişahın emrinden dışarı çıkıyor, hatta isyana hazırlanıyordu. Bu büyük ve şenî günahı yapmış gibi kalbinde heyecan ve nedametle karışık zehirli bir sızı duydu. Canını padişah ve devlet uğrunda vermeye ahdetmiş miydi? O halde bu canı kimden, nereye, niçin kaçıracaktı? Artık, birdenbire kuvvetlenmiş iraddesinin hükmüne tâbi demir elleriyle tuttuğu bu kırmızı keseyi kaldırdı. Dudaklarına dokundurdu. Sonra başına götürdü.

Güneş bulutlar içinden gizlice doğarken, doludizgin Niş'e girdi. Canlı bir yıldırım gibi, dar ve bozuk sokaklardan geçti. Beyin konağı önünde atından atladı. Kendisini tanıyan kapıcılar, sipâhîler, askerler:  
— Tosun Bey! Tosun Bey!  
Diye koşuştular. İki kanadı açık geniş kapının, ortasında bir fener sarkan beyaz badanalı kemeri altından, temiz ve zemini kara taş kaplı iç avluya ilerledi. Bağırdı:  
— Çabuk Bey'e haber verin, ferman var...  
Hizmetkârların arasından ayrılan uzun boylu kapıcıbaşı öne düştü. Onu taş merdivenlerden çıkardı. Bey, sabah namazını kılarak selamlığa çıkmış, rahat rahat çubuğunu çekiyor, mahmurluk keyfini yetiştiriyordu. Odasına ansızın Tosun Bey'i girdiğini görünce şaşaladı. Bu Bey, onun cesaret ve kahramanlığına meftun, ihtiyar, feleğin çemberinden geçmiş eski bir askerdi. Hemen ayağa kalktı. Kucakladı. Alnından öptü:  
— Safa geldin yiğidim, hayır haberler getirdin...  
Tosun Bey gülerek:  
— Bir ferman-ı hümâyun getirdim.  
Dedi. Ve koynundan kırmızı keseyi çıkardı. Öptü. Başına koydu. Uzattı. İhtiyar Bey, bilhassa tosun Bey'le gönderilen bu fermanın ehemmiyetini düşündü. Yorgun yüreği hopladı. Sarardı. Titrek, zayıf ve kıllı elleriyle bu keseyi aldı. Öptü. Başına koydu. Mumun bozukluğuna bile dikkat etmedi. Kopardı. Fermanı çıkardı. Açtı. Okudu. Uzun çubuğunun dayalı durduğu yüksek sedire yıkılıverdi. Karşısında Tosun Bey, bir eli kalçasında, dinç ve levent duruyor, gülümsüyordu. Zavallı ihtiyar ağlamaya başladı:  
— Ne ağlıyorsun, Bey hazretleri?  
İhtiyar inledi:  
— bu fermanın ne yazdığını biliyor musun?  
— Biliyorum: Benim kafamın kesilmesini yazıyor..  
— ...  
İhtiyar bey, bütün memlekette kahramanlığı dillere destan olan bu al yanaklı, gür bıyıklı, dağ parçası, heybetli, cesur, güzel bahadıra ıslak gözleriyle uzun uzun baktı. Acaba niçin gazaba uğramıştı? Böyle bir arslanı, celladın eline vermek ne büyük bir insafsızlıktı. Hangi vicdan buna razı olurdu? Ak sakalına yakışmayan masum bir hıçkırıkla:  
— Kabahatin ne?  
Diye sordu.  
— Padişahım bilir...  
— Ben senin basını kesmem, Tosun Bey. Şimdi affını yazacağım. Çifte tatar çıkaracağım. İstirhamım kabul olunmazsa kendi başımın kesilmesini isteyeceğim.  
— Hayır, Bey! Hayır... Padişahın emrinden dışarı çıkma. Başımı kes... Kestikten sonra affımı istirham et. Padişahım, kendi emri yerine geldikten sonra, ben kulunu affetsin.

İhtiyar bey daha ziyâde ağlıyor, hıçkırıyordu: — Ben senin gibi bir yiğide kıyamam. Ben seni kesemem. Elim dilim buna varmaz. — ... — Vallahi seni kesemem... — ... Yeni uyanmış erkek bir arslan sükunuyla gülümseyen Tosun Bey'in parlak çehresi birdenbire karardı. Gür kaşları çatıldı. Şahin bakışlı iri ela gözleri açıldı. Nefret ve hiddetle kılıcını çekti: — Padişahımın emrini yapmayan âsilerin başını ben keserim!... Diye kükreyerek yumuşak kalplı, zayıf ve itaatsız ihtiyarın üzerine yürüdü. Al çuhadan büyük kapı perdesinin arkasında gizli nöbet bekleyen silahlı hademeler koşuştular. Ve onu tuttular.

Yarım saat sonra:

Sırmalı resmî kavuğunu çıkararak başına mütevazi ibadet külahını geçirmiş olan ak sakallı bey, tenha odasında, seccadesine oturmuş, boynu bükük "Yâsin" okurken, dışarda mahzun ve belirsiz bir yağmur serpeliyor; iç avlunun siyah taşlarındaki taze ve sıcak kanlar üstüne, sahipleri görünmeyen samimi gözyaşları gibi damlıyordu.

# Fon Sadriştayn’ın Karısı

O gün İstanbul'da kalsam bile hiçbir iş yapamayacaktım. Müthiş, acı, anlatılmaz bir sinir nöbeti yine beni kıvrandırıyordu. Bu korkunç hali bilmeyenler ne kadar mesutturlar! İnsanın birdenbire bütün ümitleri, bütün zevki, bütün neşesi kaybolur. Gözünün önünde hayat, hava, ufuk, her şey kararır. Dostlar düşman görünür. Sevgililerden nefret edilir... Ben işte bu sinir denilen ateşsiz cehennemin içine düşünce kendimi kırlara atarım. Tenha korular, sevinçli mazilere benzeyen gölgeli yollar, dallarda geçmiş bir saadetin canlı hâtıraları gibi uçuşan kuşlar bana ilâhi bir teselli füsunuyla tesir eder; hafiflerim. Beynimdeki ağırlık yumuşar. Şakaklarımın ateşi söner.

O gün yine böyle perişan bir haldeydim. Hafiflemek, beynimdeki granit ağırlığı yumuşatmak, başımın kaynayan hararetlerini söndürmek için bir Boğaziçi vapuruna atladım. İlkbahardı. Tatlı bir rüzgâr esiyor... Vapur ilerledikçe aklım başıma geliyor gibi oluyordu.

Açılıyordum...

Güvertedeydim; görülmemiş kuşlara mahsus beyaz, pembe, mor yalılara, yeşil korulara, mavi tepelere bakıyordum. Gözlerimdeki kırmızı karanlık silindikçe kulağım da işitmeye başladı. Dizlerimde, bileklerimde, omuzlarımda yorgun ağrılar hissediyor, geniş geniş gerinmek istiyordum. Biraz doğruldum. Başımı sağa çevirdim; müthiş, iri, kıpkırmızı bir Alman yanıma oturmuş, gayet beyaz bir keten mendille terini siliyordu. Birbiri üzerine attığı bacaklarına, kalın dizlerine, dokunulsa kan fışkıracak sanılan tombul ellerine baktım. Sonra gözlerimi sararmış ellerime, takallüs etmiş dizlerime çevirerek: — Ah, ne sıhhat!.. Dedim. Hem gayr-i ihtiyarî düşünmeye başladım. İşte bu, sinirleri adalât içinde kaybolmuş, kavî, gürbüz bir mesuttu! Kimbilir ne güzel yiyor, ne iştiha ile içiyor, ne kadar kolaylıkla hazmediyordu. İnce ceketinin üzerinden kalın vücudunun kabarıklığı belli oluyor, sağ cebinden kocaman bir gazete tomarı görünüyordu. Bir rüya kadar râbıtasız, intizamsız tedâîlerle Almanya'yı, Almanlıktaki sırrı, Almanlar'ın sıhhatini, saadetini, neşelerini hatırlıyordum. Bu nasıl bir milletti! Kendi gibi, fertleri de kavî, muntazam, mes'uttu!..

İşte şu yanımdaki, tıpkı nöbet bekleyen bir askerdi. Sivil esvap giymiş bir asker... Mendilini devşirdi. Büyük bir intizam ile iki kat, dört kat, sekiz kat, nihayet on altı kat yaptı. Cebine koydu. Gazetesini okumaya başladı. Vapur, biraz sonra bir iskeleye yanaşıyordu. Çıkmak için kalkanlardan bir Türk, bu can, bu kan âbidesine doğru geldi. Gayet arsız bir Türkçe ile:  
— Vay, Fon Sadriştayn!.. diye haykırdı, nereye böyle?  
— Tarabya'ya...  
—  Ne yapacaksın?  
— Almanya'dan bizimkinin bir akrabası gelmiş. Onun adresini anlayacağım.  
. . . . . .

O kadar güzel Türkçe söylüyordu ki, insan vücudunu, yüzünü görmese, ismini işitmese, şivesine aldanacak, Türk diyecekti. Vapur tekrar kalktı. Alman, gazetesine devam etmedi. Mendili gibi dikkatle katlayıp cebine koydu. Sahillere bakmaya başladı. Bilmem nasıl oldu, nazarlarımız birbirine çarptı. Mavi, iri, biraz kanlı Alman gözleri... Fakat o kadar sevimli, o kadar hoş ki...

Ben, arkamdan bile birisinin bana baktığını hisseder, rahatsız olurum. Herkes benim gibi midir bilmem! Artık mor tepeli, beyaz yalılı, cennet sahillere bakamıyor, Alman'ın gözlerini üzerimde hissediyordum. Evet, bana bakıyordu. Hissimde yanılmamak için yavaşça gözlerimi çevirdim. Hemen onun gözlerini gördüm; gülüyordu. Ağzıyla değil, bütün yüzüyle, bütün vücuduyla gülüyordu:  
—  Beni tanıyamadınız mı?  
Dedi.  
—  Hayır...  
Dedim.  
—  Halbuki ben sizi tanıdım.  
— Yanılıyorsunuz, Herr, diye gülümsedim, benim hiçbir Alman tanıdığım yoktur.  
—  Ben Alman değilim.  
—  Nesiniz?  
— Türk...  
—  Halbuki isminiz?  
— Ha, ismim diye lafımı kesti, demin benimle konuşan gevezeden işittiniz. Fon Sadriştayn, değil mi? Bu benim ismim değil, lakabımdır. Benim ismim "Sadrettin" dir. Çok zayıflamışsınız ama, yine sizi tanıdım. Ben sizin sınıf arkadaşınızım.  
Dikkatle tekrar yüzüne baktım. Hayır, hayır... Yanılıyordu! Ben böyle bir Herkül'ü mektepte değil, hattâ bütün hayatımda görmemiştim. O ne göğüstü yarabbi!  
— Yanılıyorsunuz efendim, dedim, mektepte iken arkadaşlarımın en uzun boylusu, en kuvvetlisi bendim. Sizin gibi iriyarı, dev gibi bir adam, mektebimizde değil, hatta memleketimizde yoktur.  
. . . . . . . .

Alman gülmeye başladı. —  Biraz haklısınız dedi, fakat benim vücuduma bakmayınız. Gözlerime bakınız. Mektepte iken, hatta iki üç sene evvel ben son derece cılızdım. Mektepte siz, bütün arkadaşlarım benim cılızlığımla eğlenir, arkamdan hep "Yuha! Serçe Pehlivan!" diye haykırırdınız. Serçe Pehlivan! Şimdi hatırlıyor musunuz? —  ! ! ! Ağzım biraz açık kaldı. Kollarım yanıma düştü. Öyle büyük, öyle hayalin kabul edemeyeceği bir hayret içindeydim ki... Kendimi toplayamıyordum. Mazinin birden önüme açılan hâtırası içinde Serçe Pehlivan'ı, Sıska Sadrettin'i gördüm. İri mavi gözlü, ince, zayıf, bitkin bir çocuk! Jimnastik muallimi onu derste daima bir tarafa ayırır: "Sen yalnız seyret oğlum" derdi. O kadar zayıftı ki, muallim, eğer barfikse asılacak olursa, kollarının mutlaka kopacağını söylerdi. Hayır hayır... Bu mümkün değildi. Sıska Sadrettin, yürümeye, lakırdı söylemeye, gülmeye üşenen Serçe Pehlivan...

Gayr-i ihtiyarî başımı sallıyor:  
—  Hayır, hayır...  
Diyordum. Alman:  
— Vallahi ben işte, Serçe Pehlivan'ım! dedi.  
Fakat nasıl oluyordu? Bu mümkün müydü? İnsan bu kadar değişebilir miydi? Her şeyin bir hududu vardı. Bir sıska ne kadar kuvvetlense bir Herkül, bir sıhhat heykeli olamazdı.

Güldüm, dudaklarımı kıvırdım:  
—  O halde âb-ı hayat içmiş olmalısınız.  
— Evet, âb-ı hayat içtim, dedi, fakat Hızır aleyhisselâmınki gibi, hiç sabahı olmayan gecelerin içinden aylarca giderek bulunmuş gizli bir membâdan değil...  
—  Ya nereden?  
—  Kırk sekiz saatlik bir yerden, Almanya'dan!  
— .....  
Bu laftan birşey anlamadım. Anlamadığımı o da gördü, güldü:  
— Açık söyleyeyim, dedi, Almanya'ya gittim. Bir Alman kızıyla evlendim. Alman kadınının ne olduğunu siz bilmezsiniz. Bütün Almanya, bütün Almanlık, bütün Almanlığın zenginliği, Alman ordusunun kuvveti Alman kadınının eseridir... Ben Alman kadınıyla evlenmezden evvel tartılır, tamam otuz okka gelirdim. Bugün doksan beş kilo geliyorum. Almanya'nın yirmi milyon nüfusunu yarım asırda altmış yetmiş milyon yapan Alman kadını, beni de üç sene içinde otuzdan doksan beşe çıkardı. Eğer Alman kadınını tanışanız buna asla şaşmaz, hem de pek tabiî görürdünüz.

Hararetle Alman kadınını anlatırken dolgun bileklerine, geniş kalçalarına, iri göğsüne, kalın boynuna, kıpkırmızı yüzüne bakıyor, mektepteki mâhut sıska, solgun "Serçe Pehlivan" dan böyle bir hârikanın nasıl zuhur edebileceğini düşünüyor, bir türlü gözlerime, kulaklarıma inanamıyordum. Lafını kestim: — Rica ederim, nasıl Almanya'ya gittiniz? Nasıl evlendiniz? Nasıl âb-ı hayat içtiniz. Şunları anlatınız. Almanya'ya dair malûmatım var. Nafile zahmete girmeyiniz... Dedim.

Fon Sadriştayn:  
—  Pekala, gayet basit!  
Diye başladı anlatmaya... Dinlerken sinirleniyor, göğsümde sıkıcı bir ağırlık duyuyordum.  
— "Mektepten çıktıktan sonra seninle hiç tesadüf etmedik. Dışarı gittiğini işitmiştim. Benim başıma neler geldi, neler... Hükümet dairelerinde, kalem müdürlerinden, mümeyyizlerinden, kapıcılarından hiçbir tanıdığımız olmadığı için tabiî hiçbir kaleme giremedim. Girsem de tabiî hiç terakki edemeyecektim. Mecburiyet tahtında hükümet memuriyetinden vazgeçtim. Biraz resim yaptığımı bilirsin. Almanca'ya da çalışmıştım. Çat pat konuşuyordum. Anadolu Şimendifer Kumpanyası'na müracaat ettim. İmtihan oldum. Resim şubesine girdim. On lira maaşım vardı. Anam babam, ben pek küçükken ölmüşler. Beni halam büyütmüştü. Onunla oturuyordum. Fakat bilmem niçin her gün daha ziyade zayıflıyordum. Halam dermansızlığıma baktıkça, "Evlenmelisin Sadrettin, diyordu, senin rahata ihtiyacın var. Bekarlık sana yaramıyor..." Ben de bu lafa inandım. Evlenmeye kalktım. Maaşım yetişmezse halam da ayda birkaç lira verecekti. Kız aramaya başladı. Her gün evden görücü gittiler. Nihayet gayet şık, gayet güzel, Fransızca konuşur, piyano çalar bir kız buldular. Akrabalarımızdan birinin evinde güya bizi tesadüf ettirdiler. Konuştuk. Birbirimizi beğendik. Bu, zayıf, açık sarı saçlı, saz benizli, sinemalarda aşkla elem rollerine çıkan aktrislere benzer narin bir kızdı. Canlanmış, insan şekline girmiş bir şiirdi. Uzatmayayım... Nişanlandık. Nikahlandık. Düğün oldu. Karımı gelin gibi halamın yanına almıştık. Bir ay kadar asayiş yolunda gitti. Karım yemeklere iniyor, odasında oturuyor, bir de sokağa gezmeye çıkıyordu. İkinci ayın başında halam "Bu gelin değil, Allahın cezası..!" diye söylenmeye başladı. Bir akşam geldim. Karım karşıma geçti. Çatık kaşla sordu:  
— Sen beni hizmetçi kız diye mi aldın?  
— Hayır, dedim.  
— Öyleyse neye aldın?  
Diye tekrar sordu.  
— Zevce diye...  
— Bu halde ben bu evde durmam.  
— Niçin?  
Diye aptallaştım.  
— Bana halan iş gördürmek istiyor, dedi, ben hiçbir iş yapamam. Yapmadım. Hem de yapmayacağım. Yarın buradan çıkartır, yahut beni bırakırsın. Ben annemin evine gideceğim.  
Ellerini tuttum, biraz sabretmesini, öfkesi geçeceğini söyledim. Nerede?  
— Nafile, nafile... Vallahi durmam!  
Diye boyuna yemin ediyordu.

Annemden kalma bir evim vardı. Onu rehine koyarak bir ev tuttuk. Bir ev tutmak nedir? Bilmezsiniz belki... Ben o vakit öğrendim. Daha kapıyı açmadan üçyüz lira bitti. Bir aşçı, iki hizmetçi tuttuk. Fakat hatırlayınız ki maaşım on lira... Odun, kömür, gaz, erzak, yağ falan parası yirmi lirayı geçiyordu. Altı lira da evin kirası... Etti yirmi altı... Karım da on lira tuvaleti için istiyordu. Etti otuz altı... Halbuki maaşım on lira... Evi sattım. Elime binikiyüz lira kadar bir şey geçti. Bu para ile bir buçuk sene yaşadık. Ama ben istikbali düşünerek üzülüyor, zayıflıyor, perişan oluyordum. Birgün kendimi muayene ettirdim. Doktor: — Dikkat ediniz, verem başlıyor, dedi. Ne yapacağımı şaşırdım. Halim karımın umurunda değildi. Müteharrik bizzat bir tuvalet makinesi gibi temizleniyor, pudralanıyor, boyanıyor, giyiniyor, geziyor, tozuyor, geliyor, yemeğini yiyor, yatağına yatıyor, rahat rahat uyuyordu! Eve pislikten girilmiyordu. Aşçı ile hizmetçinin elinde kalmıştık. Karım hatta mutfağın nerede olduğunu bilmiyordu. Hazır param bittikçe ben de yürek üzüntüsünden zayıflıyordum. Korktum. O vakit tartılmadım. İhtimal yirmi okkaya kadar inmişimdir! Yaz gelince fena halde hastalandım. Yatağa düştüm. Doktorlar ümitlerini keser gibi oldular. Mutlaka tebdil-i havaya gitmemi söylediler. Yürüyemiyordum. Dizlerim tutmuyordu. Nihayet kumpanyadan üç ay izin aldım. Kalan paramla Almanya'da oturan bir arkadaşımın yanına gittim... Meşrutiyet'ten sonra elektrikçilik öğrenmek için İstanbul'dan ayrılmış, Almanya'da ev bark düzerek bir daha dönmemişti. Siz deminden beni tanıyınca nasıl şaşırmışsanız, ben de onu görünce tıpkı sizin gibi şaşırmıştım. Enine boyuna belki birer metre büyümüş, genişlemişti. — Aman, nedir bu hal, sana ne olmuş? Diye ağzım açık kalınca: — Şaşma yavrum, burası Almanya'dır, dedi, burada yaşamak sanatı bilinir. Sen de biraz kal. Görürsün. Hakikaten bir hafta geçmeden gördüm, öğrendim. Arkadaşım: — Boşuna masrafa lüzum yok. Bizim evde yatarsın. Fazla bir odamız var. Kiracı bulamadık. Senden yirmi mark alırım. Orada yatarsın. Yemek için de her gün birer mark eder. Yalnız, masraf parası... Pişirmek parası almayız. Ayda elli mark. Burada yer, burada içer, dışarıda on para harcetmezsin. Çamaşırlarını biz bedava yıkarız. Yalnız bira masrafı ayrı... — Ben bira içmem, diyecek oldum. — Öyle şey olmaz, cahilliği bırak, diye güldü. Birasız burada yaşanmaz. Bira içmezsen iştahın açılmaz. Çok yiyemezsin. Yine sıska kalırsın. Arkadaşımın evine misafir oldum. Bira içmeye, yemeye, çok yemeye, bir fil kadar yemeye başladım. Midem bozulmuyor, pek güzel hazmediyordum. Üç ay içinde tanınmayacak bir hale geldim. En ziyade şaştığım şey, bu kadar az para ile bu kadar çok yiyebilmekliğimizdi. Arkadaşımın fabrikadaki gündeliği bir bir üstüne ayda sekiz lirayı geçmiyordu. Bu sekiz liranın içinden hem ev kirası veriyorlar, hem yiyorlar, içiyorlar, hem, evet hem de para biriktiriyorlardı. Yemek, çamaşır, dikiş dahil olmak üzere evin bütün işini arkadaşımın karısı yapıyor, yine her akşam gezmeye çıkıyor, pazar günleri bizimle beraber uzun gezintilere gelebiliyordu. Bu şaşılacak bir şeydi. Ben çok çalıştığını, yorulup yorulmadığını sorduğum zaman güler: — Ben sevgili imparatoriçemiz kadar çalışıyorum. Niçin yorulayım? Derdi. Sonra hemen sevgili imparatoriçelerinin hayatını, hiç hizmetçi kullanmadığını, son derece iktisada riayet ettiğini, hatta büyük çocuklarının esvapları eskiyince atmayıp bir yaş daha küçük çocuklarına giydirdiğini... Yegane kızını hep eski esvaplarını bozarak süslediğini, imparatorun iktisat faziletlerini, masraflı oluyor diye en lezzetli yemeği hatta bir defa bile yemekten vazgeçtiğini anlatmaya başlardı. Bu iri, bu canlı, bu güzel, bu kuvvetli kadının beyaz temiz dişlerini göstererek, gülerek söylediği bütün bu fazilet, bu iktisat menkıbelerini dinlerken gayr-i ihtiyarî İstanbul'u, kendi hayatımızı, zayıf karımın müsrifliklerini, beşer liraya ancak ikişer defa giyilen bluzları, beşer mecidiyelik ipekli çorapları, her iki ayda bir Kalivrusi'ye yirmişer liraya yaptırdığı tayyörleri, otuzar liralık el dantelâlarını hatırladım. İstanbul'a dönmek saatleri yaklaştıkça içimde bir sıkıntı peyda oluyor, büyüyor, beni hastalandırıyordu. Bu rahatı, bu saadeti, bu fazileti memleketimde mümkün değil bulamayacaktım. Istırabımı arkadaşıma açtım. Acıdı. Bana hak verdi. Fakat: — Bu rahat, bu saadet, bu fazilet Almanya'nın toprağında, taşında, coğrafyasında değil, Alman kadınındadır, dedi, Almanya'nın saadetini, refahını, zenginliğini Alman kadını yapar. Sana bir Alman kızı bulalım. Onunla evlen. İstanbul'a dön. Tıpkı Almanya'daki intizam, Almanya'daki istirahat içinde yaşarsın. Bu, olabilir miydi? Evli olduğumu söyledim. Karımı boşarsam birkaç yüz lira nikah verecek param olmadığını anlattım. Arkadaşım: — Hiç korkma dedi. Alman karısı seni on lira ile Türkiye gibi ucuz bir yerde yüz liralık refah içinde yaşatır. Bir senede hiç borcun kalmaz. Ölümden kurtulursun. Düşündüm, taşındım. Alman kadınını gördükten sonra benim müsrif, şık karım hayalime korkunç bir hasar kâbusu gibi geliyordu. İstanbul'a dönmek, borç içinde, rezalet içinde sürünerek aç, sefil ölmek... Yahut Alman kadını denilen bir mes'udiyet makinesi alarak her şeyi silkip atmak... Rahat, müsterih, mes'ut yaşamak... Bu iki yoldan birisine mutlak gidecektim. Ölüme mi? Yaşamaya mı? Ölümü tercih edemiyordum. Gayr-i ihtiyari İstanbul'daki zenginlerin, en çok maaş alan memurların müsriflik, idaresizlik yüzünden çektikleri sefaletleri, en zengin paşaların, beylerin ölümlerinden bir ay sonra çoluk çocuklarının hemen dilenecek derecelere indiklerini aklımdan geçirdim. İdaresiz, iktisatsız, intizamsız bir hayatın paraca ne kadar talihi olsa, yine istikbâli kapkaraydı. İstanbul'daki evimden, karımdan ürktüm. Kurtulmak, yaşamak için... Alman kadını kati bir ilaç, bir dermandı. Bir âb-ı hayattı! Tekrar evlenmeye karar verince kız bulmak uzun sürmedi. Arkadaşımın dostlarından birinin akrabası olan şimdiki karımı bir pazar bana takdim ettiler. Pek hoşuma gitti. Babası iki sene evvel ölmüş, bir mühendisti. Nişanlandık. Kızın küçük bir çeyizi vardı. Nikahlandık. Size yemin ederim ki, resmî evrak ücretinden başka on para masrafım olmadı. Balayı yapar gibi İstanbul yolunu tuttuk. Karım birinci sınıf yolcular arasında seyahat etmemize razı olmadı. Aldığımızı, gazetenin parasına varıncaya kadar bir deftere yazmaya başladı: "Para kazanmak erkeğin, kazanılan paranın iştirâ kuvvetini arttırmak da kadının vazifesidir" diyordu. İstanbul'a geldik. Beyoğlu'nda bir otele indik. Ben yokken zavallı eski şık karım kendisi gibi şık, zarif, tek gözlüklü bir beye âşık olmuş... Onun arzusuyla hemen ayrıldık. Yeni karımı evime getirdim. Aşçı ile hizmetçileri görünce şaşırdı. "Bizde bankerler bile ayrı aşçı, ayrı hizmetçi tutmaz" dedi. Her üçünü de savdırdı. — Evde ne iş olursa ben yaparım, diyordu. Yemek, çamaşır, dikiş, temizlik, bulaşık, tahta silmek, kunduraları boyamak filan... Geldiğimizin ertesi akşam evin kirasını sordu. Ben: — Altı lira... Deyince hayretinden gözleri patlayacaktı. — Hiçbir adam vâridâtının yarısından ziyadesini ev kirası verir mi? Diye şaşıyor, Türkiye halkının hiç hesap bilmediğini söylüyor: — Sizde bir, iki, üç, dört, beş, on, yirmi, otuz var mı? Yazınızda rakam işaretleri var mıdır? Diye tuhaf sualler soruyordu. Evvela möbleleri sattırdı. Paralarını bankaya koydu. O ay evi de bıraktırdı. Haydarpaşa'da bir Alman evinin üst katını sekiz mecidiyeye kiraladı. Burası mutfağıyla, aptesanesiyle, ayrılmış bir apartıman dairesi gibiydi. İki odası vardı. Birini yatak odası yaptı, birini oturma... Bu ikinci odada hem misafirlerimizi kabul ediyor, hem de yemeğimizi yiyorduk... Rahat, mesut yaşamaya başladık. Kira dahil olduğu halde aylık masrafımızı tam beş lira ediyordu. Maaşımdan artan beş lirayı karım her ay bankaya götürüyor, mobilyalardan aldığımız paranın üzerine ekliyordu. O vakitten beri her ay beş lira harcediyoruz. Ben saat sekizde gara gidiyorum. Her gün öğle üstü karım bir sefer tasıyla yemeğimi, ekmeğimi ayağıma getirir, her akşam gelir, beni alır, beraber gezeriz. Saat altı buçuğa gelince beni gezintide yalnız bırakır, eve döner, yedi buçuğa kadar yemeği hazırlar, ben gelince yemeği hazır bulur, otururum. Yemekten sonra kemanla klasik parçalar çalar, klasik şiirler okur. Onbirde hemen yatarız. Karım altıda yataktan kalkar. Kahvaltıyı hazırlar. Benimle beraber çarşıdan o günkü zahireyi almak için çıkar. Pazar günleri yaz olsun, kış olsun, mutlaka dağlara gezmeye çıkarız. Akşama kadar dolaşırız. Karıma göre en güzel eğlence kırda yayan gezmek, kırların havasından istifade etmektir. Üç senedir işte hayatımız bu program içinde geçiyor. Bir gün daha bu program bozulmadı. Geçen sene maaşım onbeş lira oldu. Karım bunun masrafımıza hiçbir tesir yapamayacağını söyledi. Her ay bankaya beş lira yerine on lira götürmeye başladı. Karımın fikrince masraf vâridâta göre değil, ihtiyaca göre yapılırdı. Vâridât artabilirdi. Fakat vâridâtın artması masrafın çoğalması için mantıkî bir sebep olamazdı. Masraf, yine ihtiyacın derecesinde kalmak icap ederdi. Bunu ben de muhakeme ettim. Doğru buldum. Bu kadar basit, bu kadar doğru bir hükme acaba Türkiye'de kaç Türk sahiptir? Bir Türk'ün aylık vâridâtı yirmi beş lira iken otuz lira oldu mu, hemen evini değiştirmeye, daha fazla bir hizmetçi tutmaya kalkar. Halbuki bizim kumpanyanın müdür muavini yüzlerce lira maaş aldığı halde masrafı ihtiyacına göredir. Yani tıpkı benimki gibi... Onun karısı da hizmetçi aşçı, uşak kullanmaz. Çarşıdan erzakını bile kendi pazarlık eder, kendi alır, kendi evine getirir. Karım: — Ancak doğacak çocuklar masrafa bir şey ilâve ettirir der, çünkü ihtiyaç değişir. Masraf da o ihtiyaca uymalı. Evet, nihayet bizim de bir gün masrafımızın çoğalması icabeder gibi oldu. Karım gebeydi. İşte ben asıl iktisat faziletinin ne olduğunu karımın gebeliğinde gördüm. — Bir hizmetçi tutsak... Sen gebesin... Rahatsız oluyorsun! Dedim. Karım katiyyen reddetti. Gebeler için yürümek, iş görmek lazım olduğunu, gebelikte oturmak intihardan, havaleye, ölüme koşmaktan başka bir şey olmadığını söyledi. Hiç tertibimiz bozulmadı. Yine sabahları pazara gidiyor, gara yemeğimi getiriyor, akşamları beraber geziyorduk. Karnı büyüdü, büuüdü, büyüdü. Sekiz aylık, galiba dokuz aylık oldu. Ben: — Pek yaklaştı, artık bir adam tutsak... dedim. — Daha vakit var, daha vakit var! Diyordu. Bir gün yine sabahleyin evden çıktık. O pazara sapmak için benden ayrıldı. Öğleyin yemeğimi getirdi. Akşam üstü, geldi, beni aldı. Biraz gezindik. Gayet bol bir manto giymişti. Yine akşam yemeğini hazırlamak için bir saat evvel benden ayrıldı. Ben arkasından eve gelince her vakitki gibi sofrayı hazır buldum. Oturdum, yemeğe başladık. Tam yemek ortasında öbür odadan: — Viyak, viyak... Diye bir seda gelmez mi? — Bu ne? Dedim. Karım tavrını bozmadan gayet tabiî bir şey söylüyormuş gibi: — Çocuk! dedi, bugün doğurdum... Gözlerimi açtım. Ben hâlâ bir Alman kadınının ne olduğunu tamamıyla anlayamamıştım. — Ne diyorsun? diye haykırdım. Ebe nerden buldun? — Ebesiz doğurdum, dedi, ebe hekim demektir. Ben hasta mıyım? Ebeye ne lüzum var? — Ne vakit doğurdun? Diye tekrar haykırdım. Karım istifini bozmadan cevap verdi: — Senin yemeğini gara bıraktıktan sonra dönerken ağrı duydum. Eve geldim. Muşambaları siliyordum. Ağrı ziyadeleşti. Banyoyu doldurdum. Çamaşır leğenini hazırladım. Doğurdum. Çocuğumu yıkadım, sardım, yatırdım. Kendim de yıkandım. Sonra yemeği hazırladım. Gezmek için geldim, seni aldım. Şimdi gelince beş dakika kadar süt verdim... Hemen ayağa kalktım. Odaya doğru, bu kendi kendine doğan çocuğumu görmeye koşuyordum. Beni tuttu: — Otur, rica ederim. Yemeğin intizamını bozma. Kalkınca gidip görürsün... Dedi. Yemekten sonra küçük bir sepetin içine yatırılmış yavrumu gördüm. Açık mavi gözleri tıpkı annesininkine benziyordu. Şimdi altı aylık oldu. Henüz masrafımızda bir ziyadelik yok... Karım dört beş yaşına girmeden bir çocuğun hiçbir masrafı olamayacağını söylüyor... Bir hafta geçmeden çocuğun uyuması, ağlaması, yemesi intizama girdi...

Oh, azizim, ne çabuk... Tarabya'ya geldik. Ben buraya çıkacağım. Veriniz elinizi, sıkayım. Anladınız ya, ben niçin otuz okkadan doksan beş kilo oldum. Alman kadını... Alman hayatı... İntizamla istirahat! İşte saadetin sırrı! Allahaısmarladık. Her pazar yayan Çamlıca tepesine çıkarız. Sen de gelirsen, orada görüşürüz. Allahaısmarladık..!"

— Madama benden ihtiramlar! Dedim. Elimi sıktı. Kalktı, hızla yürüdü. İskeleden inip diğer yolcuların arasında kayboluncaya kadar arkasından baktım. Vapur kalktı. Göğsümden asabî bir ağırlığın yükseldiğini, nefes aldırmayacak gibi boğazıma tıkandığını duyuyordum.

Artık, mesut olmak için...

Görünmez bir kâbusun önünden kaçar gibi gözlerimi oğuşturdum. Üzerinde temiz martıların uçuştukları koyu prusya mavisi denize baktım. Karşı sahil mor tepeleri, beyaz yalıları, koyu nefti ağaçlıklarıyla sanki ebedi bir keyif uykusuna dalmış gibiydi. Fon Sadriştayn'ın uzvî istirahatinden, her ânına mantıkla hesap karışan saadetinden, çamaşır yıkayan, yemek pişiren, tahta silen, kundura boyayan aşkından tiksiniyordum. Tâ orada... Şu küçük yalıcıkta müsrif, hesap bilmez, saz benizli, narin, şık bir kadınla borç içinde, manevi, maddi ıstıraplar içinde... Tabiatın uyuşuk sükûnu karşısında sessiz, mahmur yaşamak daha tatlı değil miydi?

Açık mavi, ebediyetten kopmuş canlı köpük parçaları halinde, güvertenin üzerinden, sürü sürü geçen martılar: — Evet, — Evet, evet... Diye hüzünlü sesleriyle bağırışıyorlar, sanki benim ruhumun meyus sualine göklerden ilâhî bir cevap veriyorlardı.

# Fon Sadriştayn’ın Oğlu

—Yirmi beş sene sonra—

İhtiyar Fon Sadriştayn bir haftadır apartmanından dışarı çıkamamıştı. "Oburluğun zarurî neticesi" olan nikris sızıları onu, geniş pencereye dayalı derin koltuğunda ölüm için işkenceye konulmuş, ümitsiz bir esir azabıyla kıvrandırıyordu.Gecelerden beri uyku yüzü görmeyen kanlı gözleri yorgun bir bakışla Fındıklı'nın üstünden geçiyor, mavi Boğaz'ı aşarak uzaklara, tâ Çamlıca tepesine dikilip kalıyordu. Hava bir genç kız kahkahası kadar berraktı, saftı, aydınlıktı. Şuh mayısın sabah güneşi, bütün İstanbul'u beyaz altından bir ziya tufanı içinde parlatıyordu. Nihayetsiz tayyare kümeleri, mukaddes bir Kâbe'yi tavaf eden şeffaf Cennet kuşları gibi Çamlıca tepesinin üstünde dönüyor, dolaşıyordu. Bugün İstanbul'un... yalnız İstanbul'un değil, bütün Türklerin millî bir bayramıydı! Fon Sadriştayn gözlerini şeffaf kuşlardan indirdi. Üsküdar köprüsüne baktı. Otolar, tramvaylar, arabalar, alaylar... Bir karınca seli halinde akıyor; asma kulelerde, yaldızlı tanklarda büyük bayraklar sallanıyordu. Limanın sahilleri, en büyük vapurlardan en küçük kanolara varıncaya kadar ne varsa hepsi donatılmıştı. Millet genç dâhisinin doğduğu günü tebcîl ediyordu! Fon Sadriştayn, gözlerinden ruhuna dolan tatlı, aydınlık bir sevincin asabına süzüldüğünü, yavaş yavaş bütün vücuduna yayıldığını hisseder gibi oldu. Ayaklarının ağrılarını bir an unuttu. Gülümsedi. Titreyen parmaklarıyla ak düşmüş çatal sakalını kaşırken kalbinde, şimdiye kadar hiç farkına varmadığı, ince bir heyecanın hızla ürperdiğini duydu. Doğruldu. Tekrar dışarıya baktı. Her yer, hatta Dolmabahçe Sarayı bile baştan aşağı taflanlarla, tanklarla donatılmıştı. Ayaspaşa'dan kabataş'a inen dik ana yokuş iğne atılsa yere düşmeyecek derecede kalabalıktı. Bandoların, marşların, şarkıların akisleri yükseliyor, esmeyen bir rüzgâr cereyanı gibi pencereden giriyordu. Bütün İstanbul sevinçten taşıyor, kabına sığamıyordu. Fon Sadriştayn gayr-i ihtiyarî:  
—  Lida!  
Diye bağırdı. Üç odadan ibaret olan bu mini mini apartıman bir avuç kadar dardı. Mutfaktan karısı sordu:  
— Ne var?  
— Çabuk giyin, rica ederim.  
— Ne olacak?  
— Dışarı çıkalım.  
Kapıdan Madam Sadriştayn göründü. Kalın gözlükleri altında iri mavi gözleri süzüyordu. Altmışlık şişman bir ihtiyar sanılacaktı. Halbuki bu zavallı kadıncağız, henüz kırk beşinde bile değildi. Yirmi beş sene mütemadî, ağır, nihayetsiz bir iktisat sabrıyle dişten, tırnaktan arttırarak biriktirdiği servetin dünyada en ziyade sevilmesi icap eden bir vücut tarafından aşırılması, onu birdenbire çökertmiş, birkaç ay içinde saçlarını ağartmıştı. İhtiyarlık teminat akçasından mahrum hasta bir kocayla yapayalnız, ümitsiz kalınca, yine cesareti kırılmadı. Şimendifer kumpanyasından aldıkları tekâüt maaşıyla intizam içinde, iktisat içinde yine soğukkanlılıkla, rahat rahat yaşıyorlardı.  
— Dışarda ne yapacağız? Bir işimiz mi var?  
— Yok.  
— Eh?..  
— Orhan Bey'in doğduğu gün de...  
— Orhan Bey kim?  
—  Bilmiyor musun?  
—  Hayır.  
— Tuhaf!  
Madam Sadriştayn, işte otuz seneye yakın kocası Türk olduğu, Türkiye'de yaşadığı halde oturduğu memleketin hiçbir şeyini bilmiyordu.  
— Kim bu?  
— Bizim milli şairimiz! Genç dâhimiz!..  
— Ey, ne olmuş ona?  
— Birşey olmamış, doğduğu günü, bu seneden itibaren Türkler kendilerine millî bayram yaptılar. Bak her taraf donanmış...  
— .......  
Madam Sadriştayn yürüdü. Ortadaki boş masaya elini dokundurarak geçti. Pencereye yaklaştı. Kayıtsız bir tavırla dışarı baktı. Sonra:  
— İyi...  
Deyip çekilirken kocası:  
— Haydi beraber çıkalım, Lida...  
Dedi.  
— Benim mutfakta işim var. Sen yalnız çık!  
— Gel işini bırak, Lida, büyük günün şerefine!  
Ciddî kadın ihtiyar kocasının bu çocukça arzusuna güldü:  
— Bu büyük günden bana ne? dedi, sizin kendi bayramınız.  
—.......  
Cevap beklemeden odadan çıktı. Fon Sadriştayn gözlerini alçı tavana kaldırdı. Ayaklarının sızıları sanki kalbinde toplandı. Evet, doğruydu. Kendi bayramından ona neydi? Kendi onun bayramlarına bir nezaket olsun diye iştirak ederken tatsız bir angarya ağırlığı duymuyor muydu? İşte yirmi sekiz sene bir çatı altında beraber ihtiyarladıkları halde ruhları birbirlerine yabancıydı. Aralarında ummanların, karlı şâhikaların ayırdığı geçilmez bir hudut var gibiydi. İhtiyarladıkça, ihtiyarlayıp hastalandıkça, bu çorak buz çölü daha ziyade genişliyor, daha ziyade büyüyordu. Artık eski kayıtsızlığından eser kalmamıştı. Her şeye sinirleniyor, vakasız geçen bir hayatın, tek tük hâtıralarından kendine derin bir elem yaratıyordu. Kitap okuyamıyor, kırlarda gezemiyor, yemek yiyemiyor, bira içemiyor... Sofradaki saatin, sızılarına karışan tiktaklarını dinleyip oturuyordu. Karısının böyle soğuk davranışı bir an evvel kalbinde tutuşan iftihar alevini söndürmüştü. Ayakları tekrar zonklamaya başladı. Elleriyle dizlerini sıkıyor, yüzünü buruşturuyor; davranmak, kalkıp dışarı çıkmak için kendinde kuvvet bulamıyordu. Ansınız sokaktan bir çığlık aksetti:  
— Vakit, Havadis,Tanî, Turan, İkdam, Büyük Gazete... Büyük Gazete... Yarın, Haliç, Güzel İstanbul, havadis... havadis...  
. . . . . . . .

Müvezzî geçiyordu. Fon Sadriştayn koltuğundan kalktı. Pencereden başını çıkardı. Seslendi:  
— Gazeteci, gazeteci!..  
Bu, ufak bir çocuktu. Durdu. Yukarı baktı.  
— Beşinci kata gel!  
— Asansör var mı?  
— Yok.  
— Gelemem.  
Halbuki bu müstesna günde gazetelerin ne yazdığını Fon Sadriştayn çok merak ediyordu.  
— Ne kadar gazeten varsa hepsinden birer tane alacağım... dedi.  
— ......  
Çocuk cevap vermedi. Nazlı nazlı sarı badanalı binanın yüksekliğini süzdü.  
— Bahşiş de veririm.  
— Geliyorum...  
. . . . . . . .

Çocuk apartımanın kapısından girince Fon Sadriştayn duramadı. Yatak odasına geçerken gözü mutfağa kaçtı. Karısı ocağın başında saat rakkası gibi sallanarak bir kap çalkalıyordu. Çantasından on kuruş aldı. Hastalara mahsus o müvesvis adımlarla sanki çürük bir zemine basıyormuş gibi dikkatle yürüdü. Gitti, apartımanın dar merdivenine açılan kapısını aralık etti. Dayandı. Bekledi. O kadar sabırsızlanıyordu ki... Bir dakika içinde iki saat bekledim sandı. Çocuk nefes nefese çıkınca her gazeteden birer tane aldı, geri kalan parayı ona bağışladı... Kapıyı hızla iterek odasına döndü. Derin koltuğa çöktü. Zayıf dizlerinin üstünde gazeteleri açmaya başladı. Her gazete bugünkü nüshasını Orhan Bey'e hasretmişti. Ayaklarının sızılarını unuttu. Bu yüksek pencereden kuş bakışıyla şaşaasını gördüğü İstanbul'un kalbi sanki bu kağıtların içindeydi. Hepsi Orhan Bey'in çehresini tabiî büyüklükte ilk sahifelerine basmışlardı. Fon Sadriştayn, şimdiye kadar bu meşhur genç dâhinin kendisini hiç görmemişti. Ama resmini birdenbire tanır gibi oldu. Bu ince kaşlar, bu derin gözler, bu tatlı gülüş... Ona hiç yabancı gelmedi. Bu necip yüzü çok görmüştü. Ama nerede? Ne vakit? Nasıl? Dikkatle bakarak düşündü, düşündü. Bir türlü hatırlayamıyordu. Haliçin başındaki programa bir göz gezdirdi. Bu bayrama İstanbul'un bütün ilmî, edebî, siyasî mahfilleri, darülfünunları, ressam, musikişinas, mimar, heykeltraş, tiyatro cemiyetleri; liseler, deniz, kara, hava spor kulüpleri; elektrikçilik, tayyarecilik, tahtelbahircilik dernekleri filan hepsi iştirak ediyor, ordu İstanbul'daki kıtalarını geçit yaptırmak için sabahleyin erkenden Çamlıca'da topluyordu. Sevgili dâhinin doğduğu, büyüdüğü, hâlâ içinde yaşadığı küçük köşk oradaydı. Bütün halk denizden, Üsküdar köprüsünden o tarafa doğru akiyordu. Fon Sadriştayn bile edebiyatı hiç sevmezken, Orhan Bey'in eserlerinden bazılarını okumuştu. Ülkenin Uyanışı unvanlı şiirini hatırlayınca ruhunda tatlı bir heyecan dalgalandı..Programdan sonra Orhan Bey'in hayatına dair yazılan şeyleri okumaya başladı. Bu büyük şair henüz yirmi yedi yaşındaydı. Bir âşık gibi halkı sevmiş, daima halkın içinde yaşamış, birbiri arkasına on cilde yakın eserler çıkarmıştı. On dokuz yaşındayken Anadolu'yu gezmiş, köylerde, kulübelerde, obalarda misafir kalarak Türkler'in millî destanını dinlemiş, onun ruhuna hulûl etmişti. Sonra milletine üç cilt nefis şiir, iki cilt roman vermiş, üç mükemmel trajedi yazmıştı. Turanın altın harflerle bastığı satırlar ruhunda gayet ulvî, gayet büyük bir takdir uyandırdı. Tekrar tekrar okudu:

"... Orhan, asrımızın en büyük dâhisidir. O, devirlerden beri gaflet kâbusuyla uyuşmuş bir millete yüksek vicdanını duyurdu. Lisanını öğretti. Ondan evvel Türkler'in umumî bir lisanı yoktu. İstanbul'da "tabiî Türkçe" tahkir olunuyor, birtakım şair, birtakım edip taslakları "Servet-i Fünun" un, mâhut Frenk mukallitlerini taklit ederek Arapça, Acemce terkip düzmeyi bir marifet, bir sanat sayıyorlardı. Yahut "Tasfiyeciler" in sunî lisanını millî Türkçe zannediyorlardı. Orhan Bey, ilk darbeyi bu gafillere indirdi. Edebî şaheserlerindeki tabiîliğin olanca büyüklüğüyle demek istedi ki: — Edebiyat, sanat, bir zümre için, bir sınıf için, birkaç kişinin marazî keyfi için değildir. Sanat bütün bir milletindir! Onun konuştuğu, kitaplardan öğrenmeden bildiği tabiî lisanla edâ olunmalıdır!"

Büyün Gazete genç şairi tebcil ederken ne yapacağını şaşırıyor:

"Ey genç dâhi! Sen bizim hâlikimizsin! Senden evvel Türk milleti birbirini tanımazdı. Hıyve, Buhara, Semerkant, Kâşgar, Kafkasya, Azerbeycan, Anadolu, İstanbul'un lisanını anlamazdı. İstanbul'un içinde, yaşayanlar bile kendi memleketlerinin edebiyatını duymazlardı. Senden evvel şairler, bütün duygularını ondan saklarlardı. Dinin sırrî derinliklerine istiğrak ederek orada lâhutî vecitler yaşamazlardı. Edebiyatımıza asrî bir diyaneti, bugünkü felsefeye uygun bir tasarrufu ilk defa sokan sen oldun. Sen mukaddes bir güneş gibi doğdun! Gökteki hayat verici güneş nasıl arzın yüksek, alçak yerlerine seyyanen aydınlığını serperse, sen de tıpkı onun gibi milletini "avam, havas", diye ikiye ayırmadın. Hepsinin üstüne dinî bir vecdin, millî bir mefkurenin şulelerini saçtın. İstanbul'un narin kızları, Anadolu'nun pehlivan çocukları, hatta Türkistan'ın saf çobanları şiirlerini ezberlerdi. Yüzlerce seneden beri kalbimizde uyuyan ilâhî aşk, senin bir mısranla tekrar tutuştu..." diyordu.  
Güzel İstanbul gazetesinin hiçbir şeyi beğenmemekle, her şeye taarruz etmekle şöhret alan münekkidi bile: "Ben Orhan Bey'in dehası karşısında secde ederim. Ona kadar tabiî lisanlarıydı, bu kadar yüksek eserler yazılmamıştı. O, İstanbul lehçesini bütün türk milletine sevdirdi. İstanbul lehçesi onun sayesinde bütün bir milletin samimî lisanı oldu.Ona kadar herkes ya Acem'i ya Frenk'i taklit ediyordu. O ne Frenk'e ne Acem'e baktı. Ne de âşık sazlarını, tekke neylerini taklit etti. Gözlerini kendi ruhuna çevirdi. Türk hissini duydu. Kahramanlıklarını, hikâyelerini, mevzularını, lisanını hep Türk vicdanında buldu..." diye takdirden kendini alamıyordu. Fon Sadriştayn, gazetelere öyle dalmıştı ki... Karısının dışarıdan kendisini çağırdığını işitmedi. Kapı birden açılınca toplandı:  
— Yemek hazır!  
— Ben yiyemeyeceğim. Midem bozuk.  
— Süt iç.  
— Sonra.  
— Pekala!  
— .......  
Okuduğu gazeteler sağ yanında bir yığın olmuş, deminden önünde, kahverengi muşambanın üstüne akseden ziya müstatîli tamamıyla silinmişti. Birden top sesleri başladı. Pencereden baktı. Programın dediği gibi, donanma Çamlıca karşısında geçit yapıyor, şairi selamlıyordu. Demek ki saat on ikiydi:  
— Akşama doğru çıkarım. Gece alayında bulunurum, dedi.  
Yine gazetelere daldı. Milletinin bu kadar büyük bir dâhi yaratması, lezzeti anlatılmaz bir sevinçle onu sarsıyordu. Yarın gazetesinin muhabiri genç şairle yaptığı bir mülakatı da yazıyordu. Fon Sadriştayn, Orhan'ın sözlerini tekrar tekrar okudu. Bu dâhi: "Ben her şeyi annemden öğrendim. Annem beni dinî bir vecd içinde büyüttü. Şiirimde duyduğunuz "lirizm" in menbâı ondan aldığım dinî terbiyenin heyecanlarıdır. Şiirlerimi, hikâyelerimi, trajedilerimi evvela masal halinde ondan işittim. Onun halktan olan ruhu bana halk sevgisini, halk aşkını, nefhetti. Bundan dolayıdır ki, kafiyelerim halkın tâbirleri, musikim halkın dilindeki ahenktir..." diyordu. On cilt eseri başka başka matbaalar tarafından ayrı ayrı şekillerde basılmıştı. Yarın her şekilden bir örneğin resmini gösteriyor, bütün eserlerinin mevzularına dair malûmat veriyordu.

Fon Sadriştayn, saatlerce bu tafsilâtı okudu. Bin seneden beri bir milletin ruhunda akmadan biriken rebâbeti taşırmak, yetmiş seksen milyonluk bir milletin uyuyan vicdanını uyandırmak... Şüphesiz dünyada yapılacak ilâhî işlerin en büyüğüydü! Hiçbir dahi bu kadar gençken milleti tarafından anlaşılmamıştı. Turan'ın her tarafından onu selamlamak için heyetler gelmişti. Kâşgar'dan, Buhara'dan, Fargane'den, Hıyve'den, Altay şehirlerinden, her yerden, her yerden... Mesut şair, ebediliğin lezzetini ebedi hayata karışmadan tadıyordu. Fon Sadriştayn böyle takdirler, tahayyürler, meftunluklar içinde düşünürken, ansızın bütün nikris sızılarını yine kalbinde duydu. Duyduğu acıdan az daha ölecekti. Elini göğsüne koydu. Yüzünü buruşturdu. Başını eğdi. Dişlerini sıktı. Kendi oğlu aklına gelmişti. Gözlerini kapadı. Fakat hâtırasını kapayamazdı. Arzusuna rağmen hayalinde onun yüzünden çektiği ıstıraplar maziden daha şedîd bir vuzuhla uyanıyordu. O da şimdi Orhan Bey gibi yirmi yedi yaşındaydı. Tahsili için, terbiyesi için o kadar çalıştığı halde, onda her faziletin ölümünü görmekten başka bir şey elde edememişti. Şüphesiz Orhan gibi dâhiler milyarda bir doğardı. Kimbilir, bu yaratıcı ruhu ona veren annesi ne ulvî, ne mükemmel bir kadındı. Fakat kendi karısı da fena mıydı? Fedakârdı. Namusluydu. Muktesitti. Çalışkandı. Ciddiydi. Halbuki oğlu hodgâm, azimsiz, müsrif, tembel, karaktersiz bir serseriydi. Daha küçükken riyakârlığa başlamıştı. Annesine: "Ben Alman'ım! Türkler eşektir!", kendisine: "Ben Türk'üm! Almanlığı kabul etmem" diyerek ikisinin arasında gizli gizli buz dağları yükseltir; sonra yalanla, düzenle her birisinin muhabbetini ayrı ayrı çalar, çaldığı iki muhabbeti sahiplerine karşı birer şantaj âleti yapardı. Fon Sadriştayn, tamamıyla tepesi dökülmüş başını ellerine aldı: — Niçin böyle oldu? Niçin böyle oldu? Diye inledi. Annesinin faziletleri niçin ona geçmemişti? Kendisi fenalıktan nefret eden, sakin, akıllı, çalışkan bir adamdı. Niçin bu halleri çocuğuna geçmemişti? Hususiyle Orhan gibi mükemmel bir şahsiyet yalnız annesine kalmış bir yetimdi. Hayatının hikâyesine bakılırsa, daha kendi bir yaşında iken babası Çanakkale'de şehit düşmüştü. Kalbi hızla çarpmaya başladı. Oğlunun rezaletlerini hatırladıkça tıkanacak gibi oluyordu... Yirmi beş sene içinde bin türlü sıkıntı ile istikballeri için biriktirdikleri serveti bankadaki kasadan Arsen Lüpenvarî bir entrika ile aşırıp Amerika'ya kaçtığından beri, karı koca, ismini bile ağızlarına almıyorlardı. Madam Sadriştayn, oğlu aklına gelince, kendisi gibi heyecana düşer, yüzü kızarır, elleri ayakları titrer: — Şeytan alsın, şeytan alsın! Onun yüzünü bir daha bize gösterme Allahım! Diye diz çökerek yanık yanık ibadet etmeye başlar, gözlerinden acı gözyaşları boşanırdı. Şimdi kimbilir neredeydi? Ne Türk olabilmişti, ne de Alman... Her milletin haricinde, her ahlâkın dûnunda, kötü bir enmûzeçti. İki ziyadan karanlık hâsıl olması gibi; annesinin, babasının milliyetlerindeki faziletler de, sanki onda birleşince bir fezâhat haline geçmişti. Fon Sadriştayn, genç yaşında milletine mefkûre peygamberi olan Orhan'ın ailesini düşündü. Oğullarının bu mazhariyeti, bu şerefi için ne kadar mesut olmuşlar, ne kadar iftihar etmişlerdi! Daima hayalin fevkinde, olmayacak şeyleri isteyen marazî bir baba gıptasıyla: "Ah, benim Hasip de böyle bir dâhi olsaydı..." diyordu. Orhan Bey... İşte her dâhi gibi onu da annesi yaratmıştı.

Acaba annesi nasıl ulvî, nasıl mükemmel bir kadındı? Oğlunu ilhamın, hayatın, hakikatin tabiî membâlarına götüren, koca bir millete halaskar yapacak kadar millî bir terbiye veren bir kadın acaba nasıl bir vücuttu? İhtiyar Fon Sadriştayn, içinden ruhuna akseden bu sualleri düşüne düşüne zayıf dimağını yordu. Koltuğunda bir afyon sarhoşu gibi sızıverdi.

Karısı pencereyi kaparken uyandığı zaman güneş çoktan batmış, ortalık tamamıyla kararmıştı. Boğaz, saraylar, karşı yaka, bütün liman, Üsküdar köprüsü, Çamlıca tepesi elektrik çiçekleriyle donatılmış; alkış, musiki, bando sesleri esirî bir tufan gibi her tarafı kaplamıştı.  
— Bu gece rutubet var!  
— Ben çıkacağım.  
Madam Sadriştayn sordu:  
— Niçin?  
— Gezmeye...  
— Maksadın şenliği görmekse, buradan daha iyi görünüyor. Sokakta ne yapacaksın?  
— Hiç.  
— Bak...  
İkisi tâ yemek zamanına kadar pencereden güzel İstanbul'un nur içinde parlayışına uzun uzun baktılar. Hiç konuşmadılar.

Fon Sadriştayn bu milli bayramın ertesi günü, daha ertesi günü rahat edemedi. Vâkıâ nikris sızıları durmuştu. Lâkin "sabit bir fikir" ruhuna sükûn vermiyor, onu eski kayıtsızlığına döndürmüyordu. Acaba cihana böyle bir dâhi yetiştiren kadın nasıl bir şeydi?  
— Ah onu bir görsem...  
Diyordu.

Arzusunu unutamayan hasta bir ihtiyar asabiyetiyle üzülüyor, koltuğunda oturamıyordu. Öğle yemeğinden kalkınca yatak odasına geçti, giyindi. Kalın meşe bastonunu aldı. Sofrayı toplayan karısı:  
— Nereye gidiyorsun?  
Diye sordu.  
— Gezmeye.  
— Geç kalma. Akşamlar rutubetli oluyor.  
— Pekala.  
Kapıdan çıktı. Dar, karanlık merdivenleri dinlene dinlene indi. Yokuşa saptı. Ayazpaşa Parkı'nın önündeki küçük telefon merkezine girdi. Rehberde Orhan Bey'in adresini aradı, buldu. Telefonu eline aldı:  
— Çamlıca, bir, beş...  
— Buyurun.  
— Allo.  
— Efendim.  
— Orhan Bey'in köşkü mü?  
— Evet efendim.  
Bu, ince bir kız sesiydi. Fon Sadriştayn tekrar sordu:  
— Anneleri hanımefendi orada mı?  
— Buradalar.  
— Ben kendilerini tebrike gelmek, ziyaret etmek istiyorum. Kabul buyururlar mı?  
— Kimsiniz? Sorayım efendim.  
— Bir ihtiyar deyiniz.  
— İsminiz?  
— Meşhur bir adam değil. Sadrettin, Anadolu Şimendifer Kumpanyası mütekâit memurlarından... Şöhretim Sadriştayn...  
— Sorayım efendim, bekleyiniz.  
. . . . . . . .

İki dakika kadar bekledi. İnce ses âletin içinden tekrar aksetti:  
— Alo...  
— Efendim.  
— Buyurunuz, kabul edecekler. Ne vakit geleceksiniz?  
— Şimdi.  
— Buyurun efendim.  
Fon Sadriştayn kulübeden çıkınca parkın önünde duran otomobillerden birine atladı: "Çamlıca, Orhan Bey'in köşküne" dedi. Görmeyen gözlerle etrafına bakıyor, göreceği büyük kadını düşünüyordu. Otomobil ona pek ağır yürüyor gibi geldi. Üsküdar köprüsünü geçerken dayanamadı. Şoföre: "Daha çabuk!.." diye rica etti.

Onbeş dakikada Çamlıca'ya gelmişti. Otomobilcinin gösterdiği demir parmaklıklı bir kapıdan girince, karşısında kaldığı manzaranın letafetinden şaşırdı. Balıksırtı geniş bir yolun iki tarafında büyük akasyalar sakin gölgeleriyle her tarafı kaplıyor, zarif tarhlarda isimlerini bilmediği çiçekler, vücutları görünmeyen peri gözleri gibi kendine bakıyorlardı. Tatlı kokular içinde yürüdü. İleride, bu gayet loş gölgeler altında daha beyaz duran mermer bir havuz vardı. Onun başına gelince durdu. Bir bülbül ötüyordu. Etrafına tekrar bir göz gezdirdi. Yasemin kemerlerle örtülü keçi yolları sarmaşıktan kameriyelere gidiyor, büyük büyük çamlar bahçe duvarlarını gizliyordu. Havuzun kenarındaki kamıştan kanepeye uzanacağı geldi. Berrak suyun içinde kırmızı balıklar uyuyorlardı.  
—Ne letafet yarabbi!  
Dedi. Burası küçük bir cennete benziyordu. Orhan'ın nefis mısraları kadar hülya, haz, hayat doluydu. İstemeye, istemeye kendi hayatını hatırladı. Böyle bir bahçenin hayali, rüyasına bile girmemişti. Dar merdivenler, kalın möbleler, kaba dolaplar... Halbuki bu muhit baştan aşağı bir şiirdi. Kendi hayatı bu samimî şiirin yanında ağır bir nesre, bir bakkal dükkanının ilanına benziyordu. Evet, kendi hayatı çirkin değilse bile, hiç de güzel değildi. Vaktiyle kazandığı paralarla pekala böyle güzel bir köşede yaşayabilir, yaşamının ulvî zevkini tadabilirdi. Ama iktisat hırsı... Onu her türlü güzellikten uzak bulundurmuş, "faydalı" dan başka her şeye düşman etmişti. Neticede ne kâr vardı? Biriktirdikleri paraları oğlu çalıp kaçmamış mıydı? Yine teessüründen kalbi burkuldu. Duramadı. Köşkün mermer peronuna ilerledi. Geniş pencerelerinin beyaz tülleri rüzgârla sallanıyordu. Önündeki havuzuyle neftî gölgeler altında uyuyan bu mini mini yuva öyle nefis, öyle bediî bir dekor teşkil ediyordu ki... Fon Sadriştayn:  
— Bu sahnede doğan, büyüyen nasıl dâhi olmaz?  
Dedi. Hayatında ilk defa, düşünmeden güzelliğin rolünü anlıyordu. Temiz basamakları yavaş yavaş çıktı. Camlı beyaz kapının elektrik düğmesine bastı, genç bir kız karşısına çıktı:  
— Hanımefendiyi ziyarete geldim.  
— Telefonla söylemiştiniz, değil mi efendim?  
— Evet.  
— Buyurunuz.  
Yol verdi. Fon Sadriştayn büyük şairin evini çok kalabalık tasavvur ediyordu. Halbuki burada çıt bile yoktu. Bastonunu portmantoya dayarken kıza: "Orhan Bey burada mı?" diye sordu.  
— Hayır efendim.  
— Ya nerede?  
— İki hafta evvel Bolu'ya gitti.  
— Kendi şenliğinde bulunmadı mı?  
— Hayır efendim.  
Kızın kapısını açtığı küçük bir salona girdi. Sedirleri, duvarları, perdeleri o kadar zarifti ki... Daha hepsine ayrı ayrı bakmadan yüreğinde tatlı bir heyecan duydu. Kız:  
— Hanımefendiye haber vereyim.  
Diye çekildi. Duvarlarda en meşhur Türk ressamlarının levhaları vardı. Tâ kapının karşısında otuz sene evvelki seferi formalı bir genç zabit resmi asılmıştı. Bakışında necib bir derinlik parlıyordu. Fon Sadriştayn: "Bu mutlaka şairin Çanakkale'de şehit düşen babası olacak!" dedi. Tavanın nakışlarında, yerdeki halının, döşemelerin renklerinde öyle bir ahenk vardı ki, insan bakarken kendisini bir "sükûn musikisi" içinde sanacaktı. Kız, arkasından:  
— Buyurun efendim  
Dedi. Fon Sadriştayn döndü. Kapıdan çıktı. Mermer sofayı geçti. Şimdi bu şiirden yuvayı yapan, bu şiirin içinde büyük dâhiyi yetiştiren büyük kadını görecekti. Yüreği yine tatlı bir heyecanla çarpmaya başladı. Önünde açılan kapıdan girdi. İndirilmiş bir perdenin yarım aydınlık gölgesinde henüz genç denecek bir kadının ayakta durduğunu gördü. Birden gözlerine inanamadı. Dikkatle baktı. Taş kesildi. Nefesi tutuldu. Etrafı karardı, düşecekti.  
— !..  
— Değil mi? Sadrettin Bey?  
— .......  
— Tanıdınız.  
— .......  
— Evet, buyurun oturunuz.  
— .......  
Fon Sadriştayn düşmemek için arkasına dayandı. Başını yere eğdi, elleriyle yüzünü kapadı:  
— Beni affediniz, beni affediniz! diyebildi.  
Orhan'ın annesi, gayet yüksek bir âlemden günahkârlara seslenen şefkatli bir melâike gibi sordu:  
— Zaman her elemi siler, Sadrettin Bey, sıkılmayınız. Size artık bir dargınlığım kalmadı ki, affedeyim. Yirmi beş sene... Fakat, haydi beni boşadınız, Almanya'da sevdiğiniz bir kadını üzerime aldınız, neyse... Fakat niçin bana iftira ettiniz? Biliyordunuz ki, ben gayet afifim. Niçin o iftirayı geveze bir romancıya anlatıp yazdırdınız? İşte bu yara hâlâ içimde sızlıyor.  
—  Ben... söyle... medim!  
— O halde, onun o kadar mübalâğaları yetmiyormuş gibi, keyfi için bana attığı iftiraya niçin "yalan" demediniz.  
Fon Sadriştayn heyecandan boğuluyordu:  
— Onu da affediniz!  
Diye kekeledi. Başka birşey söyleyemedi. Bu karanlıkta duramadı. Düşünemedi. Döndü. Kapıdan çıktı. Ürkmüş bir deli gibi kendisini bahçeye attı. Vaktiyle hakikatini inkâr ettiği bir mâbetten kovulan perişan bir dinsiz nedametiyle bu zümrüt yuvadan, milletin bu mukaddes kâbesinden hızla uzaklaştı.

Apartımanın kapısını açan Madam Sadriştayn haykırdı:  
— Hani bastonun?  
— ......  
Kocasının cevap vermediğini görünce hiddetlendi:  
— Kânun-ı sânîden beri dört bastondur kaybediyorsun. Bu dalgınlık değil, sersemlik!..  
— ......  
Fon Sadriştayn odasına doğru yürüdü.  
— Artık, yalnız çıkarken, eline baston almaktan seni men ederim!  
— ......  
Yine cevap vermedi. Koltuğuna çöktü. Yaşarmış gözlerini Çamlıca Tepesi'ne dikti. Sofadaki duvar saatinin tik takları, mutfakta kaynayan patates tenceresinin fıkırtısıyla karışarak kulakalrında büyüyor, müthiş bir gürültü gibi beyninin tâ içinde gümbürdüyordu.

# Forsa

Akdeniz'in, esâtir yuvası nihayetsiz ufuklarına bakan küçük tepe, mini mini bir çiçek ormanı gibiydi. İnce uzun dallı badem ağaçlarının alaca gölgeleri sahile inen keçi yoluna düşüyor, ilkbaharın tatlı rüzgarlarıyla sarhoş olan martılar, çılgın naralarıyla havayı çınlatıyorlardı. Badem bahçesinin yanı geniş bir bağdı. Beyaz taşlardan yapılmış kısa bir duvarın ötesindeki zeytinlik, ta vadiye kadar iniyordu. Bağın ortasındaki viran kulübenin kapısız medhalinden  bir ihtiyar çıktı. Saçı sakalı bembeyazdı. Kamburunu düzeltmek istiyormuş gibi gerindi. Elleri, ayakları titriyordu. Gök kadar boş, gök kadar sakin duran denize baktı, baktı. — Hayırdır inşallah! dedi. Duvarın dibindeki taş yığınlarına çöktü. Başını ellerinin arasına aldı. Sırtında yırtık bir çuval vardı. Çıplak ayakları topraktan yoğurulmuş sanılacaktı. Zayıf kolları kirli tunç rengindeydi. Tekrar başını kaldırdı. Gökle denizin birleştiği dumandan çizgiye dikkatle baktı. Fakat görünürde bir şey yoktu.

Bu, her gece uykusunda kendini kurtarmak için birçok gemilerin pupa yelken geldiğini gören zavallı eski bir Türk forsasıydı. Esir olalı kırk seneden ziyâde geçmişti. Otuz yaşında dinç, levent, kuvvetli bir kahramanken Malta korsanlarının eline düşmüştü. Yirmi sene onların kadırgalarında kürek çekti. Yirmi sene iki zincirle iki ayağından rutubetli bir geminin dibine bağlanmış yaşadı. Yirmi senenin yazları, kışları, rüzgârları, fırtınaları, güneşleri önün granit vücudunu eritemedi. Zincirleri küflendi, çürüdü, kırıldı. Yirmi sene içinde birkaç defa halkalarını, çivilerini değiştirdiler. Fakat onun çelikten daha sert adaleli bacaklarına bir şey olmadı. Yalnız abdest alamadığı için üzülürdü. Daima güneşin doğduğu tarafı sol ilerisine alır, gözlerini kıbleye çevirir, beş vaktini gizli gizli, işaretle edâ ederdi. Elli yaşına gelince, korsanlar onu, "Artık iyi kürek çekemez!" diye çıkarıp bir adada satmışlardı. Efendisi bir çiftçiydi. On sene kuru ekmekle onun yanında çalıştı. Allah'a çok şükrediyordu. Çünkü artık bacaklarından mıhlı değildi. Abdest alabiliyor, tam kıblenin karşısına geçiyor, unutmadığı âyetlerle namaz kılıyor, duâ edebiliyordu. Bütün ümidi memleketine, Edremit'e kavuşmaktı. Otuz sene içinde hiçbir an ümidini kesmedi. "Öldükten sonra dirileceğime nasıl inanıyorsam, elli yıl esirlikten sonra da memleketime kavuşacağıma öyle inanırım!" derdi. En şanlı, en meşhur Türk gemicilerindendi. Daha yirmi yaşındayken Tarık Boğazı'nı geçmiş, poyraza doğru haftalarca, aylarca, kenar, kıyı görmeden gitmiş, rast geldiği ücra adalardan cizyeler almış, irili ufaklı donanmaları tek başına hafif gemisiyle berbat etmişti. O vakitler Türkeli'nde namı dillere destandı. Padişah bile kendisini saraya çağırtmış, maceralarını dinlemişti. Çünkü Hızır Aleyhisselam'ın gittiği diyarları dolaşmıştı. Öyle denizlere gitmişti ki, üzerinde dağlardan, adalardan büyük buz parçaları yüzüyordu. Oraları tamamıyla başka bir cihandı. Altı ay gündüz, altı ay gece olurdu! Karısını, işte bu, senesi bir büyük günle bir büyük geceden ibaret olan  başka cihandan almıştı. Gemisi altın, gümüş, inci, elmas, esir dolu vatana dönerken, kenarsız denizin ortasında evlenmiş, oğlu Turgut, Çanakkale'yi geçerken doğmuştu. Şimdi kırkbeş yaşında olmalıydı. Acaba yaşıyor muydu? Hayalini unuttuğu, karlardan beyaz karısı acaba hâlâ sağ mıydı? Kırk senedir, yalnız taht şehrinin, İstanbul'un minareleri ufku, hayalinden hiç silinmemişti. "Bir gemim olsa gözümü kapar, Kabataş'ın önüne demir atarım" diye düşünürdü. Altmış yaşını geçtikten sonra efendisi, onu sözde âzâd etti. Bu âzâdetmek değil; sokağa, açlığa, perişanlığa atmaktı. İhtiyar esir, bu viran bağın içndeki harap kulübeyi buldu. İçine girdi. Kimse bir şey demedi. Ara sıra kasabaya iniyor, ihtiyarlığına acıyanların verdiği ekmek parçalarını toplayıp dönüyordu. On senes daha geçti. Artık hiç kuvveti kalmamıştı. Hem bağ sahibi de artık kendisini istemiyordu. Nereye gidecekti?

Fakat işte, eskiden beri gördüğü rüyaları yine görmeye başlamıştı. Kırk senelik  bir rüya... Türkler'in, Türk gemilerinin gelişi...

Gözlerini kadit elleriyle iyice ovdu. Denizin gökle birleştiği yere yine baktı. Evet, mutlaka geleceklerdi. Buna o kadar emindi ki... — Kırk sene görülen bir rüya yalan olamaz! Diyordu. Kulübe duvarının dibine uzandı. Yavaş yavaş gözlerini kapadı. İlkbahar bir umut tufanı gibi her tarafı parlatıyordu. Martıların: — Geliyorlar, geliyorlar, seni kurtarmaya geliyorlar! Gibi işittiği tatlı seslerini dinleye dinleye daldı. Duvar taşlarının arasından çıkan kertenkeleler üzerinde geziniyorlar, çuvaldan esvabının içine kaçıyorlar, gür beyaz sakalının üstünde oynaşıyorlardı. İhtiyar esir rüyasında, ağır bir Türk donanmasının limana girdiğini görüyordu. Kasabaya giden yola birkaç bölük asker çıkarmışlardı. Al bayrağı uzaktan tanıdı. Yatağanlar, kalkanlar güneşin aksiyle parlıyordu.

— Bizimkiler! Bizimkiler!  
Diye bağırarak uyandı. Doğruldu. Üstündeki kertenkeleler kaçıştılar. Limana baktı. Hakikaten kalenin karşısına bir donanama gelmişti. Kadırgaların, yelkenlerin, küreklerin biçimine dikkat etti. Sarardı. Gözlerini açtı. Kalbi hızla çarpmaya başladı. Ellerini göğsüne koydu. Bunlar Türk gemileriydi. Kenara yanaşıyorlardı. Gözlerine inanamadı. "Acaba rüyam devam mı ediyor?" şüphesine düştü. Fakat uyanıkken rüya görülür müydü? Kanaat getirmek için elini ısırdı. Yerden sivri bir taş parçası aldı. Alnına vurdu. Evet, işte hissediyordu. Uyanıktı. Gördüğü rüya değildi. O uyurken, donanma burnun arkasından birdenbire zuhur etmiş olacaktı. Sevinçten, hayretten dizlerinin bağı çözüldü. Hemen çöktü. Karaya çıkan bölükler, ellerinde al bayrak, kalenin etrafına doğru ilerliyorlardı. Kırk senelik bir beklemenin son azmiyle davrandı. Birden kemikleri çatırdadı. Badem ağaçlarının çiçekli gölgeleriyle örtülen yoldan yürüdü. Kenara doğru koştu. Koştu. Koştu. Karaya çıkan askerler, ak sakallı bir ihtiyarın kendilerine doğru koştuğunu görünce:  
— Dur!  
Diye bağırdılar. İhtiyar durmadı, bağırdı:  
— Ben Türk'üm, oğullar, ben Türk'üm.  
— ...  
Askerler onun yaklaşmasını beklediler. İhtiyar, Türkler'in yanına yaklaşınca önüne ilk geleni tutup öpmeye başladı. Gözlerinden yaşlar akıyordu. Haline bakanların hepsi müteessir olmuştu. Biraz heyecanı sükun bulunca ona sordular:

— Kaç yıldır tutsaksın?  
— Kırk!  
— Nerelisin?  
— Edremitli.  
— Adın ne?  
— Kara Memiş.  
— Kaptan mıydın?  
— Evet...  
İhtiyarın etrafındaki askerler birbirine karıştı. Bir çığlıktır koptu. "Bey'e haber verin!... Bey'e haber verin!" diye bağrışıyorlardı. İhtiyarın kollarına girdiler. Kuş gibi deniz kenarına uçurdular. Bir sandala koydular. Büyük bir kadırgaya çıkardılar. Askerin içinde onun menkıbelerini bilmeyen, şöhretini duymayan yoktu. Biraz güvertede durdu. Sevinçten kırk senedir hasret kaldığı millettaşlarını görmekten, şaşırmış, aptallaşmıştı. Ayağına bir çakşır geçirdiler. Sırtına bir kaftan attılar. Başına bir kavuk koydular.  
— Haydi, Bey'in yanına!  
Dediler. Kendini kadırgaya getiren askerlerle beraber büyük geminin kıçına doğru yürüdü. Kara palabıyıklı, sırmalı esvabının üzerine demir, çelik zırhlar giymiş, iri bir adamın karşısında durdu.  
— Sen kaptan Kara Memiş misin?  
— Evet! dedi.  
— Hızır Aleyhisselâm'in geçtiği yerlerden geçen sen misin?  
— Benim.  
— Doğru mu söylüyorsun?  
— Ne yalan söyleyeceğim?  
— Aç bakayım sağ kolunu!  
İhtiyar, kaftanın altından kolunu çıkardı. Sıvadı. Bey'e uzattı. Pazusunda haç şeklinde derin bir yara izi vardı. Bu yarayı, gecesi altı ay süren bir adadan karısını kaçırırken almıştı. Bey, ellerine sarıldı. Öpmeye başladı.  
— Ben senin oğlunum! dedi.  
— Turgut musun?  
— Evet  
— ...

İhtiyar esir sevincinden bayılmıştı. Kendine gelince oğlu, ona:  
— Ben karaya cenk için çıkıyorum. Sen gemide rahat kal, dedi.  
Eski kahraman kabul etmedi:  
— Hayır. Ben de beraber cenge çıkacağım.  
— Çok ihtiyarsın baba.  
— Fakat kalbim kuvvetlidir.  
— Rahat et! Bizi seyret!  
— Kırk yıldır dövüşü özledim.  
Oğlu:  
— Vurulursun! Vatana hasret gidersin!  
Diye onu gemide bırakmak istedi. Kara Memiş, o vakit birdenbire gençleşmiş bir kaplan gibi doğruldu. Duramıyordu. Kalkan, kılıç istedi. Sonra geminin kıçında sallanan sancağı göstererek:  
— Şehit olursam bunu üzerime örtün! Vatan al bayrağın dalgalandığı yer değil midir? dedi.  
. . . . . .
