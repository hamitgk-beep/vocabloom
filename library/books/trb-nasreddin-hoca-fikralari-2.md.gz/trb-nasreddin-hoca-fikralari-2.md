# Evlilik Hazırlığı

Hoca habire döşeme tahtalarını söküp tavana, tavan tahtalarını da söküp döşemeye çakıyormuş. Bunu gören komşular merakla olayın nedenini sormuşlar.

– Yakında evleneceğim, demiş Hoca. İnsan evlenince evin altı üstüne gelir derler ya, ben de bari şu tamirle iki masrafı bir edeyim dedim!

# Fincancı Katırları

Hoca bir gece mezarlıktan geçerken aniden ayağı kayar ve eski bir mezarın içine düşer. O anda aklına geceyi orada bir ölü gibi geçirerek yazıcı melekleri görme fikri gelir. Hemen yatar ve beklemeye başlar. Bir süre sonra mezarlığa yaklaşmakta olan fincancı kervanından yükselen katırların çan sesleri, katırcıların konuşmaları, homurtular derken iyice yaklaşan seslerden korkan Hoca kıyamet vakti geldi sanarak dışarıda ne olduğunu görmek için mezardan dışarı çıkınca, bir anda yarı çıplak Hoca'yı gören katırlar ürker. Hortlak görmüş gibi her biri bir tarafa kaçışan katırlar bütün yükleri yerlere yuvarlar, fincanları zayi ederler. Bunun üzerine sinirlenen fincancılar koşup Hoca'yı yakalarlar:

– Be adam gecenin bir vakti ne yapıyorsun burada? derler. Hoca korkudan kekeleyerek:

– Be be ben öbür dünyadan geldim. Bir bakayım burada işler nasıl gidiyor, deyince adamlar Hoca'yı bir güzel pataklarlar.

Bin perişan eve dönen Hoca'yı telaşlı karısı karşılar:

– Eee, anlat bakalım ne bu halin? Öbür dünya nasıl? Ne var? Hoca biraz vakurlu biraz üzgün:

– Hiç bir şey. Ta ki fincancı katırlarını ürkütene kadar.

# Geç Yiğidim

Hoca, Akşehir'de bir akşam evine dönerken karşıdan iri yarı bir köpeğin geldiğini görür. Köpek bir an durur ve hemen köşe başındaki mezarlıktaki bir mezar taşına işemeye başlar. Hoca, korkutmak için köpeğe hoşt der ama ne çare ki, köpek cevap olarak kocaman dişlerini göstererek Hoca'ya hırlar. Hoca ister ki, köpek kaçsın veya kenara çekilsin ama hayvan üstüne üstüne gelmektedir. Hoca bakar ki iş kötü, hemen kenara çekilir ve hafifçe eğilerek köpeğe döner:

– Geç yiğidim geç!

# Göle Maya Çalmak

Bazı insanlar olması güç istekleri uğruna zamanlarını harcarlar. Nasreddin Hoca da bu konuda nasihat verebilmek için göl kenarına yoğurt mayasıyla gitmiş. Eline kaşığı almış ve başlamış mayayı göle dökmeye. Hoca'yı görenler, "Hoca, sen ne yapıyorsun?" demişler hayret içinde. Hoca bir göle bakmış, bir şaşkınlıkla kendisini izleyenlere ve gülerek "Göle yoğurt mayası çalıyorum," demiş. Birisi Hoca'nın yanına yaklaşıp "Olur mu, göl yoğurt mayası tutar mı hiç?" deyince Nasreddin Hoca cevaplamış, "Ya tutarsa?"

# Gönlüm Razı Olmadı

Nasreddin Hoca, kasabadan Kur’an-ı Kerim, tefsir ve ilmihal gibi bazı kitaplar almış. Bir çuvala yerleştirmiş. Çuvalı sırtına almış, eşeğine binmiş düşmüş köyün yoluna.

Yolda Hoca'yı görenler :

- “ Bre Hoca, çuvalı niye kendi sırtına aldın ?”

diye sormuşlar.

- “Ne yaparsın” demiş Hoca, “Zavallı hayvan zaten benim bütün kahrımı çekiyor. Kendi bindiğim yetmiyormuş gibi çuvalı da ona taşıtmaya gönlüm razı olmadı.”

# Görev Ayrımı

Hocanın evinde, bir gün kaza ile yangın çıkar. Komşuları koşup Hoca’yı bulurlar.

– Efendi, evin yanıyor, derler.

Hoca umursamaz bir tavır takınarak:

–Vallahi komşular, der. O benim sorumluluğumda değil. Biz hatunla işleri aramızda taksim ettik. Ben evin dışında olup bitenlerle meşgul olurum. Hatun da evin içişlerine bakar. Varın, siz yangın haberini, bizim hatuna yetiştirin!

# Gülmez Sultan

Nasreddin Hoca'nın karısı, hep asık suratlıymış. Gülmek nedir hiç bilmezmiş. Hoca pek çok kere ona bu sevimsiz huyunu terk etmesi için ricada bulunmuş, ama bir türlü yüzünü güler hale getirememiş. Bir akşam yorgunluktan bitkin bir halde eve dönen Hoca, kapıyı çalmış. Karısı her zamanki gibi asık suratla onu karşılamış.

Nasreddin Hoca:

– Nedir bu suratın? Yüzünden düşen bin parça oluyor. Bu gülmez sultanlıktan ne zaman vazgeçeceksin, diye karısına söylenmeye başlamış.

Kadın kendine bir bahane bulmak için:

– Komşularımızdan bir kadın öldü de, ailesine başsağlığı dilemeye gittim. Cenaze evinden gelen kimse gülmez ki, demiş.

Hoca bu bahanenin geçersiz olduğunu şu sözlerle ifade etmiş:

– Haydi, haydi! Ben senin düğün evinden geldiğin zamanı da bilirim.

# Günahı Affettirmek

Nasreddin Hoca'nın çirkin bir hanımı varmış. Bir akşamüzeri Nasreddin Hoca saatlerce gözünü ayırmadan hanımını seyretmiş. Bu olaya şaşıran hanımı kocasına bakarak:

–Ne oldu, niye beni böyle seyrediyorsun, demiş.

–Ben güzel bir kadın gördüm ve gözümü ayırmadan saatlerce onu seyrettim; birkaç defa kendimi zorlayarak bakmamak istedim, olamadı. Şimdi de yaptığım günahı affettirmek için kaç saat ona baktıysam o kadar da sana gözümü ayırmadan bakacağım, demiş.

# Güneş mi Daha Faydalıdır Yoksa Ay mı?

Hocaya bir gün:

— Güneş mi daha faydalıdır, yoksa Ay mı? diye sorarlar.

Nasreddin Hoca hiç düşünmeden cevap verir:

— Ay daha faydalıdır.  
— Neden Hocam?  
— Efendim, mâlûm ya, Güneş gündüzleri doğar. Ay ise, geceleri çıktığı için ortalığı nura boğar. Elbette Ay daha faydalıdır!

# Güvercin Erkek miydi, Dişi mi

Nasreddin Hoca, vaizliği sırasında bir gün Nuh Peygamber kıssasını anlatıyormuş. Cemaat de kendisini can kulağıyla dinliyormuş. Nihayet kıssanın son kısmına gelinmiş. Nuh Peygamberin, tufandan sonra sular çekilirken bir güvercini salıverdiğini ve güvercinin ağzında bir otla döndüğünü, böylece artık karanın yakın bulunduğunun anlaşıldığını nakletmiş. Cemaat arasında bulunan geveze bir kadın, beklenmedik bir soru sormuş:

– Hoca efendi, Nuh Peygamberin salıverdiği bu güvercin, erkek miydi, dişi miydi, demiş.

Nasreddin Hoca, bir süre düşündükten sonra, sorunun cevabını hemen bulmuş:

– Erkek idi, demiş.

– Nereden bildin? Kitapta yeri mi var?

– Hayır! Kitaplarda bu yolda bir kayıt yok. Ama insanda akıl var. Hiç Nuh Peygamberin salıverdiği güvercin dişi olsaydı, çenesini o kadar müddet kapalı tutabilir miydi? Taşıdığı otu, gemiye getirmeden yolda çoktan düşürürdü.

# Hak Etmiş

Hoca su içmek için bir çeşmenin başına gelir fakat bakar ki, çeşmenin ağzı bir ağaç parçasının ucuna bez sarılarak kapatılmış. Ayağını çeşmenin duvarına yaslayıp şöyle bir asılınca tıkacın yerinden çıkmasıyla birlikte çeşmeden fışkıran su Hoca'yı baştan aşağı ıslatır. Homurdanarak yerinden kalkan Hoca:

– Belli ki hak etmişsin de ağzına böyle ot tıkamışlar.

# Hakikat Nerede?

Günlerden bir gün Hoca’ya:

–Hoca, hakikat nerede, diye sormuşlar.

Hoca:

–Ben onun nerede olduğunu bulurum, ama hakikatin olduğu yer mi var, diye cevap vermiş.

# Halep Oradaysa Arşın Burada

Palavracının biri başına topladığı üç beş cahile karşı övünüp duruyormuş :

- İşte ben güçlü ve maharetli bir adamım. Evet ben Halep'te bulunduğum sıralarda altmış arşın uzağa atlamış bir kimseyim!.. Nasreddin Hoca da bu sırada oradan geçiyormuş. Palavracının yanına yaklaşıp :

- Yaa demiş demek sen altmış arşın atlarsın. Haydi atla da görelim. Adam hık mık etmiş.

- Ama demiş ben Halep'te atladım. Hoca kızmış :

- Canım demiş, Halep oradaysa arşın burada.

# Hamallığını Kendi Çeker

Bir gün Hoca’ya sorarlar: “Zekeri büyük olan kimsenin cima vaktinde safası var mıdır.” diye. Hoca da:

– Hamallığını kendisi çeker ama zevkini eller sürer, demiş.

# Hangisi?

Hoca'nın bir zamanlar iki karısı vardır. Bunlardan biri yaşlı diğeri genç ve güzeldir. Bunlar bir gün Hoca'ya beklenmeyen bir soru sorarlar:

– Akşehir gölünde kayığımız devrilse hangimizi kurtarırsın?

Hoca cevap vermeden kurtulamayacağını anlayınca, yaşlı karısına döner ve şöyle der:

– Hanım sen biraz yüzme biliyordun galiba?

# Hazır Cevap

Nasreddin çölden eşekle geliyormuş ve devamlı eşeğini dövüyormuş. Onunla karşılaşan birisi ona:

–Siz ne biçim insansınız! Dilsiz, ağızsız, konuşmayı bilmeyen hayvanı niye böyle dövüyorsunuz, demiş.

–Özür dilerim, ben ne bileyim onun sizin gibi akrabasının olduğunu.

# Hepsini

Zengin bir adam Hoca'yla alay etmek için:

– Hocam sen bu kitapların hepsini okuyor musun gerçekten? der.

Hoca:

– Senin kaç evin ve koyunun var, diye sorunca, adam:

– O kadar çok ki, sayısını ben bile bilmiyorum, deyince Hoca, cevabı yapıştırır:

– Sen o evlerin hepsinde yaşayıp koyunların hepsini de yiyor musun!

# Hepsinin Tadı Aynı

Hoca, eşeğine iki küfe üzüm yüklemiş, evine götürüyormuş. Şehre girince çocuklar başına üşüşüp:

– Hocam, bize birer salkım üzüm ver, demişler. Hoca, çocukların çokluğunu görünce her birine üçer beşer üzüm vermiş.

– Hocam, bu kadar az verilir mi, diye sormuşlar.

Hoca demiş ki:

– Çocuklar, küfelerdeki bütün üzümlerin tadı da, bir tanesinin tadı da aynı. Az yemekle çok yemek arasında bir fark yok ki!

# Herkesi Memnun Edemezsin

Hoca merhum, oğlu ile bir köye gidiyormuş. Oğlunu eşeğe bindirmiş. Bazı kimseler görüp:

— Hey gidi zamane gençleri, ağzının ilmiyle şu ihtiyar babasını yayan yürütüyor da kendisi rahat rahat eşeğe binip gidiyor, demişler.

Çocuk:

— Bak baba! sana ısrar etmedim mi? Haydi artık daha ziyade inat etme, şu eşeğe bin, demiş.

Hoca eşeğe binmiş. Biraz gitmişler. Bir kaç kişi tesadüf edip:

— Ayol senin kemiğin kartlaşmış, hem işte geldin işte gidiyorsun. Bu taze fidanı bu kadar zahmete koşup da kavurmak layık mı? derler.

Hoca tutar, çocuğu da arkasına bindirir. Birkaç adım gider gitmez, bir bölük herze-vekile daha tesadüf ederler. Bunlar da bakıp:

— Amma insafsızlık ha! Bir eşekçiğe iki kişi birden biner de uzun yola gider mi? Bakın şu herife, hoca da olacak! derler.

Hoca artık kızıp eşekten kendi de oğlu da inerler. Önlerine katarlar. Çok geçmez bittesadüf birkaç adama rast gelirler.

— Allah Allah! Bu ne budalalık. Eşek önlerinde bomboş hoplaya sıçraya koşsun da kendileri bu sıcakta toza toprağa bulanarak kan ter içinde yayan yürüsünler. Dünyada ne şaşkın adamlar var!

Dediklerini işitince Hoca oğluna dönerek demiş ki:

— Lakin yahu! Bu halkın dilinden kurtulabilen varsa ona aşkolsun. Ne yaparsan yap, herkesi memnun edemezsin. Sen yalnızca Allah'ı memnun etmeye bak.

# Hisseli Mal

Nasreddin Hoca'nın Akşehir'de yarı hissesi kendine ait ortak bir evi varmış. Bir gün bu yarım hisseyi satılığa çıkarmış.

Emlakçı:

– Hocam, acelen ne idi? İleride daha yüksek fiyata satardın, deyince:

– Ben hisseli malı sevmem, demiş Nasreddin Hoca. On seneden beri ortağımın gönlünü yapmaya çalışıyordum. Nihayet satmaya bugün razı edebildim.

# Hiç Hakkı

Nasreddin Hoca'ya kadılığı sırasında bir adam başvurmuş. Yanında da kılıksız bir hamal varmış.

– Bu adamdan davacıyım Kadı Efendi, demiş. Hakkımı vermiyor bana!

– Ne hakkın var onda?

Adam anlatmış:

– Bu hamal odun yüklemiş gidiyordu. Bir ara ayağı kaydı. Odunlar sırtından yere döküldü. Benden odunları sırtına yüklemem için yardım istedi. Ben de zahmetime karşılık bana ne vereceğini sordum. “Hiç!” dedi. İstediğini yaptım. O da odunları götüreceği yere götürdü, ücretini aldı. Ben kendisinden bana vaatte bulunduğu “hiç”i vermesini istiyorum, o ise oralı bile olmuyor. Hakkımı versin!

Nasreddin Hoca:

– Haklısın, demiş. Şöyle yanıma yaklaş! Davacı sevinerek Hoca'ya yaklaşmış. Nasreddin Hoca, oturduğu pöstekinin bir ucunu tutarak kaldırmış. Ve adama sormuş:

– Orada ne görüyorsun?

Adam:

– Hiç! diye cevap vermiş.

– Güzel, demiş Nasreddin Hoca. Al o “hiç”i de buradan hemen uzaklaşmaya bak! Hakkın kalmasın!

# Hoca Kabaktan Bıkınca

Nasreddin Hoca, bir Ramazanda civar köylerden birine gitmiş. Daha ilk gün, vaaz sırasında kabaktan “cennet yemeğidir” diye bahsetmiş. Mevsim de kabak mevsimi olduğundan köylüler artık Hoca’ya her akşam kabak yemeği göndermeye başlamışlar. Bir gün, iki gün, beş gün, yedi gün derken, Hoca’ya kabak yemekten bıkkınlık gelmiş. Köylüye kabağın cennet yiyeceği olduğunu söylediğine bin defa pişman olmuş. Ama ok bir defa yaydan çıkmış olduğu için, yapacak bir şey de yokmuş. Canı da müthiş tavuk istiyormuş. Nihayet, bir ikindi vakti vaaza başlayınca, sözü döndürüp dolaştırıp yine yemek bahsine getirmiş. Kabağın cennet yiyeceği olduğunu tekrarlamış. Ancak arkasından da:

– Sizin şu fukara hocaya, her gün cennet yiyeceğini layık görmeniz, onu gurura sevk edebilir. Onun için, arada bir ayağı çamurlu bir tavuk da gönderirseniz, tevazu yönünden daha uygun olur! deyivermiş.

# Hoca Üzerine Ne Aldı?

Nasreddin Hoca ile bir grup arkadaşı kırda piknik yapmaya karar verirler. Herkes sıra ile bir şeyler hazırlamayı üzerine alır.

Biri:

– Kuzu dolması benim üzerime olsun, der.

İkincisi:

– Börek benim üzerime olsun, der.

Üçüncüsü:

– Yenecek yemişler benim üzerime olsun, der.

Böylece her biri, bir şeyi üzerine alırken, bakarlar ki Nasreddin Hoca hiç oralı olmuyor. Sadece ağzını iştahla şapırdatıp duruyor. İçlerinden biri dayanamayıp sorar:

– Bre Hoca!.. Herkes üzerine bir şey aldı. Sen ise ağzını açmıyorsun. Böyle şey olmaz, sen de üzerine bir şey almalısın.

Hoca bu ısrarlı istek karşısında, üzerine alacağı şeyi şu şekilde açıklar:

– Hepiniz üzerinize bir şeyler aldınız. Bu kır sıvışmaya gelmez, bol bol yiyip içmezsem; Allah'ın ve Peygamber'in bütün laneti de benim üzerime olsun! der.

# Hoca'nın Küpü

Nasreddin Hoca, evindeki çatlak küpü pazara götürüp satışa çıkarmış. Küpün çatlak olduğunu gören aşçılar:

– Bu küp çatlak Hoca, işe yaramaz, içindekini dışarı döker, demişler.

– Allah Allah, demiş Hoca. Anlaşılan sizin almaya niyetiniz yok. Bari kimsenin malını açık açık kötülemeyin. Bunun içindeki pamuğu karım az önce boşalttı. Bir parçası bile dökülmemişti.

# Hoca'nın Kılıcı

Nasreddin Hoca zamanında, Akşehir´de silah taşıma yasağı ilan edilmiş. Hoca da bir kılıç kuşanıp, sokağa çıkmış. Bu işin kontrolü ile vazifeli memur, onu bu şekilde görünce yanına yaklaşıp:

— "Neden böyle kılıçla dolaşıyorsun?"

diye sormuş.Hoca:

— "Bu kılıç, medresede, kitaplardaki yazı hatalarını düzeltmeye yarar"

cevabını verince, memur alaylı alaylı:

— "O işi küçük bir çakı da görür, bu biraz büyük değil mi?"

demiş. Bunun üzerine Hoca:

— "Efendi efendi!" sen ne diyorsun, bazan öyle büyük hatalar oluyor ki, bu bile küçük geliyor"

cevabını vermiştir.

Tabii ki Nasreddin Hoca böyle söylemekle, ilmin ve ilim ehlinin önemini dile getirip, eğer ilim ehli doğruyu öğrenmez ve öğretmezse, cemiyetin karışacağını, hatta bu sebeple savaş bile çıkacağını bildirmiştir.

# Hoca'nın Oğlunun Zekası

Hoca bir gün, oğlunun zekâsını ölçmek için onu küçük bir sınavdan geçirmeye karar vermiş. Çağırmış yanına:

– Al şu on akçeyi, bana bakkaldan bir minare al da gel, demiş.

Oğlan parayı almış, dışarı çıkmış. Önüne gelen ilk arkadaşına dert yanmış:

– Şu babamın yaptığı işe bak sen. Bana on akçe verdi, “Git bakkaldan minare al!” dedi.

Arkadaşı:

– Eee, demiş, sen ne yaptın?

– Eee'si me'si mi var. Ne yapayım yani! Bugün tatil günü değil mi? Bakkallar kapalı!

# Hoca'nın Tehdidi

Hoca büyük bir açlık hissetmeye başladığı anda uzak bir köye gelir. Oraya vardıktan sonra bütün çiftçileri muhtarın yanına çağırttırır ve kızgınlıkla şöyle der:

– Ben köyünüzde kaldığım müddetçe bana yeterince yemek vereceksiniz. Aksi halde gittiğim son köyde beni aç bıraktıklarında onlara yaptığımın aynısını size de yaparım! Onu büyük bir büyücü sandıklarından önce korkarlar. Bundan dolayı da istediği kadar ona yemek verirler. Birkaç gün sonra tekrar yola koyulmak istediğinde köydeki meraklının biri sorar:

– Eğer size yiyecek bir şey vermeseydik ne yapardınız?

Hoca o zaman gülerek cevap verir:

– O zaman aç olarak yoluma devam ederdim. Son gittiğim köyde de aynı şeyi yapmıştım.

# Işığı Gören Dışarı Çıkıyor

Hoca'nın karısı hamileymiş. Bir gece ansızın ağrısı tutmuş. Hoca hemen ebeye koşmuş. Ebe gelmiş, komşu kadınlar da toplanmışlar. Hoca'nın karısı biraz sonra nur topu gibi bir oğlan doğurmuş. Hoca'yı çağırıp kucağına vermişler. Hoca çok memnun olmuş. Bu sırada kadının ağrıları yeniden tutmaya başlamış. Ebe:

– İkiz galiba, demiş.

Derhal gereken önlemleri alıp Hoca'ya da bir mum vermişler. Az sonra bir kız dünyaya gelmiş.

Hoca:

– Kız çocuğu, annesine yoldaş olur, demiş.

Hoca'nın karısının ağrıları kesilmiyormuş. Aman demeye kalmadan, bir oğlan daha dünyaya getirmiş. Hoca, çocukların arka arkaya geldiklerini görünce, derhal üfleyerek mumu söndürmüş. Kadınlar şaşırmışlar. Hayretle Hoca'ya:

– Ne yaptın Hoca Efendi? Böyle zamanda mum söndürülür mü, demişler.

Hoca:

– Ne yapayım? Işığı gören dışarı çıkıyor, cevabını vermiş.

# Kadınların Dedikodusu

Bir vakit Hoca hastalanır. Komşu kadınları işitip hatır sormağa gelirler. Hoca'yı iyi bulup kadınlardan biri latife kasdıyla:

— Efendi, Allah gecinden versin, şayet sana bir emr-i hak vaki olursa ne diyerek yas tutalım?

Diye sorunca Hoca o halinde de latifeleşmekten vazgeçmeyip:

— Kadınların sohbetine doymazdı diye ağlayınız, diyerek kadınları güldürmüştür.

# Karanlıkta Sağ Sol Nasıl Fark Edilir?

Nasreddin Hoca ile karısı bir gece yarısı uyanırlar. Ortalık zifiri karanlıktır. O tarihlerde geceleri ışık meselesi ya çıra, yahut da mumla halledilmektedir.

Karısı:

–Efendi, şu mumu yakıver! der.

Hoca:

– Mum neredeki, diye sorar.

– Sağ tarafında olacak.

Hoca cevap verir:

– Aman hatun! Bu zifiri karanlıkta sağımı solumu nereden bileceğim?

# Karının Malıdır

Nasreddin Hoca su dökerken zekerine arı sokar. Hoca arıya bakarak söylenir:

– İyi buldun bal alacak çiçeği, der. Durma hemen kaç, zira karının malıdır, senin ile kavga eder, demiş.

# Kaz Gibi

Hoca, abdest alırken suyu bitmiş. Bunun için tek ayağını yıkayamamış. Namaz esnasında tek ayağı üzerinde duruyormuş.

– Hoca, neden tek ayak üzerinde duruyorsun, diye sormuşlar.

Hoca şöyle cevap vermiş:

– Bu ayak abdestli değildir.

# Kazan Doğurdu

Bir gün Hoca, komşusundan bir kazan ister, işini bitirince kazanın içine küçük bir tencere koyup iade eder. Kazan sahibi tencereyi görünce:

– Bu nedir, diye sorar.

Hoca cevap verir:

– Müjde! Kazanınız doğurdu.

Bu haber komşusunun hoşuna gider.

– "Pekâlâ!" diyerek tencereyi kabullenir.

Hoca yine bir gün komşusundan kazanı ister. Alır ama bu sefer iade etmez. Sahibi bir süre bekler. Kazanın gelmediğini görünce, Hocanın evine gelir, kazanı geri ister. Hoca üzüntülü bir çehre ile:

– Sizlere ömür, kazan öldü! der.

Komşu hayretle:

– Aman Hocam, hiç kazan ölür mü, deyince, Hoca'nın cevabı hazırdır:

– Kazanın doğurduğuna inanırsın da, öldüğüne niçin inanmazsın?

# Kemiklerinden Dirilen Kurban

Hocalarının üç öğrencisine ziyafet için kullandığı bir kuzu varmış. Yemekten sonra, kuzunun bütün kemikleri biraraya getirilir ve hocaları el açıp dua edince, yine dirilirmiş. Hocalarının olmadığı bir gün, üç arkadaş kuzuyu gizlice dere kenarına getirip kesmiş. Kemikleri toplamışlar ve dua etmişler, kuzu dirilmiş. Ancak, muzip Nasreddin bir kemiği saklamış ve bu yüzden de kuzu aksayarak yürümeye başlamış. Derler ki, Hocası, Nasreddin'e "Dünya durdukça insanlar da sana hep böyle gülsün." diye dua etmiş.

# Kendi Öldü Kendi Haber Verdi

Evvela Hüseyin Çelebi der ki: Nasreddin Hoca hikâyetidir ki meğer (Hoca) meger (ve) vehimden olmuş bir sahrada yitmiş kimesne gelip kaldırmamış, ahi acıkur, varır hatunına kendi kande ve ne yerde olduğun ve öldüğün beyan eder. Hatunu ehli mahalleye "Hoca öldü, gelin varalım getürelim." der. Halk der ki: "Kim geldi haber getüdi?" diyecek hatuni der ki: "Garip Hoca'nın kimi var? Öz kendi öldi ve kendi haber verdi, yine gitti. Pes bizim gibi fakirlerin kimi ola?"

# Kenefte Sakız Çiğnemek

Hoca'ya birisi şaka olsun diye:

– Hoca, demiş, ben kenefte bile sakız çiğnerim, Bunun kitapta yeri var mı?

Hoca, bu adamı bozmamak için:

– Bak oğlum, demiş, bunu bir daha yapma.

Fakat adam:

– Anladık Hoca da, sen bunun yerini kitap da gördün mü görmedin mi, diye yılışınca, Hoca:

– Hayır oğlum, demiş, ben görmediğim şeyi gördüm diyemem. Ama seni öyle keneften sakız çiğneyerek çıkarken görenler, oraya ettiğin şeyi yediğini zannederler.

# Kibir

Adamın biri, Hocam senin evliyalar katında ulu bir kişi olduğun söylenir aslı var mıdır, diye sorar.

Hoca'nın böyle bir iddiası elbette yoktur, ama bir kere soruldu ya.

– Her halde öyle olmalı, der.

Çevresindekiler hemen:

– O zaman göster bakalım kerametini, derler.

Hoca:

– Ey ulu çınar çabuk yanıma gel, der. Der ama tabii ne gelen ağaç var ne giden. Hoca kendisi ağacın yanına gider.

Orada bulunanlar:

– Ne oldu Hoca, ağacı getiremedin, kendin oraya gittin, derler ve gülerler.

Hoca:

– Bizde kibir yoktur, dağ yürümezse kul yürür, der.

# Kilim

Hoca, bir köye konuk olmuş. Birkaç gün sonra Hoca'nın heybesi kaybolmuş.

Hoca, köy ağalarına:

– Bana bakın, demiş, heybemi bulursanız bulun, yoksa ben yapacağımı bilirim!

Ağaları bir telaştır almış, köylüleri sıkıştırmışlar, nihayet heybe bulunmuş. Ağalardan biri merak edip:

– Hocam, demiş, heybe bulunmasaydı ne yapacaktın bize?

Hoca cevap vermiş:

– Size yapacağım bir şey yoktu. Evde eski bir kilim vardı, onu bozup heybe yapacaktım.

# Kim Daha Büyük?

Hoca’ya, "Efendi, padişah mı büyük yoksa çiftçi mi?" demişler.

Hoca:

“Çiftçi büyük elbet” demiş ve eklemiş;

“Çünkü çiftçi buğday yetiştirip vermezse pâdişah acından ölür.”

# Kim Haber Verdi?

Nasreddin Hoca merhum, bir gün pazardan bir okka şeftali almış, ceplerine doldurmuş. Mahalle çocuklarının cıvıl cıvıl oynaştıkları bir arsanın önünden geçerken onları yanına çağırmış:

– Çocuklar, demiş, şu iki cebimdeki meyvelerin ne olduğunu ilk bilene, şeftalinin en büyüğünü vereceğim. Bilin bakalım cebimde hangi meyve var?

Çocuklar hep birden:

– Şeftali! diye bağırmışlar. Hoca bu cevaba pek şaşırmış:

– Vay canına, demiş. Acaba bunu size hangi boşboğaz haber verdi?

Daha sonra da ceplerindeki bütün şeftalileri çocuklara dağıtmış.

# Kim Tuhaf?

Hoca, bir gün yolda giderken, birisi ona gülünç bir soru sormuş:

– Hoca, senden önce ve senden sonra evlenenleri tuhaf bulmuyor musun?

– Her ikisini de tuhaf buluyorum, demiş Hoca.

– Neden böyle, diye bir daha sormuş arkadaşı.

– Neden mi? Benden önce evlenenlere, bana hiç öğüt vermedikleri için kızıyorum. Benden sonra evlenenler de, onlara hiç öğüt vermediğim için, bana kızıyorlar.

# Kime Görüneyim?

Hoca evlendiği ilk gece karısının yüzünü ilk kez görünce, felaket derecede çirkin olduğunu fark eder. Fakat olan olmuştur. Ertesi sabah, kadın nazlanarak Hoca'ya sorar:

– Kocacığım, kime görüneyim, kime görünmeyeyim? Bu konuda bana bir şey söylemedin.

Bu soru, Hoca'nın bütün sabrını bitirir. Hoca cevap verir:

– Bana görünme de, kime görünürsen görün!

# Kimi Kimden Sorarsınız

Hoca'nın karısı ölür. Cenazesinin evden çıkarılacağı sırada imam, usule uyarak cemaate hitaben sorar:

– Merhumeyi nasıl bilirsiniz? Herkes beraberce:

– İyi biliriz! der denmez koşa koşa imamın yanına gelen Hoca:

– Aman, aman! Sen onu benden sor; kimi kimden soruyorsun!

# Kör Dövüşü

Nasreddin Hoca çocukluğunda çok haşarı ve şakacıymış. Bir gün birkaç kör, bir kahvenin önünde oturuyorlarmış. Küçük Nasreddin de çarşıya gitmek için oradan geçiyormuş. Elindeki para kesesini körlerin kulakları dibinde şangır şungur şakırdatarak:

– Alın şu paraları da, aranızda paylaşın, demiş. Fakat kimseye hiçbir şey vermeden uzakta bir köşeye çekilmiş, olacakları seyre başlamış. Körler: “Sana verdi, yok bana vermedi” diyerek birbirlerine düşmüşler, yaka paça kavgaya tutuşmuşlar. Ortalık iyice karışmış.

Küçük Nasreddin, karşıdan olanları seyredip şöyle söylüyormuş:

– İşte kör dövüşü buna derler

# Kırk Yıllık Sirke

Bir gün, kapı komşusu Nasreddin Hoca'ya:

– Hocam, sizde kırk yıllık sirke var mı? Hastamıza ilaç için lazım oldu da, der.

Hoca:

– Var, ama veremem! diye cevap verir.

Komşu:

– Canım Hoca, bir parça versen ne olur, diye rica eder.

Hoca yine:

– Veremem, deyince bu sefer sebebini sorar.

Hoca şu açıklamayı yapar:

– Eğer şuna buna dağıtsaydım, evde hiç kırk yıldan beri sirke kalır mıydı!

# Lütfun da Hoş Kahrın da

Günün birinde uzun bir yolculuktan dönen Hoca, güneş altında koşmaktan yorulur ve dua etmeye başlar.

– Aman Allah'ım çok yoruldum, daha fazla yürüyemiyorum. Lütfen bana bir eşek gönder. Kısa bir zaman sonra Hoca yanında eşek de taşıyan bir atlı genç görür. Buna çok sevinir.

Atlı yaklaşınca Hoca'yı görür ve ona şöyle der:

– Sen tembel adam! Niçin burada oturuyorsun? Bak benim eşek yolculuktan ve sıcaktan bitkinleşti. Buraya gel ve onu bir sonraki şehre kadar taşı!

Önce Hoca itiraz etmek ister, fakat genç adamın kendisini döveceğini hissedince korkar.

Böylece Hoca eşeği bir sonraki şehre kadar taşımaya razı olur. Yorucu birkaç saatten sonra şehre varırlar.

Genç adam Hoca'yı dışarıda bırakarak hana girer. Bunu gören Hoca yorgunluktan yere yığılır ve şöyle dua eder:

– Oh, aman Allah'ım, artık çok şey öğrendim. Bundan sonra dualarımda dikkatli olacağım.

# Mavi Boncuk

Nasreddin Hoca'nın iki tane hanımı varmış. Bunlara değişik zamanlarda birer mavi boncuk vererek kesinlikle diğer eşine veya başka bir kimseye göstermemesini tembih etmiş. Bir gün hanımlar Hoca'nın yanına gelerek sormuş:

– Hocam hangimizi daha çok seviyorsun?

Hoca hemen işi bağlamış:

– Sadece mavi boncuk verdiğimi daha çok seviyorum.

# Minare Nasıl Yapılır?

Nasreddin Hoca, Konya'ya giderken yolda bir köylüsüyle karşılaşır. Selamlaşırlar, birlikte yol almaya başlarlar. Köylü o güne kadar hiç minare görmemiştir. Konya'ya yaklaşırlarken, minareleri görür ve nasıl yapıldıklarına bir türlü akıl erdiremez. Hoca'ya sorar:

– Hoca Efendi, şu sivri sivri yüksek şeyleri nasıl yaparlar?

Hoca gülerek cevap verir:

– Bunu bilmeyecek ne var? Kuyuların içini dışına çevirirler, olur biter.

# Nasıl

Hoca bir gün karısının bilgisini denemek amacıyla sorar:

– Karıcığım, ölü bir adamın, ölmüş olduğunu nasıl anlarsın?

Karısı şu cevabı vermiş:

– Kendisine sorarım.

# Nerede Kadı Yoksa

Günlerden bir gün Nasreddin Hoca'ya sormuşlar, “Efendi cehenneme mi girsek daha iyi; yoksa cennete mi?”

Nasreddin Hoca cevap vermiş:

– Nerede kadı yoksa oraya girin.

# Neuzü Billah

Timurlenk, bir gün Hoca'ya sormuş:

– Hoca, bilirsin ki Abbasi halifelerinden her birinin unvanı Muvaffak Billah, Mütevekkil Alallah gibi şeylerdir. Ben de onların arasında olsaydım, unvanım ne olurdu?

Hoca, derhal şu cevabı vermiş:

–Hiç şüphe yok, sizinki de Neuzü billah olurdu.

# Niçin Helva Yapmazsın?

Akşehir’in çarşısında dolaşırken, Hoca’nın canı helva çekmiş. Canı çekmiş çekmesine de, ne yapsın, cepte metelik yok. İlk dükkâna girip sormuş:  
– Un var mı?  
– Var.  
– Şeker?  
– Var!  
– Yağ?  
– O da var.  
– Eee, mübarek, niçin duruyorsun, helva yapsana!

# O Dua Sizde, Bu Akıl Bizde İken

Nasreddin Hoca bir gece, damda bir hırsızın gezindiğini hisseder. Sesini yükselterek karısına şu sözleri söyler:

– Hatun! Geçen gece geldim. Kapıyı çaldım, duymadın. Ben de şu duayı okudum ve ayın ışığına yapışıp eve girdim!

Bacadan konuşmaları dinlemekte olan hırsız, hocanın okuduğu duayı hemen ezberler. Sonra duayı okur, iki eliyle ayın ışığına sarılıp yavaşça ineceği zannıyla kendini damdan aşağıya bırakıverir. Büyük bir gürültüyle yere çakılır. Hoca hemen koşup hırsızın yakasına yapışır.

– Hanım, çabuk mumu getir, hırsızı yakaladım! diye hanımını da yardıma çağırır.

Acıdan inlemekte olan hırsız ise, şöyle sızlanır:

– Hocam acele etme. O dua sizde, bu akıl bizde iken öyle kolay kolay elinizden kurtulamayız.

# O Kadar İnce Eleyip Sık Dokumayın

Nasreddin Hoca bir gün evini tamire koyulur. Tamir bitince, evin önünde bir hayli moloz yığılır. Halk sokaktan gelip geçerken rahatsız olurlar. Hoca'ya, bunu kaldırmasını söylerler.

O da kazma küreği alarak moloz yığınının yanında bir çukur kazmaya başlar. Dostlarından biri, bunu görünce:

– Ne yapıyorsun Hoca, diye sorar.

Hoca, moloz yığınını gösterdikten sonra:

– Halk, şu moloz yığınından şikâyet ediyor. Bir çukur kazıyorum ki, bunları gömeyim. Halk da sokaktan rahat geçebilsin! der.

Adam:

– İyi ama, ya bu çukurdan çıkan toprak ne olacak? Onu nasıl kaldıracaksın, diye sorar. Hoca şaşırır. Bir anda verecek cevap bulamaz.

– Canım sen de o kadar ince eleyip sık dokumasan olmaz mı? deyiverir.

# O Konuşursa Bu da Düşünür

Bir gün pazarda bir papağanın 100 altına satıldığını gören Nasreddin Hoca, evinden bir hindi getirip, 200 altın ister. Herkes Hoca'ya şöyle der; —Hindi hiç 200 altın olur mu?

—Az önce bunun yarısı kadar kuş, 100 altına satıldı, bu neden 200 altın etmesin.

—O; marifeti olan, nadir bir kuş. Senin benim gibi konuşur.

—"O da marifet mi; o kuş konuşursa, bu da düşünür" cevabını vererek, düşünmenin ve az konuşmanın önemini dile getirir.

# O Zaman Başka

Hoca'nın kadılık yaptığı sıralarda bir adam gelmiş:

-Hoca efendi demiş,size bir şey danışacağım.

-Buyrun sorun. Demiş Hoca, adam sözünü sürdürmüş:

-Geçen gün , komşuların size ait olduğunu söyledikleri bir inek, tarlada bizim ineğin karnını vurup öldürmüş. Şimdi ne yapmam gerek? Hoca , sakallarını sıvazlayıp bir an düşündükten sonra :

-Hayvan bu, demiş, dava edecek değilsin ya!..

-Teşekkür ederim kadı efendi.

-Sahibinin de bu işte suçu yok;ne bilsin böyle olacağını? Adamın yüzü gülmüş, tekrar söze başlamadan önce:

-Kusura bakma kadı efendi, demin ben bir yanlışlık yaptım, ölen inek benimki değil, seninki imiş. Hoca , yerinden doğrulup:

-Bak demiş, şimdi iş değişti. O halde verin raftaki kara kaplı kitabı da hele bir bakalım! ...
