# Acemi Bülbül

Nasreddin Hoca bir gün komşusunun bahçesine girer.

Bahçedeki armutları görünce dayanamaz.

Bir tane yer,dayanamaz bir daha,bir daha derken armut ağacına çıkıverir.

Başlar yemeye.

Tam bu sırada bahçenin sahibi çıkagelir.

Hoca şaşkınlıkla başlar bülbül gibi ötmeye.

Bahçenin sahibi şaşkın şaşkın Hocanın olduğu ağacın yanına varıp,

— Ne yapıyorsun burada, diye bağırır.

Hoca sakince cevap verir.

— Ben bülbülüm yuvam da burada, der.

Tekrar cırlak sesiyle ötmeye başlar.

Bahçe sahibi öfkeyle

— Bülbül böylemi öter be adam, diye bağırınca,

Hoca

— Ben acemi bülbülüm. Acemi bülbül ancak böyle öter.

# Adam Olmak

Hocaya bir gün:

– Adam olmanın yolu nedir, diye sormuşlar.

Hoca şu cevabı vermiş:

– Bilenler söylerken, bilmeyenler can kulağıyla dinlemeli; bilmeyenler söylerken, susturmanın çaresine bakmalı.

# Aklı

Nasreddin Hoca'ya bir gün:

– Karın aklını kaybetti, demişler. Hoca düşünmeye başlamış.

– Ne düşünüyorsun hocam, diye sormuşlar.

– Bizim karının aklı zaten yoktu ki, kaybetsin. Acaba başka bir şey mi kaybetti diye düşünüyorum!

# Aklı Yoktu ki

Dimişler Nâsırüddin Hâceye âh Düşüben oğlun ussı gitdi nâgâh

Dimiş ussı yoğ idi bu ne tan iş Nesi gitdi ola idün ki teftiş

Çoğ oğlancuklar olur karı zîrek Görüp işütdigin anlar tizirek

Cevabında sözine kâdir olur Ulalub ilm okısa mâhir olur

Bir oğlancuk işüdün bir harife Cevap ile ne hoş geçmiş lâtife

# Akıllı Çocuk

Nasreddin mektepte okurken hocasına her türlü soruyu sorarmış. Hocası bazı soruların cevabını bilmediği için Nasreddin'e kızmış:

– Sen kendi bilgini kendinde sakla! Yoksa bazen gençliğinde akıllı olanlar büyüdükten sonra deli olurlar, demiş.

Nasreddin de:

–Demek ki, siz gençliğinizde çok akıllıydınız.

# Al Elimi

Bir gün Nasreddin Hoca, dostları ile birlikte kıra pikniğe gitmiş.

Bir dere kenarında gezerlerken, içlerinden biri derin olan dereye yuvarlanıvermiş. Yüzme de bilmediğinden sulara dalıp dalıp çıkmaya ve boğulma alametleri göstermeye başlamış. Arkadaşları ellerini uzatarak onu kurtarmak istemişler.

– Ver elini! Ver elini! diye seslenmişler.

Ama deredeki kişi oralı bile olmamış. Neredeyse boğulup gidecekmiş. Birden Nasreddin Hoca devreye girmiş. Hemen kolunu sıvamış. Derenin kenarına varıp elini uzatmış.

– Al elimi! diye seslenmiş. Boğulmak üzere olan adam, bu söz üzerine hemen Hocanın eline sarılmış. Hoca da arkadaşlarının yardımıyla onu rahatça çekerek sudan çıkarmış.

Herkes bu işe şaşıp kalmış. Nihayet içlerinden biri dayanamayıp:

– Hoca, bu adam niçin hiçbirimizin elini tutmadı da, senin elini tuttu, diye sormuş. Nasreddin Hoca gülerek şu cevabı vermiş:

– Siz onu benim kadar tanımadığınız için nasıl sesleneceğinizi bilemediniz. O, cimrinin tekidir. Hayatında hiçbir şey vermeye alışmamıştır. Kendisine: “Ver elini!” diye seslendiğiniz vakit, aldırış etmemesi o yüzdendir. Buna karşılık ne bulursa almaya can atar. Ben onun bu huyunu iyi bildiğim için: “Al elimi!” dedim. Gördüğünüz gibi hemen yapışıverdi.

# Allah Taksimi mi Kul Taksimi mi

Çocuklar, mahallede birbirlerine girmişler. Kavga döğüş, kıyamet. Ele geçirdikleri bir kucak cevizi bir türlü doğru dürüst bölüştüremiyorlarmış. Kavganın kızıştığı bir sırada Hoca da oradan geçiyormuş. Çocuklar koşarak ona başvurmuşlar:

– Hoca Efendi, ne olur, şunları bize güzelce bölüştürüver. Çocuklar bir kenara çekilmişler. Hoca geçmiş cevizlerin başına:

– Çocuklar demiş, Allah taksimi mi istersiniz, yoksa kul taksimi mi?

Çocukların hepsi birden:

– Allah taksimi, Allah taksimi! diye bağırmışlar.

Bunun üzerine Hoca bir avuç ceviz alıp bir çocuğa vermiş. Arkasından iki cevizi bir başkasına, birkaç avucu ötekine, beş altı taneyi berikine. Bazı çocuklara da hiç vermemiş. Çocuklar Hoca'ya itiraza başlamışlar.

– Bu nasıl taksim Hoca Efendi, haksızlık ettin, demişler.

Hoca da:

– Çocuklar, demiş, siz benden Allah taksimi istemediniz mi? Allah taksimi böyledir. O, dilediğine az, dilediğine çok verir, hiç vermediği de olur, herkes kısmetine boyun eğer!

# Allah Versin

Nasreddin Hoca damda çalışırken aşağıdan geçen bir dilenci Hoca'ya seslenmiş:

—Hoca, aşağıya gel, bir şey söyleyeceğim.

Hoca aşağıya inmiş.

—Ne var?

Dilenci:

— Allah rızası için bir sadaka.

Hoca:

— Gel benle.

Hoca dilenciyi almış yukarı çıkarmış, yukarda: — Allah versin! demiş.

# Allah'ın Hikmeti

Hoca merhum, yazın sıcağında eşeğine binmiş bir köye gidiyormuş. Yolda büyük bir ceviz ağacının altında merkebinden inip hayvanı bir ağaca bağlamış. Kendisi de ağacın diğer bir cihetine koyu bir gölgeye çekilmiş. Kavuğunu başından çıkarıp göğsünü bağrını açarak hem serinliyor, hem de terini kurutuyormuş. O esnada tarladaki koca koca helvacı kabaklarına bakmış, bir aralık başını kaldırıp ceviz tanelerini de görmüş. Kendi kendine:

— Ya Rabbi! Şu incecik otta kocaman kuzu gibi kabaklar halk etmişsin. Şu dalları gökyüzüne çıkmış, çadırı bir evlek yeri kaplamış olan, bedenini iki kişi kucaklamadan aciz bulunan ceviz ağacında, ceviz taneleri de kabak otundan bitmesi münasip olurdu.

Derken meğer o esnada bir karga da bir cevizi oyup içini yemeğe uğraşıyormuş. Ceviz kabuğundan fırlayıp süratle inerken nasılsa tam Hoca'nın alnına rast gelir. Hoca'nın gözünden dehşetli bir şimşek sıçrar. Bir kere "Vay!" deyip iki eliyle kafasını tutar. Hemen kavuğunu bulup sıkı fıkı başına geçirir. Kalbini şiddetli bir Allah korkusu kaplayıp:

— Tövbe ya Rabbi! Bir daha senin işine karışmam. Her ne yaratmışsan hepsinde bir hikmet var. Allah saklasın! Şimdi ağaçta ceviz yerine kabak bulunmuş olsaydı, bizim tüysüz yalın kat kafa tuzlan buz olurdu. Demiştir.

# Anahtar

Hoca bir gün anahtarını kaybetmiş. Bahçede döne döne anahtarını arıyormuş. Hanımı sormuş:

– Hocam, anahtarı nerede düşürdün?

– Be kadın, demiş Hoca, Nerede düşürdüğümü bilsem, hiç arar mıyım?

# Arapça Öğretiyor

Hoca bir gün bir komşusunun Arapça öğrenmek istediğini duyar. Hoca derse başlar ve komşusu da şöyle bir soru sorar:

– Hocam, Arapçada soğuk çorba ne demek?

O anda cevabı aklına gelmeyince:

– Haa, evet! Onu öğrenmen gerekmez. Sen hiçbir zaman soğuk çorba içmezsin. Bunun dışında da Araplar çorbalarını soğuk içmezler! diye cevap verir.

# Atınca Uzarmış

Nasreddin Hoca, bir gün çarşıda gezerken, adi görünüşlü bir kılıcın yüz akçeye satılmakta olduğunu görmüş. Şaşkınlık içinde:

– Yahu! Bu, alelade bir kılıç, demiş. Bunun yenisini on akçeye almak mümkün iken, neden yüz akçe istiyorsunuz?

Kılıcı dolaştıran kişi:

– Bu adi bir kılıç gibi görünüyor, ama öyle değildir. İleri doğru savruldu mu, kendiliğinden iki arşın uzar, demiş.

Hoca merhum, bunu öğrenince, hemen evine koşmuş. Maşayı kaptığı gibi çarşıya gelmiş. Başlamış iki yüz akçeye satmak için dolaştırmaya.

Görenler, kendisine takılmışlar:

– Sen delirdin mi Hoca? Bir akçe etmez maşaya kim iki yüz akçe verir ki, demişler. Hoca hemen karşılık vermiş:

– Az önce burada atıldığı zaman iki arşın uzayan bir kılıç için yüz akçe istenmiyor muydu? Bizim karı bana kızıp da attı mı, bu maşa da on arşından fazla uzar.

# Ağaçtan Öte Bir Yol

Mahallenin çocukları Nasreddin Hoca'ya muzip bir şaka yapmak istemişler. Plânlarını kurmuşlar. "Hocayı ağaca çıkaralım. Ayakkabılarını alıp uzaklaşarak biraz şaka yapalım, hem güler eğleniriz" diye düşünmüşler. Hocanın yoldan geçeceği saatlerde, uçurtmalarını büyükçe bir ağaca taktırmışlar. Hocayı beklemeye başlamışlar. Hoca oradan geçerken de hemen etrafını sarmışlar: - "Hocam uçurtmamız ağaca takıldı. Biz çıkıp kurtaramadık. Bize yardımcı olur musunuz?" demişler. - "Hay hay" demiş Hoca. Ayakkabılarını çıkarıp sırt çantasına yerleştirmeye başlamış. Çocuklar : - "Hoca efendi onları niye yanına alıyorsun? Ağaçta pabuçları ne yapacaksın?" demişler. - "Belli olmaz ki evlâtlarım" demiş Hoca; "Bu iyiliğime karşı Rabbim, belki bana ağaçtan öte bir yol ikram eder."

# Baba Sözü Dinleyeceği Tutmuş

Nasreddin Hoca'nın bir oğlu varmış. Ne denirse tam tersini yaparmış. Bir gün Nasreddin Hoca ile oğlu Akşehir'e gidip oradan iki çuval tuz almışlar. Eşeğe yükleyip köylerine dönmek için yola koyulmuşlar. Köylerinin yakınındaki dereye geldiklerinde, Nasreddin Hoca, derenin en sığ yerinden karşı tarafa geçmiş. Oğlu da eşeği sudan geçirmeye çalışıyormuş. Ama eşeğin sırtındaki çuvallardan biri, neredeyse suya değmek üzereymiş.  Hoca, oğlunun ters huyunu bildiği için seslenmiş:

– Sevgili oğlum. Çuvallardan biri suya değecek. Biraz daha asıl da, iyice suya gömülsün.

Ne var ki çocuğun o gün uysallığı üzerindeymiş. Tutup, babasının dediğini yapmış. Neticede iki çuval birden suyun içine düşmüş. Nasreddin Hoca:

– Ne yapıyorsun şaşkın oğlum! diye bağırmış, ama bu arada tuzlar da suda eriyip gitmiş.

Nasreddin Hoca'nın oğlu, babasının kızgınlığı karşısında şöyle söyleniyormuş:

– Kırk yılda bir baba sözü dinleyelim dedik, gene de yaranamadık.

# Balık Başı

Hoca yolculuk sırasında mola verip bir hana girer, bu sırada hana bir başka yolcu daha girer ve ikisi birden hancıdan yiyecek bir şeyler isterler. Fakat hancı yiyecek olarak sadece bir balık olduğunu söyler ve bunu paylaşmalarını önerir. Bunun üzerine Hoca:

– Ben balığın sadece başını yiyeceğim, der. Hancı bunun nedenini sorar.

Hoca da:

– Balık başı zekâyı arttırır, balık başı yiyen insan akıllı olur, der. Bunun üzerine diğer yolcu hemen atılır ve Hocaya:

– Balık başını niye sen yiyeceksin, ben yemek istiyorum, der. Hoca da itiraz etmez ve balığın koca gövdesini Hoca yer ve bir güzel karnını doyurur, diğer yolcu ise sadece balığın başını yer ve sonra Hocaya seslenir:

– Sen koca gövdeyi yedin karnını doyurdun ben sadece kafayı yedim aç kaldım, der. Hoca da bunun üzerine:

– Bak nasıl da hemen akıllandın, der.

# Belki de Biliyordur

Nasreddin Hoca, boş vakitlerinde oğlu ile konuşmaktan çok zevk alırdı. Ona sorular sorar, aldığı cevaplardan pek memnun kalırdı. Oğlunun gözlerinde, sanki kendi zekâsının pırıltılarını görürdü.

Bir gün yine evde baba oğul konuşurlarken, oğlan:

– Baba, ben senin doğduğunu bilirim! diye bir söz söyledi.

Karısı bu sözü düyunca, hemen oğlunu azarlamaya başladı. Bu sözün çok saçma olduğunu, hiçbir çocuğun babasının doğduğunu bilemeyeceğini söyledi.

Hoca ise, oğlunu bozmamak için hemen söze atıldı:

– Bu sözlerinle çocuğu ne diye incitip duruyorsun? Görüyorsun ki çocuk akıllıca. Belki de biliyordur, deyiverdi.

# Ben Sağ İken

Civar köylüleri Hoca'yı yığılıvermiş görünce başına üşüşerek,

— Biçare adam ölmüştür, diyerek hemen köyden bir tabut getirip Hoca'yı koyarlar.

Şehre götürürken yolda çamurlu sarp bir bataklığa tesadüf ederler. Yol çatallanıp birkaç geçit görünse de hangisinin daha iyi olduğunu kestiremeyerek:

— Acaba şuradan mı gitsek yoksa buradan mı? diye müşavereye koyulmalarıyla Hoca tabuttan başını kaldırarak:

— Ben sağ iken şuradan geçerdim, demiştir.

# Ben Uyuyorum

Bir gün Nasreddin Hoca şehre gelip, bir arkadaşıyla birlikte handa kalmış.

Gece yarısı arkadaşı sormuş:

- Hocam, uyudunuz mu?

- Buyurun bir şey mi var?

- Biraz borç para isteyecektim.

Nasreddin Hoca derhal horlamaya başlayıp, ben uyuyorum, demiş.

# Ben Yapacağımı Bilirim

Nasreddin Hoca, bıkıp usanmış artık Timur’un yaptıklarından. Bir gün, her şeyi göze alarak huzuruna çıkmış. Timur’a:

– Bana bak, demiş. Akşehir’den gidecek misin, yoksa gitmeyecek misin?

Timur, Nasreddin Hoca’nın bu sorusuna önce şaşırmış. Sonra sinirli bir biçimde:

– Gitmeyeceğim. Ne olacak, diye sormuş. Nasreddin Hoca:

– Eğer sen Akşehir’den gitmezsen, ben yapacağımı bilirim, demiş.

Timur’un bu tehditkâr söz karşısında sinirleri iyice bozulmuş.

– Ne yaparsın ki be adam, diye bağırmış.

Nasreddin Hoca ne yapacağını şu sözlerle açıklamış:

– Eğer sen buradan gitmezsen, kasabalıyı alıp ben buradan gideceğim.

# Ben de Senin Gibi Düşünüyorum

Nasreddin Hoca günlerden bir gün bahçeye giderek orada ne bulduysa karpuz, kavun, havuç, şalgam koparıp çuvala doldurmuş. Tam iş başındayken bahçıvan ona doğru gelmiş:

– Burada ne arıyorsun, demiş.

Hoca şöyle cevap vermiş:

– Geceki korkunç fırtına beni buraya attı.

– Öyle mi? Ya bunları kim kopardı?

– Nasıl fırtına beni oradan buraya kadar fırlattıysa kendisine tutunduğum şeyler de elimde kaldı. Bahçıvan:

– Peki bunları çuvalına kim doldurdu?

Hoca hayret ederek şöyle der:

– Ben de sizin düşündüğünüz şeyi düşünüyorum

# Beni Baş Aşağı Gömün

Nasreddin Hoca bir gün dostları ile bir mecliste konuşurken:

– Vasiyetim olsun, dedi. Öldüğüm zaman beni baş aşağı gömün!

Onun bu isteği, herkes tarafından garip karşılandı, içlerinden biri:

– Bunu neden istiyorsun Hoca, diye sordu.

Nasreddin Hoca'nın cevabı hazırdı:

– Yarın kıyamet koptuğu zaman, dünya altüst olacak, değil mi? Ben işte o zaman dosdoğru kalkarım.

# Bildiği

Nasreddin Hoca bir gün eşeğini bulamaz ve basar yaygarayı:

–Eğer eşeği hemen bulmazsam ben bilirim yapacağımı! diye. Bir kaç saatte eşek bulunur ve Hocaya birisi sorar:

– Hocam bulunmasaydık ne yapacaktın? Hoca biraz tebessümle:

– Ne olacak gidip yenisini alacaktım.

# Bilenler Bilmeyenlere Anlatsın

Hoca Nasreddin Efendi Akşehir'de bir gün vaaz için kürsüye çıkıp:

— Ey mü'minler! Ben size ne söyleyeceğim bilir misiniz? Demiş.

Cemaatin "Bilmeyiz" demeleriyle Hoca:

— Siz bilmeyince ben size ne söyleyeyim, deyip kürsüden iner, bırakır gider.

Yine bir gün kürsüye çıkıp evvelki sualini tekrar edince bu sefer de cemaat "Biliriz" derler. Hoca:

— Madem ki biliyorsunuz, o surette benim söylemekliğime ne lüzum kalır? Der, yine çekilir gider.

Cemaat hayrette kalarak:

— Efendi bir daha kürsüye çıkarsa kimimiz bilir, diğer kimimiz bilmeyiz diyelim, diye karar verirler.

Hoca yine bir gün kürsüye çıkıp ahaliye evvelki sualini tekrar ederek "Kimimiz biliriz, kimimiz bilmeyiz" cevabını alınca, ciddiyetine hiç halel getirmeyerek:

— Ne kadar âlâ, öyle ise bileniniz bilmeyeninize anlatsın, demiş

# Bindiği Dalı Kesmek

Hoca, bir ağaca çıkıp dalı kesmeye başlar. Aşağıdan biri bu hali görüp:

— Hoca ne yapıyorsun? Şimdi düşeceksin, der.

Hoca buna hiç ehemmiyet vermezse de akabinde dal çatır çutur kırılır, Hoca da paldır küldür düşer. Hoca yarasına beresine bakmayarak hemen fırlayıp o adamı bulur:

— Ay oğul anlaşıldı, sen erbab-ı mükaşefeden bir adamsın. Madem ki benim düşeceğimi bildin, öleceğimi de bilirsin. İlla benim öleceğim zamanı haber ver, diye yakasına sarılır, bırakmaz.

Herif yakasını kurtarıp yoluna devam etmek için:

— Eşeğine odunu yükletip yukarı giderken eşek bir zırlayınca canının yarısı gider, ikincisinde hepsi çıkar.

Yolunda amiyane bir cevap verir, yoluna gider. Hoca'ya zaten havanın sıcaklığından ve fevkalâde yorgunluktan bir halsizlik gelmiş olmakla o esnada eşeğin birinci zırlamasında kendisinde ölüm alametleri hissedip ikincisinde büsbütün sinirleri boşanarak:

— Eyvah! Ben öldüm, der, kendisini bırakıverir.

# Bir Pul Eksik Veriniz

Hoca bir gün ırmak kenarında yürürken on kör gelir. Kendilerini adam başı bir pula ırmaktan karşıya geçirmesi için Hoca ile pazarlık ederler. Hoca bunları geçirirken, birini ırmak suyu alır götürür. Körler feryada başlar. Bunu gören Hoca, "Niçin feryat edersiniz, bir pul eksik veriniz" demiş.

# Biraz da Katran İlave Et

Bir köylünün keçisi uyuz olur. Kendisine katran sürmesini tavsiye ederler, ama köylü, keçiyi alıp Hoca'ya getirir.

– Hoca, senin nefesin uyuz illetine birebirmiş. Şu keçiye bir nefes et, der. Hoca, ona şu tavsiyeyi yapar:

– Nefes ederim amma, hastalığın bir an evvel hayvandan kaybolmasını istersen, benim nefesime sen de biraz katran ilave et!

# Biri Benden Yanadır

Nasreddin Hoca’nın ehli bir gece daralıp döşeğinde yatarken ensesini Hoca’ya döner. Hoca ehline dönerek:

–Ne tarafa dönsen deliğin biri benden yanadır, der.

# Biz Yaşıtız

Sen mi, yoksa senin kardeşin mi büyük, diye Hoca'ya sormuşlar.

–Annem geçen sene, “Kardeşin senden bir yaş büyük,” demişti. Bir sene geçti, artık ikimiz yaşıtız, diye yanıt vermiş Hoca.

# Bizim Çocuklar

Nasreddin Hoca'nın karısı ölür. Ölen karısından beş çocuğu olan Hoca, beş çocuğu olan bir dul kadınla evlenir. Hoca'nın yeni eşinden de iki çocuğu olur. Bir gün karısı feryadı basar:

– Hoca Hoca yetiş! Senin çocuklarla benim çocuklar bir olmuş, bizim çocukları dövüyorlar.

# Bozukluk Çömlekte

Nasreddin Hoca merhumun Konya'da bir işi çıkmış. Oradaki kadıdan bir ilâm alması gerekiyormuş. Gitmiş, derdini dökmüş. Kadı oralı bile olmadan bu işin çıkmayacağını, kendisine istediği ilâmı veremeyeceğini söylemiş. Ne kadar ısrar etmişse de kararından dönmemiş. Hoca mahkemeden küskün küskün çıkınca, bir ahbabına rastlamış. Adamcağız Hoca'nın bu halini görünce: — Hayrola Hoca, nedir bu halin? diye sormuş. Hoca da zaten dert dökecek birini arıyormuş. Hemen başından geçenleri anlatarak sözlerini şöyle tamamlamış: — Bunca masraf ederek, kalktık Konya'ya kadar geldik. Kadı ise haklı olduğum halde ilâmı vermedi. Nasıl dertlenmem? Ahbabı hangi kadıya başvurmuş olduğunu öğrenince: — Sen de tam adamına düşmüşsün, demiş. O kadı, Konya'da rüşvet almakla meşhurdur. Rüşvet almadan kimseye ilâm filân vermez. Balı da çok sever. Sen çarşıdan bir çömlek bal alarak ona götür. Hemen ilâmı alırsın! Nasreddin Hoca bunu öğrenince, rüşvetçi kadıya bir oyun oynamaya karar vermiş. Önce bir çömlek satın alarak bunu sarı balçıkla doldurmuş. Üzerine de bir parmak kalınlığında süzme bal koymuş. Yeniden aynı kadıya başvurmuş. Kadı içi bal dolu büyük çömleği görünce, hemen Nasreddin Hoca'ya istediği ilâmı mühürleyip vermiş. Nasreddin Hoca dışarı çıkar çıkmaz da hemen çömleğe kaşığını daldırmış. Daldırmasıyla beraber de altının sarı balçık dolu olduğunu görmüş ve nasıl bir oyuna geldiğini anlayınca, adamını Hoca'nın arkasından göndermiş: — Demin buraya gelen Hoca'yı önle! Ona verdiğim ilâmda bir bozukluk var. Buraya gelsin de düzgününü vereyim, demiş. Tabiî maksadı ilâmı alıp yırtmak, yenisini de vermemek. Adam koşmuş ve oradan henüz fazla uzaklaşmamış bulunan Nasreddin Hoca'ya yetişerek: — Hey Hoca Efendi, demiş. Kadı Efendi Hazretlerinin sana vermiş olduğu ilâmda bir bozukluk varmış. Şunu bana ver. Benimle beraber gel de sana düzgününü versin, demiş. Tabiî Hoca meseleyi anlamış: — Bozukluk ilâmda değil, bal çömleğindedir, diyerek yoluna devam etmiş.

# Boş Mektup

Hoca komşusunun düğün evinde yemek yenilmekte olduğunu tahmin ettiği bir zamanda bir kağıdı dürüp büküp bir tarafına koyarak kapıyı çaldı.

— Ne istersin? Dediklerinde:

— Hane sahibine mektup getirdim, demekle uşak Hoca'yı içeri aldı.

Hoca hemen selam verip çöktü. Yemeği atıştırmağa başladı. Hane sahibi:

— Bunun üzeri yazılı değildir, deyince Hoca:

— Efendim! Kusra bakmayınız. Aceleye geldiğinden onun içi de yazılı değildir, demiştir

# Boş Mideyle Uyku

Hoca bir gün misafirliğe gitmiş. Ev sahipleri de yemek yemişler. Hoca’yı da yemek yedi sanmışlar ve yemek getirmemişler. O da sıkılmış, bir şey söyleyememiş. Konuşulmuş, görüşülmüş, şerbetler içilmiş, Hoca’yı öbür odaya götürüp yatağını göstermişler.

– Allah rahatlık versin, deyip gitmişler. Hoca, aç karnına bir türlü uyuyamamış. Sağa dönmüş, sola dönmüş, ama yine de uyuyamamış. Kalkıp ev sahiplerinin odasına gitmiş, kapıyı çalmış.

– Hayrola, Hocam ne var, demişler. Hoca demiş ki:

– Efendim, yumuşak bir yatak yapmışsınız, rahatım kaçtı, uyuyamadım. Bilirsiniz, biz fukaralıktan yetişmiş adamlarız. Siz bana bir kül pidesi verin de yarısını yatak, yarısını yorgan yapayım, mışıl mışıl uyuyayım.

# Bu Gidişle Hiç

Hoca merhum rüzgarlı havada deve üstünde kavut yermiş. Fakat ağzına attıkça yel alır götürür, hiç boğazına gitmek kısmet olmazmış. Arkadaşlarından biri:

— Hoca Efendi nedir o yediğin? deyince Hoca merhum:

— Bu gidişle hiç, demiştir.

# Bu Mümkün Değil

Hoca, bir ara, zeytin satmaya heveslenmiş. Bir küfe zeytin alarak pazarda satmaya başlamış. Kadının biri zeytin küfesine yaklaşıp fiyatını sormuş ve zeytini pahalı bulmuş. Hoca:

– Hele bir tane ye de tadına bak, demiş. Kadın:

– Baksam ve beğensem bile peşin para ile alacak değilim. deyince, Hoca:

– Canım sen yabancı mısın? Rahmetli kocanla dostluğumuz vardı. Ne olacak, sonra verirsin parasını! Lakin şu zeytinden bir tane tat da gör, demiş. Kadın ise nazlanmakta devam etmiş:

– İmkânsız, bugün oruçluyum. Üç yıl önce Ramazanda hastalanmıştım da bir hafta oruç tutamamıştım. Bugünlerde o borcumu ödüyorum. Bu söz üzerine Hoca, başını sallamış:

– Haydi, güle güle git! Ben vazgeçtim bu alışverişten. Zira Allah'a olan borcunu üç yıl sonra ödeyen bir kimse, kulun zeytin borcunu kim bilir ne zaman verir!

# Bu Nasıl Ülke?

Nasreddin Hoca, bir kış günü köye gitmek için yola çıkar. Her taraf buz tutmuştur. Birden çevresini köpekler sarar. Taş almak için eğilir. Ama hangi taşa el atsıysa bir türlü yerinden kıpırdatamaz. Köpeklere bakarak elini açar:

– Ey Allah'ım bu nasıl ülke? Taşları bağlayıp köpekleri salmışlar.

# Bu Zavallı Deve mi ki?

Hoca akşam üzeri hanesine giderken mahallesinin çocuklarından biri gelip:

— Hoca Efendi şu çocuk benim kulağımı ısırdı, diye şikayet eylediği sırada o çocuk da:

— Hayır! Ben ısırmadım, kendi ısırdı, deyince Hoca:

—Sus haşarı! Bu zavallı deve mi ki kendi kulağını ısırabilsin, demiştir.

# Buldunuz Ya Sahibi Ölmüş Eşeği

Hoca bir kış günü ormanda odun keserken eli ayağı üşüyünce:

– Ben öldüm, deyip bir kenara uzanmış. Biraz sonra kurtlar gelip ileride ağaca bağlı eşeğini yemeye başlamışlar. Bu hale bakmış ve:

– Yiyin bakalım, yiyin! Buldunuz ya sahibi ölmüş eşeği, demiş.

# Bulmak Zevki

Hoca yine bir gün merkebini kaybetmiş, çarşıda bağıra bağıra:

– Benim merkebimi kim bulursa, yularıyla, semeriyle müjde olarak ona vereceğim, diyerek herkese bildirmiş.

Birisi:

– Hoca, merkebi semeriyle, yularıyla bulana tekrar verdikten sonra, ha kaybetmişsin, ha kaybetmemişsin bir şey fark eder mi? Bundan sen ne kazanmış olacaksın, diye sormuş!

Hoca gülerek:

– İyi; ama bulmak zevkini o kadar önemsiz mi zannediyorsun!

# Buzlu Hoşaf

Yazın sıcak günlerinden biriymiş. Nasreddin Hoca'yı bir ziyafete davet etmişler. Sofraya gelen lezzetli yemekler yenilmiş. Sıra buzlu hoşafa gelmiş. Ev sahibi, önüne konan kepçe gibi büyük bir kaşıkla hoşafı içmeye başlamış. Hoşaftan her alışta:

– Oh! Aman, yandım, öldüm, diyormuş. Hoca ise elindeki küçük kaşıkla hoşaftan bir tad alamıyormuş. Sağa bakmış; sola bakmış; olmamış. Nihayet dayanamayarak ev sahibine:

– Aman efendi, demiş. Elinizdeki kepçeyi bana lütfediniz de bir kere de ben yanıp öleyim!

# Böyle Olmalı

Hoca kıyı boyunca uzun bir yolculuk yapmaktadır. Fakat gel gör ki, bu sıcak havada suyu da bitince susuzluktan dudakları bile kurumuş. Ne kadar kendini sıksa da susuzluğa dayanamaz ve biraz olsun susuzluğumu dindirir diye deniz suyundan içmeye karar verir. Ama nerede! Susuzluğunu dindirmesi bir yana Hoca tuzlu suyu içince içi bir kat daha yanar. Yola bir miktar devam edince bir tatlı su birikintisine rast gelir ve kana kana içer. Sonra da kavuğunu çıkararak içine su doldurur ve kendinden emin adımlarla denizin kıyısına gelir ve kavuğundakini denize doğru savurarak:

– Bırak kabarmayı, dalgalanıp köpürmeyi su dediğin böyle olur, der.

# Cennet Fıkrası

Bir gün Padişah, Nasreddin hocaya sormuş;  
— Ben öldüğümde cennete mi gideceğim, cehenneme mi?  
Hoca, Padişahdan korkmadan;  
— Tabii ki cehenneme gideceksiniz.  
Öfkeden padişahın sakalı kabarır.  
Nasreddin hoca;  
— Cennete gideceğinizi söylemek isterdim ama cellatlarınızın öldürdüğü insanlar yüzünden cennete sığamazsınız. O yüzden mecbur cehenneme gideceksiniz.

# Ceza

Nasreddin Hoca kadı iken yanına bir kız gelmiş ve delikanlının birinin onu zorla öptüğünü söyleyerek şikâyet etmiş.

Hoca ona:

–Bence bunu, aynı şekilde cezalandırmak gerekir. Sen de zorla onu öp! diye ceza vermiş.

# Cübbenin İçinde Ben de Vardım

Bir gün Hoca’nın evinde bir gürültü kopmuş. Hoca hiddet içinde evden çıkınca, onu gören komşusu:

– Hayrola Hoca Efendi, demiş. Sizin evde bu sabah epeyce gürültü vardı.

Nasreddin Hoca içini çekerek cevap vermiş:

– Evlilik hali. Hanımla biraz atıştık da.

– Kavganızı duyduk. Ama arkasından çıkan gürültü neydi?

– Bizim hanım bana kızdı. Cübbeme bir tekme attı. Cübbem de paldır küldür merdivenlerden aşağıya yuvarlandı. Duyduğunuz, herhalde onun gürültüsüdür.

– Aman Hoca Efendi. Hiç cübbe merdivenden düşerken bu kadar gürültü çıkarır mı?

Nasreddin Hoca anlayışsızlığın bu kadarına artık dayanamamış:

– Sen de amma uzun ettin be komşu, demiş. Yuvarlanırken cübbenin içinde ben de vardım işte.

# Davetiye

Nasreddin Hoca'nın komşusu evlenirken Hoca'dan davetiye dağıtmasını istemiş. Hoca şehirde kendini beğenmiş olarak ün kazanan bir zenginin davetiyesini vermeye gitmiş. Hoca'yı gören zengin sinirinden :

– Davetiyeleri dağıtmaya iyi bir insan bulamamışlar mı, demiş.

Nasreddin Hoca:

– İyi insanlar da vardı, ama onlar iyi insanların davetiyelerini vermeye gitti, diye cevap vermiş.

# Dolmuş

Temel, dolmuşuyla giderken yol kenarında birisi elini kaldırıp dolmuşu çağırır. Yolcu açık kapıya yaklaşır ve "Yer var mı?" diye sorar. Temel dolmuşun içine hızlıca göz atar ve en arkada tek kişilik yer olduğunu görür "Arkada var" diye cevaplar. Kapıda bekleyen adam arka sıradaki boş yere bakar "Ben arkada gitmem" diye somurtur. Temel ellerini havaya kaldırarak sorar "Niye arkası Akçaabat'a gitmiyor mu?"

# Dört Ayaklı Kadı

Birgün şehrin kadısı Nasreddin hoca ile alay edebilmek için:

–Efendi duyduğuma göre siz her şeyi çift görüyormuşsunuz. Doğru mu?

Nasreddin Hoca cevap vermiş:

–Doğru efendim, şimdi de sizi dört ayaklı görüyorum.

# Dörtten Dördü Çıkarırken

Hoca mektepte okurken öğretmeni Hoca'ya:

–Dörtten dördü çıkarırsan ne olur, diye sormuş.

Hoca biraz düşünmüş.

Öğretmen:

–Bak, bunu şöyle çözelim: Senin cebinde dört metelik var diyelim. Onlar cebinden düşmüş. Sonra cebinde ne kalır?

–Delik! diyerek Hoca cevap vermiş.

# Döve Döve Helva Yedirirler

Bir gün Hoca Konya'ya varıp bir helvacı dükkanına girer. Hemen bismillah deyip helva yemeğe başlar. Helvacı, "Bre adam ne yaparsın?" diye Hocayı dövmeye başlayınca Hoca, "Ne güzel belde imiş, bu Konyalı helvayı döve döve yedirir" demiş.

# Dükkan

Temel'in babası ölüm döşeğindedir ve göz ucuyla odayı süzer. "Nazife burada mıdır?" diye sorar. Eşi yaklaşır "buradayım". der. "Temel burada mıdır?" diye tekrar sorar. "Buradayım babacuğum" yanıtını verir Temel. "Kızım burda mıdır?" sorusuna da olumlu yanıt alır. Odada bir sessizlik olur ve yaşlı adam yatağında biraz doğrulur. "Küçük oğlum da burda mıdır?" diye sorunca oğlu yatağa yaklaşır. Ölmek üzere olan yaşlı adam öksürdükten sonra yüksek bir sesle konuşur "Allah cezanızı versin. Hepiniz buradasınız, peki dükkana kim bakıyor?"

# Düşmesem de Zaten İnecektim

Nasreddin Hoca bir gün eşeğini koştururken düşer. Onu düşerken gören çocuklar:

– A... Nasreddin Hoca eşekten düştü. Nasreddin Hoca eşekten düştü, diye alaya alırlar.

Nasreddin Hoca, hiçbir şey olmamış gibi:

– Önemi yok, çocuklar, der. Düşmesem de zaten inecektim.

# Elin Ağzı Torba değil ki Büzesin

Nasreddin Hoca oğlunu okulundan alırken eşekle gelmiş. Oğluyla eşeğin üzerinde evin yolunu tutmuşlar. Aradan zaman geçmiş. Bir grup insan önlerine çıkmış. İçlerinden biri;

-"Hoca ayıp değil mi, eşek o kadar yükü nasıl taşısın?"

Hoca da oğlunu eşekten indirip yoluna devam etmiş. Aradan zaman geçmiş bir insan;

- "Ayıp hoca ayıp. Küçücük çocuk yürütülür mü?"

Hoca çocuğu eşeğe oturtmuş. Kendi yoluna devam etmiş. Aradan yine zaman geçmiş birisi;

- "Bu zamane çocukları böyle işte, ihtiyar babaları yürür kendileri eşeğe biner."

Bu söz çocuğun ağrına gider ve eşekten iner, ikisi de yayan giderler. Oradan gevezenin birisi:

- "Enayilere bakın eşek önde gidiyor bunlar yayan."

Bunun üzerine Nasreddin Hoca:

- "Görüyorsun ya oğlum, elin ağzı torba değil ki büzesin."

# En Tehlikeli Yaratık

Bir gün dostları Hoca'ya:

– Dünyada en tehlikeli ve korkunç hayvan hangisidir, diye sormuşlar.

Hoca tereddütsüz:

– İnsandır, demiş.

Dostları bu cevaba hayret etmişler ve itiraz ederek:

– Bu, nasıl olur, demişler.

Hoca şu açıklamayı yapmış:

– Köpek ekmeğini yediği adama hıyanet etmez. Yılan kendisine dokunmayanı sokmaz. Kurt, insanın bulunduğu yerlerden uzakta yaşar. Halbuki insan, hiç de böyle değildir. O kendisine iyilik edene bile fenalık yapar. Siz, hiç dünyada, kendi cinsine insanlar kadar kötülük eden bir varlık gördünüz ve duydunuz mu?

# Eski Aylar

Bir gün Hoca kıra gezmeğe çıkmış. Bir çobanla karşılaşmış. Çoban Hoca’ya şu soruyu sormuş:

– Ay, küçücük doğar, büyür, tekerlek olur, on beşinden sonra gene küçülüp hilal şeklini alır; acaba eskiyi ne yaparlar?

Hoca gülmüş:

– İlahi çoban, bu kadarcık şeyi bilemedin mi, demiş. Eski ayı uzatırlar, şimşek yaparlar. Görmez misin, gök gürleyince kılıç gibi nasıl uzayıp parlar

# Etraflıca İlgi

Nasreddin Hoca, kendi köyünde hâkim olarak çalışırken, adamın biri gayet heyecanlı bir şekilde ona doğru koşmuş ve hakkını istemiş:

– Saldırıya uğradım ve soyuldum! diye bağırıyormuş. Hemen bu köyün önünde.

Buradan biri olmalı. Suçluyu bulmanızı istiyorum. Benim pelerinimi, kılıcımı ve hatta çizmemi de çaldı!

– Gördüğüm kadarıyla atletini çalmamış?

– Hayır, onu çalmadı.

Hoca:

–O halde o bizim köyden değil. Burada her şeyle etraflıca ilgilenilir. Sen suçluyu aramızda haksız yere arıyorsun.

# Ev Yanmış Ama Tahtakurusundan da Kurtulmuş

Bir gün, Hoca'nın evi yanıyormuş. Karısı ve komşuları telaş içinde evden taşıyabildikleri eşyayı kurtarmaya çalışırlarken Hoca yanan evin karşısına geçip keyifli keyifli gülüyormuş. Onun bu tasasız halini şaşkınlık içinde seyredenler, dayanamayıp sormuşlar:

– Yahu Hocam, sen deli misin? Evin yanarken neden böyle gülüp seyrine bakıyorsun? Hoca'nın cevabı hazırmış:

– A dostlar, ben sevinmeyeyim de kimler sevinsin. Allah'a binlerce şükür ki, artık tahtakurusundan kurtuluyorum.

# Evin Çatısında Tartışma

Bir yaz gecesi Nasreddin ile hanımı çatıda yatarlarken tartışmaya başlamışlar. Tartışmanın sonu dövüşmeye varmış ve Nasreddin birden aşağıya düşüp kendini kaybetmiş. Bunu gören komşuları gelip Nasreddin'i zorlukla kendine getirmişler ve ona nasıl düştüğünü sormuşlar.

Nasreddin:

–Benim nasıl düştüğümü öğrenmek isteyen damın üstünde hanımı ile tartışsın, diyerek cevap vermiş
